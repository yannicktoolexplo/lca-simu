"""Programmatic simulation engine API.

This module is the stable boundary for callers that want to run the simulation
without knowing about the historical CLI script. The first implementation still
delegates to the existing engine entrypoint, but all inputs and outputs are
structured so the internals can later move to an in-memory engine.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields
from datetime import datetime, timezone
import json
import math
from pathlib import Path
from typing import Any, Literal
from uuid import uuid4

from etudecas.simulation.analysis_batch_common import (
    apply_scales,
    load_json,
    numeric_kpis,
    run_simulation,
    safe_name,
    write_json,
)


SimulationOutputProfile = Literal["minimal", "diagnostic", "lot_trace", "full_debug"]


@dataclass(frozen=True)
class SimulationOverrides:
    """Structured parameter changes applied before a simulation run."""

    factors: dict[str, float] = field(default_factory=dict)
    demand_item_scale: dict[str, float] = field(default_factory=dict)
    capacity_node_scale: dict[str, float] = field(default_factory=dict)
    supplier_node_scale: dict[str, float] = field(default_factory=dict)
    supplier_capacity_node_scale: dict[str, float] = field(default_factory=dict)
    edge_src_lead_time_scale: dict[str, float] = field(default_factory=dict)
    edge_src_reliability_scale: dict[str, float] = field(default_factory=dict)
    scenario_flags: dict[str, bool] = field(default_factory=dict)
    engine_args: tuple[str, ...] = ()


@dataclass(frozen=True)
class SimulationRequest:
    """Complete request for one simulation run.

    Provide either `input_graph` or `input_path`. `output_dir` is optional; when
    omitted, a deterministic API run folder is created under
    `etudecas/simulation/result/_api_runs`.
    """

    input_graph: dict[str, Any] | None = None
    input_path: Path | str | None = None
    scenario_id: str = "scn:BASE"
    days: int = 0
    output_profile: SimulationOutputProfile = "diagnostic"
    overrides: SimulationOverrides = field(default_factory=SimulationOverrides)
    output_dir: Path | str | None = None
    run_id: str | None = None
    run_script: Path | str = Path("etudecas/simulation/engine/run_first_simulation.py")
    skip_map: bool = True
    skip_plots: bool = True
    run_lot_audit: bool = False
    control_schedule_csv: Path | str | None = None
    seed: int | None = None
    common_random_numbers: bool | None = None
    # Keep new fields after the historical positional API.  In particular,
    # callers written before feedback control was introduced expect the two
    # arguments following control_schedule_csv to be seed and CRN.
    control_policy_json: Path | str | None = None
    demand_perturbation_csv: Path | str | None = None


@dataclass(frozen=True)
class SimulationResult:
    """Structured result returned by the simulation API."""

    run_id: str
    scenario_id: str
    output_dir: Path
    input_path: Path
    summary: dict[str, Any]
    kpis: dict[str, float]
    stdout: str
    output_profile: SimulationOutputProfile
    run_manifest: dict[str, Any] = field(default_factory=dict)
    generic_manifest: dict[str, Any] = field(default_factory=dict)
    artifacts: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "scenario_id": self.scenario_id,
            "output_dir": str(self.output_dir),
            "input_path": str(self.input_path),
            "summary": self.summary,
            "kpis": self.kpis,
            "output_profile": self.output_profile,
            "run_manifest": self.run_manifest,
            "generic_manifest": self.generic_manifest,
            "artifacts": self.artifacts,
        }


def load_request_graph(request: SimulationRequest) -> dict[str, Any]:
    if request.input_graph is not None:
        return json.loads(json.dumps(request.input_graph))
    if request.input_path is None:
        raise ValueError("SimulationRequest requires either input_graph or input_path.")
    return load_json(Path(request.input_path))


def apply_scenario_flags(data: dict[str, Any], scenario_id: str, flags: dict[str, bool]) -> None:
    if not flags:
        return
    scenarios = data.get("scenarios") or []
    scenario = next((scn for scn in scenarios if str(scn.get("id")) == scenario_id), None)
    if scenario is None:
        raise ValueError(f"Unknown scenario: {scenario_id!r}")
    economic_policy = scenario.get("economic_policy")
    if not isinstance(economic_policy, dict):
        economic_policy = {}
    for key, value in flags.items():
        economic_policy[str(key)] = bool(value)
    scenario["economic_policy"] = economic_policy


def apply_overrides(data: dict[str, Any], scenario_id: str, overrides: SimulationOverrides) -> dict[str, Any]:
    mutated = apply_scales(
        base_data=data,
        scenario_id=scenario_id,
        factors=overrides.factors,
        demand_item_scale=overrides.demand_item_scale,
        capacity_node_scale=overrides.capacity_node_scale,
        supplier_node_scale=overrides.supplier_node_scale,
        supplier_capacity_node_scale=overrides.supplier_capacity_node_scale,
        edge_src_lead_time_scale=overrides.edge_src_lead_time_scale,
        edge_src_reliability_scale=overrides.edge_src_reliability_scale,
    )
    apply_scenario_flags(mutated, scenario_id, overrides.scenario_flags)
    return mutated


def _float_mapping(value: Any) -> dict[str, float]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError("Scale overrides must be objects")
    result = {}
    for key, number in value.items():
        if not isinstance(key, str) or not key:
            raise ValueError("Scale identifiers must be non-empty strings")
        try:
            valid = type(number) in (int, float) and math.isfinite(number) and number >= 0
        except OverflowError:
            valid = False
        if not valid:
            raise ValueError(f"Scale {key} must be a finite non-negative number")
        result[key] = float(number)
    return result


def _bool_mapping(value: Any) -> dict[str, bool]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError("Scenario flags must be an object")
    if any(not isinstance(k, str) or not k or type(v) is not bool for k, v in value.items()):
        raise ValueError("Scenario flags require string keys and JSON booleans")
    return dict(value)


def overrides_from_dict(payload: dict[str, Any] | None) -> SimulationOverrides:
    payload = {} if payload is None else payload
    if not isinstance(payload, dict) or set(payload) - {f.name for f in fields(SimulationOverrides)}:
        raise ValueError("Unknown or invalid simulation overrides")
    engine_args = payload.get("engine_args", ())
    if not isinstance(engine_args, (list, tuple)) or any(not isinstance(arg, str) for arg in engine_args):
        raise ValueError("engine_args must be a sequence of strings")
    return SimulationOverrides(
        factors=_float_mapping(payload.get("factors")),
        demand_item_scale=_float_mapping(payload.get("demand_item_scale")),
        capacity_node_scale=_float_mapping(payload.get("capacity_node_scale")),
        supplier_node_scale=_float_mapping(payload.get("supplier_node_scale")),
        supplier_capacity_node_scale=_float_mapping(payload.get("supplier_capacity_node_scale")),
        edge_src_lead_time_scale=_float_mapping(payload.get("edge_src_lead_time_scale")),
        edge_src_reliability_scale=_float_mapping(payload.get("edge_src_reliability_scale")),
        scenario_flags=_bool_mapping(payload.get("scenario_flags")),
        engine_args=tuple(str(arg) for arg in engine_args),
    )


def request_from_dict(payload: dict[str, Any]) -> SimulationRequest:
    """Parse trusted Python/JSON input without coercing strings into booleans.

    Internal paths and engine arguments remain available here; HTTP applies its
    narrower contract before calling this parser. Zero days means graph horizon.
    """
    if not isinstance(payload, dict) or set(payload) - {f.name for f in fields(SimulationRequest)}:
        raise ValueError("Unknown or invalid simulation request fields")
    for name in ("skip_map", "skip_plots", "run_lot_audit", "common_random_numbers"):
        if name in payload and not (name == "common_random_numbers" and payload[name] is None):
            if type(payload[name]) is not bool:
                raise ValueError(f"{name} must be a JSON boolean")
    for name in ("days", "seed"):
        value = payload.get(name, 0 if name == "days" else None)
        if value is not None and (type(value) is not int or value < 0):
            raise ValueError(f"{name} must be a non-negative integer")
        if name == "days" and value is None:
            raise ValueError("days must be a non-negative integer")
    profile = payload.get("output_profile", "diagnostic")
    if not isinstance(profile, str) or profile not in {"minimal", "diagnostic", "lot_trace", "full_debug"}:
        raise ValueError("Unsupported output profile")
    for name in ("input_path", "output_dir", "run_script", "control_schedule_csv", "control_policy_json", "demand_perturbation_csv"):
        value = payload.get(name)
        if value is not None and (not isinstance(value, (str, Path)) or not str(value).strip()):
            raise ValueError(f"{name} must be a non-empty path")
    if payload.get("run_id") is not None and (not isinstance(payload["run_id"], str) or not payload["run_id"].strip()):
        raise ValueError("run_id must be a non-empty string")
    if "scenario_id" in payload and (not isinstance(payload["scenario_id"], str) or not payload["scenario_id"].strip()):
        raise ValueError("scenario_id must be a non-empty string")
    if (payload.get("input_graph") is None) == (payload.get("input_path") is None):
        raise ValueError("Provide exactly one of input_graph and input_path")
    if payload.get("input_graph") is not None and not isinstance(payload["input_graph"], dict):
        raise ValueError("input_graph must be an object")
    return SimulationRequest(
        input_graph=payload.get("input_graph"),
        input_path=payload.get("input_path"),
        scenario_id=str(payload.get("scenario_id") or "scn:BASE"),
        days=int(payload.get("days") or 0),
        output_profile=payload.get("output_profile") or "diagnostic",
        overrides=overrides_from_dict(payload.get("overrides")),
        output_dir=payload.get("output_dir"),
        run_id=payload.get("run_id"),
        run_script=payload.get("run_script") or Path("etudecas/simulation/engine/run_first_simulation.py"),
        skip_map=bool(payload.get("skip_map", True)),
        skip_plots=bool(payload.get("skip_plots", True)),
        run_lot_audit=bool(payload.get("run_lot_audit", False)),
        demand_perturbation_csv=payload.get("demand_perturbation_csv"),
        control_schedule_csv=payload.get("control_schedule_csv"),
        control_policy_json=payload.get("control_policy_json"),
        seed=int(payload["seed"]) if payload.get("seed") is not None else None,
        common_random_numbers=(
            bool(payload["common_random_numbers"])
            if payload.get("common_random_numbers") is not None
            else None
        ),
    )


def default_run_id(scenario_id: str) -> str:
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"{timestamp}_{safe_name(scenario_id)}_{uuid4().hex[:8]}"


def default_output_dir(run_id: str) -> Path:
    return Path("etudecas/simulation/result/_api_runs") / run_id


def _load_json_if_exists(path: Path) -> Any:
    if not path.exists():
        return {} if path.suffix.lower() == ".json" else []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {} if path.suffix.lower() == ".json" else []
    return data


def profile_engine_args(profile: SimulationOutputProfile, *, run_lot_audit: bool) -> list[str]:
    if profile == "minimal":
        args = ["--output-profile", "compact", "--no-lot-trace", "--skip-lot-audit"]
    elif profile == "diagnostic":
        args = ["--output-profile", "compact", "--no-lot-trace", "--skip-lot-audit"]
    elif profile == "lot_trace":
        args = ["--output-profile", "compact", "--lot-trace"]
        if not run_lot_audit:
            args.append("--skip-lot-audit")
    elif profile == "full_debug":
        args = ["--output-profile", "full", "--lot-trace"]
        if not run_lot_audit:
            args.append("--skip-lot-audit")
    else:
        raise ValueError(f"Unsupported output profile: {profile}")
    return args


def simulate(request: SimulationRequest, *, run_executor=None) -> SimulationResult:
    """Run one simulation from structured inputs and return structured outputs."""

    # Native dataclass callers obey the same contract as JSON callers.
    request = request_from_dict(asdict(request))
    run_id = request.run_id or default_run_id(request.scenario_id)
    output_dir = Path(request.output_dir) if request.output_dir is not None else default_output_dir(run_id)
    input_path = output_dir / "inputs" / "simulation_input.json"

    base_graph = load_request_graph(request)
    from etudecas.knowledge_graph.schema import validate_graph_contract
    errors = [issue for issue in validate_graph_contract(base_graph) if issue["level"] == "error"]
    if errors:
        raise ValueError(f"Invalid simulation graph: {errors}")
    graph = apply_overrides(base_graph, request.scenario_id, request.overrides)
    write_json(input_path, graph)

    extra_args = profile_engine_args(request.output_profile, run_lot_audit=request.run_lot_audit)
    extra_args.extend(str(arg) for arg in request.overrides.engine_args)
    demand_perturbation_csv = str(
        request.demand_perturbation_csv or ""
    ).strip()
    control_schedule_csv = str(request.control_schedule_csv or "").strip()
    control_policy_json = str(request.control_policy_json or "").strip()
    if control_schedule_csv and control_policy_json:
        raise ValueError(
            "SimulationRequest cannot combine control_schedule_csv with "
            "control_policy_json: choose open-loop schedule or state feedback."
        )
    if control_schedule_csv:
        extra_args.extend(["--control-schedule-csv", control_schedule_csv])
    if control_policy_json:
        extra_args.extend(["--control-policy-json", control_policy_json])
    if demand_perturbation_csv:
        extra_args.extend(
            ["--demand-perturbation-csv", demand_perturbation_csv]
        )
    # Keep these typed controls last so an explicit request cannot be silently
    # shadowed by the backward-compatible free-form engine_args escape hatch.
    if request.seed is not None:
        extra_args.extend(["--seed", str(int(request.seed))])
    if request.common_random_numbers is not None:
        extra_args.append(
            "--common-random-numbers"
            if request.common_random_numbers
            else "--no-common-random-numbers"
        )

    summary, stdout = (run_executor or run_simulation)(
        run_script=Path(request.run_script),
        input_json=input_path,
        output_dir=output_dir,
        scenario_id=request.scenario_id,
        days=request.days,
        skip_map=request.skip_map,
        skip_plots=request.skip_plots,
        extra_args=extra_args,
    )
    run_manifest = _load_json_if_exists(output_dir / "run_manifest.json")
    generic_manifest = _load_json_if_exists(output_dir / "run" / "run_manifest.json")
    artifacts = _load_json_if_exists(output_dir / "run" / "artifact_index.json")
    if not isinstance(run_manifest, dict):
        run_manifest = {}
    if not isinstance(generic_manifest, dict):
        generic_manifest = {}
    if not isinstance(artifacts, list):
        artifacts = []
    return SimulationResult(
        run_id=run_id,
        scenario_id=request.scenario_id,
        output_dir=output_dir,
        input_path=input_path,
        summary=summary,
        kpis=numeric_kpis(summary),
        stdout=stdout,
        output_profile=request.output_profile,
        run_manifest=run_manifest,
        generic_manifest=generic_manifest,
        artifacts=artifacts,
    )


__all__ = [
    "SimulationOutputProfile",
    "SimulationOverrides",
    "SimulationRequest",
    "SimulationResult",
    "apply_overrides",
    "overrides_from_dict",
    "request_from_dict",
    "simulate",
]
