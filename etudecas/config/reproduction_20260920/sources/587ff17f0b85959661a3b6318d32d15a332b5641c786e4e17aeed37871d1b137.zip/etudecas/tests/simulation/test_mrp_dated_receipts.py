"""Independent, in-memory examples for the opt-in dated-receipt policy.

These checks validate a bounded coverage rule, not an ERP algorithm or the
absence of shortages before the end of a coverage window. No file fixtures.
"""
from __future__ import annotations

import math

import pytest

from etudecas.simulation.engine import run_first_simulation as engine


PAIR = ("M-1", "item:1")


def test_dated_receipts_late_order_does_not_cover_near_need():
    calendar = engine.DatedReceiptCalendar()
    calendar.add(PAIR, 12, 30)
    calendar.add(PAIR, 40, 90)

    # End-of-day 10: 20 on hand, target 100, only 30 arrives by day 16.
    eligible = calendar.quantity(PAIR, decision_day=10, through_day=16)
    assert eligible == 30
    assert max(0, 100 - 20 - eligible) == 50
    assert max(0, 100 - 20 - calendar.total(PAIR)) == 0
    assert calendar.total(PAIR) == 120


def test_dated_receipts_both_window_limits_are_inclusive():
    calendar = engine.DatedReceiptCalendar()
    for day, quantity in [(9, 2), (10, 3), (16, 5), (17, 7)]:
        calendar.add(PAIR, day, quantity)
    assert calendar.quantity(PAIR, decision_day=10, through_day=16) == 8
    assert calendar.quantity(PAIR, decision_day=10, through_day=10) == 3
    assert calendar.quantity(PAIR, decision_day=10, through_day=9) == 0
    assert calendar.total(PAIR) == 17


def test_dated_receipts_received_today_is_only_counted_as_on_hand():
    calendar = engine.DatedReceiptCalendar()
    calendar.add(PAIR, 10, 12)
    calendar.add(PAIR, 11, 8)
    # The simulator receives before planning: 5 + 12 physically on hand.
    calendar.remove(PAIR, 10, 12)
    on_hand = 17
    pending = calendar.quantity(PAIR, decision_day=10, through_day=11)
    assert pending == 8
    assert on_hand + pending == 25
    assert calendar.total(PAIR) == 8


def test_dated_receipts_exclusion_never_cancels_the_physical_receipt():
    calendar = engine.DatedReceiptCalendar()
    calendar.add(PAIR, 40, 90)
    assert calendar.quantity(PAIR, decision_day=10, through_day=16) == 0
    assert calendar.quantity(PAIR, decision_day=33, through_day=40) == 90
    assert calendar.total(PAIR) == 90
    calendar.remove(PAIR, 40, 90)
    assert calendar.total(PAIR) == 0
    assert calendar.quantity(PAIR, decision_day=40, through_day=47) == 0


def test_dated_receipts_disjoint_origins_accumulate_once_without_unit_rounding():
    calendar = engine.DatedReceiptCalendar()
    # Three distinct scheduled receipts: lane, external purchase, estimation.
    # An index lookup may neither duplicate nor consume any origin.
    for quantity in (7.25, 11.5, 13.75):
        calendar.add(PAIR, 15, quantity)
    for _ in range(3):
        assert calendar.quantity(PAIR, decision_day=10, through_day=15) == 32.5
        assert calendar.total(PAIR) == 32.5
    calendar.remove(PAIR, 15, 11.5)
    assert calendar.quantity(PAIR, decision_day=10, through_day=15) == 21
    assert calendar.total(PAIR) == 21


def test_dated_receipts_queries_follow_new_orders_and_partial_receipts():
    calendar = engine.DatedReceiptCalendar()
    calendar.add(PAIR, 12, 10)
    calendar.add(PAIR, 14, 20)
    assert calendar.quantity(PAIR, decision_day=10, through_day=14) == 30
    calendar.add(PAIR, 13, 7)
    assert calendar.quantity(PAIR, decision_day=10, through_day=14) == 37
    calendar.remove(PAIR, 12, 4)
    assert calendar.quantity(PAIR, decision_day=10, through_day=14) == 33
    calendar.remove(PAIR, 14, 20)
    assert calendar.quantity(PAIR, decision_day=13, through_day=14) == 7
    assert calendar.total(PAIR) == 13


def test_dated_receipts_does_not_mix_sites_or_articles():
    calendar = engine.DatedReceiptCalendar()
    calendar.add(PAIR, 12, 10)
    calendar.add(("M-2", "item:1"), 12, 100)
    calendar.add(("M-1", "item:2"), 12, 1000)
    assert calendar.quantity(PAIR, decision_day=10, through_day=15) == 10
    assert calendar.quantity(("missing", "item:1"), decision_day=10, through_day=15) == 0
    assert calendar.total(("M-2", "item:1")) == 100


def test_dated_receipts_fully_received_day_can_be_reused():
    calendar = engine.DatedReceiptCalendar()
    calendar.add(PAIR, 12, 10)
    calendar.remove(PAIR, 12, 10)
    assert calendar.total(PAIR) == 0
    calendar.add(PAIR, 12, 3)
    assert calendar.quantity(PAIR, decision_day=12, through_day=12) == 3
    assert calendar.total(PAIR) == 3


@pytest.mark.parametrize("value", [None, math.nan, math.inf, -1])
def test_dated_receipts_missing_or_invalid_quantity_is_not_imputed(value):
    calendar = engine.DatedReceiptCalendar()
    with pytest.raises((TypeError, ValueError)):
        calendar.add(PAIR, 12, value)
    assert calendar.total(PAIR) == 0


@pytest.mark.parametrize("day", [None, math.nan, math.inf, 12.5, True])
def test_dated_receipts_missing_or_fractional_date_is_not_imputed(day):
    calendar = engine.DatedReceiptCalendar()
    with pytest.raises((TypeError, ValueError)):
        calendar.add(PAIR, day, 10)
    assert calendar.total(PAIR) == 0


def test_dated_receipts_unknown_or_excess_receipt_is_rejected():
    calendar = engine.DatedReceiptCalendar()
    calendar.add(PAIR, 12, 10)
    for day, quantity in [(11, 1), (12, 11)]:
        with pytest.raises((KeyError, ValueError)):
            calendar.remove(PAIR, day, quantity)
    assert calendar.total(PAIR) == 10


@pytest.mark.parametrize("days, expected", [(0, 10), (1, 10), (1.1, 11), (7, 16), (7.1, 17)])
def test_dated_receipt_cover_includes_current_day(days, expected):
    assert engine.mrp_receipt_cover_end_day(10, days) == expected


@pytest.mark.parametrize("days", [None, math.nan, math.inf, -1])
def test_dated_receipt_cover_requires_documented_finite_window(days):
    with pytest.raises((TypeError, ValueError)):
        engine.mrp_receipt_cover_end_day(10, days)


def test_dated_receipt_window_does_not_claim_to_solve_intermediate_shortage():
    calendar = engine.DatedReceiptCalendar()
    calendar.add(PAIR, 16, 100)
    # Need 100 on day 11, receipt only day 16: an aggregate window credits it.
    assert calendar.quantity(PAIR, decision_day=10, through_day=16) == 100
    assert calendar.quantity(PAIR, decision_day=10, through_day=11) == 0
    # Both are true. A time-phased demand balance is still needed to detect the
    # day-11 shortage; passing these tests must not be called ERP calibration.


def test_production_safety_target_keeps_the_largest_existing_floor():
    # The three targets have one common quantity unit; they are not additive.
    assert engine.production_mrp_safety_target(500, 10, 20, 100) == 500
    assert engine.production_mrp_safety_target(50, 10, 20, 100) == 200
    assert engine.production_mrp_safety_target(50, 10, 20, 300) == 300


def test_production_safety_target_uses_converted_days_without_second_conversion():
    # 20 working days have already become 28 calendar days upstream.
    assert engine.production_mrp_safety_target(0, 125, 28, 0) == 3500
    assert engine.production_mrp_safety_target(0, 0, 28, 175) == 175
    assert engine.production_mrp_safety_target(0, 1.25, 2, 0) == 2.5


@pytest.mark.parametrize("position", range(4))
@pytest.mark.parametrize("value", [None, math.nan, math.inf, -1])
def test_production_safety_target_does_not_impute_invalid_source_values(position, value):
    arguments = [100, 10, 20, 50]
    arguments[position] = value
    with pytest.raises((TypeError, ValueError)):
        engine.production_mrp_safety_target(*arguments)


def test_production_safety_target_rejects_overflow_instead_of_infinite_orders():
    with pytest.raises(ValueError):
        engine.production_mrp_safety_target(0, 1e308, 1e308, 0)
