"""Etudecas package."""
