"""Supplier criticality KPI builder."""

