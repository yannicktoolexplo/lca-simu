"""Prepare, run and compare an isolated shared-component demand hypothesis.

Only the first industrial MRP vintage informs the hypothesis. H, J, K and
inventory photographs never enter the estimator. Missing weeks stay unknown.
The 1.25 screening ratio is a declared study convention, not an ERP rule.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from copy import deepcopy
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
ORIGIN = datetime(2025, 1, 1)
SITES = {'1430': 'M-1430', '1450': 'SDC-1450', '1810': 'M-1810', '1920': 'DC-1920'}
DEFAULT_REFERENCE = ROOT / 'artifacts/testing/mrp_execution_20260928/simulation_v6'
DEFAULT_WORK = ROOT / 'artifacts/testing/shared_materials_20260929/study'


def unit(value):
    value = str(value).strip().upper().rstrip('.')
    if value == 'G':
        return 'KG', .001
    if value in ('UN', 'ZUN', 'UNIT', 'UNITS'):
        return 'UN', 1.
    if value in ('KG', 'M'):
        return value, 1.
    raise ValueError(f'Unsupported unit: {value}')


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)


def read_first_plan(path):
    import openpyxl
    book = openpyxl.load_workbook(path, read_only=True, data_only=True)
    first = None
    records = []
    try:
        for line, row in enumerate(book['Feuille1'].iter_rows(min_row=2, values_only=True), 2):
            vintage = row[0]
            if not isinstance(vintage, datetime):
                raise ValueError(f'Invalid vintage A{line}')
            if first is None or vintage < first:
                first, records = vintage, []
            if vintage != first:
                continue
            canonical, factor = unit(row[5])
            if row[8] is None:
                raise ValueError(f'Missing gross requirement I{line}; absence is not zero')
            qty = float(row[8]) * factor
            if not math.isfinite(qty) or qty < 0:
                raise ValueError(f'Invalid gross requirement I{line}')
            records.append({'item': str(row[1]).zfill(6), 'division': str(row[3]),
                            'type': str(row[2]), 'unit': canonical, 'qty': qty,
                            'day': (row[6] - ORIGIN).days, 'row': line})
    finally:
        book.close()
    return (first - ORIGIN).days, records


def consumption_network(graph):
    """Coefficients in canonical units, including upstream transformation BOMs."""
    producers, states = {}, {}
    for node in graph['nodes']:
        for state in node.get('inventory', {}).get('states', []):
            states[(node['id'], state['item_id'])] = state
        for process in node.get('processes', []):
            outputs = process.get('outputs', [])
            if len(outputs) != 1:
                raise ValueError('Study requires a single output per production process')
            item = outputs[0]['item_id']
            if item in producers:
                raise ValueError(f'Ambiguous production site for {item}')
            producers[item] = (node['id'], process)

    def expand(item, trail=()):
        if item not in producers:
            return {}
        if item in trail:
            raise ValueError('Cyclic BOM')
        node, process = producers[item]
        _, base_factor = unit(process['batch_size_unit'])
        base = float(process['batch_size']) * base_factor
        if base <= 0:
            raise ValueError('Nonpositive BOM base')
        result = defaultdict(float)
        for component in process['inputs']:
            child = component['item_id']
            _, factor = unit(component['ratio_unit'])
            ratio = float(component['ratio_per_batch']) * factor / base
            result[(node, child)] += ratio
            for pair, coefficient in expand(child, (*trail, item)).items():
                result[pair] += ratio * coefficient
        return dict(result)
    return states, producers, expand


def estimate_first_plan(graph, known_day, records, threshold=1.25):
    """Pure estimator. Additional downstream use is deducted from upstream residuals."""
    if threshold <= 1 or not math.isfinite(threshold):
        raise ValueError('Screening threshold must exceed one')
    states, producers, expand = consumption_network(graph)
    start = known_day + 7  # Current bucket may include old backlog; do not invent new demand.
    grouped = defaultdict(list)
    for row in records:
        grouped[(SITES[row['division']], 'item:' + row['item'])].append(row)
    for rows in grouped.values():
        days = [r['day'] for r in rows]
        if len(set(days)) != len(days):
            raise ValueError('Duplicate pair/week in first vintage')
    pf = {pair[1]: rows for pair, rows in grouped.items()
          if rows[0]['type'] == 'PF' and pair[1] in producers}
    coefficients = {item: expand(item) for item in pf}
    direct_pairs = set().union(*(set(c) for c in coefficients.values()))
    # A component output drives its upstream ingredients; visit it first.
    depth = {pair: len(expand(pair[1])) for pair in direct_pairs}
    ordered = sorted(grouped, key=lambda pair: (-depth.get(pair, -1), pair))
    schedules, audit, selected = [], [], []
    for pair in ordered:
        rows = sorted(grouped[pair], key=lambda row: row['day'])
        info = {'pair': rows[0]['item'] + '/' + rows[0]['division'],
                'node_id': pair[0], 'item_id': pair[1], 'unit': rows[0]['unit'],
                'article_type': rows[0]['type'], 'known_day': known_day,
                'status': 'not_selected', 'reason': None}
        audit.append(info)
        roots = [item for item, c in coefficients.items() if pair in c]
        if pair not in states or not roots:
            info['reason'] = 'no_modelled_consumption_at_this_site_or_no_stock_state'
            continue
        canonical, engine_factor = unit(states[pair]['uom'])
        if canonical != rows[0]['unit'] or any(r['unit'] != canonical for r in rows):
            raise ValueError(f'Unit disagreement for {pair}')
        ends = []
        for item in roots:
            days = sorted(r['day'] for r in pf[item] if known_day <= r['day'] < 365)
            if not days or days != list(range(known_day, days[-1] + 1, 7)):
                ends = []
                break
            ends.append(min(365, days[-1] + 7))
        if not ends:
            info['reason'] = 'finished_product_forecast_has_missing_weeks'
            continue
        end = min(ends)
        def sum_in_window(series):
            return sum(r['qty'] * min(7, end - r['day']) / 7
                       for r in series if start <= r['day'] < end)
        own_by_pf = {item: sum_in_window(pf[item]) * coefficients[item][pair]
                     for item in roots}
        own = sum(own_by_pf.values())
        induced = 0.
        for child in selected:
            coefficient = expand(child['item_id']).get(pair, 0.)
            for row in child['canonical_schedule']:
                overlap = max(0, min(end, row['day'] + row['period_days']) - max(start, row['day']))
                induced += coefficient * row['qty'] * overlap / row['period_days']
        total = sum_in_window(rows)
        represented = own + induced
        ratio = total / represented if represented > 0 else None
        info.update({'horizon_start_day': start, 'horizon_end_exclusive': end,
                     'source_reported_requirement': total, 'own_bom_requirement': own,
                     'own_requirement_by_pf': own_by_pf, 'already_induced_by_downstream': induced,
                     'source_to_represented_ratio': ratio,
                     'reported_source_weeks': sum(start <= r['day'] < end for r in rows),
                     'source_cells': [f"I{r['row']}" for r in rows if start <= r['day'] < end]})
        if ratio is None or ratio <= threshold or info['reported_source_weeks'] < 3:
            info['reason'] = 'no_sufficient_positive_residual_on_full_common_horizon'
            continue
        fraction = (total - represented) / total
        info.update(status='estimated_complement', reason='first_vintage_excess_after_full_horizon_bom_and_upstream_deduction',
                    estimated_other_use_fraction=fraction,
                    shared_use_status='user_suspected' if info['pair'] in ('042342/1430', '002612/1810', '007923/1810') else 'hypothesis_only')
        canonical_schedule = []
        for row in rows:
            if not start <= row['day'] < end:
                continue
            days = min(7, end - row['day'])
            theoretical = row['qty'] * fraction * days / 7
            physical = theoretical / engine_factor
            if canonical == 'UN':
                physical = math.floor(physical + .5)
            if physical <= 0:
                continue
            schedules.append({'demand_id': f"shared:{row['item']}:{row['division']}:{row['row']}",
                              'node_id': pair[0], 'item_id': pair[1], 'known_day': known_day,
                              'period_start_day': row['day'], 'period_days': days,
                              'qty': physical, 'uom': states[pair]['uom'],
                              'source_file': 'Flow_Data_MRP_results.xlsx',
                              'source_cells': f"Feuille1!I{row['row']}",
                              'estimation_basis': json.dumps({'method': 'first_plan_aggregate_residual_share',
                                                   'fraction': fraction, 'unrounded_canonical_qty': theoretical,
                                                   'screening_ratio': threshold, 'evidence_pair': info['pair']}, sort_keys=True)})
            canonical_schedule.append({'day': row['day'], 'period_days': days, 'qty': physical * engine_factor})
        selected.append({'item_id': pair[1], 'canonical_schedule': canonical_schedule})
        info['scheduled_canonical_qty'] = sum(r['qty'] for r in canonical_schedule)
    return schedules, sorted(audit, key=lambda row: row['pair'])


def protected(plan):
    for path, expected in plan['protected_inputs'].items():
        if sha(path) != expected:
            raise ValueError(f'Protected input changed: {path}')


def revision_series(records, vintages, pair, fraction):
    """Replace future forecasts; never inject the current, possibly overdue bucket."""
    item, division = pair.split('/')
    versions = []
    for known in sorted(set(vintages)):
        rows = []
        for record in records:
            if record['known_day'] != known or record['day'] <= known or record['day'] >= 365:
                continue
            if record['unit'] != 'KG':
                raise ValueError('The isolated revision study supports KG only')
            rows.append({'demand_id': f'shared-revision:{item}:{division}:{record["day"]}',
                         'period_start_day': record['day'], 'period_days': min(7, 365 - record['day']),
                         'qty': record['qty'] * fraction * min(7, 365 - record['day']) / 7,
                         'source_file': 'Flow_Data_MRP_results.xlsx',
                         'source_cells': f'Feuille1!I{record["row"]}',
                         'estimation_basis': json.dumps({'method': 'fixed_first_plan_share_revised_future',
                                                        'fraction': fraction}, sort_keys=True)})
        if len({r['period_start_day'] for r in rows}) != len(rows):
            raise ValueError('Duplicate target week in a revision')
        versions.append({'vintage_id': f'mrp:{known}', 'known_day': known,
                         'rows': sorted(rows, key=lambda r: r['period_start_day'])})
    return {'node_id': SITES[division], 'item_id': 'item:' + item, 'uom': 'KG',
            'period_anchor_day': 4, 'period_days': 7, 'repeat_period_days': 0,
            'current_bucket_policy': 'freeze_previous_exclude_current_vintage',
            'missing_future_policy': 'unprovided_not_observed_zero', 'versions': versions}


def prepare_revisions(args):
    """001848/1810 only: dated knowledge experiment, with frozen witnesses."""
    import openpyxl
    reference = args.reference.resolve()
    old = json.loads((reference / 'plan.json').read_text(encoding='utf8'))
    protected(old)
    graph_path = reference / 'shared_components_graph.json'
    graph = json.loads(graph_path.read_text(encoding='utf8'))
    meta = graph['meta']['external_component_demands']
    pair = '001848/1810'
    info = next(r for r in meta['estimation_audit'] if r['pair'] == pair)
    fraction = info['estimated_other_use_fraction']
    workbook = ROOT / 'data/source/Flow_Data_MRP_results.xlsx'
    records, vintages = [], set()
    book = openpyxl.load_workbook(workbook, read_only=True, data_only=True)
    try:
        for line, row in enumerate(book['Feuille1'].iter_rows(min_row=2, values_only=True), 2):
            known = (row[0] - ORIGIN).days
            if not 0 <= known < 365:
                continue
            vintages.add(known)
            if str(row[1]).zfill(6) != '001848' or str(row[3]) != '1810':
                continue
            canonical, factor = unit(row[5])
            if row[8] is None or not math.isfinite(float(row[8])) or float(row[8]) < 0:
                raise ValueError(f'Invalid requirement I{line}')
            records.append({'known_day': known, 'day': (row[6] - ORIGIN).days,
                            'qty': float(row[8]) * factor, 'unit': canonical, 'row': line})
    finally:
        book.close()
    series = revision_series(records, vintages, pair, fraction)
    meta['rows'] = [r for r in meta['rows'] if (r['node_id'], r['item_id']) != ('M-1810', 'item:001848')]
    meta.update(schema_version=2, versioned_series=[series])
    meta['assumptions'] += [
        '001848/1810 only: successive MRP vintages replace future complementary forecasts.',
        'Its first-plan estimated share stays fixed; later inventories, H, J and K never fit demand.',
        'Current weekly demand freezes from the last vintage strictly before the week starts.',
        'Missing rows are unknown: no supported additional demand is injected; older rows are not carried over.',
        '001848 revisions cover 2025 only and do not repeat. Other 18 shared-use hypotheses are unchanged.',
    ]
    graph_file = args.workdir / 'shared_components_graph.json'
    write(graph_file, graph)
    write(args.workdir / 'scope_audit.json', {'pair': pair, 'fraction': fraction,
          'version_count': len(series['versions']), 'source_rows': records,
          'basis': info, 'independent_stock_fit': False})
    commands = {}
    for name, previous in [('nominal', 'nominal'), ('usages_complementaires', 'usages_complementaires'),
                           ('revisions_001848', 'usages_complementaires')]:
        command = list(old['commands'][previous])
        command[0] = sys.executable
        command[command.index('--output-dir') + 1] = str(args.workdir / name)
        if name == 'revisions_001848':
            command[command.index('--input') + 1] = str(graph_file)
            command[command.index('--days') + 1] = '365'
        commands[name] = command
    inputs = dict(old['protected_inputs'])
    inputs.update({str(p): sha(p) for p in [graph_path, graph_file, workbook]})
    plan = {'schema_version': 2, 'experiment': 'weekly_revisions_001848', 'reference': str(reference),
            'commands': commands, 'protected_inputs': inputs, 'estimator_sha256': sha(Path(__file__)),
            'csv_witnesses': {name: str(reference / name / 'data') for name in ('nominal', 'usages_complementaires')},
            'labels': {'nominal': 'Nominal conservé', 'usages_complementaires': 'Usages partagés · plan du 5 janvier figé',
                       'revisions_001848': '001848 Avène · besoins révisés chaque semaine'}}
    protected(plan)
    write(args.workdir / 'plan.json', plan)
    print(json.dumps({'pair': pair, 'versions': len(series['versions']), 'fixed_fraction': fraction}), flush=True)


def prepare(args):
    reference = args.reference.resolve()
    old = json.loads((reference / 'plan.json').read_text(encoding='utf8'))
    graph_path = reference / 'source_forecasts_graph.json'
    graph = json.loads(graph_path.read_text(encoding='utf8'))
    workbook = ROOT / 'data/source/Flow_Data_MRP_results.xlsx'
    known, records = read_first_plan(workbook)
    rows, audit = estimate_first_plan(graph, known, records)
    if not rows:
        raise ValueError('No supported complementary requirements')
    graph['meta']['external_component_demands'] = {
        'schema_version': 1, 'origin': '2025-01-01', 'scenario_id': 'scn:BASE',
        'semantics': 'incremental_non_modelled_component_use', 'repeat_period_days': 365,
        'rows': rows, 'estimation_audit': audit,
        'assumptions': ['First January 5 MRP vintage frozen; no later source version informs this demand.',
                        'Current vintage bucket excluded: old backlog is not identified as new demand.',
                        'Projected component use is treated as a physical demand hypothesis, not observed consumption.',
                        'Missing weeks remain unknown; no additional demand is inferred there.',
                        'Aggregate residual share is not an identified list of other products.',
                        'Upstream residual deducts additional downstream use to avoid double counting.',
                        'Modeled finished products have physical allocation priority.',
                        'Years 2-5 repeat the first-year hypothetical complementary calendar.'],
    }
    graph_file = args.workdir / 'shared_components_graph.json'
    write(graph_file, graph)
    write(args.workdir / 'scope_audit.json', {'schema_version': 1, 'known_day': known,
          'screening_ratio': 1.25, 'pairs': audit, 'rows': len(rows)})
    commands = {}
    for name, reference_name in [('nominal', 'nominal'), ('reference_datee', 'planification_datee'), ('usages_complementaires', 'planification_datee')]:
        command = list(old['commands'][reference_name])
        command[0] = sys.executable
        command[command.index('--output-dir') + 1] = str(args.workdir / name)
        if name == 'usages_complementaires':
            command[command.index('--input') + 1] = str(graph_file)
        commands[name] = command
    inputs = {str(ROOT.parent / path): digest for path, digest in old['protected_inputs'].items()}
    inputs.update({str(p): sha(p) for p in [graph_path, graph_file, workbook]})
    plan = {'schema_version': 1, 'reference': str(reference), 'commands': commands,
            'protected_inputs': inputs, 'estimator_sha256': sha(Path(__file__)),
            'labels': {'nominal': 'Nominal conservé', 'reference_datee': 'MRP daté · sans usages complémentaires',
                       'usages_complementaires': 'MRP daté · usages complémentaires estimés'}}
    protected(plan)
    write(args.workdir / 'plan.json', plan)
    print(json.dumps({'pairs_examined': len(audit), 'pairs_selected': [r['pair'] for r in audit if r['status'] == 'estimated_complement'], 'rows': len(rows)}), flush=True)


def run(args):
    from etudecas import regenerate as regen
    from etudecas.testing.qualification import require_run_invariants
    plan = json.loads((args.workdir / 'plan.json').read_text(encoding='utf8'))
    protected(plan)
    for name in plan['commands']:
        if (args.workdir / name).exists():
            raise ValueError(f'Refuse overwrite: {name}')
    bundle = regen._capture_sources(args.workdir, list(plan['commands'].values()))
    results = []
    for name, command in plan['commands'].items():
        start = time.perf_counter()
        with (args.workdir / f'{name}.log').open('x', encoding='utf8') as log:
            subprocess.run(command, cwd=ROOT.parent, stdout=log, stderr=subprocess.STDOUT, check=True)
        elapsed = time.perf_counter() - start
        regen._record_run('nominal', args.workdir / name, command,
                          source_bundle=regen._check_sources(bundle), elapsed_seconds=elapsed)
        checks = require_run_invariants(args.workdir / name)
        write(args.workdir / name / 'invariants.json', checks)
        result = {'name': name, 'elapsed_seconds': elapsed, 'invariants_ok': checks['ok']}
        if name in plan.get('csv_witnesses', {}) or (plan.get('schema_version') == 1 and name in ('nominal', 'reference_datee')):
            prior = (Path(plan['csv_witnesses'][name]) if name in plan.get('csv_witnesses', {}) else
                     Path(plan['reference']) / ('nominal' if name == 'nominal' else 'planification_datee') / 'data')
            a = {p.name: sha(p) for p in prior.glob('*.csv')}
            b = {p.name: sha(p) for p in (args.workdir / name / 'data').glob('*.csv')}
            result['csv_identity'] = bool(a) and a == b
            result['changed_csv'] = sorted(k for k in a.keys() | b.keys() if a.get(k) != b.get(k))
            if not result['csv_identity']:
                write(args.workdir / f'{name}_regression.json', result)
                raise ValueError(f'Witness regression: {result}')
        results.append(result)
        protected(plan)
        print(json.dumps(result), flush=True)
    write(args.workdir / 'runs.json', {'ok': True, 'results': results})


def render(args):
    from etudecas.visualization.maps.source_comparison import build_comparison_payload
    from etudecas.visualization.maps.portable_diagnostic import build_comparison_map
    plan = json.loads((args.workdir / 'plan.json').read_text(encoding='utf8'))
    protected(plan)
    payload = build_comparison_payload(ROOT / 'data/source/Flow_Data_Inventory_and_Replenishment_rules.xlsx',
                                       ROOT / 'data/source/Flow_Data_MRP_results.xlsx',
                                       {name: args.workdir / name for name in plan['commands']})
    for name, label in plan['labels'].items():
        payload['runs'][name]['label'] = label
    revised = plan.get('experiment') == 'weekly_revisions_001848'
    if revised:
        payload['default_pair'] = '001848/1810'
        payload['default_runs'] = ['usages_complementaires', 'revisions_001848']
    payload['conventions'] += ([
        'Essai 001848 à Avène : seul son calendrier complémentaire est révisé. Les 18 autres usages estimés restent figés.',
        'La part estimée des autres usages reste celle du 5 janvier ; aucun inventaire ultérieur ne sert à ajuster la consommation.',
        'Les versions MRP remplacent les prévisions futures à leur date de connaissance. Chaque semaine exécutée est figée depuis le dernier plan strictement antérieur à son début.',
        'La colonne I de la semaine courante peut inclure des reports : elle ne crée pas un nouveau besoin. Les retards physiques du modèle sont conservés séparément.',
        'Une semaine absente du dernier plan reste inconnue : aucune demande complémentaire n’y est injectée, sans reprise d’une ancienne ligne omise.',
        'Les commandes engagées, les stocks de départ et les jours de sécurité restent conservés. Les entrées prévues industrielles H ne sont pas imposées à la simulation.',
        'Le scénario révisé couvre uniquement 2025. Les deux témoins sont recalculés sur cinq ans et comparés aux références conservées.',
        'Les autres panneaux et les deux suivis de lots restent ceux du nominal historique.',
    ] if revised else [
        'Usages complémentaires : hypothèse figée à partir du seul plan MRP du 5 janvier, sans utiliser les inventaires ultérieurs pour calculer les sorties.',
        'La semaine courante du premier plan est exclue : elle peut contenir des retards antérieurs. Les besoins complémentaires commencent au 12 janvier.',
        'Les besoins complémentaires sont estimés sur le périmètre des autres usages ; ils ne prouvent ni leur identité ni leur consommation exécutée dans les données industrielles.',
        'Le stock global, les sécurités et la nomenclature sont conservés. Les PF étudiés sont servis en priorité ; les besoins complémentaires non servis restent visibles.',
        'Les absences de semaines sources restent inconnues. Aucune consommation supplémentaire n’est inventée pour ces semaines.',
        'Les années 2 à 5 répètent le calendrier complémentaire estimé de la première année ; seule 2025 dispose d’inventaires de comparaison.',
        'Les autres onglets et les deux suivis de lots restent ceux du nominal historique ; ce panneau présente les trois nouveaux calculs.',
    ])
    write(args.workdir / 'comparison.json', payload)
    delivery = build_comparison_map(ROOT / 'resultats/02_carte_lots_recente.html', payload, args.html)
    write(args.workdir / 'delivery.json', delivery)
    impact = []
    for pair, row in payload['pairs'].items():
        old = row['simulations']['usages_complementaires' if revised else 'reference_datee']['metrics'].get('previous_day_physical')
        new = row['simulations']['revisions_001848' if revised else 'usages_complementaires']['metrics'].get('previous_day_physical')
        if old and new:
            impact.append({'pair': pair, 'unit': row['unit'], 'source_mean': old['observed_mean'],
                           'mae_before': old['mae'], 'mae_after': new['mae'], 'mae_change': new['mae'] - old['mae'],
                           'bias_before': old['bias'], 'bias_after': new['bias']})
    write(args.workdir / 'impact.json', {'stock_comparisons': impact})
    print(json.dumps({'html': str(args.html), 'pairs_compared': len(impact)}), flush=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=['prepare', 'prepare-revisions', 'run', 'render'])
    parser.add_argument('--reference', type=Path, default=DEFAULT_REFERENCE)
    parser.add_argument('--workdir', type=Path, default=DEFAULT_WORK)
    parser.add_argument('--html', type=Path, default=ROOT / 'resultats/composants_partages_20260929/carte.html')
    args = parser.parse_args(argv)
    args.workdir = args.workdir.resolve()
    args.workdir.relative_to(ROOT / 'artifacts/testing')
    args.workdir.mkdir(parents=True, exist_ok=True)
    args.html = args.html.resolve()
    args.html.relative_to(ROOT)
    globals()[args.phase.replace('-', '_')](args)


if __name__ == '__main__':
    main()
