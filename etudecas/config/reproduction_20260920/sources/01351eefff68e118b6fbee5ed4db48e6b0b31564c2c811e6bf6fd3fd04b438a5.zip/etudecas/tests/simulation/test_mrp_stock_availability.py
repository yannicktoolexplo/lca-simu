"""Pure in-memory oracles for held opening stock; no filesystem fixtures."""
from __future__ import annotations

from copy import deepcopy
import pytest

from etudecas.simulation.engine import run_first_simulation as engine


PAIR = ("M-1", "item:1")


def make_state(*, quantity=4, release_day=3, knowledge_date="2025-01-01", assumption="", rows=None):
    stock = {PAIR: 10.0}
    ledger = engine.LotLedger(enabled=True)
    ledger.seed_opening_stock(day=0, stock=stock, item_unit_map={"item:1": "UN"})
    payload = {
        "schema_version": 1,
        "knowledge_date": knowledge_date,
        "assumption": assumption,
        "rows": rows if rows is not None else [{
            "node_id": "M-1", "item_id": "item:1", "quantity": quantity,
            "uom": "UN", "release_day": release_day, "source_row": "MRP!J2",
        }],
    }
    availability = engine.InitialStockAvailability(
        payload, stock=stock, item_unit_map={"item:1": "UN"}, origin_date="2025-01-01"
    )
    availability.initialize(stock=stock, ledger=ledger)
    return stock, ledger, availability


def test_held_stock_release_conserves_physical_lot_and_blocks_reservation():
    stock, ledger, availability = make_state()
    lot_id = next(iter(ledger.lots))
    assert stock[PAIR] == 6
    assert availability.held_by_pair[PAIR] == 4
    assert ledger.pair_balance(node_id=PAIR[0], item_id=PAIR[1]) == 10
    with pytest.raises(ValueError, match="available"):
        ledger.consume(day=0, node_id=PAIR[0], item_id=PAIR[1], qty=7,
                       event_type="shipment_reserve", uom="UN")
    assert len(ledger.lots) == 1
    assert availability.release(2, stock=stock, ledger=ledger) == {}
    assert availability.release(3, stock=stock, ledger=ledger) == {PAIR: 4}
    assert stock[PAIR] == 10
    assert availability.held_by_pair[PAIR] == 0
    assert list(ledger.lots) == [lot_id]
    assert ledger.lots[lot_id]["qty_remaining"] == 10
    assert availability.release(3, stock=stock, ledger=ledger) == {}
    assert [row["event_type"] for row in ledger.event_rows] == [
        "opening_stock", "stock_availability_hold", "stock_availability_release"
    ]
    assert {row["qty_after"] for row in ledger.event_rows} == {10}
    assert ledger.genealogy_rows == []


def test_fifo_skips_held_stock_then_reuses_same_lot_after_release():
    stock, ledger, availability = make_state(quantity=10)
    opening_id = next(iter(ledger.lots))
    later_id = ledger.create_lot(day=1, node_id=PAIR[0], item_id=PAIR[1], qty=3,
                                 source_type="lane_receipt", event_type="lane_receipt", uom="UN")
    allocations = ledger.consume(day=1, node_id=PAIR[0], item_id=PAIR[1], qty=3,
                                 event_type="production_consume", uom="UN")
    assert [(row["lot_id"], row["qty"]) for row in allocations] == [(later_id, 3)]
    assert ledger.lots[opening_id]["qty_remaining"] == 10
    availability.release(3, stock=stock, ledger=ledger)
    allocations = ledger.consume(day=3, node_id=PAIR[0], item_id=PAIR[1], qty=4,
                                 event_type="production_consume", uom="UN")
    assert [(row["lot_id"], row["qty"]) for row in allocations] == [(opening_id, 4)]
    assert ledger.lots[opening_id]["qty_remaining"] == 6


def test_planner_counts_only_known_releases_within_dated_cover():
    stock, ledger, availability = make_state()
    assert availability.planning_quantity(PAIR, decision_day=0, through_day=2) == 0
    assert availability.planning_quantity(PAIR, decision_day=0, through_day=3) == 4
    availability.release(3, stock=stock, ledger=ledger)
    assert availability.planning_quantity(PAIR, decision_day=3, through_day=9) == 0
    assert stock[PAIR] == 10


def test_partial_consumption_and_two_releases_keep_one_physical_lot():
    rows = [{"node_id": PAIR[0], "item_id": PAIR[1], "quantity": qty,
             "uom": "UN", "release_day": day, "source_row": source}
            for qty, day, source in [(4, 3, "MRP!J2"), (2, 5, "MRP!J3")]]
    stock, ledger, availability = make_state(rows=rows)
    assert stock[PAIR] == 4
    ledger.consume(day=1, node_id=PAIR[0], item_id=PAIR[1], qty=3,
                   event_type="demand_service", uom="UN")
    stock[PAIR] -= 3
    assert ledger.pair_balance(node_id=PAIR[0], item_id=PAIR[1]) == 7
    availability.release(3, stock=stock, ledger=ledger)
    assert (stock[PAIR], availability.held_by_pair[PAIR]) == (5, 2)
    ledger.consume(day=4, node_id=PAIR[0], item_id=PAIR[1], qty=5,
                   event_type="demand_service", uom="UN")
    stock[PAIR] -= 5
    assert ledger.pair_balance(node_id=PAIR[0], item_id=PAIR[1]) == 2
    availability.release(5, stock=stock, ledger=ledger)
    assert (stock[PAIR], availability.held_by_pair[PAIR]) == (2, 0)
    assert len(ledger.lots) == 1
    assert all(row["event_type"] != "stock_reconciliation" for row in ledger.event_rows)


@pytest.mark.parametrize("quantity,release_day", [(11, 3), (1.5, 3), (float("nan"), 3),
                                                (float("inf"), 3), (-1, 3), (4, -1), (4, 1.5)])
def test_invalid_physical_quantities_and_dates_are_rejected(quantity, release_day):
    with pytest.raises(ValueError):
        make_state(quantity=quantity, release_day=release_day)


def test_future_knowledge_requires_named_backcast_assumption():
    with pytest.raises(ValueError, match="knowledge"):
        make_state(knowledge_date="2025-01-05")
    _, _, availability = make_state(knowledge_date="2025-01-05", release_day=11,
        assumption="backcast_first_snapshot_for_separate_experiment")
    assert availability.knowledge_day == 4
    assert availability.effective_knowledge_day == 0
    assert availability.planning_quantity(PAIR, decision_day=0, through_day=11) == 4


def test_duplicate_source_and_cumulative_overallocation_are_rejected():
    row = {"node_id": PAIR[0], "item_id": PAIR[1], "quantity": 6,
           "uom": "UN", "release_day": 3, "source_row": "MRP!J2"}
    with pytest.raises(ValueError, match="source"):
        make_state(rows=[row, deepcopy(row)])
    other = {**row, "source_row": "MRP!J3"}
    with pytest.raises(ValueError, match="physical"):
        make_state(rows=[row, other])


def test_default_ledger_has_no_availability_fields_or_events():
    ledger = engine.LotLedger(enabled=True)
    ledger.seed_opening_stock(day=0, stock={PAIR: 10}, item_unit_map={PAIR[1]: "UN"})
    ledger.consume(day=0, node_id=PAIR[0], item_id=PAIR[1], qty=3,
                   event_type="demand_service", uom="UN")
    assert [row["qty_after"] for row in ledger.event_rows] == [10, 7]
    assert all("held_qty" not in row for row in ledger.event_rows)
    assert "qty_held" not in next(iter(ledger.lots.values()))


@pytest.mark.parametrize("horizon_days,release_day", [(2, 5), (2, 1), (366, 365)])
def test_material_balance_includes_held_stock_until_its_dated_release(horizon_days, release_day):
    from etudecas.visualization.maps.simulation_payload import apply_physical_material_balances

    last = horizon_days - 1
    row = {"scope": "material", "node_id": "M", "item_id": "RM", "unit": "UN",
           "consumed_qty": 99, "planned_qty": 3, "yearly": {"1": {"consumed_qty": 99}}}
    if horizon_days > 365:
        row["yearly"]["2"] = {"consumed_qty": 99}
    def event(kind, qty, day):
        return {"node_id": "M", "item_id": "RM", "uom": "UN",
                "event_type": kind, "qty": qty, "day": day}
    events = [event("opening_stock", 10, 0), event("stock_availability_hold", 4, 0),
              event("stock_availability_release", 4, release_day),
              event("lane_receipt", 2, last), event("production_consume", 3, last)]
    stocks = [{"node_id": "M", "item_id": "RM", "day": last,
               "stock_end_of_day": 9 if release_day <= last else 5}]
    if horizon_days > 365:
        stocks.insert(0, {"node_id": "M", "item_id": "RM", "day": 364, "stock_end_of_day": 6})
    apply_physical_material_balances([row], events, stocks,
                                     horizon_days=horizon_days, source_available=True)
    assert row["balance_status"] == "reconciled"
    assert row["initial_qty"] == 10
    assert row["delivered_qty"] == 2
    assert row["consumed_qty"] == 3
    assert row["stock_outflow_qty"] == 0
    assert row["stock_adjustment_qty"] == 0
    assert row["final_stock_qty"] == 9  # Independent oracle: 10 + 2 - 3.
    assert row["balance_gap_qty"] == 0
    assert row["theoretical_consumed_qty"] == 99
    if horizon_days > 365:
        assert row["yearly"]["1"]["final_stock_qty"] == 10
        assert row["yearly"]["2"]["initial_qty"] == 10
