"""Shared map data loading, graph contracts and reusable HTML panel formatting."""
from __future__ import annotations
import csv, json, math, html
from pathlib import Path
from typing import Any, Iterable
from dataclasses import dataclass
from etudecas.case_config import (
    display_node_id as case_display_node_id,
    is_upstream_internal_site as case_is_upstream_internal_site,
    standard_order_override,
)





NODE_TYPE_STYLES = {
    "supplier_dc": {"name": "Supplier DC", "color": "#1f77b4", "symbol": "circle"},
    "factory": {"name": "Factory", "color": "#d62728", "symbol": "square"},
    "distribution_center": {"name": "Distribution Center", "color": "#ff7f0e", "symbol": "diamond"},
    "customer": {"name": "Customer", "color": "#2ca02c", "symbol": "star"},
}

PILOTAGE_HIDDEN_NODE_IDS = {"M-1450"}
SIMULATION_HIDDEN_ITEM_IDS: set[str] = set()

MANUAL_GEO_OVERRIDES = {
    # Fournisseurs 021081: le geocodage automatique retombait au centroide USA.
    "SDC-VD0949099A": {
        "lat": None,
        "lon": None,
        "location_ID": "USA - BOONE NC - 28607",
        "country": "United States",
    },
    "SDC-VD0960508A": {
        "lat": None,
        "lon": None,
        "location_ID": "USA - DURHAM NC - 27704",
        "country": "United States",
    },
    "SDC-VD0972460A": {
        "lat": None,
        "lon": None,
        "location_ID": "USA - VD0972460A FL - 33930",
        "country": "United States",
    },
    "SDC-VD0975221A": {
        "lat": None,
        "lon": None,
        "location_ID": "USA - FORT PIERCE FL - 34947",
        "country": "United States",
    },
}


GENERIC_PAYLOAD_KEYS = {
    "nodes",
    "edges",
    "time_series",
    "events",
    "lots",
    "diagnostics",
}


def _to_float(x: Any) -> float | None:
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def is_pilotage_hidden_node(node_id: str) -> bool:
    return bool(node_id) and node_id in PILOTAGE_HIDDEN_NODE_IDS


def is_pilotage_hidden_edge(src: str, dst: str) -> bool:
    return is_pilotage_hidden_node(src) or is_pilotage_hidden_node(dst)


def is_upstream_internal_site(node_id: str) -> bool:
    return case_is_upstream_internal_site(node_id)


def display_node_label(node_id: str) -> str:
    return case_display_node_id(node_id)


def is_simulation_hidden_item(item_id: str) -> bool:
    return bool(item_id) and item_id in SIMULATION_HIDDEN_ITEM_IDS


def standard_order_override_for_edge(edge: dict[str, Any]) -> dict[str, Any] | None:
    src = str(edge.get("from") or "")
    dst = str(edge.get("to") or "")
    for item_id in edge.get("items") or []:
        override = standard_order_override(src, dst, item_id)
        if override:
            return override
    return None


def display_standard_order_qty(edge: dict[str, Any]) -> float:
    override = standard_order_override_for_edge(edge)
    if override:
        return max(0.0, float(override["qty"]))
    return max(0.0, _to_float(((edge.get("attrs") or {}).get("standard_order_qty")) or 0.0) or 0.0)


def compact_graph_payload(raw: dict[str, Any]) -> dict[str, Any]:
    nodes_in = raw.get("nodes", [])
    edges_in = raw.get("edges", [])
    if not isinstance(nodes_in, list) or not isinstance(edges_in, list):
        raise ValueError("Expected JSON with list fields: nodes and edges.")

    connected_node_ids: set[str] = set()
    for edge in edges_in:
        if not isinstance(edge, dict):
            continue
        src = str(edge.get("from") or "")
        dst = str(edge.get("to") or "")
        if is_pilotage_hidden_edge(src, dst):
            continue
        if src:
            connected_node_ids.add(src)
        if dst:
            connected_node_ids.add(dst)

    nodes: list[dict[str, Any]] = []
    for node in nodes_in:
        if not isinstance(node, dict):
            continue
        node_id = str(node.get("id") or "")
        if is_pilotage_hidden_node(node_id):
            continue
        inventory_states = (((node.get("inventory") or {}).get("states")) or [])
        processes = node.get("processes") or []
        if (
            node_id
            and node_id not in connected_node_ids
            and not inventory_states
            and not processes
        ):
            continue
        geo = node.get("geo", {}) or {}
        lat = node.get("lat", geo.get("lat"))
        lon = node.get("lon", geo.get("lon"))
        location_id = node.get("location_ID")
        country = geo.get("country")
        geo_override = MANUAL_GEO_OVERRIDES.get(node_id)
        if geo_override:
            lat = geo_override["lat"]
            lon = geo_override["lon"]
            location_id = geo_override["location_ID"]
            country = geo_override["country"]
        try:
            lat = float(lat) if lat is not None else None
            lon = float(lon) if lon is not None else None
        except (TypeError, ValueError):
            lat = None
            lon = None
        nodes.append(
            {
                "id": node.get("id"),
                "type": node.get("type", "unknown"),
                "name": node.get("name", ""),
                "location_ID": location_id,
                "country": country,
                "lat": lat,
                "lon": lon,
            }
        )

    edges: list[dict[str, Any]] = []
    for edge in edges_in:
        if not isinstance(edge, dict):
            continue
        src = str(edge.get("from") or "")
        dst = str(edge.get("to") or "")
        if is_pilotage_hidden_edge(src, dst):
            continue
        items = edge.get("items", [])
        if not isinstance(items, list):
            items = []
        edges.append(
            {
                "id": edge.get("id"),
                "type": edge.get("type", "unknown"),
                "from": src,
                "to": dst,
                "items": items,
                "planned_lead_days": max(1.0, _to_float(((edge.get("lead_time") or {}).get("mean"))) or 1.0),
                "distance_km": max(0.0, _to_float(edge.get("distance_km")) or 0.0),
                "standard_order_qty": display_standard_order_qty(edge),
            }
        )

    node_types = sorted({n.get("type", "unknown") for n in nodes})
    return {
        "schema_version": raw.get("schema_version"),
        "meta": raw.get("meta", {}),
        "nodes": nodes,
        "edges": edges,
        "node_types": node_types,
        "node_type_styles": NODE_TYPE_STYLES,
    }


def merge_hover_payload_maps(
    primary: dict[str, Any],
    fallback: dict[str, Any],
) -> dict[str, Any]:
    merged: dict[str, Any] = {}
    node_ids = set(primary) | set(fallback)
    for node_id in node_ids:
        primary_payload = primary.get(node_id) or {}
        fallback_payload = fallback.get(node_id) or {}
        incoming = primary_payload.get("incoming") or fallback_payload.get("incoming")
        outgoing = primary_payload.get("outgoing") or fallback_payload.get("outgoing")
        third = primary_payload.get("third") or fallback_payload.get("third")
        fourth = primary_payload.get("fourth") or fallback_payload.get("fourth")
        compare = primary_payload.get("compare") or fallback_payload.get("compare")
        if incoming or outgoing or third or fourth or compare:
            merged[node_id] = {
                "incoming": incoming,
                "outgoing": outgoing,
                "third": third,
                "fourth": fourth,
                "compare": compare,
            }
    return merged


@dataclass(frozen=True)
class PayloadSection:
    """Named business payload section consumed by the map shell."""

    key: str
    value: Any


def payload_section(key: str, value: Any) -> PayloadSection:
    if not key or not isinstance(key, str):
        raise ValueError("Payload section key must be a non-empty string.")
    return PayloadSection(key=key, value=value)


def merge_payload_sections(
    base_payload: dict[str, Any],
    sections: Iterable[PayloadSection],
) -> dict[str, Any]:
    """Return a payload copy with named sections applied in order."""

    payload = dict(base_payload)
    for section in sections:
        payload[section.key] = section.value
    return payload


def build_payload_layers_manifest(manifests: Iterable[dict[str, Any]]) -> dict[str, Any]:
    """Build a lightweight domain manifest for the map payload."""

    domains: dict[str, dict[str, Any]] = {}
    for manifest in manifests:
        domain = str(manifest.get("domain") or "")
        if not domain:
            raise ValueError("Payload layer manifest is missing a domain.")
        domains[domain] = manifest
    return {
        "version": 1,
        "domains": domains,
    }


def build_generic_payload_contract(payload: dict[str, Any]) -> dict[str, Any]:
    """Expose a stable lightweight generic view for future renderers/APIs.

    Existing maps still consume the rich legacy top-level sections.  The generic
    contract must not duplicate those heavy structures; it exposes references,
    counts and the run package metadata so future viewers can migrate without
    making autonomous HTML files much larger.
    """

    lot_trace = payload.get("lot_trace", {}) or {}
    run_contract = payload.get("run_contract", {}) or {}
    artifacts = run_contract.get("artifacts") if isinstance(run_contract, dict) else []
    if not isinstance(artifacts, list):
        artifacts = []
    return {
        "schema_version": "etudecas.map_viewer_payload.v1",
        "nodes": payload.get("nodes", []) or [],
        "edges": payload.get("edges", []) or [],
        "run_contract": run_contract,
        "artifact_domains": sorted(
            {
                str(row.get("domain"))
                for row in artifacts
                if isinstance(row, dict) and str(row.get("domain") or "")
            }
        ),
        "counts": {
            "nodes": len(payload.get("nodes", []) or []),
            "edges": len(payload.get("edges", []) or []),
            "lot_events": len(lot_trace.get("events", []) or []),
            "lot_nodes": len(lot_trace.get("lots", {}) or {}),
            "simulation_diagnostics_sections": len(payload.get("simulation_diagnostics", {}) or {}),
            "scenario_comparison_figures": len((payload.get("scenario_comparison", {}) or {}).get("figures", {}) or {}),
        },
    }


def attach_generic_payload_contract(payload: dict[str, Any]) -> dict[str, Any]:
    """Return a payload copy with the generic contract under `generic`."""

    out = dict(payload)
    out["generic"] = build_generic_payload_contract(payload)
    return out


# Consolidated from map_data_loader: unchanged business definitions.

def _map_value_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def load_json_dict(json_path: Path) -> dict[str, Any]:
    try:
        data = json.loads(json_path.read_text(encoding="utf-8")) if json_path.exists() else {}
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def read_csv_rows(csv_path: Path) -> list[dict[str, str]]:
    if not csv_path.exists():
        nested_data_path = csv_path.parent / "data" / csv_path.name
        if nested_data_path.exists():
            csv_path = nested_data_path
    if not csv_path.exists():
        return []
    with csv_path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def output_root_from_csv(csv_path: Path) -> Path:
    if csv_path.parent.name == "data":
        return csv_path.parent.parent
    return csv_path.parent


def read_timeline_horizon_days(output_root: Path) -> int | None:
    summary = load_json_dict(output_root / "summaries" / "first_simulation_summary.json")
    for key in ("timeline_days", "sim_days", "total_simulated_timeline_days"):
        value = _map_value_float(summary.get(key))
        if value is not None and value > 0:
            return int(math.ceil(value))
    return None

# Consolidated from map_render: unchanged business definitions.

def render_json_panel_html(title: str, description: str, data: Any) -> str:
    def public_panel_fields(value):
        if isinstance(value, dict):
            return {
                key: None if str(key).casefold() in {
                    "lat", "latitude", "lon", "lng", "longitude", "coordinates",
                    "site_address", "geocode_query", "bbox", "map_center"
                } else public_panel_fields(item)
                for key, item in value.items()
            }
        if isinstance(value, list):
            return [public_panel_fields(item) for item in value]
        return value

    data = public_panel_fields(data)
    pretty = json.dumps(data, indent=2, ensure_ascii=False, sort_keys=True)
    return "".join(
        [
            "<div class=\"factoryHtmlPanelContent jsonPanelContent\">",
            f"<div class=\"orderLedgerTextHeader\">{html.escape(title)}</div>",
            f"<div class=\"orderLedgerStatus\">{html.escape(description)}</div>",
            "<div class=\"jsonPanelPreWrap\">",
            f"<pre class=\"jsonPanelPre\">{html.escape(pretty)}</pre>",
            "</div>",
            "</div>",
        ]
    )


def json_html_asset(title: str, description: str, data: Any) -> dict[str, str]:
    return {
        "html": render_json_panel_html(title, description, data),
    }


def render_data_table(headers: list[str], rows: list[list[Any]]) -> str:
    if not rows:
        return "<div class=\"panelEmptyState dataEmptyState\">Aucune donnee disponible.</div>"
    header_html = "".join(f"<th>{html.escape(str(header))}</th>" for header in headers)
    body_html = "".join(
        "<tr>"
        + "".join(f"<td>{html.escape(str(cell if cell is not None else 'n/a'))}</td>" for cell in row)
        + "</tr>"
        for row in rows
    )
    return (
        "<div class=\"dataSummaryTableWrap\">"
        "<table class=\"dataSummaryTable\">"
        f"<thead><tr>{header_html}</tr></thead>"
        f"<tbody>{body_html}</tbody>"
        "</table>"
        "</div>"
    )


def render_data_kv(rows: list[tuple[str, Any]]) -> str:
    if not rows:
        return ""
    return "".join(
        [
            "<div class=\"dataKvGrid\">",
            *(
                f"<div class=\"dataKvLabel\">{html.escape(str(label))}</div>"
                f"<div class=\"dataKvValue\">{html.escape(str(value if value not in (None, '') else 'n/a'))}</div>"
                for label, value in rows
            ),
            "</div>",
        ]
    )


def html_tooltip_attrs(tooltip: str | None) -> str:
    return f" data-tooltip=\"{html.escape(tooltip, quote=True)}\" tabindex=\"0\"" if tooltip else ""


def html_tooltip_class(base_class: str, tooltip: str | None) -> str:
    base = base_class.strip()
    if not tooltip:
        return base
    return f"{base} riskTooltipHost".strip()


def render_data_panel_html(title: str, subtitle: str, sections: list[tuple[str, str]]) -> str:
    section_parts: list[str] = []
    for section_title, content in sections:
        section_parts.extend(
            [
                "<section class=\"dataSummarySection\">",
                f"<div class=\"dataSummarySectionTitle\">{html.escape(section_title)}</div>",
                content,
                "</section>",
            ]
        )
    section_html = "".join(section_parts)
    return "".join(
        [
            "<div class=\"factoryHtmlPanelContent dataSummaryPanelContent\">",
            f"<div class=\"orderLedgerTextHeader\">{html.escape(title)}</div>",
            f"<div class=\"orderLedgerStatus\">{html.escape(subtitle)}</div>",
            "<div class=\"dataSummaryScroll\">",
            section_html,
            "</div>",
            "</div>",
        ]
    )


def data_html_asset(title: str, subtitle: str, sections: list[tuple[str, str]]) -> dict[str, str]:
    return {
        "html": render_data_panel_html(title, subtitle, sections),
    }


def metric_label_value(label: str, value: Any) -> dict[str, str]:
    return {"label": label, "value": str(value)}


def metric_section(title: str) -> dict[str, str]:
    return {"label": title, "value": ""}


def fmt_qty(value: Any, digits: int = 1) -> str:
    numeric = _map_value_float(value)
    if numeric is None or math.isnan(numeric):
        return "n/a"
    return f"{numeric:,.{digits}f}".replace(",", " ")


def fmt_days(value: Any, digits: int = 1) -> str:
    numeric = _map_value_float(value)
    if numeric is None or math.isnan(numeric):
        return "n/a"
    return f"{numeric:.{digits}f} j"


def fmt_pct(value: Any, digits: int = 1) -> str:
    numeric = _map_value_float(value)
    if numeric is None or math.isnan(numeric):
        return "n/a"
    return f"{numeric:.{digits}f}%"
