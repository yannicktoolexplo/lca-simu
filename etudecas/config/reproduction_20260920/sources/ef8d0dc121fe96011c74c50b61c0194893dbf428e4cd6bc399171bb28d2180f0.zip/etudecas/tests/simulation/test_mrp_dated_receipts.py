"""Independent, in-memory examples for the opt-in dated-receipt policy.

These checks validate a bounded coverage rule, not an ERP algorithm or the
absence of shortages before the end of a coverage window. No file fixtures.
"""
from __future__ import annotations

import math
from copy import deepcopy

import pytest

from etudecas.simulation.engine import run_first_simulation as engine
from etudecas.simulation.engine.mrp_planning import (
    FirmReceipt, LotSizing, Requirement, plan_dated_requirements,
)


PAIR = ("M-1", "item:1")


def test_dated_receipts_late_order_does_not_cover_near_need():
    calendar = engine.DatedReceiptCalendar()
    calendar.add(PAIR, 12, 30)
    calendar.add(PAIR, 40, 90)

    # End-of-day 10: 20 on hand, target 100, only 30 arrives by day 16.
    eligible = calendar.quantity(PAIR, decision_day=10, through_day=16)
    assert eligible == 30
    assert max(0, 100 - 20 - eligible) == 50
    assert max(0, 100 - 20 - calendar.total(PAIR)) == 0
    assert calendar.total(PAIR) == 120


def test_dated_receipts_both_window_limits_are_inclusive():
    calendar = engine.DatedReceiptCalendar()
    for day, quantity in [(9, 2), (10, 3), (16, 5), (17, 7)]:
        calendar.add(PAIR, day, quantity)
    assert calendar.quantity(PAIR, decision_day=10, through_day=16) == 8
    assert calendar.quantity(PAIR, decision_day=10, through_day=10) == 3
    assert calendar.quantity(PAIR, decision_day=10, through_day=9) == 0
    assert calendar.total(PAIR) == 17


def test_dated_receipts_received_today_is_only_counted_as_on_hand():
    calendar = engine.DatedReceiptCalendar()
    calendar.add(PAIR, 10, 12)
    calendar.add(PAIR, 11, 8)
    # The simulator receives before planning: 5 + 12 physically on hand.
    calendar.remove(PAIR, 10, 12)
    on_hand = 17
    pending = calendar.quantity(PAIR, decision_day=10, through_day=11)
    assert pending == 8
    assert on_hand + pending == 25
    assert calendar.total(PAIR) == 8


def test_dated_receipts_exclusion_never_cancels_the_physical_receipt():
    calendar = engine.DatedReceiptCalendar()
    calendar.add(PAIR, 40, 90)
    assert calendar.quantity(PAIR, decision_day=10, through_day=16) == 0
    assert calendar.quantity(PAIR, decision_day=33, through_day=40) == 90
    assert calendar.total(PAIR) == 90
    calendar.remove(PAIR, 40, 90)
    assert calendar.total(PAIR) == 0
    assert calendar.quantity(PAIR, decision_day=40, through_day=47) == 0


def test_dated_receipts_disjoint_origins_accumulate_once_without_unit_rounding():
    calendar = engine.DatedReceiptCalendar()
    # Three distinct scheduled receipts: lane, external purchase, estimation.
    # An index lookup may neither duplicate nor consume any origin.
    for quantity in (7.25, 11.5, 13.75):
        calendar.add(PAIR, 15, quantity)
    for _ in range(3):
        assert calendar.quantity(PAIR, decision_day=10, through_day=15) == 32.5
        assert calendar.total(PAIR) == 32.5
    calendar.remove(PAIR, 15, 11.5)
    assert calendar.quantity(PAIR, decision_day=10, through_day=15) == 21
    assert calendar.total(PAIR) == 21


def test_dated_receipts_queries_follow_new_orders_and_partial_receipts():
    calendar = engine.DatedReceiptCalendar()
    calendar.add(PAIR, 12, 10)
    calendar.add(PAIR, 14, 20)
    assert calendar.quantity(PAIR, decision_day=10, through_day=14) == 30
    calendar.add(PAIR, 13, 7)
    assert calendar.quantity(PAIR, decision_day=10, through_day=14) == 37
    calendar.remove(PAIR, 12, 4)
    assert calendar.quantity(PAIR, decision_day=10, through_day=14) == 33
    calendar.remove(PAIR, 14, 20)
    assert calendar.quantity(PAIR, decision_day=13, through_day=14) == 7
    assert calendar.total(PAIR) == 13


def test_dated_receipts_does_not_mix_sites_or_articles():
    calendar = engine.DatedReceiptCalendar()
    calendar.add(PAIR, 12, 10)
    calendar.add(("M-2", "item:1"), 12, 100)
    calendar.add(("M-1", "item:2"), 12, 1000)
    assert calendar.quantity(PAIR, decision_day=10, through_day=15) == 10
    assert calendar.quantity(("missing", "item:1"), decision_day=10, through_day=15) == 0
    assert calendar.total(("M-2", "item:1")) == 100


def test_dated_receipts_fully_received_day_can_be_reused():
    calendar = engine.DatedReceiptCalendar()
    calendar.add(PAIR, 12, 10)
    calendar.remove(PAIR, 12, 10)
    assert calendar.total(PAIR) == 0
    calendar.add(PAIR, 12, 3)
    assert calendar.quantity(PAIR, decision_day=12, through_day=12) == 3
    assert calendar.total(PAIR) == 3


@pytest.mark.parametrize("value", [None, math.nan, math.inf, -1])
def test_dated_receipts_missing_or_invalid_quantity_is_not_imputed(value):
    calendar = engine.DatedReceiptCalendar()
    with pytest.raises((TypeError, ValueError)):
        calendar.add(PAIR, 12, value)
    assert calendar.total(PAIR) == 0


@pytest.mark.parametrize("day", [None, math.nan, math.inf, 12.5, True])
def test_dated_receipts_missing_or_fractional_date_is_not_imputed(day):
    calendar = engine.DatedReceiptCalendar()
    with pytest.raises((TypeError, ValueError)):
        calendar.add(PAIR, day, 10)
    assert calendar.total(PAIR) == 0


def test_dated_receipts_unknown_or_excess_receipt_is_rejected():
    calendar = engine.DatedReceiptCalendar()
    calendar.add(PAIR, 12, 10)
    for day, quantity in [(11, 1), (12, 11)]:
        with pytest.raises((KeyError, ValueError)):
            calendar.remove(PAIR, day, quantity)
    assert calendar.total(PAIR) == 10


@pytest.mark.parametrize("days, expected", [(0, 10), (1, 10), (1.1, 11), (7, 16), (7.1, 17)])
def test_dated_receipt_cover_includes_current_day(days, expected):
    assert engine.mrp_receipt_cover_end_day(10, days) == expected


@pytest.mark.parametrize("days", [None, math.nan, math.inf, -1])
def test_dated_receipt_cover_requires_documented_finite_window(days):
    with pytest.raises((TypeError, ValueError)):
        engine.mrp_receipt_cover_end_day(10, days)


def test_dated_receipt_window_does_not_claim_to_solve_intermediate_shortage():
    calendar = engine.DatedReceiptCalendar()
    calendar.add(PAIR, 16, 100)
    # Need 100 on day 11, receipt only day 16: an aggregate window credits it.
    assert calendar.quantity(PAIR, decision_day=10, through_day=16) == 100
    assert calendar.quantity(PAIR, decision_day=10, through_day=11) == 0
    # Both are true. A time-phased demand balance is still needed to detect the
    # day-11 shortage; passing these tests must not be called ERP calibration.


def test_production_safety_target_keeps_the_largest_existing_floor():
    # The three targets have one common quantity unit; they are not additive.
    assert engine.production_mrp_safety_target(500, 10, 20, 100) == 500
    assert engine.production_mrp_safety_target(50, 10, 20, 100) == 200
    assert engine.production_mrp_safety_target(50, 10, 20, 300) == 300


def test_production_safety_target_uses_converted_days_without_second_conversion():
    # 20 working days have already become 28 calendar days upstream.
    assert engine.production_mrp_safety_target(0, 125, 28, 0) == 3500
    assert engine.production_mrp_safety_target(0, 0, 28, 175) == 175
    assert engine.production_mrp_safety_target(0, 1.25, 2, 0) == 2.5


@pytest.mark.parametrize("position", range(4))
@pytest.mark.parametrize("value", [None, math.nan, math.inf, -1])
def test_production_safety_target_does_not_impute_invalid_source_values(position, value):
    arguments = [100, 10, 20, 50]
    arguments[position] = value
    with pytest.raises((TypeError, ValueError)):
        engine.production_mrp_safety_target(*arguments)


def test_production_safety_target_rejects_overflow_instead_of_infinite_orders():
    with pytest.raises(ValueError):
        engine.production_mrp_safety_target(0, 1e308, 1e308, 0)


def test_dated_planner_keeps_late_firm_quantity_without_compensatory_purchase():
    requirements = [Requirement("A", 3, 50), Requirement("B", 7, 50)]
    receipts = [FirmReceipt("F", 5, 60)]
    original = deepcopy((requirements, receipts))
    plan = plan_dated_requirements(decision_day=0, available_qty=20,
        requirements=requirements, firm_receipts=receipts, lead_days=2,
        lot_sizing=LotSizing(integer=True))
    assert [(a.requirement_id, a.supply_id, a.qty, a.delay_days) for a in plan.commitment_allocations] == [
        ("A", "opening_stock", 20, 0), ("A", "F", 30, 2), ("B", "F", 30, 0)]
    assert [(p.release_day, p.available_day, p.requested_day, p.qty) for p in plan.proposals] == [(5, 7, 7, 20)]
    assert (plan.proposed_qty, plan.late_qty, plan.late_qty_days, plan.firm_late_qty) == (20, 30, 60, 30)
    assert {b.day: (b.before_proposals_qty, b.after_proposals_qty) for b in plan.balances} == {
        0: (20, 20), 3: (-30, -30), 5: (30, 30), 7: (-20, 0)}
    assert sum(a.qty for a in plan.allocations if a.supply_id == "F") == 60
    assert sum(a.qty for a in plan.allocations) == 100
    assert plan.unallocated_firm_qty == 0
    assert plan.closing_projected_qty == 0
    assert (requirements, receipts) == original


def test_dated_planner_receipt_on_due_day_is_on_time():
    plan = plan_dated_requirements(decision_day=0, available_qty=0,
        requirements=[Requirement("A", 3, 10)], firm_receipts=[FirmReceipt("F", 3, 10)], lead_days=2)
    assert plan.proposals == ()
    assert plan.late_qty == 0
    assert plan.closing_projected_qty == 0
    assert [(a.available_day, a.due_day, a.qty) for a in plan.allocations] == [(3, 3, 10)]


def test_dated_planner_very_late_firm_is_not_cancelled_or_bought_again():
    plan = plan_dated_requirements(decision_day=0, available_qty=0,
        requirements=[Requirement("A", 3, 50)], firm_receipts=[FirmReceipt("F", 20, 100)], lead_days=2)
    assert plan.proposals == ()
    assert (plan.late_qty, plan.late_qty_days, plan.unallocated_firm_qty) == (50, 850, 50)
    assert {b.day: b.after_proposals_qty for b in plan.balances} == {0: 0, 3: -50, 20: 50}


def test_dated_planner_new_proposal_respects_earliest_possible_arrival():
    plan = plan_dated_requirements(decision_day=4, available_qty=0,
        requirements=[Requirement("A", 5, 50)], firm_receipts=[], lead_days=3)
    assert [(p.release_day, p.available_day, p.requested_day, p.qty) for p in plan.proposals] == [(4, 7, 5, 50)]
    assert (plan.late_qty, plan.late_qty_days, plan.firm_late_qty) == (50, 100, 0)
    assert plan.balances[-1].after_proposals_qty == 0


def test_dated_planner_minimum_surplus_is_reused_by_later_need():
    plan = plan_dated_requirements(decision_day=0, available_qty=0,
        requirements=[Requirement("A", 3, 10), Requirement("B", 7, 5)], firm_receipts=[], lead_days=2,
        lot_sizing=LotSizing(minimum=20, integer=True))
    assert [(p.release_day, p.available_day, p.qty) for p in plan.proposals] == [(1, 3, 20)]
    assert plan.closing_projected_qty == 5
    assert plan.late_qty == 0
    assert [(a.requirement_id, a.qty, a.available_day) for a in plan.allocations] == [("A", 10, 3), ("B", 5, 3)]


def test_dated_planner_lot_maximum_limits_each_order_not_daily_capacity():
    plan = plan_dated_requirements(decision_day=0, available_qty=0,
        requirements=[Requirement("A", 7, 250)], firm_receipts=[], lead_days=2,
        lot_sizing=LotSizing(minimum=50, multiple=50, maximum=100, integer=True))
    assert [(p.release_day, p.available_day, p.qty) for p in plan.proposals] == [(5, 7, 100), (5, 7, 100), (5, 7, 50)]
    assert plan.proposed_qty == 250
    assert plan.closing_projected_qty == 0


def test_dated_planner_fractional_forecast_produces_whole_units_and_carries_surplus():
    plan = plan_dated_requirements(decision_day=0, available_qty=0,
        requirements=[Requirement("A", 3, 1.2), Requirement("B", 7, 1.2)], firm_receipts=[], lead_days=2,
        lot_sizing=LotSizing(integer=True))
    assert [(p.available_day, p.qty) for p in plan.proposals] == [(3, 2), (7, 1)]
    assert plan.proposed_qty == 3
    assert plan.closing_projected_qty == pytest.approx(0.6)
    assert sum(a.qty for a in plan.allocations) == pytest.approx(2.4)


def test_dated_planner_fractional_forecast_does_not_create_one_unit_from_roundoff():
    # Decimal arithmetic: 30 * 0.1 = 3, so the existing 3 UN cover every need.
    needs = [Requirement(f"N-{i:02d}", i + 1, 0.1) for i in range(30)]
    plan = plan_dated_requirements(decision_day=0, available_qty=3,
        requirements=needs, firm_receipts=[], lead_days=2, lot_sizing=LotSizing(integer=True))
    assert plan.proposals == ()
    assert plan.proposed_qty == 0
    assert plan.late_qty == 0
    assert sum(a.qty for a in plan.allocations) == pytest.approx(3)
    assert plan.closing_projected_qty == pytest.approx(0)


def test_dated_planner_known_zero_need_preserves_unallocated_firm_stock():
    plan = plan_dated_requirements(decision_day=0, available_qty=2,
        requirements=[Requirement("A", 3, 0)], firm_receipts=[FirmReceipt("F", 5, 10)], lead_days=2)
    assert plan.proposals == ()
    assert plan.allocations == ()
    assert (plan.unallocated_firm_qty, plan.closing_projected_qty) == (10, 12)


def test_dated_planner_distinct_receipt_states_contribute_once_each():
    receipts = [FirmReceipt("held", 2, 3, "held"), FirmReceipt("transit", 3, 4, "in_transit"),
                FirmReceipt("confirmed", 5, 5, "confirmed")]
    plan = plan_dated_requirements(decision_day=0, available_qty=0,
        requirements=[Requirement("A", 7, 12)], firm_receipts=receipts, lead_days=2)
    assert plan.proposals == ()
    assert [(a.supply_kind, a.qty) for a in plan.allocations] == [("held", 3), ("in_transit", 4), ("confirmed", 5)]
    assert plan.closing_projected_qty == 0


def test_dated_planner_input_permutation_keeps_same_quantities_dates_and_allocations():
    needs = [Requirement("B", 7, 50), Requirement("A", 3, 50)]
    receipts = [FirmReceipt("G", 8, 20), FirmReceipt("F", 5, 40)]
    args = {"decision_day": 0, "available_qty": 20, "lead_days": 2, "lot_sizing": LotSizing(integer=True)}
    first = plan_dated_requirements(requirements=needs, firm_receipts=receipts, **args)
    second = plan_dated_requirements(requirements=needs[::-1], firm_receipts=receipts[::-1], **args)
    assert first == second


@pytest.mark.parametrize("value", [None, math.nan, math.inf, -1, True])
@pytest.mark.parametrize("field", ["available", "requirement", "firm"])
def test_dated_planner_missing_invalid_quantity_is_not_imputed(field, value):
    with pytest.raises(ValueError):
        plan_dated_requirements(decision_day=0, available_qty=value if field == "available" else 0,
            requirements=[Requirement("A", 3, value if field == "requirement" else 10)],
            firm_receipts=[FirmReceipt("F", 3, value if field == "firm" else 10)], lead_days=2)


@pytest.mark.parametrize("value", [None, math.nan, 1.5, True])
@pytest.mark.parametrize("field", ["decision", "due", "receipt", "lead"])
def test_dated_planner_missing_noninteger_day_is_not_imputed(field, value):
    with pytest.raises(ValueError):
        plan_dated_requirements(decision_day=value if field == "decision" else 0, available_qty=0,
            requirements=[Requirement("A", value if field == "due" else 3, 10)],
            firm_receipts=[FirmReceipt("F", value if field == "receipt" else 3, 10)],
            lead_days=value if field == "lead" else 2)


@pytest.mark.parametrize("kind", ["requirement", "firm"])
def test_dated_planner_duplicate_identity_is_rejected(kind):
    needs = [Requirement("A", 3, 10)] * (2 if kind == "requirement" else 1)
    receipts = [FirmReceipt("F", 3, 10)] * (2 if kind == "firm" else 1)
    with pytest.raises(ValueError):
        plan_dated_requirements(decision_day=0, available_qty=0,
            requirements=needs, firm_receipts=receipts, lead_days=2)


def test_dated_planner_past_firm_requires_reconciliation_with_available_stock():
    with pytest.raises(ValueError):
        plan_dated_requirements(decision_day=4, available_qty=10,
            requirements=[Requirement("A", 7, 10)], firm_receipts=[FirmReceipt("F", 3, 10)], lead_days=2)


@pytest.mark.parametrize("policy", [LotSizing(minimum=20, maximum=10), LotSizing(maximum=0),
    LotSizing(multiple=10, maximum=5), LotSizing(minimum=1.5, integer=True), LotSizing(multiple=-1)])
def test_dated_planner_inconsistent_lot_policy_is_rejected(policy):
    with pytest.raises(ValueError):
        plan_dated_requirements(decision_day=0, available_qty=0,
            requirements=[Requirement("A", 3, 10)], firm_receipts=[], lead_days=2, lot_sizing=policy)


def dated_network_inputs():
    return {"decision_day": 0, "requirements_by_pair": {}, "available_by_pair": {},
            "firm_receipts_by_pair": {}, "transport_sources_by_pair": {}, "bom_by_pair": {},
            "lead_days_by_pair": {}, "lot_sizing_by_pair": {}, "reserve_targets_by_pair": {},
            "coverage_days_by_pair": {}, "active_campaigns_by_pair": {}}


def test_dated_network_available_finished_stock_prevents_component_orders():
    depot, plant, component = ("DC", "PF"), ("M", "PF"), ("M", "MP")
    args = dated_network_inputs()
    args.update(requirements_by_pair={depot: [Requirement("customer", 10, 10)]},
                available_by_pair={depot: 10}, transport_sources_by_pair={depot: [(plant, 1)]},
                bom_by_pair={plant: [(component, 3)]})
    original = deepcopy(args)
    plans, requirements, _ = engine.plan_component_network(**args)
    assert all(plan.proposed_qty == 0 for plan in plans.values())
    assert sum(r.qty for r in requirements[component]) == 0
    assert args == original


def test_dated_network_nets_stock_before_two_same_site_processes_and_transport():
    depot, plant, semi, component = ("DC", "PF"), ("M", "PF"), ("M", "SEMI"), ("M", "MP")
    args = dated_network_inputs()
    args.update(requirements_by_pair={depot: [Requirement("customer", 20, 10)]},
                available_by_pair={plant: 5}, transport_sources_by_pair={depot: [(plant, 1)]},
                bom_by_pair={plant: [(semi, 2)], semi: [(component, 3)]},
                lead_days_by_pair={depot: 2, plant: 3, semi: 4, component: 5})
    plans, requirements, _ = engine.plan_component_network(**args)
    assert {pair: p.proposed_qty for pair, p in plans.items()} == {depot: 10, plant: 5, semi: 10, component: 30}
    assert [(r.due_day, r.qty) for r in requirements[plant]] == [(18, 10)]
    assert [(r.due_day, r.qty) for r in requirements[semi]] == [(15, 10)]
    assert [(r.due_day, r.qty) for r in requirements[component]] == [(11, 30)]
    assert [(p.release_day, p.available_day, p.qty) for p in plans[component].proposals] == [(6, 11, 30)]


def test_dated_network_inter_site_intermediate_transport_explodes_bom_once():
    final, semi_at_final, semi_at_origin, raw = ("M-A", "PF"), ("M-A", "SEMI"), ("M-B", "SEMI"), ("M-B", "MP")
    args = dated_network_inputs()
    args.update(requirements_by_pair={final: [Requirement("customer", 30, 10)]},
                bom_by_pair={final: [(semi_at_final, 2)], semi_at_origin: [(raw, 3)]},
                transport_sources_by_pair={semi_at_final: [(semi_at_origin, 1)]})
    plans, requirements, _ = engine.plan_component_network(**args)
    assert plans[final].proposed_qty == 10
    assert plans[semi_at_final].proposed_qty == 20
    assert plans[semi_at_origin].proposed_qty == 20
    assert plans[raw].proposed_qty == 60
    assert sum(r.qty for r in requirements[raw]) == 60


def test_dated_network_active_wip_credits_output_once_and_needs_only_remaining_components():
    product, component = ("M", "PF"), ("M", "MP")
    args = dated_network_inputs()
    args.update(requirements_by_pair={product: [Requirement("customer", 10, 100)]},
                bom_by_pair={product: [(component, 1)]},
                active_campaigns_by_pair={product: ("C", 20, 80, 5)})
    plans, requirements, audit = engine.plan_component_network(**args)
    assert plans[product].proposed_qty == 0
    assert [(a.supply_id, a.qty) for a in plans[product].allocations] == [("campaign:C", 100)]
    assert sum(r.qty for r in requirements[component]) == 20
    assert plans[component].proposed_qty == 20
    assert audit[component]["campaign_remaining_qty"] == 20


def test_dated_network_committed_campaign_needs_components_without_new_forecast():
    product, component = ("M", "PF"), ("M", "MP")
    args = dated_network_inputs()
    args.update(bom_by_pair={product: [(component, 2)]},
                active_campaigns_by_pair={product: ("C", 20, 80, 5)})
    plans, requirements, _ = engine.plan_component_network(**args)
    assert plans[product].proposed_qty == 0
    assert plans[product].unallocated_firm_qty == 100
    assert sum(r.qty for r in requirements[component]) == 40
    assert plans[component].proposed_qty == 40


def test_dated_network_campaign_also_supplied_as_firm_is_rejected():
    product = ("M", "PF")
    args = dated_network_inputs()
    args.update(requirements_by_pair={product: [Requirement("customer", 10, 100)]},
                active_campaigns_by_pair={product: ("C", 20, 80, 5)},
                firm_receipts_by_pair={product: [FirmReceipt("campaign:C", 5, 100, "confirmed")]})
    with pytest.raises(ValueError):
        engine.plan_component_network(**args)


def test_dated_network_late_commitment_does_not_explode_repurchase_into_bom():
    product, component = ("M", "PF"), ("M", "MP")
    args = dated_network_inputs()
    args.update(requirements_by_pair={product: [Requirement("A", 3, 50), Requirement("B", 7, 50)]},
                available_by_pair={product: 20}, firm_receipts_by_pair={product: [FirmReceipt("F", 5, 60)]},
                lead_days_by_pair={product: 2}, bom_by_pair={product: [(component, 3)]})
    plans, requirements, _ = engine.plan_component_network(**args)
    assert plans[product].proposed_qty == 20
    assert plans[product].firm_late_qty == 30
    assert sum(r.qty for r in requirements[component]) == 60
    assert [(r.due_day, r.qty) for r in requirements[component]] == [(5, 60)]


def test_dated_network_transport_shares_conserve_quantity():
    destination, left, right = ("M", "MP"), ("S-A", "MP"), ("S-B", "MP")
    args = dated_network_inputs()
    args.update(requirements_by_pair={destination: [Requirement("need", 10, 100)]},
                transport_sources_by_pair={destination: [(left, 0.25), (right, 0.75)]})
    plans, requirements, _ = engine.plan_component_network(**args)
    assert sum(r.qty for r in requirements[left]) == 25
    assert sum(r.qty for r in requirements[right]) == 75
    assert plans[left].proposed_qty + plans[right].proposed_qty == 100


def test_dated_network_reserve_is_complementary_to_gross_cover_not_added_twice():
    args = dated_network_inputs()
    args.update(requirements_by_pair={PAIR: [Requirement("need", 3, 80)]},
                reserve_targets_by_pair={PAIR: 100}, coverage_days_by_pair={PAIR: 7})
    plans, requirements, audit = engine.plan_component_network(**args)
    assert audit[PAIR]["reserve_requirement_qty"] == 20
    assert sum(r.qty for r in requirements[PAIR]) == 100
    assert plans[PAIR].proposed_qty == 100


def test_dated_network_cycle_rejected_before_any_physical_state_changes():
    first, second = ("M", "A"), ("M", "B")
    args = dated_network_inputs()
    args.update(requirements_by_pair={first: [Requirement("need", 10, 1)]},
                bom_by_pair={first: [(second, 1)], second: [(first, 1)]})
    original = deepcopy(args)
    with pytest.raises(ValueError, match="acyclic"):
        engine.plan_component_network(**args)
    assert args == original


@pytest.mark.parametrize("field,value", [
    ("lead_days_by_pair", 1.5), ("lead_days_by_pair", True), ("lead_days_by_pair", -1),
    ("coverage_days_by_pair", 1.5), ("coverage_days_by_pair", True), ("coverage_days_by_pair", -1),
    ("reserve_targets_by_pair", None), ("reserve_targets_by_pair", math.nan),
    ("reserve_targets_by_pair", math.inf), ("reserve_targets_by_pair", -1),
])
def test_dated_network_invalid_policy_is_not_rounded_or_imputed(field, value):
    args = dated_network_inputs()
    args["requirements_by_pair"] = {PAIR: [Requirement("need", 10, 1)]}
    args[field] = {PAIR: value}
    with pytest.raises(ValueError):
        engine.plan_component_network(**args)


@pytest.mark.parametrize("shares", [(0.4, 0.4), (0.7, 0.7), (True, 0.5)])
def test_dated_network_invalid_transport_split_cannot_create_or_lose_requirements(shares):
    args = dated_network_inputs()
    args.update(requirements_by_pair={PAIR: [Requirement("need", 10, 100)]},
                transport_sources_by_pair={PAIR: [(("S-A", PAIR[1]), shares[0]), (("S-B", PAIR[1]), shares[1])]})
    with pytest.raises(ValueError):
        engine.plan_component_network(**args)
