"""Pure dated material planning, independent of the daily physical simulation.

Existing commitments are netted before proposing additional purchases, even
when late. This explicit no-duplicate-purchase convention is not claimed to be
the unidentified industrial ERP policy. Dates of firm receipts never change.
The signed balances are projections, not negative physical inventories.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from math import ceil, floor, fsum, isfinite
from typing import Iterable


@dataclass(frozen=True)
class Requirement:
    requirement_id: str
    due_day: int
    qty: float


@dataclass(frozen=True)
class FirmReceipt:
    receipt_id: str
    available_day: int
    qty: float
    state: str = "in_transit"


@dataclass(frozen=True)
class LotSizing:
    minimum: float = 0.0
    multiple: float = 0.0
    maximum: float | None = None
    integer: bool = False


@dataclass(frozen=True)
class Allocation:
    requirement_id: str
    supply_id: str
    supply_kind: str
    qty: float
    due_day: int
    available_day: int
    delay_days: int


@dataclass(frozen=True)
class OrderProposal:
    proposal_id: str
    release_day: int
    available_day: int
    requested_day: int
    qty: float


@dataclass(frozen=True)
class ProjectedBalance:
    day: int
    requirement_qty: float
    firm_receipt_qty: float
    proposed_receipt_qty: float
    before_proposals_qty: float
    after_proposals_qty: float


@dataclass(frozen=True)
class DatedPlan:
    decision_day: int
    opening_available_qty: float
    commitment_allocations: tuple[Allocation, ...]
    allocations: tuple[Allocation, ...]
    proposals: tuple[OrderProposal, ...]
    balances: tuple[ProjectedBalance, ...]
    late_qty: float
    late_qty_days: float
    firm_late_qty: float
    proposed_qty: float
    unallocated_firm_qty: float
    closing_projected_qty: float


def _number(value: float, field: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{field} must be a finite nonnegative quantity")
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field} must be a finite nonnegative quantity") from exc
    if not isfinite(number) or number < 0:
        raise ValueError(f"{field} must be a finite nonnegative quantity")
    return number


def _day(value: int, field: str) -> int:
    if type(value) is not int:
        raise ValueError(f"{field} must be an integer day")
    return value


def _identity(value: str, seen: set[str], field: str) -> None:
    if not isinstance(value, str) or not value.strip() or value in seen:
        raise ValueError(f"{field} must be nonempty and unique")
    seen.add(value)


def _lot_bounds(policy: LotSizing) -> tuple[float, float, float | None]:
    if type(policy.integer) is not bool:
        raise ValueError("integer must be a boolean")
    minimum = _number(policy.minimum, "minimum")
    multiple = _number(policy.multiple, "multiple")
    maximum = None if policy.maximum is None else _number(policy.maximum, "maximum")
    if maximum is not None and (maximum == 0 or minimum > maximum):
        raise ValueError("maximum must be positive and at least minimum")
    if policy.integer:
        # Bounds and purchase multiples are physical; forecasts may be fractional.
        for value in (minimum, multiple, maximum):
            if value is not None and value != floor(value):
                raise ValueError("Physical UN lot bounds must be integers")
    if multiple:
        step = Decimal(str(multiple))
        minimum = _number(float(ceil(Decimal(str(minimum)) / step) * step), "rounded minimum")
        if maximum is not None:
            maximum = float(floor(Decimal(str(maximum)) / step) * step)
            if maximum == 0 or minimum > maximum:
                raise ValueError("No purchase lot satisfies the bounds and multiple")
    return minimum, multiple, maximum


def _allocate(requirements, supplies):
    """FIFO needs and earliest availability; inputs contain only local copies."""
    # Decimal conversion of the declared quantities avoids a ghost UN purchase
    # after subtracting thirty 0.1 forecasts from three physical units.
    pools = [[identity, day, Decimal(str(qty)), kind] for identity, day, qty, kind in supplies]
    pools.sort(key=lambda row: (row[1], row[0]))
    allocations, missing = [], []
    cursor = 0
    for requirement in requirements:
        remaining = Decimal(str(requirement.qty))
        while remaining > 0 and cursor < len(pools):
            supply = pools[cursor]
            if supply[2] <= 0:
                cursor += 1
                continue
            qty = min(remaining, supply[2])
            allocations.append(Allocation(
                requirement.requirement_id, supply[0], supply[3], float(qty),
                requirement.due_day, supply[1], max(0, supply[1] - requirement.due_day),
            ))
            remaining -= qty
            supply[2] -= qty
        if remaining > 0:
            missing.append(Requirement(requirement.requirement_id, requirement.due_day, float(remaining)))
    return tuple(allocations), tuple(missing), pools


def plan_dated_requirements(
    *, decision_day: int, available_qty: float,
    requirements: Iterable[Requirement], firm_receipts: Iterable[FirmReceipt],
    lead_days: int, lot_sizing: LotSizing | None = None,
) -> DatedPlan:
    """Propose quantities not covered by stock/commitments and expose lateness.

    Requirements describe remaining needs, not repeated daily MPS signals.
    Firm receipts include each held or undelivered quantity exactly once, at its
    availability date. Receipts already available belong in available_qty.
    New proposals remain revocable until their release is physically executed.
    Lot maxima limit one order, not total daily manufacturing capacity.
    """
    decision_day = _day(decision_day, "decision_day")
    lead_days = _day(lead_days, "lead_days")
    if lead_days < 0:
        raise ValueError("lead_days must be nonnegative")
    available = _number(available_qty, "available_qty")
    policy = lot_sizing or LotSizing()
    minimum, multiple, maximum = _lot_bounds(policy)
    if policy.integer and available != floor(available):
        raise ValueError("Physical UN available stock must be integer")
    needs, receipts = tuple(requirements), tuple(firm_receipts)
    seen = set()
    for row in needs:
        _identity(row.requirement_id, seen, "requirement_id")
        _day(row.due_day, "due_day")
        _number(row.qty, "requirement qty")
    needs = tuple(sorted(needs, key=lambda row: (row.due_day, row.requirement_id)))
    seen = {"opening_stock"}
    supplies = [("opening_stock", decision_day, available, "available")]
    for row in receipts:
        _identity(row.receipt_id, seen, "receipt_id")
        _day(row.available_day, "available_day")
        if row.available_day < decision_day:
            raise ValueError("Past receipts must be reconciled with available stock")
        qty = _number(row.qty, "firm receipt qty")
        if policy.integer and qty != floor(qty):
            raise ValueError("Physical UN firm receipts must be integer")
        if row.state not in ("held", "in_transit", "confirmed"):
            raise ValueError("Firm receipt state must be held, in_transit or confirmed")
        supplies.append((row.receipt_id, row.available_day, qty, row.state))

    committed_allocations, missing, _ = _allocate(needs, supplies)
    proposals = []
    surplus = Decimal(0)
    for requirement in missing:
        remainder = Decimal(str(requirement.qty))
        need = max(Decimal(0), remainder - surplus)
        surplus = max(Decimal(0), surplus - remainder)
        while need > 0:
            qty = max(need, Decimal(str(minimum)))
            if multiple:
                qty = ceil(qty / Decimal(str(multiple))) * Decimal(str(multiple))
            if policy.integer:
                qty = Decimal(ceil(qty))
            if maximum is not None:
                qty = min(qty, Decimal(str(maximum)))
            _number(qty, "proposal qty")
            if qty <= 0:
                raise ValueError("Lot policy produced a zero purchase for a positive need")
            release = max(decision_day, requirement.due_day - lead_days)
            arrival = release + lead_days
            proposal_id = f"proposal:{len(proposals) + 1}"
            if proposal_id in seen:
                raise ValueError("Receipt id collides with a generated proposal id")
            proposals.append(OrderProposal(proposal_id, release, arrival, requirement.due_day, float(qty)))
            surplus += max(Decimal(0), qty - need)
            need = max(Decimal(0), need - qty)

    # Minimum/multiple rounding may provide earlier surplus. Reallocate by actual
    # availability so lateness is not overstated when that surplus covers a need.
    all_supplies = supplies + [(p.proposal_id, p.available_day, p.qty, "proposal") for p in proposals]
    allocations, uncovered, leftovers = _allocate(needs, all_supplies)
    if uncovered:
        raise ArithmeticError("Proposed plan does not cover every remaining quantity")
    events: dict[int, list[list[float]]] = {decision_day: [[], [], []]}
    for row in needs:
        events.setdefault(max(decision_day, row.due_day), [[], [], []])[0].append(float(row.qty))
    for row in receipts:
        events.setdefault(row.available_day, [[], [], []])[1].append(float(row.qty))
    for row in proposals:
        events.setdefault(row.available_day, [[], [], []])[2].append(row.qty)
    balances = []
    before = after = Decimal(str(available))
    for day, amounts in sorted(events.items()):
        needed, firm, proposed = (sum((Decimal(str(value)) for value in group), Decimal(0)) for group in amounts)
        before += firm - needed
        after += firm + proposed - needed
        if not isfinite(before) or not isfinite(after):
            raise ValueError("Projected balance overflow")
        balances.append(ProjectedBalance(day, float(needed), float(firm), float(proposed), float(before), float(after)))
    return DatedPlan(
        decision_day, available, committed_allocations, allocations, tuple(proposals), tuple(balances),
        fsum(a.qty for a in allocations if a.delay_days),
        fsum(a.qty * a.delay_days for a in allocations),
        fsum(a.qty for a in allocations if a.delay_days and a.supply_kind in ("held", "in_transit", "confirmed")),
        fsum(p.qty for p in proposals),
        fsum(p[2] for p in leftovers if p[3] in ("held", "in_transit", "confirmed")),
        float(after),
    )
