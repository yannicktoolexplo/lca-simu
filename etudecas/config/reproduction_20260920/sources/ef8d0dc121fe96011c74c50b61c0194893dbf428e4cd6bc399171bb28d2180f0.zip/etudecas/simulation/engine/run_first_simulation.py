#!/usr/bin/env python3
"""
Run a first-pass supply simulation from a simulation-ready graph JSON.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import re
import subprocess
import sys
from bisect import bisect_left, bisect_right
from collections import defaultdict, deque
from datetime import date, timedelta
from pathlib import Path
from typing import Any, Mapping

try:
    from etudecas.simulation.result_paths import data_path, ensure_standard_dirs, map_path, plots_path, report_path, summary_path
except ModuleNotFoundError:
    sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
    from etudecas.simulation.result_paths import data_path, ensure_standard_dirs, map_path, plots_path, report_path, summary_path

from etudecas.simulation.engine.model_semantics import (
    ReceiptLeadObservations, inventory_holding_rate, safety_calendar_anchor,
    safety_calendar_days, shipment_execution_state, transport_charge,
)
from etudecas.simulation.engine.mrp_planning import (
    FirmReceipt, LotSizing, Requirement, plan_dated_requirements,
)

from etudecas.case_config import (
    DEFAULT_PRODUCTION_COST_LINE_PROFILES,
    DEFAULT_PRODUCTION_COST_LINE_SHARES,
    DEFAULT_PRODUCTION_COST_UNIT_RATES,
    LOT_TRACE_DEFAULT_LOGISTICS_ASSUMPTIONS,
    REFERENCE_TRANSITIONS,
    is_upstream_internal_site,
    standard_order_override,
)

from etudecas.simulation.lot_trace.campaigns import (
    PRODUCTION_CAMPAIGN_FIELDS,
    build_production_campaign_rows,
)
from etudecas.simulation.lot_trace.causal_links import LOT_CAUSAL_EVENT_FIELDS, LOT_CAUSAL_GENEALOGY_FIELDS, PLAN_CAUSAL_FIELDS, causal_status, inherited_causal_fields, join_ids, planned_order_reference, resolved_causal_status, split_ids, stable_reference_id
from etudecas.simulation.lot_trace.causal_links import (
    LOT_CAUSAL_LINK_FIELDS,
    build_lot_causal_link_rows,
)
from etudecas.simulation.lot_trace.schema import LOT_TRACE_CONTRACT_VERSION

from etudecas.simulation.analysis.factory_nervousness import (
    FACTORY_NERVOUSNESS_FIELDS,
    build_factory_nervousness_rows,
)

from etudecas.simulation.lot_trace.campaigns import LOT_EXECUTION_SEMANTICS_VERSION, ProductionBatchWip, make_batch_id, physical_batch_target_qty, production_week_index

from etudecas.simulation.engine.control_schedule import (
    CONTROL_LEDGER_COLUMNS,
    ControlCatalog,
    ControlScheduleError,
    ResolvedControl,
    load_control_schedule,
)

from etudecas.simulation.engine.control_provider import (
    CanonicalObservation,
    ControlProviderError,
    StateFeedbackControlProvider,
    load_state_feedback_control_provider,
)

from etudecas.simulation.engine.control_provider_v2 import (
    load_state_feedback_control_provider_v2,
)

from etudecas.simulation.engine.control_provider_v3 import (
    load_state_feedback_control_provider_v3,
)

from etudecas.simulation.engine.control_probe import (
    CONTROL_PROBE_ACTIONS,
    CONTROL_PROBE_COMPOSITION_COLUMNS,
    CONTROL_PROBE_MODE,
    ControlProbeError,
    ProbeResolvedControl,
    compose_feedback_with_probe,
    load_control_probe_schedule,
)

from etudecas.simulation.engine.demand_perturbation import (
    DEMAND_MULTIPLIER_MAX,
    DEMAND_MULTIPLIER_MIN,
    DEMAND_PERTURBATION_AUDIT_COLUMNS,
    DemandPerturbationError,
    load_demand_perturbation_schedule,
)
from etudecas.simulation.lot_policy import (
    available_component_quantity,
    normalize_physical_quantity,
    required_component_quantity,
    resolve_canonical_lane_lot,
    resolve_internal_dispatch_multiple,
)

from etudecas.simulation.logistics import estimate_internal_truck_handling


SUPPLIER_FUNCTIONAL_CAPACITY_HEADROOM_FACTOR = 2.5
FACTORY_NOMINAL_TARGET_UTILIZATION = 0.70
SUPPLIER_UPSTREAM_SUPPLY_NODE_ID = "SUPPLIER_UPSTREAM_SUPPLY"
SUPPLIER_UPSTREAM_SUPPLY_EDGE_PREFIX = "SUPPLIER_UPSTREAM_SUPPLY"
SUPPLIER_STATE_RISK_FAMILIES = (
    "stock",
    "capacity",
    "lead",
    "availability",
    "upstream",
    "reliability",
    "quality",
    "cost",
)
LOT_TRACE_EPS = 1e-6


def _parse_supplier_state_risk_families(value: str) -> tuple[str, ...]:
    """Parse an explicit state-risk family allowlist in canonical order."""

    tokens = [token.strip().casefold() for token in str(value or "").split(",")]
    selected = {token for token in tokens if token}
    if not selected or selected == {"all"}:
        return SUPPLIER_STATE_RISK_FAMILIES
    if "all" in selected:
        raise argparse.ArgumentTypeError(
            "'all' cannot be combined with explicit supplier state-risk families"
        )
    unknown = sorted(selected - set(SUPPLIER_STATE_RISK_FAMILIES))
    if unknown:
        raise argparse.ArgumentTypeError(
            "unknown supplier state-risk families: " + ", ".join(unknown)
        )
    return tuple(
        family for family in SUPPLIER_STATE_RISK_FAMILIES if family in selected
    )


def _nonnegative_finite_float(value: str) -> float:
    """Parse a finite non-negative CLI factor without silently clipping it."""

    try:
        parsed = float(value)
    except (TypeError, ValueError) as exc:
        raise argparse.ArgumentTypeError("must be a number") from exc
    if not math.isfinite(parsed) or parsed < 0.0:
        raise argparse.ArgumentTypeError("must be finite and greater than or equal to 0")
    return parsed


def _load_pair_stock_scale_overrides(
    csv_path: Path,
    *,
    valid_pairs: set[tuple[str, str]],
    context: str,
) -> tuple[dict[tuple[str, str], float], str]:
    """Load a strict node/item stock-scale sensitivity schedule."""

    if not csv_path.exists() or not csv_path.is_file():
        raise ValueError(f"{context} CSV not found: {csv_path}")
    raw_bytes = csv_path.read_bytes()
    with csv_path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        actual_columns = list(reader.fieldnames or [])
        required_columns = ["node_id", "item_id", "scale"]
        if set(actual_columns) != set(required_columns) or len(actual_columns) != 3:
            raise ValueError(
                f"{context} CSV columns must be exactly "
                "node_id,item_id,scale"
            )
        overrides: dict[tuple[str, str], float] = {}
        for line_number, row in enumerate(reader, start=2):
            node_id = str(row.get("node_id") or "").strip()
            item_id = str(row.get("item_id") or "").strip()
            if not node_id or not item_id:
                raise ValueError(
                    f"{context} CSV line {line_number}: "
                    "node_id and item_id are required"
                )
            pair = (node_id, item_id)
            if pair in overrides:
                raise ValueError(
                    f"{context} CSV line {line_number}: "
                    f"duplicate pair {node_id},{item_id}"
                )
            if pair not in valid_pairs:
                raise ValueError(
                    f"{context} CSV line {line_number}: "
                    f"pair {node_id},{item_id} is not an inventory state in the graph"
                )
            try:
                scale = _nonnegative_finite_float(str(row.get("scale") or ""))
            except argparse.ArgumentTypeError as exc:
                raise ValueError(
                    f"{context} CSV line {line_number}: "
                    f"scale {exc}"
                ) from exc
            overrides[pair] = scale
    if not overrides:
        raise ValueError(f"{context} CSV must contain at least one row")
    return overrides, hashlib.sha256(raw_bytes).hexdigest()


def load_opening_observed_stock_scale_overrides(
    csv_path: Path,
    *,
    valid_pairs: set[tuple[str, str]],
) -> tuple[dict[tuple[str, str], float], str]:
    """Load strict pair-scoped pre-warmup opening-stock factors."""

    return _load_pair_stock_scale_overrides(
        csv_path,
        valid_pairs=valid_pairs,
        context="opening observed stock scale",
    )


def load_measurement_start_stock_scale_overrides(
    csv_path: Path,
    *,
    valid_pairs: set[tuple[str, str]],
) -> tuple[dict[tuple[str, str], float], str]:
    """Load strict pair-scoped measured-J0 cutover stock factors."""

    return _load_pair_stock_scale_overrides(
        csv_path,
        valid_pairs=valid_pairs,
        context="measurement-start stock scale",
    )


def load_measurement_start_in_transit_scale_overrides(
    csv_path: Path,
    *,
    valid_pairs: set[tuple[str, str]],
) -> tuple[dict[tuple[str, str], float], str]:
    """Load strict pair-scoped measured-J0 standard-pipeline factors."""

    overrides, source_sha256 = _load_pair_stock_scale_overrides(
        csv_path,
        valid_pairs=valid_pairs,
        context="measurement-start in-transit scale",
    )
    above_one = [pair for pair, factor in overrides.items() if factor > 1.0]
    if above_one:
        node_id, item_id = above_one[0]
        raise ValueError(
            "measurement-start in-transit scale CSV factor must be between "
            f"0 and 1 for {node_id},{item_id}"
        )
    return overrides, source_sha256


def _attach_shipment_trace_ids(
    delivery_schedule: list[tuple[int, float, float]],
    *,
    start_sequence: int,
    risk_event_ids: list[Any] | tuple[Any, ...],
) -> tuple[list[tuple[int, float, float, str, str]], int]:
    """Attach one stable transaction ID to every physical delivery chunk."""

    sequence = int(start_sequence)
    event_ids_text = ",".join(
        dict.fromkeys(str(event_id) for event_id in risk_event_ids if str(event_id))
    )
    traced: list[tuple[int, float, float, str, str]] = []
    for arrival_day, pulled_qty, delivered_qty in delivery_schedule:
        sequence += 1
        traced.append(
            (
                int(arrival_day),
                float(pulled_qty),
                float(delivered_qty),
                f"SHIP-{sequence:08d}",
                event_ids_text,
            )
        )
    return traced, sequence


def _finite_median(values: list[float]) -> float | None:
    """Return the median of finite values without introducing dependencies."""

    ordered = sorted(float(value) for value in values if math.isfinite(float(value)))
    if not ordered:
        return None
    middle = len(ordered) // 2
    if len(ordered) % 2:
        return ordered[middle]
    return 0.5 * (ordered[middle - 1] + ordered[middle])


def _warmup_boundary_jsonable(value: Any) -> Any:
    """Build a deterministic audit representation, not a restart snapshot."""

    if isinstance(value, Mapping):
        entries = [
            {
                "key": _warmup_boundary_jsonable(key),
                "value": _warmup_boundary_jsonable(item),
            }
            for key, item in value.items()
        ]
        return sorted(
            entries,
            key=lambda entry: json.dumps(
                entry["key"],
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ),
        )
    if isinstance(value, (list, tuple, deque)):
        return [_warmup_boundary_jsonable(item) for item in value]
    if isinstance(value, (set, frozenset)):
        items = [_warmup_boundary_jsonable(item) for item in value]
        return sorted(
            items,
            key=lambda item: json.dumps(
                item,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ),
        )
    if isinstance(value, float) and not math.isfinite(value):
        return {"non_finite_float": repr(value)}
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return repr(value)


def _warmup_boundary_sha256(value: Any) -> str:
    payload = json.dumps(
        _warmup_boundary_jsonable(value),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _canonical_supplier_disruption_proxy(
    events: list[dict[str, Any]],
    output_day: int,
) -> tuple[float, int]:
    """Summarize active physical supplier events as a bounded severity proxy.

    This is deliberately *not* a probability.  It only normalizes the strongest
    active availability/capacity/quality/lead-time/write-off effect to ``[0, 1]``
    so a feedback policy can react to the physical state without reading a
    future realized incident.  Cost-only events are excluded from the score.
    """

    reduction_types = {
        "stock",
        "capacity",
        "reliability",
        "quality_yield",
        "availability",
        "external_capacity",
        "external_availability",
        "external_quality_yield",
    }
    ratio_increase_types = {"lead_time", "external_lead_time"}
    additive_delay_types = {
        "lead_time_extra_days",
        "quality_delay",
        "external_lead_time_extra_days",
    }
    physical_types = reduction_types | ratio_increase_types | additive_delay_types | {
        "stock_writeoff"
    }
    severities: list[float] = []
    event_ids: set[str] = set()
    for event in events:
        if not (
            int(event.get("start_day", 0))
            <= int(output_day)
            <= int(event.get("end_day", 0))
        ):
            continue
        risk_type = str(event.get("risk_type") or "")
        if risk_type not in physical_types:
            continue
        multiplier = to_float(event.get("multiplier"), 1.0)
        if risk_type in reduction_types:
            severity = max(0.0, 1.0 - multiplier)
        elif risk_type in ratio_increase_types:
            severity = max(0.0, 1.0 - (1.0 / max(1.0, multiplier)))
        elif risk_type in additive_delay_types:
            severity = max(0.0, multiplier) / 10.0
        else:
            severity = max(0.0, multiplier)
        severities.append(max(0.0, min(1.0, severity)))
        event_ids.add(str(event.get("event_id") or f"anonymous_{len(event_ids)}"))
    return (max(severities, default=0.0), len(event_ids))


def _paired_lead_time_identity(
    *,
    seed: int,
    measured_day: int,
    lane: Mapping[str, Any],
    source_mode: str,
) -> str:
    return "|".join(
        [
            str(int(seed)),
            str(int(measured_day)),
            str(lane.get("edge_id") or ""),
            str(lane.get("src") or ""),
            str(lane.get("dst") or ""),
            str(lane.get("item_id") or ""),
            str(source_mode),
        ]
    )


def _paired_lead_time_seed(identity: str, invocation_ordinal: int) -> int:
    """Stable CRN seed for the nth invocation of one physical lane/day stream."""

    digest = hashlib.sha256(
        f"{identity}|{int(invocation_ordinal)}".encode("utf-8")
    ).digest()
    return int.from_bytes(digest[:8], "big", signed=False)


def _supplier_controlled_need_qty(
    base_need_qty: float,
    base_lane_weights: Mapping[int, float],
    supplier_order_multipliers: Mapping[int, float],
) -> float:
    """Apply supplier-targeted order controls to the aggregate MRP need.

    The supplier multipliers operate on each lane's neutral MRP share before
    constraints and lotification.  Applying their weighted mean to the pair
    need preserves the multi-source allocation while allowing a multiplier
    above one to increase a mono-source order.
    """

    nonnegative_need = max(0.0, float(base_need_qty))
    weight_total = sum(
        max(0.0, float(weight))
        for weight in base_lane_weights.values()
    )
    if nonnegative_need <= 0.0 or weight_total <= 0.0:
        return nonnegative_need
    controlled_weight_total = sum(
        max(0.0, float(weight))
        * max(0.0, float(supplier_order_multipliers.get(lane_key, 1.0)))
        for lane_key, weight in base_lane_weights.items()
    )
    return nonnegative_need * controlled_weight_total / weight_total


SUPPLIER_NOMINAL_PARAMETER_FIELDS = [
    "supplier_id",
    "supplier_name",
    "item_id",
    "dst_node_id",
    "edge_id",
    "uom",
    "input_initial_stock_qty",
    "simulated_opening_stock_qty",
    "base_stock_qty",
    "min_stock_end_of_day",
    "avg_stock_end_of_day",
    "final_stock_end_of_day",
    "neutral_opening_stock_floor_qty",
    "neutral_opening_stock_reducible_qty",
    "neutral_opening_stock_scale",
    "nominal_capacity_qty_per_day",
    "effective_capacity_qty_per_day",
    "capacity_basis",
    "applied_capacity_scale",
    "explicit_capacity_qty_per_day",
    "process_capacity_qty_per_day",
    "downstream_requirement_qty_per_day",
    "downstream_signal_qty_per_day",
    "external_procurement_daily_need_qty",
    "external_procurement_nominal_capacity_qty_per_day",
    "external_procurement_target_utilization",
    "external_procurement_capacity_profile",
    "external_procurement_capacity_basis",
    "external_procurement_lead_days",
    "external_procurement_pipeline_target_qty",
    "external_procurement_initial_pipeline_seed_qty",
    "avg_capacity_utilization",
    "max_capacity_utilization",
    "capacity_active_days",
    "max_capacity_used_qty_per_day",
    "neutral_capacity_floor_qty_per_day",
    "industrial_capacity_target_utilization",
    "industrial_capacity_profile",
    "industrial_nominal_capacity_qty_per_day",
    "industrial_peak_utilization_if_nominal",
    "current_capacity_headroom_vs_industrial_nominal",
    "tested_capacity_floor_qty_per_day",
    "tested_capacity_floor_factor",
    "neutral_capacity_scale_if_nominal",
    "current_capacity_headroom_factor",
    "current_capacity_headroom_vs_tested_floor",
    "capacity_floor_basis",
    "planned_lead_time_days",
    "lead_time_type",
    "lead_time_stages",
    "lead_time_source",
    "lead_time_is_default",
    "lead_reference_days",
    "lead_cover_days",
    "delay_step_limit",
    "nominal_reliability_otif",
    "reliability_source",
    "standard_order_qty",
    "standard_order_uom",
    "mrp_share",
    "mrp_rank",
    "mrp_share_basis",
    "mrp_landed_unit_cost",
    "mrp_cost_penalty",
    "mrp_lead_penalty",
    "mrp_reliability_penalty",
    "mrp_variability_penalty",
    "mrp_allocation_penalty",
    "unit_purchase_cost",
    "unit_transport_cost",
    "total_shipped_qty",
    "total_pulled_qty",
    "shipment_rows",
    "first_shipment_day",
    "last_shipment_day",
]

FACTORY_NOMINAL_CAPACITY_FIELDS = [
    "node_id",
    "node_name",
    "node_type",
    "process_id",
    "output_item_id",
    "uom",
    "current_capacity_qty_per_day",
    "current_capacity_limit_mode",
    "capacity_source",
    "industrial_capacity_target_utilization",
    "industrial_capacity_profile",
    "industrial_nominal_capacity_qty_per_day",
    "industrial_peak_utilization_if_nominal",
    "current_capacity_headroom_vs_industrial_nominal",
    "max_actual_qty_per_day",
    "max_planned_qty_after_lot_rule",
    "max_desired_qty_per_day",
    "total_actual_qty",
    "avg_actual_qty_per_active_day",
    "active_days",
    "constraint_rows",
    "current_avg_utilization",
    "current_max_utilization",
    "capacity_binding_days",
    "input_shortage_days",
    "lot_policy_mode",
    "lot_fixed_qty",
    "lot_min_qty",
    "lot_max_qty",
    "lot_multiple_qty",
    "max_lots_per_week",
]

SUPPLIER_RISK_APPLIED_FIELDS = [
    "day",
    "supplier_id",
    "dst_node_id",
    "item_id",
    "edge_id",
    "event_ids",
    "causal_root_ids",
    "stock_multiplier",
    "capacity_multiplier",
    "lead_time_multiplier",
    "lead_time_extra_days",
    "quality_delay_days",
    "reliability_multiplier",
    "quality_yield_multiplier",
    "availability_multiplier",
    "purchase_cost_multiplier",
    "transport_cost_multiplier",
    "external_capacity_multiplier",
    "external_availability_multiplier",
    "external_lead_time_multiplier",
    "external_lead_time_extra_days",
    "external_quality_yield_multiplier",
    "external_cost_multiplier",
    "stock_writeoff_fraction",
]

SUPPLIER_STATE_RISK_EVENT_FIELDS = [
    "event_id",
    "causal_root_id",
    "trigger_day",
    "start_day",
    "end_day",
    "supplier_id",
    "item_id",
    "dst_node_id",
    "edge_id",
    "risk_family",
    "risk_type",
    "multiplier",
    "trigger_metric",
    "trigger_value",
    "threshold",
    "consecutive_days",
    "effect",
    "notes",
]

SUPPLIER_STOCK_FLOW_FIELDS = [
    "day",
    "node_id",
    "item_id",
    "uom",
    "stock_start_of_day",
    "incoming_qty",
    "incoming_upstream_pipeline_qty",
    "incoming_external_market_qty",
    "incoming_estimated_source_qty",
    "stock_writeoff_qty",
    "outgoing_pulled_qty",
    "outgoing_shipped_qty",
    "outgoing_unreliable_loss_qty",
    "stock_end_of_day",
    "balance_delta_qty",
    "balance_check_gap_qty",
]

PRODUCTION_LOT_EVENT_FIELDS = [
    "event_id",
    "day",
    "event_type",
    "lot_id",
    "node_id",
    "item_id",
    "qty",
    "qty_after",
    "uom",
    "source_type",
    "source_id",
    "shipment_id",
    "risk_decision_day",
    "risk_event_ids",
    "related_lot_id",
    "production_campaign_id",
    "notes",
    "business_batch_id",
    "stock_lot_id",
    "lot_occurrence_id",
    "provenance_batch_id",
    "departure_day",
    "arrival_day",
    "handling_unit_id",
    "trace_status",
    "trace_reason",
    "lot_trace_contract_version",
    *LOT_CAUSAL_EVENT_FIELDS,
]

PRODUCTION_LOT_GENEALOGY_FIELDS = [
    "day",
    "link_type",
    "parent_lot_id",
    "parent_node_id",
    "parent_item_id",
    "child_lot_id",
    "child_node_id",
    "child_item_id",
    "parent_qty",
    "child_qty",
    "allocation_share",
    "source_id",
    "shipment_id",
    "risk_decision_day",
    "risk_event_ids",
    "production_campaign_id",
    "notes",
    "component_allocation_share",
    "business_batch_id",
    "stock_lot_id",
    "lot_occurrence_id",
    "parent_business_batch_id",
    "parent_stock_lot_id",
    "parent_lot_occurrence_id",
    "child_business_batch_id",
    "child_stock_lot_id",
    "child_lot_occurrence_id",
    "provenance_batch_id",
    "departure_day",
    "arrival_day",
    "handling_unit_id",
    "trace_status",
    "trace_reason",
    "lot_trace_contract_version",
    *LOT_CAUSAL_GENEALOGY_FIELDS,
]

OPENING_PURCHASE_ORDER_LOT_TRACE_FIELDS = [
    "source_row",
    "supplier_id",
]


def lot_trace_csv_fields(*, dated_availability: bool = False, opening_purchase_risks: bool = False) -> dict[str, list[str]]:
    """The actual export schema; dated receipts retain their source provenance."""
    extra = OPENING_PURCHASE_ORDER_LOT_TRACE_FIELDS if dated_availability or opening_purchase_risks else []
    return {
        "events": [*PRODUCTION_LOT_EVENT_FIELDS, *extra],
        "genealogy": [*PRODUCTION_LOT_GENEALOGY_FIELDS, *extra],
    }

OPENING_PURCHASE_ORDER_RISK_AUDIT_FIELDS = [
    "source_row",
    "source_file",
    "shipment_id",
    "risk_decision_day",
    "supplier_id",
    "dst_node_id",
    "item_id",
    "edge_id",
    "risk_event_ids",
    "risk_types",
    "unsupported_risk_types",
    "planned_qty_before",
    "pulled_qty_after",
    "physical_shipped_qty_after",
    "usable_qty_after",
    "quantity_loss_before_physical_qty",
    "quantity_loss_at_quality_release_qty",
    "physical_delivery_day_before",
    "physical_delivery_day_after",
    "usable_day_before",
    "usable_day_after",
    "release_day",
    "transport_delay_days",
    "quality_release_delay_days",
    "availability_multiplier",
    "reliability_multiplier",
    "quality_yield_multiplier",
    "lead_time_multiplier",
    "lead_time_extra_days",
    "quality_delay_days",
    "capacity_multiplier",
    "purchase_cost_multiplier",
    "transport_cost_multiplier",
    "interpretation",
]

PRODUCTION_PLAN_EVENT_FIELDS = [
    "day",
    "campaign_id",
    "semantics_version",
    "campaign_started_day",
    "node_id",
    "output_item_id",
    "batch_id",
    "batch_started_day",
    "batch_target_qty",
    "batch_executed_start_qty",
    "batch_executed_today_qty",
    "batch_executed_end_qty",
    "process_tau_days",
    "release_gate_mode",
    "wip_start_qty",
    "wip_end_qty",
    "released_qty",
    "released_lot_id",
    "is_day_zero_carry_in",
    "event_type",
    "reason",
    "desired_qty",
    "planned_qty_after_lot_rule",
    "actual_qty",
    "shortfall_vs_desired_qty",
    "shortfall_vs_lot_plan_qty",
    "binding_input_item_id",
    "planned_qty_before",
    "planned_qty_after",
    "lot_policy_mode",
    "lot_fixed_qty",
    "lot_min_qty",
    "lot_max_qty",
    "lot_multiple_qty",
    "max_lots_per_week",
    "started_lots_this_week",
    "requested_lot_starts",
    "actual_lot_starts",
    "campaign_requested_qty",
    "campaign_started_qty",
    "campaign_remaining_start_qty",
    "campaign_remaining_end_qty",
    "next_expected_receipt_day",
    "notes",
    *PLAN_CAUSAL_FIELDS,
]

OPENING_PRODUCTION_ORDER_LANE_PREFIX = "OPENING_PRODUCTION_ORDER|"
OPENING_PURCHASE_ORDER_LANE_PREFIX = "OPENING_PURCHASE_ORDER|"

def to_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


def supplier_planning_reliability(
    nominal_reliability: float,
    effective_reliability: float,
    *,
    gross_up_temporary_risk_loss: bool,
) -> float:
    """Return the reliability known by MRP when sizing a supplier pull.

    Nominal lane reliability belongs to the standing plan. Temporary risk
    multipliers can either be treated as anticipated yield loss (historical
    behavior) or as a surprise short shipment/rejection observed only after
    the order has been sized.
    """

    nominal = max(0.01, min(1.0, float(nominal_reliability)))
    effective = max(0.01, min(1.0, float(effective_reliability)))
    return effective if gross_up_temporary_risk_loss else nominal


class LotLedger:
    """Optional lot-level trace layered on top of aggregate stock equations."""

    def __init__(self, *, enabled: bool = True, scenario_id: str = "") -> None:
        self.enabled = enabled
        self.scenario_id = str(scenario_id or "")
        self._lot_seq = 0
        self._event_seq = 0
        self._campaign_seq = 0
        self._campaign_seq_by_pair: dict[tuple[str, str], int] = defaultdict(int)
        self.planned_order_id_by_campaign: dict[str, str] = {}
        self._shipment_identity_by_signature: dict[str, str] = {}
        self.lots_by_pair: dict[tuple[str, str], deque[str]] = defaultdict(deque)
        self.lots: dict[str, dict[str, Any]] = {}
        self.event_rows: list[dict[str, Any]] = []
        self.genealogy_rows: list[dict[str, Any]] = []
        self.stock_availability_enabled = False

    @staticmethod
    def _normalize_origin_contributions(value: Any) -> dict[str, float]:
        if not isinstance(value, dict):
            return {}
        return {
            str(order_id): max(0.0, to_float(qty, 0.0))
            for order_id, qty in value.items()
            if str(order_id).strip() and max(0.0, to_float(qty, 0.0)) > LOT_TRACE_EPS
        }

    @classmethod
    def _origin_contributions_json(cls, value: Any) -> str:
        normalized = cls._normalize_origin_contributions(value)
        return json.dumps(
            {key: round(normalized[key], 6) for key in sorted(normalized)},
            ensure_ascii=False,
            separators=(",", ":"),
        ) if normalized else ""

    def next_campaign_id(self, *, day: int, node_id: str, item_id: str) -> str:
        self._campaign_seq += 1
        pair = (str(node_id), str(item_id))
        self._campaign_seq_by_pair[pair] += 1
        campaign_id = f"CMP-{self._campaign_seq:08d}-{node_id}-{item_id}-D{day}"
        self.planned_order_id_by_campaign[campaign_id] = planned_order_reference(
            node_id=str(node_id),
            item_id=str(item_id),
            ordinal=self._campaign_seq_by_pair[pair],
        )
        return campaign_id

    def planned_order_id(self, campaign_id: str) -> str:
        return str(self.planned_order_id_by_campaign.get(str(campaign_id), ""))

    def _next_lot_id(self, *, day: int, node_id: str, item_id: str, source_type: str) -> str:
        self._lot_seq += 1
        return f"LOT-{self._lot_seq:08d}"

    def next_shipment_identity(
        self,
        *,
        departure_day: int,
        arrival_day: int,
        route_id: str,
    ) -> tuple[str, str]:
        """Return one route/date shipment ID; handling unit stays unknown without source data."""

        signature = "|".join(
            (
                str(route_id),
                str(int(departure_day)),
                str(int(arrival_day)),
            )
        )
        shipment_id = self._shipment_identity_by_signature.get(signature)
        if not shipment_id:
            signature_hash = hashlib.sha1(signature.encode("utf-8")).hexdigest()[:16].upper()
            shipment_id = f"SHP-{signature_hash}"
            self._shipment_identity_by_signature[signature] = shipment_id
        return shipment_id, ""

    def _next_event_id(self) -> str:
        self._event_seq += 1
        return f"LEVT-{self._event_seq:08d}"

    def _append_event(
        self,
        *,
        day: int,
        event_type: str,
        lot_id: str,
        node_id: str,
        item_id: str,
        qty: float,
        qty_after: float,
        uom: str = "",
        source_type: str = "",
        source_id: str = "",
        shipment_id: str = "",
        risk_decision_day: int | str = "",
        risk_event_ids: str = "",
        related_lot_id: str = "",
        production_campaign_id: str = "",
        notes: str = "",
        source_row: str = "",
        supplier_id: str = "",
        business_batch_id: str = "",
        stock_lot_id: str = "",
        lot_occurrence_id: str = "",
        provenance_batch_id: str = "",
        departure_day: int | str = "",
        arrival_day: int | str = "",
        handling_unit_id: str = "",
        trace_status: str = "traced",
        trace_reason: str = "",
        scenario_id: str = "",
        causal_event_ids: Any = "",
        causal_root_ids: Any = "",
        causal_status_value: str = "",
        baseline_reference_id: str = "",
        planned_order_id: str = "",
        origin_production_contributions: dict[str, float] | None = None,
        origin_allocation_basis: str = "",
        required_item_id: str = "",
        consumed_item_id: str = "",
        replacement_qty: float = 0.0,
        replacement_reason: str = "",
        replacement_transition_id: str = "",
    ) -> None:
        if not self.enabled:
            return
        normalized_origin_contributions = self._normalize_origin_contributions(
            origin_production_contributions
        )
        row = {
                "event_id": self._next_event_id(),
                "day": int(day),
                "event_type": event_type,
                "lot_id": lot_id,
                "node_id": node_id,
                "item_id": item_id,
                "qty": round(qty, 6),
                "qty_after": round(qty_after, 6),
                "uom": uom,
                "source_type": source_type,
                "source_id": source_id,
                "shipment_id": shipment_id,
                "risk_decision_day": risk_decision_day,
                "risk_event_ids": risk_event_ids,
                "related_lot_id": related_lot_id,
                "production_campaign_id": production_campaign_id,
                "notes": notes,
                "business_batch_id": business_batch_id,
                "stock_lot_id": stock_lot_id or lot_id,
                "lot_occurrence_id": lot_occurrence_id,
                "provenance_batch_id": provenance_batch_id,
                "departure_day": departure_day,
                "arrival_day": arrival_day,
                "handling_unit_id": handling_unit_id,
                "trace_status": trace_status or "traced",
                "trace_reason": trace_reason,
                "lot_trace_contract_version": LOT_TRACE_CONTRACT_VERSION,
                "scenario_id": str(scenario_id or self.scenario_id),
                "causal_event_ids": join_ids(causal_event_ids),
                "causal_root_ids": join_ids(causal_root_ids) or join_ids(causal_event_ids),
                "causal_status": resolved_causal_status(
                    causal_event_ids,
                    root_ids=causal_root_ids,
                    provided_status=causal_status_value,
                ),
                "baseline_reference_id": baseline_reference_id,
                "planned_order_id": planned_order_id,
                "origin_production_order_ids": join_ids(normalized_origin_contributions),
                "origin_production_contributions_json": self._origin_contributions_json(
                    normalized_origin_contributions
                ),
                "origin_allocation_basis": origin_allocation_basis,
                "required_item_id": required_item_id,
                "consumed_item_id": consumed_item_id,
                "replacement_qty": round(max(0.0, to_float(replacement_qty, 0.0)), 6),
                "replacement_reason": replacement_reason,
                "replacement_transition_id": replacement_transition_id,
            }
        # These fields are emitted only for the opt-in opening purchase-order
        # replay.  Keeping them absent otherwise preserves the historical lot
        # CSV schema and byte-level outputs of default runs.
        if str(source_row):
            row["source_row"] = str(source_row)
        if str(supplier_id):
            row["supplier_id"] = str(supplier_id)
        self.event_rows.append(row)

    def create_lot(
        self,
        *,
        day: int,
        node_id: str,
        item_id: str,
        qty: float,
        source_type: str,
        source_id: str = "",
        shipment_id: str = "",
        risk_decision_day: int | str = "",
        risk_event_ids: str = "",
        uom: str = "",
        event_type: str = "create",
        related_lot_id: str = "",
        production_campaign_id: str = "",
        notes: str = "",
        source_row: str = "",
        supplier_id: str = "",
        business_batch_id: str | None = None,
        provenance_batch_id: str = "",
        departure_day: int | str = "",
        arrival_day: int | str = "",
        handling_unit_id: str = "",
        trace_status: str = "traced",
        trace_reason: str = "",
        scenario_id: str = "",
        causal_event_ids: Any = "",
        causal_root_ids: Any = "",
        causal_status_value: str = "",
        baseline_reference_id: str = "",
        planned_order_id: str = "",
        origin_production_contributions: dict[str, float] | None = None,
        origin_allocation_basis: str = "",
        required_item_id: str = "",
        consumed_item_id: str = "",
        replacement_qty: float = 0.0,
        replacement_reason: str = "",
        replacement_transition_id: str = "",
    ) -> str:
        qty = max(0.0, to_float(qty, 0.0))
        if normalize_unit(uom) == "UN":
            qty = require_physical_integer(qty, uom)
        if qty <= LOT_TRACE_EPS or not self.enabled:
            return ""
        node_id = str(node_id)
        item_id = str(item_id)
        lot_id = self._next_lot_id(day=day, node_id=node_id, item_id=item_id, source_type=source_type)
        lot_sequence = self._lot_seq
        stock_lot_id = f"STOCKLOT-{lot_sequence:08d}"
        lot_occurrence_id = f"LOCC-{lot_sequence:08d}"
        resolved_business_batch_id = business_batch_id
        if resolved_business_batch_id is None:
            resolved_business_batch_id = (
                ""
                if (trace_status or "").startswith("untraced")
                else f"BATCH-{lot_sequence:08d}"
            )
        normalized_origin_contributions = self._normalize_origin_contributions(
            origin_production_contributions
        )
        self.lots[lot_id] = {
            "lot_id": lot_id,
            "business_batch_id": resolved_business_batch_id,
            "stock_lot_id": stock_lot_id,
            "lot_occurrence_id": lot_occurrence_id,
            "provenance_batch_id": provenance_batch_id,
            "node_id": node_id,
            "item_id": item_id,
            "created_day": int(day),
            "source_type": source_type,
            "source_id": source_id,
            "initial_qty": qty,
            "qty_remaining": qty,
            "uom": uom,
            "shipment_id": shipment_id,
            "departure_day": departure_day,
            "arrival_day": arrival_day,
            "handling_unit_id": handling_unit_id,
            "trace_status": trace_status or "traced",
            "trace_reason": trace_reason,
            "scenario_id": str(scenario_id or self.scenario_id),
            "causal_event_ids": join_ids(causal_event_ids),
            "causal_root_ids": join_ids(causal_root_ids) or join_ids(causal_event_ids),
            "causal_status": resolved_causal_status(
                causal_event_ids,
                root_ids=causal_root_ids,
                provided_status=causal_status_value,
            ),
            "baseline_reference_id": baseline_reference_id,
            "planned_order_id": planned_order_id,
            "origin_production_contributions": normalized_origin_contributions,
            "origin_production_order_ids": join_ids(normalized_origin_contributions),
            "origin_allocation_basis": origin_allocation_basis,
            "required_item_id": required_item_id,
            "consumed_item_id": consumed_item_id,
            "replacement_qty": max(0.0, to_float(replacement_qty, 0.0)),
            "replacement_reason": replacement_reason,
            "replacement_transition_id": replacement_transition_id,
        }
        if str(source_row):
            self.lots[lot_id]["source_row"] = str(source_row)
        if str(supplier_id):
            self.lots[lot_id]["supplier_id"] = str(supplier_id)
        self.lots_by_pair[(node_id, item_id)].append(lot_id)
        self._append_event(
            day=day,
            event_type=event_type,
            lot_id=lot_id,
            node_id=node_id,
            item_id=item_id,
            qty=qty,
            qty_after=qty,
            uom=uom,
            source_type=source_type,
            source_id=source_id,
            shipment_id=shipment_id,
            risk_decision_day=risk_decision_day,
            risk_event_ids=risk_event_ids,
            related_lot_id=related_lot_id,
            production_campaign_id=production_campaign_id,
            notes=notes,
            source_row=source_row,
            supplier_id=supplier_id,
            business_batch_id=resolved_business_batch_id,
            stock_lot_id=stock_lot_id,
            lot_occurrence_id=lot_occurrence_id,
            provenance_batch_id=provenance_batch_id,
            departure_day=departure_day,
            arrival_day=arrival_day,
            handling_unit_id=handling_unit_id,
            trace_status=trace_status,
            trace_reason=trace_reason,
            scenario_id=scenario_id,
            causal_event_ids=causal_event_ids,
            causal_root_ids=causal_root_ids,
            causal_status_value=causal_status_value,
            baseline_reference_id=baseline_reference_id,
            planned_order_id=planned_order_id,
            origin_production_contributions=normalized_origin_contributions,
            origin_allocation_basis=origin_allocation_basis,
            required_item_id=required_item_id,
            consumed_item_id=consumed_item_id,
            replacement_qty=replacement_qty,
            replacement_reason=replacement_reason,
            replacement_transition_id=replacement_transition_id,
        )
        return lot_id

    def seed_opening_stock(
        self,
        *,
        day: int,
        stock: dict[tuple[str, str], float],
        item_unit_map: dict[str, str],
    ) -> None:
        if not self.enabled:
            return
        for node_id, item_id in sorted(stock):
            qty = max(0.0, to_float(stock[(node_id, item_id)], 0.0))
            if qty <= LOT_TRACE_EPS:
                continue
            self.create_lot(
                day=day,
                node_id=node_id,
                item_id=item_id,
                qty=qty,
                source_type="opening_stock",
                source_id="initial_simulation_state",
                uom=item_unit_map.get(item_id, ""),
                event_type="opening_stock",
                trace_status="untraced_before_horizon",
                trace_reason="opening_stock_aggregated_without_source_batch_detail",
            )

    def change_stock_availability(
        self, *, day: int, node_id: str, item_id: str, qty: float,
        source_id: str, release: bool = False,
        allocations: list[dict[str, Any]] | None = None, notes: str = "",
        source_type: str = "initial_stock_availability",
    ) -> list[dict[str, Any]]:
        """Change usability of existing lots without changing physical balances."""
        if not self.enabled:
            return []
        self.stock_availability_enabled = True
        candidates = allocations if allocations is not None or release else [
            {"lot_id": lot_id, "qty": max(0.0, self.lots[lot_id]["qty_remaining"]
                                         - self.lots[lot_id].get("qty_held", 0.0))}
            for lot_id in self.lots_by_pair[(node_id, item_id)]
        ]
        candidates = candidates or []
        if sum(float(row["qty"]) for row in candidates) + LOT_TRACE_EPS < qty:
            raise ValueError("Insufficient existing lot quantity for stock availability change")
        remaining = qty
        changed = []
        for allocation in candidates:
            if remaining <= LOT_TRACE_EPS:
                break
            lot_id = str(allocation["lot_id"])
            lot = self.lots[lot_id]
            take = require_physical_integer(min(remaining, float(allocation["qty"])), lot["uom"])
            if take <= LOT_TRACE_EPS:
                continue
            held = float(lot.get("qty_held", 0.0))
            if release and take > held + LOT_TRACE_EPS:
                raise ValueError("Stock release exceeds held quantity")
            lot["qty_held"] = max(0.0, held - take) if release else held + take
            self._append_event(
                day=day, event_type="stock_availability_release" if release else "stock_availability_hold",
                lot_id=lot_id, node_id=node_id, item_id=item_id, qty=take,
                qty_after=lot["qty_remaining"], uom=lot["uom"],
                source_type=source_type, source_id=source_id, notes=notes,
                business_batch_id=lot["business_batch_id"], stock_lot_id=lot["stock_lot_id"],
                lot_occurrence_id=lot["lot_occurrence_id"], provenance_batch_id=lot["provenance_batch_id"],
                trace_status=lot["trace_status"], trace_reason=lot["trace_reason"],
            )
            changed.append({"lot_id": lot_id, "qty": take})
            remaining -= take
        return changed

    def consume(
        self,
        *,
        day: int,
        node_id: str,
        item_id: str,
        qty: float,
        event_type: str,
        source_id: str = "",
        shipment_id: str = "",
        risk_decision_day: int | str = "",
        risk_event_ids: str = "",
        production_campaign_id: str = "",
        uom: str = "",
        notes: str = "",
        departure_day: int | str = "",
        arrival_day: int | str = "",
        handling_unit_id: str = "",
        trace_status: str = "traced",
        trace_reason: str = "",
        scenario_id: str = "",
        causal_event_ids: Any = "",
        causal_root_ids: Any = "",
        causal_status_value: str = "",
        baseline_reference_id: str = "",
        planned_order_id: str = "",
        origin_production_contributions: dict[str, float] | None = None,
        origin_allocation_basis: str = "",
        required_item_id: str = "",
        consumed_item_id: str = "",
        replacement_reason: str = "",
        replacement_transition_id: str = "",
    ) -> list[dict[str, Any]]:
        qty = require_physical_integer(qty, uom)
        if qty <= LOT_TRACE_EPS or not self.enabled:
            return []
        node_id = str(node_id)
        item_id = str(item_id)
        pair = (node_id, item_id)
        remaining = qty
        allocations: list[dict[str, Any]] = []
        queue = self.lots_by_pair[pair]
        if self.stock_availability_enabled:
            available_total = sum(max(0.0, self.lots[key]["qty_remaining"]
                                      - self.lots[key].get("qty_held", 0.0)) for key in queue)
            if qty > available_total + LOT_TRACE_EPS:
                raise ValueError("Consumption or reservation exceeds available lot stock")
        while remaining > LOT_TRACE_EPS:
            while queue and max(0.0, to_float(self.lots[queue[0]].get("qty_remaining"), 0.0)) <= LOT_TRACE_EPS:
                queue.popleft()
            if not queue:
                self.create_lot(
                    day=day,
                    node_id=node_id,
                    item_id=item_id,
                    qty=remaining,
                    source_type="ledger_reconciliation",
                    source_id=source_id or event_type,
                    uom=uom,
                    event_type="stock_reconciliation",
                    notes="Synthetic lot created because aggregate stock existed without lot detail.",
                    trace_status="untraced_origin",
                    trace_reason="aggregate_stock_without_lot_detail",
                )
            lot_id = queue[0]
            if self.stock_availability_enabled:
                lot_id = next(key for key in queue if self.lots[key]["qty_remaining"]
                              - self.lots[key].get("qty_held", 0.0) > LOT_TRACE_EPS)
            lot = self.lots[lot_id]
            physical_before = max(0.0, to_float(lot.get("qty_remaining"), 0.0))
            available = max(0.0, physical_before - lot.get("qty_held", 0.0))
            take = min(available, remaining)
            if take <= LOT_TRACE_EPS:
                queue.popleft()
                continue
            lot_origin_contributions = self._normalize_origin_contributions(
                lot.get("origin_production_contributions")
            )
            event_origin_contributions: dict[str, float] = {}
            if lot_origin_contributions and available > LOT_TRACE_EPS:
                fraction = min(1.0, take / physical_before)
                for order_id, contribution_qty in lot_origin_contributions.items():
                    allocated_qty = min(contribution_qty, contribution_qty * fraction)
                    if allocated_qty > LOT_TRACE_EPS:
                        event_origin_contributions[order_id] = allocated_qty
                    lot_origin_contributions[order_id] = max(
                        0.0,
                        contribution_qty - allocated_qty,
                    )
                lot["origin_production_contributions"] = {
                    order_id: contribution_qty
                    for order_id, contribution_qty in lot_origin_contributions.items()
                    if contribution_qty > LOT_TRACE_EPS
                }
                lot["origin_production_order_ids"] = join_ids(
                    lot["origin_production_contributions"]
                )
            explicit_origin_contributions = self._normalize_origin_contributions(
                origin_production_contributions
            )
            for order_id, contribution_qty in explicit_origin_contributions.items():
                event_origin_contributions[order_id] = (
                    event_origin_contributions.get(order_id, 0.0) + contribution_qty
                )
            event_origin_basis = (
                origin_allocation_basis
                or (
                    "proportional_mixed_stock"
                    if len(event_origin_contributions) > 1
                    else str(lot.get("origin_allocation_basis") or "direct_batch")
                    if event_origin_contributions
                    else ""
                )
            )
            lot["qty_remaining"] = max(0.0, physical_before - take)
            remaining -= take
            lot_trace_status = str(lot.get("trace_status") or "")
            lot_trace_reason = str(lot.get("trace_reason") or "")
            effective_trace_status = (
                lot_trace_status
                if trace_status == "traced" and lot_trace_status not in {"", "traced"}
                else trace_status
            )
            effective_trace_reason = trace_reason or (
                lot_trace_reason if effective_trace_status == lot_trace_status else ""
            )
            allocations.append(
                {
                    "lot_id": lot_id,
                    "node_id": node_id,
                    "item_id": item_id,
                    "qty": take,
                    "uom": lot.get("uom") or uom,
                    **(
                        {"source_row": str(lot.get("source_row"))}
                        if str(lot.get("source_row") or "")
                        else {}
                    ),
                    **(
                        {"supplier_id": str(lot.get("supplier_id"))}
                        if str(lot.get("supplier_id") or "")
                        else {}
                    ),
                    "business_batch_id": str(lot.get("business_batch_id") or ""),
                    "stock_lot_id": str(lot.get("stock_lot_id") or lot_id),
                    "lot_occurrence_id": str(lot.get("lot_occurrence_id") or ""),
                    "provenance_batch_id": str(lot.get("provenance_batch_id") or ""),
                    "trace_status": effective_trace_status,
                    "trace_reason": effective_trace_reason,
                    "scenario_id": str(scenario_id or lot.get("scenario_id") or self.scenario_id),
                    "causal_event_ids": join_ids(lot.get("causal_event_ids"), causal_event_ids),
                    "causal_root_ids": join_ids(lot.get("causal_root_ids"), causal_root_ids)
                    or join_ids(lot.get("causal_event_ids"), causal_event_ids),
                    "causal_status": resolved_causal_status(
                        join_ids(lot.get("causal_event_ids"), causal_event_ids),
                        root_ids=join_ids(lot.get("causal_root_ids"), causal_root_ids),
                        provided_status=causal_status_value,
                    ),
                    "baseline_reference_id": str(
                        baseline_reference_id or lot.get("baseline_reference_id") or ""
                    ),
                    "planned_order_id": str(planned_order_id or lot.get("planned_order_id") or ""),
                    "origin_production_order_ids": join_ids(event_origin_contributions),
                    "origin_production_contributions": event_origin_contributions,
                    "origin_production_contributions_json": self._origin_contributions_json(
                        event_origin_contributions
                    ),
                    "origin_allocation_basis": event_origin_basis,
                    "required_item_id": required_item_id,
                    "consumed_item_id": consumed_item_id or item_id,
                    "replacement_qty": take if required_item_id and required_item_id != (consumed_item_id or item_id) else 0.0,
                    "replacement_reason": replacement_reason,
                    "replacement_transition_id": replacement_transition_id,
                }
            )
            self._append_event(
                day=day,
                event_type=event_type,
                lot_id=lot_id,
                node_id=node_id,
                item_id=item_id,
                qty=take,
                qty_after=to_float(lot.get("qty_remaining"), 0.0),
                uom=lot.get("uom") or uom,
                source_type=str(lot.get("source_type") or ""),
                source_id=source_id,
                shipment_id=shipment_id,
                risk_decision_day=risk_decision_day,
                risk_event_ids=risk_event_ids,
                production_campaign_id=production_campaign_id,
                notes=notes,
                source_row=str(lot.get("source_row") or ""),
                supplier_id=str(lot.get("supplier_id") or ""),
                business_batch_id=str(lot.get("business_batch_id") or ""),
                stock_lot_id=str(lot.get("stock_lot_id") or lot_id),
                lot_occurrence_id=str(lot.get("lot_occurrence_id") or ""),
                provenance_batch_id=str(lot.get("provenance_batch_id") or ""),
                departure_day=departure_day,
                arrival_day=arrival_day,
                handling_unit_id=handling_unit_id,
                trace_status=effective_trace_status,
                trace_reason=effective_trace_reason,
                scenario_id=scenario_id or str(lot.get("scenario_id") or ""),
                causal_event_ids=join_ids(lot.get("causal_event_ids"), causal_event_ids),
                causal_root_ids=join_ids(lot.get("causal_root_ids"), causal_root_ids),
                causal_status_value=causal_status_value,
                baseline_reference_id=baseline_reference_id
                or str(lot.get("baseline_reference_id") or ""),
                planned_order_id=planned_order_id or str(lot.get("planned_order_id") or ""),
                origin_production_contributions=event_origin_contributions,
                origin_allocation_basis=event_origin_basis,
                required_item_id=required_item_id,
                consumed_item_id=consumed_item_id or item_id,
                replacement_qty=(
                    take
                    if required_item_id and required_item_id != (consumed_item_id or item_id)
                    else 0.0
                ),
                replacement_reason=replacement_reason,
                replacement_transition_id=replacement_transition_id,
            )
            if to_float(lot.get("qty_remaining"), 0.0) <= LOT_TRACE_EPS:
                if queue[0] == lot_id:
                    queue.popleft()
                else:
                    queue.remove(lot_id)
        return allocations

    def pair_balance(self, *, node_id: str, item_id: str) -> float:
        """Return remaining lot quantity for one aggregate stock pair."""

        if not self.enabled:
            return 0.0
        return sum(
            max(0.0, to_float(lot.get("qty_remaining"), 0.0))
            for lot in self.lots.values()
            if str(lot.get("node_id")) == str(node_id)
            and str(lot.get("item_id")) == str(item_id)
        )

    def reconcile_pair_to_stock(
        self,
        *,
        day: int,
        node_id: str,
        item_id: str,
        target_qty: float,
        source_id: str,
        uom: str = "",
        notes: str = "",
    ) -> dict[str, Any]:
        """Reconcile FIFO lot balances to an explicit aggregate stock target."""

        target_qty = max(0.0, to_float(target_qty, 0.0))
        if not self.enabled:
            return {
                "enabled": False,
                "balance_before_qty": 0.0,
                "balance_after_qty": 0.0,
                "removed_qty": 0.0,
                "added_qty": 0.0,
            }
        balance_before = self.pair_balance(node_id=node_id, item_id=item_id)
        removed_qty = max(0.0, balance_before - target_qty)
        added_qty = max(0.0, target_qty - balance_before)
        if removed_qty > LOT_TRACE_EPS:
            self.consume(
                day=day,
                node_id=node_id,
                item_id=item_id,
                qty=removed_qty,
                event_type="measurement_start_stock_reduction",
                source_id=source_id,
                uom=uom,
                notes=(
                    notes
                    or "FIFO lot reduction for measured-day-0 stock sensitivity."
                ),
            )
        elif added_qty > LOT_TRACE_EPS:
            self.create_lot(
                day=day,
                node_id=node_id,
                item_id=item_id,
                qty=added_qty,
                source_type="measurement_start_stock_adjustment",
                source_id=source_id,
                uom=uom,
                event_type="measurement_start_stock_increase",
                notes=(
                    notes
                    or "Reconciliation lot for measured-day-0 stock sensitivity."
                ),
            )
        balance_after = self.pair_balance(node_id=node_id, item_id=item_id)
        if abs(balance_after - target_qty) > LOT_TRACE_EPS:
            raise RuntimeError(
                "lot balance reconciliation failed for "
                f"{node_id},{item_id}: target={target_qty}, after={balance_after}"
            )
        return {
            "enabled": True,
            "balance_before_qty": balance_before,
            "balance_after_qty": balance_after,
            "removed_qty": removed_qty,
            "added_qty": added_qty,
        }

    def create_child_lot(
        self,
        *,
        day: int,
        node_id: str,
        item_id: str,
        qty: float,
        source_type: str,
        source_id: str,
        shipment_id: str = "",
        risk_decision_day: int | str = "",
        risk_event_ids: str = "",
        parent_allocations: list[dict[str, Any]],
        link_type: str,
        uom: str = "",
        production_campaign_id: str = "",
        notes: str = "",
        departure_day: int | str = "",
        arrival_day: int | str = "",
        handling_unit_id: str = "",
        trace_status: str = "traced",
        trace_reason: str = "",
        scenario_id: str = "",
        causal_event_ids: Any = "",
        causal_root_ids: Any = "",
        causal_status_value: str = "",
        baseline_reference_id: str = "",
        planned_order_id: str = "",
        origin_production_contributions: dict[str, float] | None = None,
        origin_allocation_basis: str = "",
    ) -> str:
        inherited_source_rows = sorted(
            {
                str(allocation.get("source_row") or "")
                for allocation in parent_allocations
                if str(allocation.get("source_row") or "")
            }
        )
        inherited_supplier_ids = sorted(
            {
                str(allocation.get("supplier_id") or "")
                for allocation in parent_allocations
                if str(allocation.get("supplier_id") or "")
            }
        )
        parent_batch_ids: list[str] = []
        parent_batch_seen: set[str] = set()
        parent_trace_statuses: set[str] = set()
        parent_trace_reasons: set[str] = set()
        for allocation in parent_allocations:
            parent_lot = self.lots.get(str(allocation.get("lot_id") or ""), {})
            stable_batch = str(
                allocation.get("business_batch_id")
                or parent_lot.get("business_batch_id")
                or ""
            ).strip()
            # If the stock occurrence has one stable business batch, upstream
            # component genealogy is not part of the transported batch identity.
            # Provenance batches are used only for an already mixed occurrence.
            candidates = [stable_batch] if stable_batch else str(
                allocation.get("provenance_batch_id")
                or parent_lot.get("provenance_batch_id")
                or ""
            ).split("|")
            for candidate in candidates:
                candidate = candidate.strip()
                if not candidate or candidate in parent_batch_seen:
                    continue
                parent_batch_seen.add(candidate)
                parent_batch_ids.append(candidate)
            parent_status = str(
                allocation.get("trace_status") or parent_lot.get("trace_status") or ""
            ).strip()
            parent_reason = str(
                allocation.get("trace_reason") or parent_lot.get("trace_reason") or ""
            ).strip()
            if parent_status:
                parent_trace_statuses.add(parent_status)
            if parent_reason:
                parent_trace_reasons.add(parent_reason)
        parent_batch_ids.sort()
        has_untraced_parent = any(
            status.startswith("untraced") or status == "partially_traced_mixed_occurrence"
            for status in parent_trace_statuses
        )
        inherited_business_batch_id: str | None = None
        if link_type == "production" and planned_order_id:
            inherited_business_batch_id = stable_reference_id(
                "PBATCH",
                planned_order_id,
            )
        elif link_type == "transport" and has_untraced_parent:
            inherited_business_batch_id = ""
        elif link_type == "transport" and len(parent_batch_ids) == 1:
            inherited_business_batch_id = parent_batch_ids[0]
        elif link_type == "transport" and len(parent_batch_ids) > 1:
            # A consolidated receipt is one stock occurrence, not a new
            # business batch. Its contributing batches stay in provenance.
            inherited_business_batch_id = ""
        elif link_type == "transport":
            inherited_business_batch_id = ""
        provenance_batch_id = "|".join(parent_batch_ids)
        inherited_causality = inherited_causal_fields(
            parent_allocations,
            scenario_id=scenario_id or self.scenario_id,
            causal_event_ids=causal_event_ids,
            causal_root_ids=causal_root_ids,
            causal_status_value=causal_status_value,
            baseline_reference_id=baseline_reference_id,
            planned_order_id=planned_order_id,
        )
        child_origin_contributions = self._normalize_origin_contributions(
            origin_production_contributions
        )
        if link_type == "production" and planned_order_id:
            child_origin_contributions = {
                str(planned_order_id): max(0.0, to_float(qty, 0.0))
            }
            child_origin_basis = "direct_production_order"
        else:
            parent_origin_bases: set[str] = set()
            for allocation in parent_allocations:
                allocation_contributions = self._normalize_origin_contributions(
                    allocation.get("origin_production_contributions")
                )
                allocation_basis = str(
                    allocation.get("origin_allocation_basis") or ""
                ).strip()
                if allocation_basis:
                    parent_origin_bases.add(allocation_basis)
                for order_id, contribution_qty in allocation_contributions.items():
                    child_origin_contributions[order_id] = (
                        child_origin_contributions.get(order_id, 0.0)
                        + contribution_qty
                    )
            child_origin_basis = (
                origin_allocation_basis
                or (
                    "proportional_mixed_stock"
                    if len(child_origin_contributions) > 1
                    else next(iter(parent_origin_bases))
                    if len(parent_origin_bases) == 1
                    else "direct_batch"
                    if child_origin_contributions
                    else ""
                )
            )
        resolved_trace_status = trace_status or "traced"
        resolved_trace_reason = trace_reason
        if link_type == "transport" and has_untraced_parent and parent_batch_ids:
            resolved_trace_status = "partially_traced_mixed_occurrence"
            resolved_trace_reason = (
                "consolidated_receipt_mixes_identified_and_untraced_origins"
                + (
                    f":{','.join(sorted(parent_trace_reasons))}"
                    if parent_trace_reasons
                    else ""
                )
            )
        elif link_type == "transport" and len(parent_batch_ids) > 1:
            resolved_trace_status = "mixed_batch_occurrence"
            resolved_trace_reason = "consolidated_receipt_multiple_business_batches"
        elif link_type == "transport" and has_untraced_parent:
            resolved_trace_status = "untraced_origin"
            resolved_trace_reason = (
                "inherited_untraced_parent_origin"
                + (
                    f":{','.join(sorted(parent_trace_reasons))}"
                    if parent_trace_reasons
                    else ""
                )
            )
        elif link_type == "transport" and not parent_batch_ids:
            resolved_trace_status = "untraced_origin"
            resolved_trace_reason = "transport_parent_has_no_business_batch_provenance"
        child_lot_id = self.create_lot(
            day=day,
            node_id=node_id,
            item_id=item_id,
            qty=qty,
            source_type=source_type,
            source_id=source_id,
            shipment_id=shipment_id,
            risk_decision_day=risk_decision_day,
            risk_event_ids=risk_event_ids,
            uom=uom,
            event_type=source_type,
            production_campaign_id=production_campaign_id,
            notes=notes,
            source_row=",".join(inherited_source_rows),
            supplier_id=",".join(inherited_supplier_ids),
            business_batch_id=inherited_business_batch_id,
            provenance_batch_id=provenance_batch_id,
            departure_day=departure_day,
            arrival_day=arrival_day,
            handling_unit_id=handling_unit_id,
            trace_status=resolved_trace_status,
            trace_reason=resolved_trace_reason,
            scenario_id=inherited_causality["scenario_id"],
            causal_event_ids=inherited_causality["causal_event_ids"],
            causal_root_ids=inherited_causality["causal_root_ids"],
            causal_status_value=inherited_causality["causal_status"],
            baseline_reference_id=inherited_causality["baseline_reference_id"],
            planned_order_id=inherited_causality["planned_order_id"],
            origin_production_contributions=child_origin_contributions,
            origin_allocation_basis=child_origin_basis,
        )
        if not child_lot_id or not self.enabled:
            return child_lot_id
        total_parent_qty = sum(max(0.0, to_float(a.get("qty"), 0.0)) for a in parent_allocations)
        parent_qty_by_component: dict[tuple[str, str], float] = defaultdict(float)
        if link_type == "production":
            for alloc in parent_allocations:
                component_key = (
                    str(alloc.get("item_id") or ""),
                    normalize_unit(alloc.get("uom")),
                )
                parent_qty_by_component[component_key] += max(
                    0.0,
                    to_float(alloc.get("qty"), 0.0),
                )
        child_lot = self.lots.get(child_lot_id, {})
        for alloc in parent_allocations:
            parent_qty = max(0.0, to_float(alloc.get("qty"), 0.0))
            if parent_qty <= LOT_TRACE_EPS:
                continue
            if link_type == "production":
                component_key = (
                    str(alloc.get("item_id") or ""),
                    normalize_unit(alloc.get("uom")),
                )
                component_total_qty = parent_qty_by_component.get(component_key, 0.0)
                share = parent_qty / component_total_qty if component_total_qty > LOT_TRACE_EPS else 0.0
                component_allocation_share: float | str = share
            else:
                share = parent_qty / total_parent_qty if total_parent_qty > LOT_TRACE_EPS else 0.0
                component_allocation_share = ""
            parent_lot = self.lots.get(str(alloc.get("lot_id") or ""), {})
            required_item_id = str(alloc.get("required_item_id") or "")
            consumed_item_id = str(alloc.get("consumed_item_id") or alloc.get("item_id") or "")
            replacement_qty = max(0.0, to_float(alloc.get("replacement_qty"), 0.0))
            genealogy_row = {
                    "day": int(day),
                    "link_type": link_type,
                    "parent_lot_id": str(alloc.get("lot_id") or ""),
                    "parent_node_id": str(alloc.get("node_id") or ""),
                    "parent_item_id": str(alloc.get("item_id") or ""),
                    "child_lot_id": child_lot_id,
                    "child_node_id": str(node_id),
                    "child_item_id": str(item_id),
                    "parent_qty": round(parent_qty, 6),
                    "child_qty": round(max(0.0, to_float(qty, 0.0)), 6),
                    "allocation_share": round(share, 9),
                    "source_id": source_id,
                    "shipment_id": shipment_id,
                    "risk_decision_day": risk_decision_day,
                    "risk_event_ids": risk_event_ids,
                    "production_campaign_id": production_campaign_id,
                    "notes": notes,
                    "component_allocation_share": (
                        round(component_allocation_share, 9)
                        if isinstance(component_allocation_share, float)
                        else ""
                    ),
                    "business_batch_id": str(child_lot.get("business_batch_id") or ""),
                    "stock_lot_id": str(child_lot.get("stock_lot_id") or ""),
                    "lot_occurrence_id": str(child_lot.get("lot_occurrence_id") or ""),
                    "parent_business_batch_id": str(
                        alloc.get("business_batch_id") or parent_lot.get("business_batch_id") or ""
                    ),
                    "parent_stock_lot_id": str(
                        alloc.get("stock_lot_id") or parent_lot.get("stock_lot_id") or ""
                    ),
                    "parent_lot_occurrence_id": str(
                        alloc.get("lot_occurrence_id") or parent_lot.get("lot_occurrence_id") or ""
                    ),
                    "child_business_batch_id": str(child_lot.get("business_batch_id") or ""),
                    "child_stock_lot_id": str(child_lot.get("stock_lot_id") or ""),
                    "child_lot_occurrence_id": str(child_lot.get("lot_occurrence_id") or ""),
                    "provenance_batch_id": provenance_batch_id,
                    "departure_day": departure_day,
                    "arrival_day": arrival_day,
                    "handling_unit_id": handling_unit_id,
                    "trace_status": resolved_trace_status,
                    "trace_reason": resolved_trace_reason,
                    "lot_trace_contract_version": LOT_TRACE_CONTRACT_VERSION,
                    **inherited_causality,
                    "origin_production_order_ids": join_ids(child_origin_contributions),
                    "origin_production_contributions_json": self._origin_contributions_json(
                        child_origin_contributions
                    ),
                    "origin_allocation_basis": child_origin_basis,
                    "required_item_id": required_item_id,
                    "consumed_item_id": consumed_item_id,
                    "replacement_qty": round(replacement_qty, 6),
                    "replacement_reason": str(alloc.get("replacement_reason") or ""),
                    "replacement_transition_id": str(
                        alloc.get("replacement_transition_id") or ""
                    ),
                }
            if str(alloc.get("source_row") or ""):
                genealogy_row["source_row"] = str(alloc.get("source_row"))
            if str(alloc.get("supplier_id") or ""):
                genealogy_row["supplier_id"] = str(alloc.get("supplier_id"))
            self.genealogy_rows.append(genealogy_row)
        return child_lot_id

    def record_allocation_event(
        self,
        *,
        day: int,
        event_type: str,
        parent_allocations: list[dict[str, Any]],
        source_id: str = "",
        shipment_id: str = "",
        risk_decision_day: int | str = "",
        risk_event_ids: str = "",
        departure_day: int | str = "",
        arrival_day: int | str = "",
        handling_unit_id: str = "",
        notes: str = "",
        trace_status: str = "traced",
        trace_reason: str = "",
        planned_order_id: str = "",
        baseline_reference_id: str = "",
    ) -> None:
        """Record a physical milestone for stock allocated at an earlier date."""

        if not self.enabled:
            return
        for allocation in parent_allocations:
            qty = max(0.0, to_float(allocation.get("qty"), 0.0))
            lot_id = str(allocation.get("lot_id") or "")
            if qty <= LOT_TRACE_EPS or not lot_id:
                continue
            lot = self.lots.get(lot_id, {})
            self._append_event(
                day=day,
                event_type=event_type,
                lot_id=lot_id,
                node_id=str(allocation.get("node_id") or lot.get("node_id") or ""),
                item_id=str(allocation.get("item_id") or lot.get("item_id") or ""),
                qty=qty,
                qty_after=to_float(lot.get("qty_remaining"), 0.0),
                uom=str(allocation.get("uom") or lot.get("uom") or ""),
                source_type=str(lot.get("source_type") or ""),
                source_id=source_id,
                notes=notes,
                business_batch_id=str(
                    allocation.get("business_batch_id")
                    or lot.get("business_batch_id")
                    or ""
                ),
                stock_lot_id=str(
                    allocation.get("stock_lot_id")
                    or lot.get("stock_lot_id")
                    or lot_id
                ),
                lot_occurrence_id=str(
                    allocation.get("lot_occurrence_id")
                    or lot.get("lot_occurrence_id")
                    or ""
                ),
                provenance_batch_id=str(
                    allocation.get("provenance_batch_id")
                    or lot.get("provenance_batch_id")
                    or ""
                ),
                shipment_id=shipment_id,
                risk_decision_day=risk_decision_day,
                risk_event_ids=risk_event_ids,
                departure_day=departure_day,
                arrival_day=arrival_day,
                handling_unit_id=handling_unit_id,
                trace_status=trace_status,
                trace_reason=trace_reason,
                scenario_id=str(
                    allocation.get("scenario_id")
                    or lot.get("scenario_id")
                    or self.scenario_id
                ),
                causal_event_ids=allocation.get("causal_event_ids"),
                causal_root_ids=allocation.get("causal_root_ids"),
                causal_status_value=str(allocation.get("causal_status") or ""),
                baseline_reference_id=baseline_reference_id
                or str(allocation.get("baseline_reference_id") or ""),
                planned_order_id=planned_order_id
                or str(allocation.get("planned_order_id") or ""),
                origin_production_contributions=allocation.get(
                    "origin_production_contributions"
                ),
                origin_allocation_basis=str(
                    allocation.get("origin_allocation_basis") or ""
                ),
            )


MRP_DATED_RECEIPT_FIELDS = [
    "mrp_receipt_netting_mode", "mrp_receipt_netting_scope", "receipt_cover_end_day",
    "recv_prev_within_cover_qty", "recv_prev_after_cover_qty",
    "decision_receipt_cover_end_day", "decision_recv_prev_future_qty",
    "decision_recv_prev_within_cover_qty", "decision_recv_prev_after_cover_qty",
    "decision_stock_proj_qty", "decision_target_with_backlog_qty",
    "decision_held_release_within_cover_qty", "decision_bn_qty", "decision_controlled_bn_qty",
]
PRODUCTION_MRP_SAFETY_FIELDS = [
    f"{stage}_{field}" for stage in ("mps", "production")
    for field in ("mrp_safety_enabled", "target_signal_qty", "historical_target_qty",
                  "safety_floor_qty", "applied_target_qty", "safety_time_days",
                  "safety_stock_qty", "target_multiplier", "stock_position_qty",
                  "reference_signal_basis", "reference_signal_qty")
]
MRP_SOURCE_FORECAST_FIELDS = [
    "mrp_forecast_source", "mrp_forecast_vintage_day", "mrp_forecast_cycle_index",
    "mrp_forecast_window_days", "mrp_forecast_source_days", "mrp_forecast_fallback_days",
    "mrp_forecast_daily_qty", "mrp_forecast_source_rows",
]
SOURCE_BOUNDARY_TRACE_FIELDS = [
    "source_boundary_target_qty", "source_boundary_stock_qty_before_order",
    "source_boundary_pending_qty_before_order", "source_boundary_order_qty",
    "source_boundary_fixed_lot_qty", "source_boundary_lead_days",
    "source_boundary_cover_days", "source_boundary_daily_forecast_qty",
]
MRP_NETWORK_PLAN_FIELDS = [
    "dated_action_scope",
    "dated_requirement_qty", "dated_campaign_remaining_qty", "dated_reserve_requirement_qty",
    "dated_stock_qty", "dated_firm_held_qty", "dated_firm_transit_qty", "dated_firm_production_qty",
    "dated_proposed_qty", "dated_release_today_qty", "dated_released_executed_qty",
    "dated_late_qty", "dated_late_qty_days", "dated_first_shortage_day",
    "dated_reserve_late_qty", "dated_requirement_late_qty",
    "dated_min_projected_qty", "dated_horizon_days", "dated_lead_days", "dated_lead_basis",
]
SUPPLIER_DELIVERY_ORDER_FIELDS = [
    "delivery_reference_days", "delivery_sampled_days", "receipt_source_days", "receipt_calendar",
]


def plan_component_network(
    *, decision_day: int, requirements_by_pair: Mapping,
    available_by_pair: Mapping, firm_receipts_by_pair: Mapping,
    transport_sources_by_pair: Mapping, bom_by_pair: Mapping,
    lead_days_by_pair: Mapping, lot_sizing_by_pair: Mapping,
    reserve_targets_by_pair: Mapping, coverage_days_by_pair: Mapping,
    active_campaigns_by_pair: Mapping,
) -> tuple[dict, dict, dict]:
    """Net a dated acyclic network once, downstream to upstream.

    Inputs are a planning snapshot, never mutations of physical stock. Transport
    sources are (source_pair, share). Active campaigns are
    (stable_id, remaining_work_qty, already_executed_wip_qty, estimated_finish_day).
    Their remaining components are needed once; their unfinished output is
    credited once. Only *new* manufacturing proposals explode the BOM. Future
    proposals are revocable, while late firm receipts are never repurchased.
    """
    if type(decision_day) is not int:
        raise ValueError("Dated network decision day must be an integer")
    for book in (lead_days_by_pair, coverage_days_by_pair):
        if any(type(value) is not int or value < 0 for value in book.values()):
            raise ValueError("Dated network leads and coverage must be nonnegative integer days")
    if any(isinstance(value, bool) or not isinstance(value, (int, float))
           or not math.isfinite(value) or value < 0 for value in reserve_targets_by_pair.values()):
        raise ValueError("Dated network reserve targets must be finite and nonnegative")
    requirements = {pair: list(rows) for pair, rows in requirements_by_pair.items()}
    receipts = {pair: list(rows) for pair, rows in firm_receipts_by_pair.items()}
    campaign_requirements: dict = defaultdict(float)
    for pair, (campaign_id, remaining, wip, finish_day) in active_campaigns_by_pair.items():
        if (not isinstance(campaign_id, str) or not campaign_id or type(finish_day) is not int
                or finish_day <= decision_day
                or any(isinstance(q, bool) or not isinstance(q, (int, float))
                       or not math.isfinite(q) or q < 0 for q in (remaining, wip))):
            raise ValueError("Invalid dated active production campaign")
        if remaining + wip <= LOT_TRACE_EPS:
            continue
        receipts.setdefault(pair, []).append(FirmReceipt(
            "campaign:" + campaign_id, finish_day, remaining + wip, "confirmed",
        ))
        for component_pair, ratio in bom_by_pair.get(pair, ()):
            qty = remaining * ratio
            requirements.setdefault(component_pair, []).append(Requirement(
                "campaign:" + campaign_id + ":" + "|".join(component_pair), decision_day + 1, qty,
            ))
            campaign_requirements[component_pair] += qty

    all_pairs = set(requirements) | set(receipts) | set(reserve_targets_by_pair)
    all_pairs.update(bom_by_pair)
    all_pairs.update(transport_sources_by_pair)
    upstream: dict = {}
    for pair in list(all_pairs):
        if bom_by_pair.get(pair) and transport_sources_by_pair.get(pair):
            raise ValueError("Dated network pair cannot both manufacture and buy without an explicit sourcing split")
        links = list(bom_by_pair.get(pair, ())) or list(transport_sources_by_pair.get(pair, ()))
        if any(isinstance(weight, bool) or not isinstance(weight, (int, float))
               or not math.isfinite(weight) or weight <= 0 for _, weight in links):
            raise ValueError("Dated network coefficients must be finite and positive")
        if transport_sources_by_pair.get(pair) and abs(sum(weight for _, weight in links) - 1.0) > 1e-9:
            raise ValueError("Dated transport shares must sum to one")
        upstream[pair] = links
        all_pairs.update(source for source, _ in links)
    indegree = {pair: 0 for pair in all_pairs}
    for links in upstream.values():
        for source, _ in links:
            indegree[source] += 1
    ready = deque(sorted(pair for pair, count in indegree.items() if count == 0))
    ordered = []
    while ready:
        pair = ready.popleft()
        ordered.append(pair)
        for source, _ in upstream.get(pair, ()):
            indegree[source] -= 1
            if indegree[source] == 0:
                ready.append(source)
    if len(ordered) != len(all_pairs):
        raise ValueError("Dated component planning requires an acyclic supply/BOM network")

    plans, reserve_quantities = {}, {}
    for pair in ordered:
        pair_requirements = requirements.setdefault(pair, [])
        cover = max(1, int(coverage_days_by_pair.get(pair, 1)))
        cover_end = decision_day + cover
        gross_in_cover = sum(row.qty for row in pair_requirements if row.due_day <= cover_end)
        reserve = max(0.0, float(reserve_targets_by_pair.get(pair, 0.0)) - gross_in_cover)
        reserve_quantities[pair] = reserve
        if reserve > LOT_TRACE_EPS:
            pair_requirements.append(Requirement("reserve:" + "|".join(pair), cover_end, reserve))
        plan = plan_dated_requirements(
            decision_day=decision_day, available_qty=available_by_pair.get(pair, 0.0),
            requirements=pair_requirements, firm_receipts=receipts.get(pair, ()),
            lead_days=int(lead_days_by_pair.get(pair, 1)),
            lot_sizing=lot_sizing_by_pair.get(pair, LotSizing()),
        )
        plans[pair] = plan
        for proposal in plan.proposals:
            for source, coefficient in upstream.get(pair, ()):
                requirements.setdefault(source, []).append(Requirement(
                    "derived:" + "|".join(pair) + ":" + proposal.proposal_id + ":" + "|".join(source),
                    proposal.release_day, proposal.qty * coefficient,
                ))
    audit = {pair: {
        "campaign_remaining_qty": campaign_requirements.get(pair, 0.0),
        "reserve_requirement_qty": reserve_quantities.get(pair, 0.0),
        "firm_receipts": receipts.get(pair, ()),
    } for pair in plans}
    return plans, requirements, audit


class RollingMrpForecast:
    """Source I forecasts known at a decision date, separate from physical demand.

    A missing period stays unknown and uses an explicitly supplied nominal
    forecast. Explicit zero stays zero. Only one vintage is used per decision;
    annual repetitions are synthetic scenarios, not new industrial observations.
    """

    def __init__(self, payload: Any, *, demand_pairs: set[tuple[str, str]], origin_date: str) -> None:
        if not isinstance(payload, dict) or type(payload.get("schema_version")) is not int or payload["schema_version"] != 1:
            raise ValueError("mrp_forecasts requires schema_version 1")
        if payload.get("origin") != origin_date and payload.get("origin_date") != origin_date:
            raise ValueError("MRP forecast origin must match the simulation origin")
        if payload.get("calendar") != "sunday_start":
            raise ValueError("MRP forecasts require the declared sunday_start convention")
        repeat = payload.get("repeat_period_days")
        if type(repeat) is not int or repeat <= 0:
            raise ValueError("MRP forecast repeat period must be a positive integer")
        self.repeat_period_days = repeat
        self.origin_date = origin_date
        self.current_bucket_policy = str(payload.get("current_bucket_policy") or "unspecified")
        self.demand_pairs = set(demand_pairs)
        self._plans: dict[tuple[int, tuple[str, str]], dict[int, tuple[float, str]]] = {}
        self._selection_cache: dict[int, tuple[int, int] | None] = {}
        rows = payload.get("rows")
        if not isinstance(rows, list) or not rows:
            raise ValueError("MRP forecast rows must be a nonempty list")
        vintages: set[int] = set()
        for row in rows:
            if not isinstance(row, dict):
                raise ValueError("MRP forecast row must be an object")
            pair = (row.get("node_id"), row.get("item_id"))
            if pair not in self.demand_pairs or row.get("uom") != "UN":
                raise ValueError("MRP forecast must identify a modeled UN finished-good demand pair")
            vintage, start, length = (row.get(key) for key in ("vintage_day", "period_start_day", "period_days"))
            if (type(vintage) is not int or not 0 <= vintage < repeat
                    or type(start) is not int or type(length) is not int or length != 7):
                raise ValueError("MRP forecast dates must be integer days, with seven-day source periods")
            if self.current_bucket_policy == "excluded_unresolved_carry_over" and start <= vintage:
                raise ValueError("Current and past MRP buckets cannot be treated as new forecast demand")
            quantity = row.get("qty")
            if isinstance(quantity, bool) or not isinstance(quantity, (int, float)) or not math.isfinite(quantity) or quantity < 0:
                raise ValueError("MRP forecast quantity must be finite and nonnegative")
            source_row = row.get("source_row")
            if source_row is None or isinstance(source_row, bool) or not str(source_row).strip():
                raise ValueError("MRP forecast row requires source provenance")
            plan = self._plans.setdefault((vintage, pair), {})
            for target_day in range(start, start + length):
                if target_day in plan:
                    raise ValueError("Overlapping MRP forecast periods in the same vintage and demand pair")
                plan[target_day] = (float(quantity) / length, str(source_row))
            vintages.add(vintage)
        self.vintages = sorted(vintages)
        self.row_count = len(rows)

    def selection(self, decision_day: int) -> tuple[int, int] | None:
        if type(decision_day) is not int or decision_day < 0:
            raise ValueError("MRP forecast decision day must be a nonnegative integer")
        if decision_day not in self._selection_cache:
            cycle, day_in_cycle = divmod(decision_day, self.repeat_period_days)
            index = bisect_right(self.vintages, day_in_cycle) - 1
            if index < 0 and cycle > 0:
                cycle -= 1
                index = len(self.vintages) - 1
            self._selection_cache[decision_day] = (self.vintages[index], cycle) if index >= 0 else None
        return self._selection_cache[decision_day]

    def window(self, pair: tuple[str, str], *, decision_day: int, target_day: int,
               fallback_daily_values: list[float]) -> tuple[float, dict[str, Any]]:
        if pair not in self.demand_pairs or type(target_day) is not int or not fallback_daily_values:
            raise ValueError("MRP forecast window requires a known demand pair and nonempty daily fallback")
        if any(not math.isfinite(value) or value < 0 for value in fallback_daily_values):
            raise ValueError("MRP nominal forecast fallback must be finite and nonnegative")
        selected = self.selection(decision_day)
        vintage, cycle = selected if selected is not None else (0, 0)
        offset = cycle * self.repeat_period_days
        plan = self._plans.get((vintage, pair), {}) if selected is not None else {}
        values: list[float] = []
        source_rows: set[str] = set()
        source_days = 0
        for index, fallback in enumerate(fallback_daily_values):
            source = plan.get(target_day + index - offset)
            values.append(source[0] if source is not None else fallback)
            if source is not None:
                source_days += 1
                source_rows.add(source[1])
        return sum(values) / len(values), {
            "vintage_day": vintage + offset if selected is not None else "",
            "cycle_index": cycle if selected is not None else "",
            "source_days": source_days,
            "fallback_days": len(values) - source_days,
            "source_rows": "|".join(sorted(source_rows)),
        }


def production_mrp_safety_target(
    historical_target_qty: float, output_daily_signal_qty: float,
    safety_time_calendar_days: float, safety_stock_qty: float,
) -> float:
    """Planning target only; physical lot rounding and SD dynamics stay downstream."""
    try:
        historical, signal, days, quantity = map(float, (
            historical_target_qty, output_daily_signal_qty, safety_time_calendar_days, safety_stock_qty,
        ))
    except (TypeError, ValueError) as exc:
        raise ValueError("Production safety target inputs must be finite and nonnegative") from exc
    if any(not math.isfinite(value) or value < 0 for value in (historical, signal, days, quantity)):
        raise ValueError("Production safety target inputs must be finite and nonnegative")
    target = max(historical, signal * days, quantity)
    if not math.isfinite(target):
        raise ValueError("Production safety target overflow")
    return target


def mrp_purchase_order_quantity(
    desired_qty: float, available_qty: float, standard_order_qty: float, *, binding: bool, uom: str = "",
) -> float:
    """Size a feasible purchase release; reference quantities need not be lots."""
    values = (float(desired_qty), float(available_qty), float(standard_order_qty))
    if any(not math.isfinite(value) or value < 0 for value in values):
        raise ValueError("MRP purchase quantities must be finite and nonnegative")
    desired, available, standard = values
    if desired <= 1e-9 or available <= 0:
        return 0.0
    if binding and standard > 1e-9:
        target_units = max(1, int(math.ceil(desired / standard - 1e-9)))
        feasible_units = int(math.floor(available / standard + 1e-9))
        quantity = min(target_units, feasible_units) * standard if feasible_units > 0 else 0.0
    else:
        quantity = min(desired, available)
    return physical_execution_quantity(quantity, uom)


def source_boundary_order_quantity(
    target_qty: float, stock_qty: float, pending_qty: float, fixed_lot_qty: float,
) -> float:
    """Plan an aggregate boundary supply without duplicating committed lots."""
    try:
        target, stock, pending, lot = map(float, (target_qty, stock_qty, pending_qty, fixed_lot_qty))
    except (TypeError, ValueError) as exc:
        raise ValueError("Boundary quantities must be finite numbers") from exc
    if any(not math.isfinite(value) or value < 0 for value in (target, stock, pending, lot)) or lot <= 0:
        raise ValueError("Boundary quantities must be finite, nonnegative, with a positive fixed lot")
    if not math.isfinite(stock + pending):
        raise ValueError("Boundary inventory position overflow")
    missing = max(0.0, target - stock - pending)
    if missing <= LOT_TRACE_EPS:
        return 0.0
    quantity = math.ceil(missing / lot) * lot
    if not math.isfinite(quantity):
        raise ValueError("Boundary supply quantity overflow")
    return quantity


def source_boundary_supply_policies(
    payload: Any, *, eligible_pairs: set[tuple[str, str]], item_unit_map: dict[str, str],
) -> dict[tuple[str, str], dict[str, Any]]:
    """Read explicitly documented boundaries; never infer a missing factory BOM."""
    if not isinstance(payload, dict) or type(payload.get("schema_version")) is not int or payload["schema_version"] != 1:
        raise ValueError("Source boundary supplies require schema_version 1")
    if not isinstance(payload.get("rows"), list) or not payload["rows"]:
        raise ValueError("Source boundary supplies require nonempty rows")
    policies: dict[tuple[str, str], dict[str, Any]] = {}
    for row in payload["rows"]:
        if not isinstance(row, dict):
            raise ValueError("Source boundary row must be an object")
        pair = (row.get("node_id"), row.get("item_id"))
        if pair not in eligible_pairs or pair in policies:
            raise ValueError("Source boundary must be a distinct unmodeled factory source pair")
        if normalize_unit(row.get("uom")) != normalize_unit(item_unit_map.get(pair[1])):
            raise ValueError("Source boundary unit must match its modeled stock unit")
        for field in ("lead_days", "review_period_days"):
            if type(row.get(field)) is not int or row[field] <= 0:
                raise ValueError("Source boundary lead and review periods must be positive integer days")
        if row.get("lead_calendar") != "calendar_days_assumption" or row.get("capacity_status") != "unknown_not_modeled":
            raise ValueError("Source boundary must declare its calendar convention and unknown capacity")
        if any(not isinstance(row.get(field), dict) or not row[field] for field in ("lot_source", "lead_source")):
            raise ValueError("Source boundary lot and receipt lead require source provenance")
        lot = float(row.get("fixed_lot_qty"))
        source_boundary_order_quantity(0.0, 0.0, 0.0, lot)
        require_physical_integer(lot, row["uom"])
        policies[pair] = dict(row, fixed_lot_qty=lot)
    return policies


def mrp_opening_order_cover_days(
    cover_days: float, opening_bridge_days: float, *, quantity_netting_only: bool,
) -> float:
    """Opening receipts cover quantities; they do not shorten the supply lead.

    The legacy bridge is retained only for historical reproduction. When
    receipts are netted as quantities, subtracting their opening bridge here
    would credit them twice and permanently reduce the planning horizon after
    those receipts have been consumed.
    """
    try:
        cover, bridge = map(float, (cover_days, opening_bridge_days))
    except (TypeError, ValueError) as exc:
        raise ValueError("MRP coverage days must be finite and nonnegative") from exc
    if any(not math.isfinite(value) or value < 0 for value in (cover, bridge)):
        raise ValueError("MRP coverage days must be finite and nonnegative")
    return cover if quantity_netting_only else max(0.0, cover - bridge)


def mrp_receipt_cover_end_day(decision_day: int, window_days: float) -> int:
    """Inclusive existing planning window; this is not a time-phased MRP solver."""
    if type(decision_day) is not int:
        raise ValueError("MRP decision day must be an integer")
    try:
        window = float(window_days)
    except (TypeError, ValueError) as exc:
        raise ValueError("MRP receipt window must be finite and nonnegative") from exc
    if not math.isfinite(window) or window < 0:
        raise ValueError("MRP receipt window must be finite and nonnegative")
    return decision_day + max(1, math.ceil(window)) - 1


class DatedReceiptCalendar:
    """Pending receipts by physical pair and availability day, independent of stock.

    Buckets are updated only when receipts are scheduled or received. Sorted
    dates and cumulative quantities are cached per pair, so a query never scans
    the multi-year calendar for all pairs. Different origins can be added once
    each; a received quantity must be removed before it is credited to stock.
    """

    def __init__(self) -> None:
        self._buckets: dict[tuple[str, str], dict[int, float]] = {}
        self._cache: dict[tuple[str, str], tuple[list[int], list[float]]] = {}

    @staticmethod
    def _validate(pair: tuple[str, str], arrival_day: int, qty: float) -> float:
        if (not isinstance(pair, tuple) or len(pair) != 2
                or any(not isinstance(value, str) or not value for value in pair)):
            raise ValueError("Receipt pair must contain node and item identifiers")
        if type(arrival_day) is not int:
            raise ValueError("Receipt availability day must be an integer")
        try:
            quantity = float(qty)
        except (TypeError, ValueError) as exc:
            raise ValueError("Receipt quantity must be finite and nonnegative") from exc
        if not math.isfinite(quantity) or quantity < 0:
            raise ValueError("Receipt quantity must be finite and nonnegative")
        return quantity

    def add(self, pair: tuple[str, str], arrival_day: int, qty: float) -> None:
        quantity = self._validate(pair, arrival_day, qty)
        if quantity == 0:
            return
        bucket = self._buckets.setdefault(pair, {})
        updated = bucket.get(arrival_day, 0.0) + quantity
        if not math.isfinite(updated):
            raise ValueError("Receipt calendar quantity overflow")
        bucket[arrival_day] = updated
        self._cache.pop(pair, None)

    def remove(self, pair: tuple[str, str], arrival_day: int, qty: float) -> None:
        quantity = self._validate(pair, arrival_day, qty)
        if quantity == 0:
            return
        bucket = self._buckets.get(pair, {})
        if arrival_day not in bucket:
            raise ValueError("Cannot receive a quantity absent from the receipt calendar")
        current = bucket[arrival_day]
        remaining = current - quantity
        tolerance = max(1e-9, abs(current) * 1e-12)
        if remaining < -tolerance:
            raise ValueError("Received quantity exceeds the pending receipt calendar")
        if abs(remaining) <= tolerance:
            del bucket[arrival_day]
        else:
            bucket[arrival_day] = remaining
        if not bucket:
            self._buckets.pop(pair, None)
        self._cache.pop(pair, None)

    def _prefix(self, pair: tuple[str, str]) -> tuple[list[int], list[float]]:
        cached = self._cache.get(pair)
        if cached is None:
            bucket = self._buckets.get(pair, {})
            days = sorted(bucket)
            prefix = [0.0]
            for day in days:
                amount = prefix[-1] + bucket[day]
                if not math.isfinite(amount):
                    raise ValueError("Receipt calendar cumulative quantity overflow")
                prefix.append(amount)
            cached = (days, prefix)
            self._cache[pair] = cached
        return cached

    def quantity(self, pair: tuple[str, str], *, decision_day: int, through_day: int) -> float:
        self._validate(pair, decision_day, 0.0)
        if type(through_day) is not int:
            raise ValueError("Receipt cover end day must be an integer")
        if through_day < decision_day:
            return 0.0
        days, prefix = self._prefix(pair)
        return max(0.0, prefix[bisect_right(days, through_day)] - prefix[bisect_left(days, decision_day)])

    def total(self, pair: tuple[str, str]) -> float:
        self._validate(pair, 0, 0.0)
        return self._prefix(pair)[1][-1]


class OpeningPurchaseAvailability:
    """Execute a source order's physical receipt G and usable release I once.

    The operational receipt pipeline remains a promise of availability at I.
    Held quantities are a physical decomposition of that promise, never an
    additional MRP credit. This register does not change available stock.
    """

    @staticmethod
    def marker_for(source_file: str, source_row: Any) -> str:
        if (source_file is None or source_row is None or isinstance(source_row, bool)
                or not str(source_file).strip() or not str(source_row).strip()):
            raise ValueError("Dated opening purchase requires source file and row")
        return "OPENING_DATED_PURCHASE|" + json.dumps(
            [str(source_file), str(source_row)], ensure_ascii=False, separators=(",", ":"),
        )

    def __init__(self, rows: list[dict[str, Any]], *, item_unit_map: dict[str, str]) -> None:
        self.item_unit_map = item_unit_map
        self.rows: list[dict[str, Any]] = []
        self.by_marker: dict[str, dict[str, Any]] = {}
        self.by_delivery_day: dict[int, list[dict[str, Any]]] = defaultdict(list)
        self.held_by_pair: dict[tuple[str, str], float] = defaultdict(float)
        for raw in rows:
            if raw.get("order_type") not in {"opening_purchase_order", "external_procurement_supplier_delivery"}:
                continue
            g, usable = raw.get("physical_delivery_day"), raw.get("arrival_day")
            if (type(g) is not int or type(usable) is not int or g < 0 or usable < g):
                raise ValueError("Dated opening purchase requires integer dates 0 <= G <= I")
            pair = (str(raw.get("node_id") or ""), str(raw.get("item_id") or ""))
            if not all(pair) or not normalize_unit(item_unit_map.get(pair[1], "")):
                raise ValueError("Unknown dated opening purchase pair or unit")
            try:
                if isinstance(raw.get("receipt_qty"), bool):
                    raise ValueError("Boolean is not a source quantity")
                qty = require_physical_integer(raw.get("receipt_qty"), item_unit_map[pair[1]])
            except (TypeError, ValueError) as exc:
                raise ValueError("Invalid dated opening purchase quantity") from exc
            if qty <= 0:
                raise ValueError("Dated opening purchase quantity must be positive")
            marker = self.marker_for(raw.get("source_file", ""), raw.get("source_row", ""))
            if raw.get("order_type") == "external_procurement_supplier_delivery":
                marker = raw.get("mrp_order_id")
                if not isinstance(marker, str) or not marker.strip() or not raw.get("src_node_id"):
                    raise ValueError("Supplier delivery requires its order and supplier identity")
            if marker in self.by_marker:
                raise ValueError("Duplicate dated opening purchase source row")
            row = dict(raw, node_id=pair[0], item_id=pair[1], quantity=qty,
                       uom=normalize_unit(item_unit_map[pair[1]]), marker=marker,
                       received=False, released=False, lot_id="")
            self.rows.append(row)
            self.by_marker[marker] = row
            self.by_delivery_day[g].append(row)

    def add_order(self, raw: dict[str, Any]) -> None:
        """Register one new aggregate supplier promise, with explicit G and I."""
        if raw.get("order_type") != "external_procurement_supplier_delivery":
            raise ValueError("Only a new aggregate supplier order can be appended")
        validated = OpeningPurchaseAvailability([raw], item_unit_map=self.item_unit_map)
        row = validated.rows[0]
        if row["marker"] in self.by_marker:
            raise ValueError("Supplier delivery order is already registered")
        self.rows.append(row)
        self.by_marker[row["marker"]] = row
        self.by_delivery_day[row["physical_delivery_day"]].append(row)

    def receive_physical(self, day: int, *, ledger: LotLedger) -> dict[tuple[str, str], float]:
        if type(day) is not int or day < 0:
            raise ValueError("Opening purchase physical receipt day must be a nonnegative integer")
        received: dict[tuple[str, str], float] = defaultdict(float)
        for row in self.by_delivery_day.get(day, []):
            if row["received"]:
                raise ValueError("Opening purchase physical receipt already executed")
            pair = (row["node_id"], row["item_id"])
            qty = row["quantity"]
            aggregate = row["order_type"] == "external_procurement_supplier_delivery"
            row["lot_id"] = ledger.create_lot(
                day=day, node_id=pair[0], item_id=pair[1], qty=qty, uom=row["uom"],
                source_type="supplier_delivery_receipt" if aggregate else "opening_purchase_order_receipt",
                source_id=str(row.get("edge_id") or row["marker"]) if aggregate else row["marker"],
                event_type="external_procurement_receipt" if aggregate else "opening_purchase_order_receipt", arrival_day=day,
                planned_order_id=row["marker"], baseline_reference_id=row["marker"],
                trace_status="untraced_before_boundary" if aggregate else "untraced_before_horizon",
                trace_reason="supplier_delivery_boundary_departure_and_supplier_batch_unknown" if aggregate else "source_order_known_supplier_business_batch_unknown",
                notes=(f"Simulated supplier delivery G; candidate receipt calendar; usable I={row['arrival_day']}; no physical departure inferred."
                       if aggregate else f"Source planned physical receipt G; usable I={row['arrival_day']}; not observed actual delivery."),
                source_row=row["source_row"], supplier_id=str(row.get("src_node_id") or ""),
            )
            ledger.change_stock_availability(
                day=day, node_id=pair[0], item_id=pair[1], qty=qty,
                allocations=[{"lot_id": row["lot_id"], "qty": qty}],
                source_id=row["marker"], source_type="supplier_delivery_availability" if aggregate else "opening_purchase_availability",
                notes="Physical delivery G; held until source availability I; not a second MRP credit.",
            )
            self.held_by_pair[pair] += qty
            row["received"] = True
            received[pair] += qty
        return dict(received)

    def release(self, marker: str, day: int, qty: float, *, ledger: LotLedger) -> None:
        if marker not in self.by_marker or type(day) is not int or isinstance(qty, bool):
            raise ValueError("Invalid opening purchase release identity, date or quantity")
        row = self.by_marker[marker]
        try:
            qty = require_physical_integer(qty, row["uom"])
        except (TypeError, ValueError) as exc:
            raise ValueError("Invalid opening purchase release quantity") from exc
        if (not row["received"] or row["released"] or day != row["arrival_day"]
                or not math.isfinite(qty) or abs(qty - row["quantity"]) > LOT_TRACE_EPS):
            raise ValueError("Opening purchase release must match its single physical receipt and source date")
        pair = (row["node_id"], row["item_id"])
        ledger.change_stock_availability(
            day=day, node_id=pair[0], item_id=pair[1], qty=qty, release=True,
            allocations=[{"lot_id": row["lot_id"], "qty": qty}], source_id=marker,
            source_type="supplier_delivery_availability" if row["order_type"] == "external_procurement_supplier_delivery" else "opening_purchase_availability",
            notes="Availability I of the same received lot; no receipt, procurement or transport.",
        )
        self.held_by_pair[pair] = max(0.0, self.held_by_pair[pair] - qty)
        row["released"] = True


def supplier_receipt_available_day(physical_day: int, receipt_days: int, *, origin_date: str,
                                   calendar: str = "monday_friday") -> int:
    """Candidate receipt calendar; no holiday or closure is silently inferred."""
    if (type(physical_day) is not int or physical_day < 0 or type(receipt_days) is not int
            or receipt_days < 0 or calendar != "monday_friday"):
        raise ValueError("Supplier receipt requires nonnegative integer days and explicit monday_friday calendar")
    try:
        origin = date.fromisoformat(origin_date)
    except (TypeError, ValueError) as exc:
        raise ValueError("Supplier receipt calendar requires an ISO origin date") from exc
    current = origin + timedelta(days=physical_day)
    remaining = receipt_days
    while remaining:
        current += timedelta(days=1)
        if current.weekday() < 5:
            remaining -= 1
    return (current - origin).days


class InitialStockAvailability:
    """Dated usability of stock already present; never an inbound shipment."""

    BACKCAST_ASSUMPTION = "backcast_first_snapshot_for_separate_experiment"
    DAILY_FIELDS = ["day", "node_id", "item_id", "uom", "available_qty", "held_qty",
                    "reserved_qty", "physical_qty", "released_qty"]

    def __init__(self, payload: Any, *, stock: dict[tuple[str, str], float],
                 item_unit_map: dict[str, str], origin_date: str) -> None:
        if (not isinstance(payload, dict) or type(payload.get("schema_version")) is not int
                or payload.get("schema_version") != 1):
            raise ValueError("initial_stock_availability requires schema_version 1")
        try:
            origin = date.fromisoformat(origin_date)
            knowledge = date.fromisoformat(str(payload["knowledge_date"]))
        except (TypeError, ValueError, KeyError) as exc:
            raise ValueError("Stock availability requires valid origin and knowledge dates") from exc
        self.knowledge_day = (knowledge - origin).days
        self.assumption = str(payload.get("assumption") or "")
        if self.assumption not in {"", self.BACKCAST_ASSUMPTION}:
            raise ValueError("Unknown stock availability assumption")
        if self.knowledge_day > 0 and self.assumption != self.BACKCAST_ASSUMPTION:
            raise ValueError("Stock availability knowledge date is after simulation origin")
        self.effective_knowledge_day = min(0, self.knowledge_day)
        self.knowledge_date = knowledge.isoformat()
        self.origin_date = origin.isoformat()
        self.rows: list[dict[str, Any]] = []
        self.held_by_pair: dict[tuple[str, str], float] = defaultdict(float)
        self.item_unit_map = item_unit_map
        self._initialized = False
        raw_rows = payload.get("rows")
        if not isinstance(raw_rows, list) or not raw_rows:
            raise ValueError("Stock availability rows must be a nonempty list")
        seen_sources = set()
        for raw in raw_rows:
            if not isinstance(raw, dict):
                raise ValueError("Stock availability row must be an object")
            pair = (str(raw.get("node_id") or ""), str(raw.get("item_id") or ""))
            if pair not in stock:
                raise ValueError(f"Unknown stock availability pair: {pair}")
            uom = normalize_unit(raw.get("uom"))
            if not uom or uom != normalize_unit(item_unit_map.get(pair[1], "")):
                raise ValueError(f"Stock availability unit does not match graph: {pair}")
            raw_qty = raw.get("quantity")
            if isinstance(raw_qty, bool) or not isinstance(raw_qty, (int, float)):
                raise ValueError("Stock availability quantity must be numeric")
            qty = require_physical_integer(raw_qty, uom)
            if qty <= 0:
                raise ValueError("Stock availability quantity must be positive")
            release_day = raw.get("release_day")
            if isinstance(release_day, bool) or not isinstance(release_day, int) or release_day <= 0:
                raise ValueError("Stock availability release_day must be a positive integer")
            if release_day <= self.knowledge_day:
                raise ValueError("Stock availability release must follow the source knowledge date")
            source_row = raw.get("source_row")
            if not isinstance(source_row, str) or not source_row.strip():
                raise ValueError("Stock availability source_row must be nonempty and unique")
            source_row = source_row.strip()
            if source_row in seen_sources:
                raise ValueError("Stock availability source_row must be nonempty and unique")
            seen_sources.add(source_row)
            self.held_by_pair[pair] += qty
            self.rows.append({"node_id": pair[0], "item_id": pair[1], "quantity": qty,
                              "uom": uom, "release_day": release_day, "source_row": source_row,
                              "released": False, "allocations": []})
        for pair, held in self.held_by_pair.items():
            physical = require_physical_integer(stock[pair], item_unit_map[pair[1]])
            if held > physical + 1e-9:
                raise ValueError(f"Held stock exceeds initial physical quantity for {pair}")

    def initialize(self, *, stock: dict[tuple[str, str], float], ledger: LotLedger) -> None:
        if self._initialized:
            raise ValueError("Stock availability is already initialized")
        for row in self.rows:
            pair = (row["node_id"], row["item_id"])
            row["allocations"] = ledger.change_stock_availability(
                day=0, node_id=pair[0], item_id=pair[1], qty=row["quantity"],
                source_id=row["source_row"], notes=json.dumps({
                    "knowledge_date": self.knowledge_date, "release_day": row["release_day"],
                    "assumption": self.assumption, "physical_movement": False}, sort_keys=True),
            )
            stock[pair] -= row["quantity"]
        self._initialized = True

    def planning_quantity(self, pair: tuple[str, str], *, decision_day: int,
                          through_day: int) -> float:
        if decision_day < self.effective_knowledge_day:
            return 0.0
        return sum(row["quantity"] for row in self.rows
                   if not row["released"] and (row["node_id"], row["item_id"]) == pair
                   and decision_day < row["release_day"] <= through_day)

    def release(self, day: int, *, stock: dict[tuple[str, str], float],
                ledger: LotLedger) -> dict[tuple[str, str], float]:
        if not self._initialized:
            raise ValueError("Stock availability must be initialized before release")
        released: dict[tuple[str, str], float] = defaultdict(float)
        for row in self.rows:
            if row["released"] or row["release_day"] != day:
                continue
            pair = (row["node_id"], row["item_id"])
            ledger.change_stock_availability(
                day=day, node_id=pair[0], item_id=pair[1], qty=row["quantity"], release=True,
                allocations=row["allocations"], source_id=row["source_row"],
                notes="Release of existing physical stock; no receipt, procurement or transport.",
            )
            stock[pair] += row["quantity"]
            self.held_by_pair[pair] = max(0.0, self.held_by_pair[pair] - row["quantity"])
            released[pair] += row["quantity"]
            row["released"] = True
        return dict(released)

    def audit(self) -> dict[str, Any]:
        return {"schema_version": 1, "enabled": True, "knowledge_date": self.knowledge_date,
                "origin_date": self.origin_date, "knowledge_day": self.knowledge_day,
                "effective_knowledge_day": self.effective_knowledge_day,
                "assumption": self.assumption, "physical_initial_stock_unchanged": True,
                "release_is_receipt": False, "row_count": len(self.rows),
                "rows": [{key: row[key] for key in ("node_id", "item_id", "quantity", "uom",
                                                    "release_day", "source_row")} for row in self.rows],
                "daily_csv": "data/production_stock_availability_daily.csv",
                "planning_basis": "known_release_within_forward_cover_window_including_decision_day",
                "holding_basis": "available_plus_held_reserved_excluded_as_in_nominal"}


def require_physical_integer(value: Any, uom: Any) -> float:
    """Ledger guard: a physical boundary must quantize before recording it."""
    quantity = float(value)
    if not math.isfinite(quantity) or quantity < 0:
        raise ValueError("Physical quantity must be finite and non-negative")
    if normalize_unit(uom) == "UN":
        if abs(quantity - round(quantity)) > 1e-8:
            raise ValueError(f"Physical UN quantity must be integral: {quantity}")
        return float(round(quantity))
    return quantity


def physical_execution_quantity(value: Any, uom: Any) -> float:
    """Execute only whole countable units; retain forecast residuals upstream.

    Round down at a physical boundary, before updating stock AND its ledger.
    Mass and length retain their precision. This never rounds display values.
    """
    quantity = float(value)
    if not math.isfinite(quantity):
        raise ValueError("Physical quantity must be finite")
    quantity = max(0.0, quantity)
    if normalize_unit(uom) == "UN":
        return normalize_physical_quantity(quantity, "UN", rounding="down")
    return quantity


def production_wip_execution_quantity(value: Any) -> float:
    """Drop numerical residue before component issues and WIP bookkeeping.

    Fractional work remains valid inside an unfinished batch. Work below the
    WIP ledger tolerance is not accepted and must not consume whole UN inputs.
    """
    quantity = float(value)
    if not math.isfinite(quantity) or quantity < 0:
        raise ValueError("Production WIP execution must be finite and nonnegative")
    return quantity if quantity > LOT_TRACE_EPS else 0.0


def scale_physical_allocations(allocations: list[dict[str, Any]], factor: float, uom: Any) -> list[dict[str, Any]]:
    """Scale a transit's parents with the same cumulative rounding as its total."""
    scaled: list[dict[str, Any]] = []
    cumulative = previous = 0.0
    for allocation in allocations:
        cumulative += require_physical_integer(allocation.get("qty", 0.0), uom) * factor
        boundary = physical_execution_quantity(cumulative, uom)
        qty = boundary - previous
        if qty > LOT_TRACE_EPS:
            scaled.append({**allocation, "qty": qty})
        previous = boundary
    return scaled


def normalize_unit(unit: Any) -> str:
    s = str(unit or "").strip().upper()
    aliases = {
        "UNIT": "UN",
        "UNITE": "UN",
        "UNITES": "UN",
        "UNITS": "UN",
        "ZUN": "UN",
    }
    return aliases.get(s, s)




def can_convert_units(from_unit: str, to_unit: str) -> bool:
    f = normalize_unit(from_unit)
    t = normalize_unit(to_unit)
    return f == t or {f, t} <= {"G", "KG"}


def convert_quantity(value: float, from_unit: str, to_unit: str) -> float:
    f = normalize_unit(from_unit)
    t = normalize_unit(to_unit)
    if f == t or not f or not t:
        return value
    if f == "G" and t == "KG":
        return value / 1000.0
    if f == "KG" and t == "G":
        return value * 1000.0
    return value


def normalize_lot_value(value: Any, from_unit: str, to_unit: str) -> float:
    qty = max(0.0, to_float(value, 0.0))
    if qty <= 0:
        return 0.0
    return max(0.0, convert_quantity(qty, from_unit, to_unit))


def process_lot_policy(
    proc: dict[str, Any],
    *,
    out_item: str,
    item_unit_map: dict[str, str],
) -> dict[str, Any]:
    raw = proc.get("lot_sizing") or {}
    if not isinstance(raw, dict):
        raw = {}
    item_uom = normalize_unit(item_unit_map.get(out_item, ""))
    policy_uom = normalize_unit(raw.get("uom") or item_uom)
    fixed_lot_qty = normalize_lot_value(raw.get("fixed_lot_qty"), policy_uom, item_uom)
    min_lot_qty = normalize_lot_value(raw.get("min_lot_qty"), policy_uom, item_uom)
    max_lot_qty = normalize_lot_value(raw.get("max_lot_qty"), policy_uom, item_uom)
    lot_multiple_qty = normalize_lot_value(raw.get("lot_multiple_qty"), policy_uom, item_uom)
    normalization_rule = str(raw.get("normalization_rule") or "")
    if fixed_lot_qty <= 1e-9 and min_lot_qty > 1e-9 and abs(min_lot_qty - max_lot_qty) <= 1e-9:
        fixed_lot_qty = min_lot_qty
        normalization_rule = normalization_rule or "min_equals_max_as_fixed"
    enabled = fixed_lot_qty > 1e-9 or min_lot_qty > 1e-9 or max_lot_qty > 1e-9
    execution_raw = proc.get("lot_execution") or {}
    if not isinstance(execution_raw, dict):
        execution_raw = {}
    max_lots_per_week = max(0.0, to_float(execution_raw.get("max_lots_per_week"), 0.0))
    return {
        "enabled": enabled,
        "fixed_lot_qty": fixed_lot_qty,
        "min_lot_qty": min_lot_qty,
        "max_lot_qty": max_lot_qty,
        "lot_multiple_qty": lot_multiple_qty,
        "uom": item_uom,
        "source": str(raw.get("source") or ""),
        "normalization_rule": normalization_rule,
        "max_lots_per_week": max_lots_per_week,
        "execution_source": str(execution_raw.get("source") or ""),
    }


def launch_campaign_qty(net_requirement_qty: float, lot_policy: dict[str, Any]) -> float:
    requirement = max(0.0, net_requirement_qty)
    if requirement <= 1e-9 or not lot_policy.get("enabled"):
        return requirement
    fixed_lot_qty = max(0.0, to_float(lot_policy.get("fixed_lot_qty"), 0.0))
    min_lot_qty = max(0.0, to_float(lot_policy.get("min_lot_qty"), 0.0))
    max_lot_qty = max(0.0, to_float(lot_policy.get("max_lot_qty"), 0.0))
    lot_multiple_qty = max(0.0, to_float(lot_policy.get("lot_multiple_qty"), 0.0))
    if fixed_lot_qty > 1e-9:
        return math.ceil(requirement / fixed_lot_qty) * fixed_lot_qty
    if max_lot_qty > 1e-9 and min_lot_qty > max_lot_qty + 1e-9:
        raise ValueError(
            f"Invalid lot policy: min_lot_qty={min_lot_qty} exceeds max_lot_qty={max_lot_qty}."
        )
    campaign_qty = max(requirement, min_lot_qty)
    if lot_multiple_qty > 1e-9:
        minimum_feasible = math.ceil((min_lot_qty / lot_multiple_qty) - 1e-12) * lot_multiple_qty
        maximum_feasible = (
            math.floor((max_lot_qty / lot_multiple_qty) + 1e-12) * lot_multiple_qty
            if max_lot_qty > 1e-9
            else float("inf")
        )
        if max_lot_qty > 1e-9 and maximum_feasible + 1e-9 < max(minimum_feasible, lot_multiple_qty):
            raise ValueError(
                "Invalid lot policy: no positive lot_multiple_qty fits between "
                f"min_lot_qty={min_lot_qty} and max_lot_qty={max_lot_qty}."
            )
        campaign_qty = math.ceil((campaign_qty / lot_multiple_qty) - 1e-12) * lot_multiple_qty
        if max_lot_qty > 1e-9:
            campaign_qty = min(campaign_qty, maximum_feasible)
    elif max_lot_qty > 1e-9:
        campaign_qty = min(campaign_qty, max_lot_qty)
    return max(0.0, campaign_qty)


def lot_reference_qty(lot_policy: dict[str, Any]) -> float:
    fixed_lot_qty = max(0.0, to_float(lot_policy.get("fixed_lot_qty"), 0.0))
    if fixed_lot_qty > 1e-9:
        return fixed_lot_qty
    max_lot_qty = max(0.0, to_float(lot_policy.get("max_lot_qty"), 0.0))
    if max_lot_qty > 1e-9:
        return max_lot_qty
    min_lot_qty = max(0.0, to_float(lot_policy.get("min_lot_qty"), 0.0))
    if min_lot_qty > 1e-9:
        return min_lot_qty
    lot_multiple_qty = max(0.0, to_float(lot_policy.get("lot_multiple_qty"), 0.0))
    if lot_multiple_qty > 1e-9:
        return lot_multiple_qty
    return 0.0


def should_defer_new_lot_for_stock_position(
    *,
    desired_qty: float,
    lot_policy: dict[str, Any],
    stock_qty: float,
    target_qty: float,
) -> bool:
    """Avoid launching a full lot when output stock is still inside the lot band.

    With fixed lots, a tiny daily requirement should not start a complete
    campaign if the current stock is still above target minus one lot. This is a
    production-order hysteresis: refill when the stock has actually consumed
    enough room for the next lot.
    """
    if not lot_policy.get("enabled"):
        return False
    desired = max(0.0, desired_qty)
    if desired <= 1e-9:
        return False
    lot_ref_qty = lot_reference_qty(lot_policy)
    if lot_ref_qty <= 1e-9:
        return False
    if desired >= lot_ref_qty - 1e-9:
        return False
    reorder_floor_qty = max(0.0, max(0.0, target_qty) - lot_ref_qty)
    return max(0.0, stock_qty) > reorder_floor_qty + 1e-9


def campaign_lot_count(campaign_qty: float, lot_policy: dict[str, Any]) -> int:
    qty = max(0.0, to_float(campaign_qty, 0.0))
    if qty <= 1e-9:
        return 0
    ref_qty = lot_reference_qty(lot_policy)
    if ref_qty <= 1e-9:
        return 0
    return max(0, int(math.ceil((qty / ref_qty) - 1e-9)))


def limit_campaign_qty_by_weekly_lots(
    campaign_qty: float,
    lot_policy: dict[str, Any],
    available_lot_starts: int,
) -> float:
    qty = max(0.0, to_float(campaign_qty, 0.0))
    if qty <= 1e-9:
        return 0.0
    allowed_lots = max(0, int(available_lot_starts))
    if allowed_lots <= 0:
        return 0.0
    ref_qty = lot_reference_qty(lot_policy)
    if ref_qty <= 1e-9:
        return qty
    fixed_lot_qty = max(0.0, to_float(lot_policy.get("fixed_lot_qty"), 0.0))
    min_lot_qty = max(0.0, to_float(lot_policy.get("min_lot_qty"), 0.0))
    max_lot_qty = max(0.0, to_float(lot_policy.get("max_lot_qty"), 0.0))
    capped_qty = min(qty, allowed_lots * ref_qty)
    if fixed_lot_qty > 1e-9:
        fixed_lots = max(0, int(math.floor((capped_qty / fixed_lot_qty) + 1e-9)))
        return fixed_lots * fixed_lot_qty
    if max_lot_qty > 1e-9:
        capped_qty = min(capped_qty, max_lot_qty)
    if min_lot_qty > 1e-9 and capped_qty + 1e-9 < min_lot_qty:
        return 0.0
    return max(0.0, capped_qty)


def infer_item_unit_map(nodes: list[dict[str, Any]], edges: list[dict[str, Any]]) -> dict[str, str]:
    votes: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))

    for e in edges:
        unit = normalize_unit(((e.get("order_terms") or {}).get("quantity_unit")))
        if not unit:
            continue
        for item_id in (e.get("items") or []):
            votes[str(item_id)][unit] += 3

    for n in nodes:
        for p in (n.get("processes") or []):
            for inp in (p.get("inputs") or []):
                item_id = str(inp.get("item_id"))
                unit = normalize_unit(inp.get("ratio_unit"))
                if item_id and unit:
                    votes[item_id][unit] += 1

    priority = {"KG": 4, "G": 3, "UN": 2, "M": 1}
    out: dict[str, str] = {}
    for item_id, cnt in votes.items():
        best = sorted(cnt.items(), key=lambda x: (-x[1], -priority.get(x[0], 0), x[0]))[0][0]
        out[item_id] = best
    return out


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run first-pass supply simulation.")
    parser.add_argument(
        "--input",
        default="etudecas/simulation_prep/result/supply_graph_poc_simulation_ready.json",
        help="Simulation-ready graph JSON.",
    )
    parser.add_argument(
        "--output-dir",
        default="etudecas/simulation/result",
        help="Directory where simulation outputs are written.",
    )
    parser.add_argument(
        "--scenario-id",
        default="scn:BASE",
        help="Scenario id to simulate.",
    )
    parser.add_argument(
        "--days",
        type=int,
        default=0,
        help="Simulation horizon in days (default: scenario horizon). Set 0 to use scenario horizon.",
    )
    parser.add_argument(
        "--warmup-days",
        type=int,
        default=None,
        help="Warm-up days run before the measured horizon. Defaults to scenario policy warmup_days or 0.",
    )
    parser.add_argument(
        "--initial-stock-availability", action="store_true",
        help="Opt in to meta.initial_stock_availability for held physical opening stock and dated releases.",
    )
    parser.add_argument(
        "--mrp-execution-mode", choices=["historical", "availability", "dated"], default="historical",
        help="Dated execution separates opening purchases' physical delivery G from availability I; historical preserves prior reproduction.",
    )
    parser.add_argument(
        "--mrp-receipt-netting-mode", choices=["all_future", "within_cover"], default="all_future",
        help="Experimental transport replenishment: only net pending receipts available within the existing cover window.",
    )
    parser.add_argument(
        "--production-mrp-safety-targets", action="store_true",
        help="Experimental production controller targets include source MRP safety quantities and calendar-converted days.",
    )
    parser.add_argument(
        "--production-signal-source", choices=["historical", "forecast"], default="historical",
        help="Use multilevel demand forecasts instead of downstream capacity as the production signal floor.",
    )
    parser.add_argument(
        "--mrp-forecast-source", choices=["nominal", "source"], default="nominal",
        help="Use dated meta.mrp_forecasts for planning only; physical customer demand stays unchanged.",
    )
    parser.add_argument(
        "--mrp-nonbinding-standard-order-pair", action="append", default=[], metavar="NODE,ITEM",
        help="Treat the standard order quantity as a reference, not a mandatory multiple or delivery-splitting rule, for this destination pair.",
    )
    parser.add_argument(
        "--warmup-profile-mode",
        choices=["restart", "preperiod"],
        default="restart",
        help=(
            "Demand profile used during warm-up. restart uses the beginning of the visible horizon. "
            "preperiod uses the period immediately before day 0, useful to emulate a running MRP cutover."
        ),
    )
    parser.add_argument(
        "--map-script",
        default="etudecas/visualization/maps/build_supplychain_worldmap.py",
        help="Path to map builder script.",
    )
    parser.add_argument(
        "--map-output",
        default="",
        help="Optional path to generated hover-map HTML. Defaults inside <output-dir>/maps/.",
    )
    parser.add_argument(
        "--map-payload-mode",
        choices=["chunked", "compressed", "raw", "external"],
        default="chunked",
        help=(
            "How the map DATA payload is stored. chunked keeps a standalone HTML with "
            "gzip/base64 blocks; raw embeds plain JSON and is much larger; external writes "
            "a sibling JSON file that must be served over HTTP."
        ),
    )
    parser.add_argument(
        "--skip-map",
        action="store_true",
        help="Skip map HTML generation after simulation.",
    )
    parser.add_argument(
        "--skip-plots",
        action="store_true",
        help="Skip PNG plot generation.",
    )
    parser.add_argument(
        "--output-profile",
        choices=["full", "compact"],
        default="compact",
        help="Result output volume: compact keeps only files needed for baseline review and maps.",
    )
    parser.add_argument(
        "--lot-trace",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Export lot-level events and genealogy while keeping aggregate simulation equations unchanged "
            "(default: enabled)."
        ),
    )
    parser.add_argument(
        "--skip-lot-audit",
        action="store_true",
        help="Skip automatic lot path audit generation after lot trace CSV export.",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed used by stochastic replenishment (default: 42).",
    )
    parser.add_argument(
        "--demand-perturbation-csv",
        default="",
        help=(
            "Optional exact-pair demand excitation CSV for frequency identification. "
            "Days are zero-based measured days, never warm-up days, and multipliers "
            "must be finite in [0.5, 1.5]. Empty preserves historical behavior."
        ),
    )
    parser.add_argument(
        "--control-schedule-csv",
        default="",
        help=(
            "Optional bounded daily control schedule. Days are zero-based measured "
            "days and never apply during warm-up. Empty preserves historical behavior."
        ),
    )
    parser.add_argument(
        "--control-probe-schedule-csv",
        default="",
        help=(
            "Optional additive post-feedback identification probe for V2/V3. "
            "Days are zero-based measured days and never apply during warm-up. "
            "Only order, safety-stock and production-target multipliers are "
            "supported."
        ),
    )
    parser.add_argument(
        "--control-policy-json",
        default="",
        help=(
            "Optional causal state-feedback policy. The canonical state at the "
            "end of measured day J may only generate controls effective on J+1. "
            "Cannot be combined with --control-schedule-csv."
        ),
    )
    parser.add_argument(
        "--control-policy-v2-json",
        default="",
        help=(
            "Optional gated V2 causal state-feedback policy. This additive "
            "interface is mutually exclusive with the historical schedule and "
            "V1 policy interfaces."
        ),
    )
    parser.add_argument(
        "--control-policy-v3-json",
        default="",
        help=(
            "Optional continuous V3 causal state-feedback policy. This additive "
            "interface is mutually exclusive with the historical schedule, V1 "
            "and V2 policy interfaces."
        ),
    )
    parser.add_argument(
        "--controller-prime-during-warmup",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "Feed V2/V3 end-of-day warm-up observations to controller memory "
            "without resolving or applying controls. Default is disabled."
        ),
    )
    parser.add_argument(
        "--warmup-boundary-audit",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "Emit a deterministic SHA-256 audit of core engine state at the "
            "J0 cutover. This is not a serializable restart checkpoint."
        ),
    )
    parser.add_argument(
        "--common-random-numbers",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "Key stochastic lead-time draws by seed, measured day and lane so paired "
            "policy runs share the same exogenous draw whenever the same lane/day is used. "
            "Default is disabled to preserve the historical random stream."
        ),
    )
    parser.add_argument(
        "--stochastic-lead-times",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Enable stochastic lead times sampled from transport-flow metadata (default: enabled).",
    )
    parser.add_argument(
        "--lead-time-distribution-mode",
        choices=["erlang", "industrial"],
        default="",
        help="Stochastic lead-time model. Empty uses scenario lead_time_policy.distribution_mode or erlang.",
    )
    parser.add_argument(
        "--supplier-risk-events-csv",
        default="",
        help=(
            "Optional supplier risk event CSV. Empty means no event and keeps the "
            "baseline supplier stock/capacity/lead-time/reliability behavior neutral."
        ),
    )
    parser.add_argument(
        "--supplier-risk-events-apply-to-opening-purchase-orders",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "Apply matching supplier-risk events to observed planned opening "
            "purchase orders, using their planned physical delivery day as "
            "the event decision date. Default is disabled and preserves the "
            "historical opening-order replay exactly."
        ),
    )
    parser.add_argument(
        "--supplier-state-dependent-risks",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "Enable simple state-dependent supplier risks. When enabled, supplier stock cover, "
            "capacity utilization and observed lead-time drift can trigger temporary future "
            "risk events. Default is disabled to keep baseline runs unchanged."
        ),
    )
    parser.add_argument(
        "--supplier-state-risk-families",
        type=_parse_supplier_state_risk_families,
        default=SUPPLIER_STATE_RISK_FAMILIES,
        metavar="FAMILY[,FAMILY...]",
        help=(
            "State-dependent supplier-risk families allowed to create events. "
            "Available families: stock, capacity, lead, availability, upstream, "
            "reliability, quality, cost. Empty or 'all' preserves the default "
            "behavior (all families)."
        ),
    )
    parser.add_argument(
        "--supplier-risk-loss-gross-up",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=(
            "Whether MRP immediately divides orders by temporary supplier "
            "reliability and quality-yield risk multipliers. The default keeps "
            "the historical anticipated-loss behavior. Disable it to model an "
            "unanticipated incident whose missing quantity is not perfectly "
            "compensated on the same day."
        ),
    )
    parser.add_argument(
        "--supplier-state-risk-observation-warmup-days",
        type=int,
        default=30,
        help=(
            "Minimum measured day before state-dependent supplier risks can trigger. "
            "Default: 30 days, to avoid cold-start false positives."
        ),
    )
    parser.add_argument(
        "--external-procurement-enabled",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Override supplier upstream supply availability for stress tests.",
    )
    parser.add_argument(
        "--external-procurement-proactive-replenishment",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Override proactive supplier upstream replenishment for supplier stocks.",
    )
    parser.add_argument(
        "--external-procurement-lead-days",
        type=int,
        default=0,
        help="Override supplier upstream supply lead time in days. 0 keeps scenario policy.",
    )
    parser.add_argument(
        "--external-procurement-lead-mode",
        choices=["supplier_material", "policy_fixed"],
        default="",
        help=(
            "Supplier upstream supply lead mode. supplier_material derives a supplier/item lead "
            "from source material data; policy_fixed uses external_procurement_lead_days."
        ),
    )
    parser.add_argument(
        "--external-procurement-capacity-mode",
        choices=["supplier_nominal", "policy_cap"],
        default="",
        help=(
            "Supplier upstream supply capacity mode. supplier_nominal derives a supplier/item "
            "upstream nominal cap from baseline demand and target utilization; "
            "policy_cap keeps the legacy global cap policy."
        ),
    )
    parser.add_argument(
        "--external-procurement-upstream-pipeline-fill-ratio",
        type=float,
        default=None,
        help="Opening upstream pipeline fill ratio for supplier_nominal upstream supply.",
    )
    parser.add_argument(
        "--external-procurement-nominal-capacity-scale",
        type=float,
        default=None,
        help="Scale supplier_nominal upstream supply capacity without changing nominal references.",
    )
    parser.add_argument(
        "--external-procurement-daily-cap-days",
        type=float,
        default=None,
        help="Override supplier upstream supply daily cap expressed as days of demand signal.",
    )
    parser.add_argument(
        "--external-procurement-min-daily-cap-qty",
        type=float,
        default=None,
        help="Override supplier upstream supply minimum daily capacity quantity.",
    )
    parser.add_argument(
        "--external-procurement-cost-multiplier",
        type=float,
        default=None,
        help="Override supplier upstream supply purchase cost multiplier.",
    )
    parser.add_argument(
        "--supplier-neutral-floors-csv",
        default="",
        help=(
            "Optional supplier_nominal_parameters.csv used for a sensitivity run. "
            "When provided, supplier capacities are forced to neutral_capacity_floor_qty_per_day "
            "with scale x1, and supplier opening stocks to neutral_opening_stock_floor_qty."
        ),
    )
    parser.add_argument(
        "--factory-nominal-capacities-csv",
        default="",
        help=(
            "Optional production_capacity_nominal_parameters.csv used for a sensitivity run. "
            "When provided, process capacities are forced to industrial_nominal_capacity_qty_per_day."
        ),
    )
    parser.add_argument(
        "--mrp-strict-safety-floor-from-safety-time",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=(
            "When set, the physical MRP safety floor is only "
            "safety_time_days x MRP demand signal, instead of also using "
            "opening/base stock as a floor."
        ),
    )
    parser.add_argument(
        "--restore-opening-stock-after-warmup",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=(
            "Override warm-up cutover behavior. When enabled, the physical opening stock "
            "at measured day 0 is restored after warm-up while warm-up-generated order books remain."
        ),
    )
    parser.add_argument(
        "--initial-state-scale",
        type=float,
        default=None,
        help="Override initialization_policy.state_scale for explicit-state runs.",
    )
    parser.add_argument(
        "--opening-observed-stock-scale",
        type=_nonnegative_finite_float,
        default=None,
        help=(
            "Stress-test factor applied only to observed opening inventory states "
            "loaded from the graph before warm-up (effective default: 1.0). "
            "Non-MRP base-stock references are scaled consistently; MRP snapshot "
            "positions remain state only. This is a sensitivity assumption, not a "
            "calibrated opening-state estimate."
        ),
    )
    parser.add_argument(
        "--opening-observed-stock-scale-csv",
        default="",
        help=(
            "Pair-scoped opening-stock stress assumptions from a strict CSV with "
            "columns node_id,item_id,scale. Only listed observed graph inventory "
            "states are scaled before warm-up; all other pairs remain unchanged. "
            "Mutually exclusive with --opening-observed-stock-scale."
        ),
    )
    parser.add_argument(
        "--measurement-start-stock-scale-csv",
        default="",
        help=(
            "Pair-scoped measured-day-0 stock sensitivity from a strict CSV with "
            "columns node_id,item_id,scale. Applied once after warm-up (and any "
            "configured opening-stock restore), immediately before the J0 boundary "
            "audit and measured dynamics. Lot balances are reconciled to the "
            "adjusted aggregate stock."
        ),
    )
    parser.add_argument(
        "--measurement-start-in-transit-scale-csv",
        default="",
        help=(
            "Pair-scoped measured-day-0 standard in-transit sensitivity from a "
            "strict CSV with columns node_id,item_id,scale. Applied once after "
            "warm-up, immediately before the J0 boundary audit. Only the native "
            "standard pipeline and its in_transit balance are scaled; external "
            "and estimated-source pipelines remain unchanged."
        ),
    )
    parser.add_argument(
        "--initial-factory-input-on-hand-days",
        type=float,
        default=None,
        help="Override factory input opening cover days in initialization_policy.",
    )
    parser.add_argument(
        "--initial-supplier-output-on-hand-days",
        type=float,
        default=None,
        help="Override supplier output opening cover days in initialization_policy.",
    )
    parser.add_argument(
        "--initial-distribution-center-on-hand-days",
        type=float,
        default=None,
        help="Override distribution center opening cover days in initialization_policy.",
    )
    parser.add_argument(
        "--initial-customer-on-hand-days",
        type=float,
        default=None,
        help="Override customer opening cover days in initialization_policy.",
    )
    parser.add_argument(
        "--initial-seed-safety-time-on-hand",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Whether safety-time cover may create extra opening stock beyond observed J0 stock.",
    )
    parser.add_argument(
        "--initial-seed-estimated-source-on-hand",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Whether estimated unmodeled source buffers may create extra opening stock at J0.",
    )
    parser.add_argument(
        "--initial-seed-in-transit",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Override initialization_policy.seed_in_transit.",
    )
    parser.add_argument(
        "--initial-in-transit-fill-ratio",
        type=float,
        default=None,
        help="Override initialization_policy.in_transit_fill_ratio.",
    )
    parser.add_argument(
        "--initial-seed-estimated-source-pipeline",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Override initialization_policy.seed_estimated_source_pipeline.",
    )
    parser.add_argument(
        "--initial-seed-open-orders-from-january-snapshot",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=(
            "Inject firm open purchase/production orders from the opening ERP snapshot "
            "when the graph metadata contains Extract_En_cours.xlsx rows."
        ),
    )
    parser.add_argument(
        "--opening-production-order-bom-issue-mode",
        choices=["receipt", "release", "wip"],
        default=None,
        help=(
            "How source O.Proc opening production orders consume BOM components. "
            "receipt keeps the historical behavior and issues components when the finished/semi-finished "
            "order is received. release issues components at the source release/order date and receives "
            "the output at the source entry date. wip receives the output but treats components as already "
            "issued to opening WIP, without consuming J0 free stock."
        ),
    )
    parser.add_argument(
        "--use-bom-demand-signal-for-mrp",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=(
            "Use the demand propagated through BOM and supply lanes as the MRP target signal. "
            "This avoids sizing component targets from the theoretical maximum factory capacity."
        ),
    )
    parser.add_argument(
        "--mrp-demand-signal-source",
        choices=["demand", "mps_lotified"],
        default=None,
        help=(
            "Source used to propagate MRP component demand. demand uses direct downstream demand; "
            "mps_lotified uses the lotified production plan before propagating component needs."
        ),
    )
    parser.add_argument(
        "--mrp-demand-signal-smoothing-days",
        type=int,
        default=0,
        help=(
            "Rolling window used for the MRP demand signal. 0 keeps scenario value; "
            "7 is usually appropriate for weekly MPS/lotified production."
        ),
    )
    parser.add_argument(
        "--mrp-static-fallback-for-propagated-pairs",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=(
            "Whether a component with a known propagated MRP path may fall back to static capacity "
            "when the propagated signal is zero. Disable for demand-driven component targets."
        ),
    )
    parser.add_argument(
        "--mrp-static-requirement-pair",
        action="append",
        default=[],
        metavar="NODE,ITEM",
        help=(
            "Force one pair to keep the historical static requirement as its MRP sizing signal, "
            "even when BOM/MPS propagated demand is enabled. Can be repeated."
        ),
    )
    parser.add_argument(
        "--mrp-dynamic-requirement-pair",
        action="append",
        default=[],
        metavar="NODE,ITEM",
        help=(
            "Force one pair to use propagated BOM/MPS demand by removing it "
            "from any static-requirement list inherited from the scenario or "
            "an engine profile. Can be repeated."
        ),
    )
    parser.add_argument(
        "--mrp-smoothed-cover-requirement-pair",
        action="append",
        default=[],
        metavar="NODE,ITEM",
        help=(
            "For a highly lotified dynamic pair, size lead-time stock cover "
            "from the forward cover-window mean instead of a one-day MPS lot "
            "spike. Can be repeated; daily order cadence is unchanged."
        ),
    )
    parser.add_argument(
        "--soft-safety-time-stock-target-factor",
        type=float,
        default=None,
        help="Global multiplier applied to the safety-time physical stock target.",
    )
    parser.add_argument(
        "--safety-time-calendar", choices=["weekdays", "calendar_days"], default="weekdays",
        help="Safety-cover calendar only: Monday-Friday by default; does not close factories or transport.",
    )
    parser.add_argument(
        "--soft-safety-time-stock-target-factor-pair",
        action="append",
        default=[],
        metavar="NODE,ITEM,FACTOR",
        help=(
            "Pair-specific safety-time multiplier, e.g. "
            "M-1810,item:338929,1.5. Can be repeated."
        ),
    )
    parser.add_argument(
        "--mrp-base-stock-floor-factor-pair",
        action="append",
        default=[],
        metavar="NODE,ITEM,FACTOR",
        help=(
            "Pair-specific multiplier for using opening/base stock as an MRP floor. "
            "Use 0 to keep opening stock but avoid replenishing back to it as a target."
        ),
    )
    parser.add_argument(
        "--mrp-base-stock-floor-factor",
        type=float,
        default=None,
        help=(
            "Global multiplier for using opening/base stock as an MRP floor. "
            "Default keeps scenario value; 0 tests the cleaner rule where opening stock is state only."
        ),
    )
    parser.add_argument(
        "--mrp-review-period-days",
        type=int,
        default=0,
        help=(
            "Optional cadence for upstream factory MRP replenishment decisions. "
            "0 keeps the scenario review period. Customer/DC flows stay on the scenario cadence."
        ),
    )
    parser.add_argument(
        "--mrp-target-bucket-days",
        type=int,
        default=0,
        help=(
            "Optional bucket size for the MRP target signal. "
            "For example 7 freezes the propagated MRP target on calendar weeks "
            "while keeping daily execution and daily customer service."
        ),
    )
    parser.add_argument(
        "--mrp-target-cutover-context-days",
        type=int,
        default=0,
        help=(
            "Optional target-only cutover context. For the first N visible days, "
            "the MRP target demand floor also considers the equivalent window just "
            "before day 0, using the annual demand cycle. This avoids a cold-start "
            "target cliff without pre-running the physical simulation."
        ),
    )
    parser.add_argument(
        "--mrp-multisource-policy",
        choices=["legacy", "portfolio_annual_min_lot", "portfolio_cost_risk"],
        default="legacy",
        help=(
            "MRP sourcing policy for multi-source material lanes. legacy keeps the historical split. "
            "portfolio_annual_min_lot uses 80/20, 70/20/10, 70/20/5/5 for 2/3/4 suppliers "
            "and ensures at least one standard lot per supplier per year when possible. "
            "portfolio_cost_risk keeps that annual supplier lot rule, then allocates normal MRP demand "
            "from a cost/lead/reliability score."
        ),
    )
    parser.add_argument(
        "--mrp-multisource-min-annual-lot-window-days",
        type=int,
        default=28,
        help=(
            "Final-year window used by portfolio policies to place the missing annual supplier lot. "
            "Default: 28 days."
        ),
    )
    return parser.parse_args()


def profile_value(profile: list[dict[str, Any]], day: int) -> float:
    if not profile:
        return 0.0
    step_candidates: list[tuple[int, float]] = []
    for p in profile:
        if not isinstance(p, dict):
            continue
        ptype = str(p.get("type", "constant"))
        repeat_period_days = int(to_float(p.get("repeat_period_days"), 0.0))
        eval_day = day
        if repeat_period_days > 0:
            eval_day = day % repeat_period_days
        if ptype == "constant":
            return to_float(p.get("value"), 0.0)
        if ptype == "step":
            start = int(to_float(p.get("start_day"), 0.0))
            val = to_float(p.get("value"), 0.0)
            if eval_day >= start:
                step_candidates.append((start, val))
        if ptype == "piecewise":
            points = p.get("points") or []
            for pt in points:
                if not isinstance(pt, dict):
                    continue
                t = int(to_float(pt.get("t"), -1))
                v = to_float(pt.get("value"), 0.0)
                if eval_day >= t >= 0:
                    step_candidates.append((t, v))
    if step_candidates:
        step_candidates.sort(key=lambda x: x[0])
        return step_candidates[-1][1]
    return 0.0


def _cached_profile_value(
    profile: list[dict[str, Any]],
    day: int,
    value_cache: dict[tuple[int, int], float],
) -> float:
    # The owning run retains its profiles unchanged for the cache's lifetime.
    # Identity keeps distinct profiles separate, even when their days coincide.
    key = (id(profile), day)
    try:
        return value_cache[key]
    except KeyError:
        value = profile_value(profile, day)
        value_cache[key] = value
        return value


def profile_window_average(
    profile: list[dict[str, Any]],
    day: int,
    window_days: int,
    *,
    value_cache: dict[tuple[int, int], float] | None = None,
) -> float:
    """Average days in order; an optional cache belongs to one run's fixed profiles."""
    window_days = max(1, int(window_days))
    if value_cache is not None:
        if window_days <= 1:
            return _cached_profile_value(profile, day, value_cache)
        # Keep the same ordered sum as the uncached evaluator: prefix sums or
        # rolling sums can change floating-point results and physical decisions.
        return sum(
            _cached_profile_value(profile, day + offset, value_cache)
            for offset in range(window_days)
        ) / float(window_days)
    if window_days <= 1:
        return profile_value(profile, day)
    return sum(profile_value(profile, day + offset) for offset in range(window_days)) / float(window_days)


def demand_targets_for_day(
    demand_profiles: dict[tuple[str, str], list[dict[str, Any]]],
    day: int,
    *,
    window_days: int = 1,
    value_cache: dict[tuple[int, int], float] | None = None,
) -> dict[tuple[str, str], float]:
    return {
        pair: max(0.0, profile_window_average(profile, day, window_days, value_cache=value_cache))
        for pair, profile in demand_profiles.items()
    }


def choose_scenario(data: dict[str, Any], scenario_id: str) -> dict[str, Any]:
    scenarios = data.get("scenarios", []) or []
    for scn in scenarios:
        if str(scn.get("id")) == scenario_id:
            return scn
    raise ValueError(f"Unknown scenario: {scenario_id!r}")


def lane_records(
    edges: list[dict[str, Any]],
    economic_policy: dict[str, float] | None = None,
    *,
    mrp_multisource_policy: str = "legacy",
) -> tuple[list[dict[str, Any]], dict[tuple[str, str], list[dict[str, Any]]]]:
    economic_policy = economic_policy or {}
    transport_floor = max(0.0, to_float(economic_policy.get("transport_cost_floor_per_unit"), 0.02))
    transport_per_km = max(0.0, to_float(economic_policy.get("transport_cost_per_km_per_unit"), 0.00008))
    purchase_floor = max(0.0, to_float(economic_policy.get("purchase_cost_floor_per_unit"), 0.01))
    transport_realism_multiplier = max(0.1, to_float(economic_policy.get("transport_cost_realism_multiplier"), 1.0))
    purchase_realism_multiplier = max(0.1, to_float(economic_policy.get("purchase_cost_realism_multiplier"), 1.0))
    lanes: list[dict[str, Any]] = []
    lanes_by_dest_item: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for e in edges:
        src = str(e.get("from"))
        dst = str(e.get("to"))
        lead = e.get("lead_time") or {}
        lead_days = int(round(max(1.0, to_float((lead or {}).get("mean"), 1.0))))
        lead_days_mean = max(1.0, to_float((lead or {}).get("mean"), 1.0))
        lead_stages = int(round(max(1.0, to_float((lead or {}).get("stages"), 1.0))))
        lead_time_type = str((lead or {}).get("type", "constant"))
        distance_km = max(0.0, to_float(e.get("distance_km"), 0.0))
        tc = e.get("transport_cost") or {}
        explicit_transport_cost = max(0.0, to_float((tc or {}).get("value"), 0.0))
        fallback_transport_cost = max(transport_floor, distance_km * transport_per_km)
        # Most transport flows have a default 0 transport_cost, so force a realistic floor by distance.
        cost = (explicit_transport_cost if explicit_transport_cost > 0 else fallback_transport_cost) * transport_realism_multiplier
        ot = e.get("order_terms") or {}
        sell_price = to_float((ot or {}).get("sell_price"), 0.0)
        price_base = to_float((ot or {}).get("price_base"), 1.0)
        if price_base <= 0:
            price_base = 1.0
        priced_unit_purchase_cost = max(0.0, sell_price / price_base)
        if priced_unit_purchase_cost > 0.0 and not bool((ot or {}).get("is_default")):
            unit_purchase_cost = priced_unit_purchase_cost * purchase_realism_multiplier
            purchase_cost_is_fallback = False
        else:
            unit_purchase_cost = max(purchase_floor, priced_unit_purchase_cost) * purchase_realism_multiplier
            purchase_cost_is_fallback = True
        order_unit = normalize_unit((ot or {}).get("quantity_unit"))
        attrs = e.get("attrs") or {}
        standard_order_qty_raw = max(0.0, to_float(attrs.get("standard_order_qty"), 0.0))
        standard_order_uom = normalize_unit(attrs.get("standard_order_uom") or order_unit)
        if standard_order_qty_raw > 0 and can_convert_units(standard_order_uom, order_unit):
            standard_order_qty = convert_quantity(standard_order_qty_raw, standard_order_uom, order_unit)
        else:
            standard_order_qty = standard_order_qty_raw
        service_level = e.get("service_level") or {}
        reliability = to_float(
            service_level.get("otif", e.get("otif", 1.0)),
            1.0,
        )
        if "otif" in service_level:
            reliability_source = "service_level.otif"
        elif "otif" in e:
            reliability_source = "edge.otif"
        else:
            reliability_source = "default_1.0"
        reliability = max(0.01, min(1.0, reliability))
        supply_order_frequency = (ot.get("supply_order_frequency") or {})
        order_frequency_days = int(
            round(max(1.0, to_float((supply_order_frequency or {}).get("value"), 1.0)))
        )
        delay_step_limit = int(round(max(1.0, to_float(((e.get("delay_step_limit") or {}).get("value")), 999.0))))
        base_standard_order_qty = standard_order_qty
        base_order_frequency_days = order_frequency_days
        for item_id in (e.get("items") or []):
            standard_order_qty = base_standard_order_qty
            order_frequency_days = base_order_frequency_days
            standard_order_qty_note = ""
            lane_order_uom = order_unit or standard_order_uom
            canonical_decision = None
            dispatch_decision = None
            if lane_order_uom in {"G", "KG", "UN", "M"}:
                canonical_decision = resolve_canonical_lane_lot(
                    origin_id=src,
                    destination_id=dst,
                    item_id=item_id,
                    lane_uom=lane_order_uom,
                )
                dispatch_decision = resolve_internal_dispatch_multiple(
                    origin_id=src,
                    destination_id=dst,
                    item_id=item_id,
                    lane_uom=lane_order_uom,
                )
            if canonical_decision is not None:
                previous_qty = standard_order_qty
                standard_order_qty = max(0.0, canonical_decision.quantity)
                if canonical_decision.order_frequency_days is not None:
                    order_frequency_days = max(
                        1,
                        int(canonical_decision.order_frequency_days),
                    )
                standard_order_qty_note = (
                    f"canonical {canonical_decision.scope}: {previous_qty:g} -> "
                    f"{standard_order_qty:g} {canonical_decision.uom}; "
                    f"source={canonical_decision.source}; "
                    f"confidence={canonical_decision.confidence}"
                )
            override = standard_order_override(src, dst, item_id)
            if (
                override
                and standard_order_qty >= max(0.0, to_float(override.get("min_original_qty"), 0.0))
                and (
                    not override.get("uom")
                    or normalize_unit(override.get("uom")) == (order_unit or standard_order_uom)
                )
            ):
                previous_qty = standard_order_qty
                standard_order_qty = max(0.0, to_float(override.get("qty"), standard_order_qty))
                if "order_frequency_days" in override:
                    order_frequency_days = max(
                        1,
                        int(round(max(1.0, to_float(override.get("order_frequency_days"), order_frequency_days)))),
                    )
                standard_order_qty_note = str(
                    override.get("note")
                    or f"overridden from {previous_qty:g} to {standard_order_qty:g}"
                )
            lane = {
                "edge_id": str(e.get("id")),
                "src": src,
                "dst": dst,
                "item_id": str(item_id),
                "lead_days": lead_days,
                "lead_days_mean": lead_days_mean,
                "lead_stages": lead_stages,
                "lead_time_type": lead_time_type,
                "lead_time_source": str((lead or {}).get("source") or ""),
                "lead_time_is_default": bool((lead or {}).get("is_default")),
                "order_frequency_days": order_frequency_days,
                "delay_step_limit": delay_step_limit,
                "unit_transport_cost": cost,
                "transport_cost_basis": str(tc.get("per") or "unit").strip().lower(),
                "transport_tariff_batch_qty": tc.get("batch_qty"),
                "unit_purchase_cost": unit_purchase_cost,
                "raw_purchase_cost": priced_unit_purchase_cost,
                "purchase_cost_is_fallback": purchase_cost_is_fallback,
                "raw_transport_cost": explicit_transport_cost,
                "transport_cost_is_fallback": explicit_transport_cost <= 0,
                "reliability": reliability,
                "reliability_source": reliability_source,
                "availability_profile": e.get("availability_profile") or [],
                "standard_order_qty": standard_order_qty,
                "standard_order_uom": lane_order_uom,
                "standard_order_qty_note": standard_order_qty_note,
                "standard_order_policy_scope": (
                    canonical_decision.scope if canonical_decision else ""
                ),
                "standard_order_policy_source": (
                    canonical_decision.source if canonical_decision else ""
                ),
                "standard_order_policy_confidence": (
                    canonical_decision.confidence if canonical_decision else ""
                ),
                "physical_dispatch_multiple": (
                    max(0.0, dispatch_decision.quantity)
                    if dispatch_decision
                    else 0.0
                ),
                "physical_dispatch_uom": (
                    dispatch_decision.uom if dispatch_decision else ""
                ),
                "physical_dispatch_policy_scope": (
                    dispatch_decision.scope if dispatch_decision else ""
                ),
                "physical_dispatch_policy_source": (
                    dispatch_decision.source if dispatch_decision else ""
                ),
                "physical_dispatch_policy_confidence": (
                    dispatch_decision.confidence if dispatch_decision else ""
                ),
            }
            lanes.append(lane)
            lanes_by_dest_item[(dst, str(item_id))].append(lane)

    def normalized_penalties(values: list[float]) -> list[float]:
        if not values:
            return []
        low = min(values)
        high = max(values)
        if high - low <= 1e-9:
            return [0.0 for _ in values]
        return [(value - low) / (high - low) for value in values]

    def mrp_split_shares(count: int) -> list[float]:
        if count <= 0:
            return []
        if count == 1:
            return [1.0]
        if mrp_multisource_policy == "portfolio_annual_min_lot":
            if count == 2:
                return [0.8, 0.2]
            if count == 3:
                return [0.7, 0.2, 0.1]
            if count == 4:
                return [0.7, 0.2, 0.05, 0.05]
            tail = 0.1 / float(count - 2)
            return [0.7, 0.2] + [tail] * (count - 2)
        if count == 2:
            return [0.7, 0.3]
        if count == 3:
            return [0.7, 0.2, 0.1]
        tail = 0.1 / float(count - 2)
        return [0.7, 0.2] + [tail] * (count - 2)

    def assign_cost_risk_shares(values: list[dict[str, Any]]) -> None:
        if not values:
            return
        if len(values) == 1:
            lane = values[0]
            lane["mrp_share"] = 1.0
            lane["mrp_rank"] = 1
            lane["mrp_share_basis"] = "single_source"
            lane["mrp_landed_unit_cost"] = max(0.0, to_float(lane.get("unit_purchase_cost"), 0.0)) + max(
                0.0,
                to_float(lane.get("unit_transport_cost"), 0.0),
            )
            lane["mrp_cost_penalty"] = 0.0
            lane["mrp_lead_penalty"] = 0.0
            lane["mrp_reliability_penalty"] = 0.0
            lane["mrp_variability_penalty"] = 0.0
            lane["mrp_allocation_penalty"] = 0.0
            return

        landed_costs = [
            max(0.0, to_float(lane.get("unit_purchase_cost"), 0.0))
            + max(0.0, to_float(lane.get("unit_transport_cost"), 0.0))
            for lane in values
        ]
        lead_refs = [float(lead_time_reference_days(lane)) for lane in values]
        lead_covers = [float(lead_time_cover_days(lane, True, "industrial")) for lane in values]
        reliability_penalties = [max(0.0, 1.0 - max(0.01, min(1.0, to_float(lane.get("reliability"), 1.0)))) for lane in values]
        variability_raw = [
            max(0.0, cover / max(1.0, ref) - 1.0)
            for cover, ref in zip(lead_covers, lead_refs)
        ]

        cost_penalties = normalized_penalties(landed_costs)
        lead_penalties = normalized_penalties(lead_refs)
        variability_penalties = normalized_penalties(variability_raw)
        reliability_norm = normalized_penalties(reliability_penalties)
        allocation_penalties: list[float] = []
        desirabilities: list[float] = []
        for cost_penalty, lead_penalty, rel_penalty, var_penalty in zip(
            cost_penalties,
            lead_penalties,
            reliability_norm,
            variability_penalties,
        ):
            alea_penalty = (0.65 * rel_penalty) + (0.35 * var_penalty)
            penalty = (0.60 * cost_penalty) + (0.25 * lead_penalty) + (0.15 * alea_penalty)
            allocation_penalties.append(penalty)
            desirabilities.append(math.exp(-3.0 * penalty))

        desirability_total = sum(desirabilities)
        if desirability_total <= 1e-12:
            shares = [1.0 / float(len(values)) for _ in values]
        else:
            shares = [desirability / desirability_total for desirability in desirabilities]

        for lane, share, landed_cost, cost_penalty, lead_penalty, rel_penalty, var_penalty, penalty in zip(
            values,
            shares,
            landed_costs,
            cost_penalties,
            lead_penalties,
            reliability_norm,
            variability_penalties,
            allocation_penalties,
        ):
            lane["mrp_share"] = share
            lane["mrp_share_basis"] = "cost_60_lead_25_reliability_variability_15"
            lane["mrp_landed_unit_cost"] = landed_cost
            lane["mrp_cost_penalty"] = cost_penalty
            lane["mrp_lead_penalty"] = lead_penalty
            lane["mrp_reliability_penalty"] = rel_penalty
            lane["mrp_variability_penalty"] = var_penalty
            lane["mrp_allocation_penalty"] = penalty
        values.sort(
            key=lambda lane: (
                max(0.0, to_float(lane.get("mrp_allocation_penalty"), 0.0)),
                max(0.0, to_float(lane.get("mrp_landed_unit_cost"), 0.0)),
                max(1, int(to_float(lane.get("lead_days"), 1.0))),
                str(lane.get("src") or ""),
            )
        )
        for rank, lane in enumerate(values, start=1):
            lane["mrp_rank"] = rank

    for key, values in lanes_by_dest_item.items():
        values.sort(key=lambda x: (x["unit_transport_cost"], x["lead_days"], x["src"]))
        if mrp_multisource_policy == "portfolio_cost_risk":
            assign_cost_risk_shares(values)
        else:
            shares = mrp_split_shares(len(values))
            share_basis = (
                "portfolio_fixed_split_with_annual_min_lot"
                if mrp_multisource_policy == "portfolio_annual_min_lot" and len(values) > 1
                else "legacy_fixed_split"
            )
            for rank, (lane, share) in enumerate(zip(values, shares), start=1):
                lane["mrp_share"] = share
                lane["mrp_rank"] = rank
                lane["mrp_share_basis"] = share_basis
                lane["mrp_landed_unit_cost"] = max(0.0, to_float(lane.get("unit_purchase_cost"), 0.0)) + max(
                    0.0,
                    to_float(lane.get("unit_transport_cost"), 0.0),
                )
                lane["mrp_cost_penalty"] = 0.0
                lane["mrp_lead_penalty"] = 0.0
                lane["mrp_reliability_penalty"] = 0.0
                lane["mrp_variability_penalty"] = 0.0
                lane["mrp_allocation_penalty"] = 0.0
        lanes_by_dest_item[key] = values
    return lanes, lanes_by_dest_item


def node_review_period_days(node: dict[str, Any], default: int = 7) -> int:
    sim_policy = ((node.get("policies") or {}).get("simulation_policy") or {})
    return int(round(max(1.0, to_float(sim_policy.get("review_period_days"), float(default)))))


def process_output_capacity_by_item(
    node: dict[str, Any],
    item_unit_map: dict[str, str],
) -> dict[str, float]:
    out: dict[str, float] = defaultdict(float)
    for proc in (node.get("processes") or []):
        cap = max(0.0, to_float(((proc.get("capacity") or {}).get("max_rate")), 0.0))
        if cap <= 0:
            continue
        for output in (proc.get("outputs") or []):
            item_id = str(output.get("item_id") or "")
            if not item_id:
                continue
            output_uom = str(output.get("uom") or "")
            output_unit = normalize_unit(output_uom.split("/", 1)[0] if "/" in output_uom else output_uom)
            item_unit = normalize_unit(item_unit_map.get(item_id, output_unit))
            value = cap
            if output_unit and item_unit and can_convert_units(output_unit, item_unit):
                value = convert_quantity(cap, output_unit, item_unit)
            out[item_id] += max(0.0, value)
    return dict(out)


def lane_availability_multiplier(lane: dict[str, Any], day: int) -> float:
    mult = 1.0
    for window in lane.get("availability_profile") or []:
        if not isinstance(window, dict):
            continue
        start = int(round(to_float(window.get("start_day"), 0.0)))
        end = int(round(to_float(window.get("end_day"), start)))
        if start <= day <= end:
            mult *= max(0.0, to_float(window.get("multiplier"), 1.0))
    return max(0.0, mult)


def normalize_lead_time_distribution_mode(value: Any) -> str:
    mode = str(value or "erlang").strip().lower().replace("-", "_")
    if mode in {"industrial", "industrial_right_tail", "industrial_realistic"}:
        return "industrial"
    return "erlang"


def industrial_lead_cover_days(mean: float) -> int:
    # Industrial approximation: nominal lead time plus a moderate planning buffer.
    # Safety time/stock is modelled separately, so this should not be an extreme p95.
    fixed_buffer = 1.0 if mean <= 5.0 else 2.0
    return int(math.ceil(mean + max(fixed_buffer, 0.20 * mean)))


def sample_industrial_lead_days(mean: float, rng: random.Random) -> float:
    """
    Industrial lead-time approximation without historical PO data.
    Most orders arrive on the supplier reference lead time. A small portion is
    early or late, and a very small right tail models supplier/logistics delays.
    """
    reference = int(round(max(1.0, mean)))
    early_window = max(1, int(round(min(7.0, max(1.0, 0.08 * reference)))))
    late_window = max(1, int(round(min(10.0, max(2.0, 0.10 * reference)))))
    draw = rng.random()
    if draw < 0.72:
        return float(reference)
    if draw < 0.85:
        early_delta = max(1, int(round(rng.triangular(1, early_window, 1))))
        return float(max(1, reference - early_delta))
    if draw < 0.97:
        late_delta = max(1, int(round(rng.triangular(1, late_window, 1))))
        return float(reference + late_delta)

    tail_cap = max(late_window + 1, int(round(min(21.0, max(4.0, 0.18 * reference)))))
    late_tail = max(late_window + 1, int(round(rng.triangular(late_window + 1, tail_cap, late_window + 1))))
    return float(reference + late_tail)


def sample_lead_days(
    lane: dict[str, Any],
    rng: random.Random,
    stochastic: bool,
    distribution_mode: str = "erlang",
) -> int:
    deterministic = int(round(max(1.0, to_float(lane.get("lead_days"), 1.0))))
    if not stochastic:
        return deterministic

    mean = max(1.0, to_float(lane.get("lead_days_mean"), deterministic))
    stages = int(round(max(1.0, to_float(lane.get("lead_stages"), 1.0))))
    lt_type = str(lane.get("lead_time_type", "constant")).lower()
    distribution_mode = normalize_lead_time_distribution_mode(distribution_mode)

    sampled = mean
    if distribution_mode == "industrial" and "constant" not in lt_type:
        sampled = sample_industrial_lead_days(mean, rng)
    elif "erlang" in lt_type:
        sampled = rng.gammavariate(stages, mean / stages)
    elif "constant" not in lt_type:
        sigma = max(0.25, 0.30 * mean)
        sampled = rng.gauss(mean, sigma)

    sampled_days = int(max(1, math.ceil(sampled)))
    delay_limit = int(round(max(1.0, to_float(lane.get("delay_step_limit"), 999.0))))
    return min(sampled_days, delay_limit)


def compose_controlled_lane_lead_days(
    *,
    transport_lead_days_before_quality: float,
    quality_delay_days: float,
    expedite_level: float = 0.0,
    lead_time_adjustment_days: int = 0,
    delay_control_active: bool = False,
) -> int:
    """Compose transport control and an independent quality-release hold.

    Expediting and manual lead-time adjustments are transport levers.  They
    must not shorten a quarantine or any other quality-release delay.  The
    inactive branch deliberately retains the historical single-ceiling
    calculation so a neutral schedule remains byte-for-byte compatible with
    the pre-control lead-time behavior, including fractional risk inputs.
    """

    transport_before_quality = max(
        0.0,
        float(transport_lead_days_before_quality),
    )
    quality_hold = max(0.0, float(quality_delay_days))
    if not delay_control_active:
        return max(
            1,
            int(math.ceil(transport_before_quality + quality_hold)),
        )

    transport_days = max(1, int(math.ceil(transport_before_quality)))
    expedite_reduction = int(
        math.floor(
            max(0.0, float(expedite_level))
            * max(0, transport_days - 1)
        )
    )
    controlled_transport_days = max(
        1,
        transport_days
        + int(lead_time_adjustment_days)
        - expedite_reduction,
    )
    # Quality delays are expressed in whole simulation days.  Ceiling them
    # separately guarantees that the complete release hold survives the
    # transport intervention.
    quality_hold_days = max(0, int(math.ceil(quality_hold)))
    return controlled_transport_days + quality_hold_days


def lead_time_reference_days(lane: dict[str, Any]) -> int:
    return int(round(max(1.0, to_float(lane.get("lead_days_mean"), lane.get("lead_days", 1.0)))))


def lead_time_cover_days(
    lane: dict[str, Any],
    stochastic: bool,
    distribution_mode: str = "erlang",
) -> int:
    """
    Return conservative lead-time coverage in days for stock sizing.
    With stochastic lead-times, use an approximate p95.
    """
    mean = max(1.0, to_float(lane.get("lead_days_mean"), lane.get("lead_days", 1.0)))
    if not stochastic:
        cover = int(round(max(1.0, to_float(lane.get("lead_days"), mean))))
    else:
        stages = max(1.0, to_float(lane.get("lead_stages"), 1.0))
        lt_type = str(lane.get("lead_time_type", "constant")).lower()
        distribution_mode = normalize_lead_time_distribution_mode(distribution_mode)
        if distribution_mode == "industrial" and "constant" not in lt_type:
            cover = industrial_lead_cover_days(mean)
        elif "erlang" in lt_type:
            # Erlang(k, theta): sd = mean / sqrt(k)
            sd = mean / math.sqrt(stages)
            cover = int(math.ceil(mean + 1.65 * sd))
        elif "constant" in lt_type:
            sd = 0.0
            cover = int(math.ceil(mean + 1.65 * sd))
        else:
            # Fallback dispersion used in sampling branch.
            sd = max(0.25, 0.30 * mean)
            cover = int(math.ceil(mean + 1.65 * sd))
    delay_limit = int(round(max(1.0, to_float(lane.get("delay_step_limit"), 999.0))))
    return max(1, min(cover, delay_limit))


def propagate_demand_rates(
    demand_target_daily: dict[tuple[str, str], float],
    lanes: list[dict[str, Any]],
) -> dict[tuple[str, str], float]:
    """
    Propagate customer demand signal upstream on same-item transport flows.
    """
    upstream: dict[tuple[str, str], list[tuple[str, str]]] = defaultdict(list)
    for lane in lanes:
        src_pair = (str(lane["src"]), str(lane["item_id"]))
        dst_pair = (str(lane["dst"]), str(lane["item_id"]))
        upstream[dst_pair].append(src_pair)

    signal: dict[tuple[str, str], float] = defaultdict(float)
    queue: deque[tuple[str, str]] = deque()
    for pair, val in demand_target_daily.items():
        d0 = max(0.0, to_float(val, 0.0))
        if d0 <= 0:
            continue
        if d0 > signal[pair]:
            signal[pair] = d0
            queue.append(pair)

    while queue:
        dst_pair = queue.popleft()
        d0 = signal[dst_pair]
        for src_pair in upstream.get(dst_pair, []):
            if d0 > signal[src_pair] + 1e-9:
                signal[src_pair] = d0
                queue.append(src_pair)

    return dict(signal)


def build_process_input_requirements_by_output_pair(
    nodes: list[dict[str, Any]],
    item_unit_map: dict[str, str],
) -> dict[tuple[str, str], list[tuple[tuple[str, str], float]]]:
    requirements: dict[tuple[str, str], list[tuple[tuple[str, str], float]]] = defaultdict(list)
    for node in nodes:
        node_id = str(node.get("id"))
        for proc in node.get("processes") or []:
            batch_size = to_float(proc.get("batch_size"), 1000.0)
            if batch_size <= 0:
                batch_size = 1000.0
            output_items = [
                str((out or {}).get("item_id"))
                for out in (proc.get("outputs") or [])
                if (out or {}).get("item_id") is not None
            ]
            if not output_items:
                continue
            input_requirements: list[tuple[tuple[str, str], float]] = []
            for inp in proc.get("inputs") or []:
                in_item = str((inp or {}).get("item_id"))
                if not in_item:
                    continue
                ratio = to_float((inp or {}).get("ratio_per_batch"), 0.0)
                if ratio <= 0:
                    continue
                input_unit = normalize_unit((inp or {}).get("ratio_unit"))
                item_unit = normalize_unit(item_unit_map.get(in_item, input_unit))
                req_per_output_unit = convert_quantity(ratio / batch_size, input_unit, item_unit)
                if req_per_output_unit > 0:
                    input_requirements.append(((node_id, in_item), req_per_output_unit))
            if not input_requirements:
                continue
            for out_item in output_items:
                requirements[(node_id, out_item)].extend(input_requirements)
    return dict(requirements)


def propagate_supply_demand_rates(
    demand_target_daily: dict[tuple[str, str], float],
    lanes: list[dict[str, Any]],
    process_input_requirements_by_output_pair: dict[tuple[str, str], list[tuple[tuple[str, str], float]]],
) -> dict[tuple[str, str], float]:
    """
    Propagate demand upstream through same-item transport flows and through production BOMs.

    This is used for MRP sizing: a finished-good demand signal creates component
    requirements at the producing site, then those component requirements propagate
    to upstream suppliers on the corresponding item transport flows.
    """
    adjacency: dict[tuple[str, str], list[tuple[tuple[str, str], float]]] = defaultdict(list)
    for lane in lanes:
        src_pair = (str(lane["src"]), str(lane["item_id"]))
        dst_pair = (str(lane["dst"]), str(lane["item_id"]))
        adjacency[dst_pair].append((src_pair, 1.0))
    for output_pair, input_reqs in process_input_requirements_by_output_pair.items():
        for input_pair, req_per_output_unit in input_reqs:
            if req_per_output_unit > 0:
                adjacency[output_pair].append((input_pair, req_per_output_unit))

    signal: dict[tuple[str, str], float] = defaultdict(float)
    propagated_by_edge: dict[tuple[tuple[str, str], tuple[str, str], float], float] = defaultdict(float)
    queue: deque[tuple[str, str]] = deque()
    for pair, val in demand_target_daily.items():
        qty = max(0.0, to_float(val, 0.0))
        if qty <= 0:
            continue
        signal[pair] += qty
        queue.append(pair)

    guard = 0
    guard_limit = max(1000, 20 * (len(adjacency) + sum(len(v) for v in adjacency.values()) + 1))
    while queue:
        guard += 1
        if guard > guard_limit:
            break
        pair = queue.popleft()
        source_qty = signal.get(pair, 0.0)
        if source_qty <= 0:
            continue
        for upstream_pair, multiplier in adjacency.get(pair, []):
            if multiplier <= 0:
                continue
            edge_key = (pair, upstream_pair, round(multiplier, 12))
            already_propagated = propagated_by_edge.get(edge_key, 0.0)
            delta = source_qty - already_propagated
            if delta <= 1e-9:
                continue
            propagated_by_edge[edge_key] = source_qty
            signal[upstream_pair] += delta * multiplier
            queue.append(upstream_pair)

    return dict(signal)


def lotified_mps_component_signal(
    output_demand_signal: dict[tuple[str, str], float],
    *,
    day: int,
    process_input_requirements_by_output_pair: dict[tuple[str, str], list[tuple[tuple[str, str], float]]],
    production_lot_policy_by_pair: dict[tuple[str, str], dict[str, Any]],
    process_capacity_by_output_pair: dict[tuple[str, str], float],
    mps_open_campaign_qty_by_pair: dict[tuple[str, str], float],
    mps_started_lots_by_week_pair: dict[tuple[int, tuple[str, str]], int],
    expand_internal_outputs: bool = True,
) -> tuple[dict[tuple[str, str], float], dict[tuple[str, str], float]]:
    """
    Build component demand from a lotified master production schedule.

    The input is the output demand seen by production nodes. For each produced
    output, this function applies the same lot/campaign rules used by execution,
    then explodes the planned production through the BOM. If an input is itself
    produced internally, its requirement is queued as a demand for that upstream
    process before non-produced component demand is returned. When the caller
    already supplies a complete program for every output, disabling expansion
    prevents counting the same intermediate program twice.
    """
    component_signal: dict[tuple[str, str], float] = defaultdict(float)
    planned_output_signal: dict[tuple[str, str], float] = defaultdict(float)
    pending: deque[tuple[str, str]] = deque()
    pending_qty: dict[tuple[str, str], float] = defaultdict(float)
    produced_pairs = set(process_input_requirements_by_output_pair)
    for pair, qty in output_demand_signal.items():
        qty = max(0.0, to_float(qty, 0.0))
        if qty <= 1e-9:
            continue
        pending_qty[pair] += qty
        pending.append(pair)

    guard = 0
    guard_limit = max(1000, 10 * (len(produced_pairs) + len(output_demand_signal) + 1))
    while pending:
        guard += 1
        if guard > guard_limit:
            break
        out_pair = pending.popleft()
        required_qty = pending_qty.pop(out_pair, 0.0)
        if required_qty <= 1e-9:
            continue
        input_requirements = process_input_requirements_by_output_pair.get(out_pair)
        if not input_requirements:
            continue

        lot_policy = production_lot_policy_by_pair.get(out_pair, {"enabled": False})
        cap_qty = max(0.0, process_capacity_by_output_pair.get(out_pair, 0.0))
        campaign_remaining_start_qty = max(0.0, mps_open_campaign_qty_by_pair.get(out_pair, 0.0))
        planned_qty = required_qty
        week_index = int(day // 7)
        week_key = (week_index, out_pair)
        if lot_policy.get("enabled"):
            if campaign_remaining_start_qty <= 1e-9 and required_qty > 1e-9:
                campaign_requested_qty = launch_campaign_qty(required_qty, lot_policy)
                campaign_started_qty = campaign_requested_qty
                weekly_lot_limit = max(0, int(math.floor(to_float(lot_policy.get("max_lots_per_week"), 0.0))))
                if weekly_lot_limit > 0:
                    started_lots = int(mps_started_lots_by_week_pair.get(week_key, 0))
                    available_lots = max(0, weekly_lot_limit - started_lots)
                    campaign_started_qty = limit_campaign_qty_by_weekly_lots(
                        campaign_requested_qty,
                        lot_policy,
                        available_lots,
                    )
                    mps_started_lots_by_week_pair[week_key] = (
                        started_lots + campaign_lot_count(campaign_started_qty, lot_policy)
                    )
                campaign_remaining_start_qty = campaign_started_qty
                mps_open_campaign_qty_by_pair[out_pair] = campaign_started_qty
            planned_qty = campaign_remaining_start_qty

        if cap_qty > 1e-9:
            planned_qty = min(planned_qty, cap_qty)
        planned_qty = max(0.0, planned_qty)
        if planned_qty <= 1e-9:
            continue
        if lot_policy.get("enabled"):
            mps_open_campaign_qty_by_pair[out_pair] = max(0.0, campaign_remaining_start_qty - planned_qty)

        planned_output_signal[out_pair] += planned_qty
        for input_pair, req_per_output_unit in input_requirements:
            input_qty = planned_qty * max(0.0, req_per_output_unit)
            if input_qty <= 1e-9:
                continue
            if expand_internal_outputs and input_pair in produced_pairs:
                pending_qty[input_pair] += input_qty
                pending.append(input_pair)
            else:
                component_signal[input_pair] += input_qty

    return dict(component_signal), dict(planned_output_signal)


def pair_label(node_id: str, item_id: str) -> str:
    return f"{node_id} | {item_id}"


def scenario_policy_value(scenario: dict[str, Any], key: str, default: float) -> float:
    raw = scenario.get(key, None)
    if raw is None:
        policy = scenario.get("inventory_policy") or {}
        raw = policy.get(key, None)
    return to_float(raw, default)


def scenario_policy_bool(scenario: dict[str, Any], key: str, default: bool) -> bool:
    raw = scenario.get(key, None)
    if raw is None:
        policy = scenario.get("inventory_policy") or {}
        raw = policy.get(key, None)
    if raw is None:
        return default
    if isinstance(raw, bool):
        return raw
    return str(raw).strip().lower() in {"1", "true", "yes", "y", "on"}


def scenario_policy_dict(scenario: dict[str, Any], key: str) -> dict[str, Any]:
    raw = scenario.get(key, None)
    if raw is None:
        policy = scenario.get("inventory_policy") or {}
        raw = policy.get(key, None)
    return raw if isinstance(raw, dict) else {}


def normalize_policy_item_id(item_id: str) -> str:
    item_id = str(item_id).strip()
    return item_id if item_id.startswith("item:") else f"item:{item_id}"


def policy_pair_key(node_id: str, item_id: str) -> str:
    return f"{str(node_id).strip()}|{normalize_policy_item_id(item_id)}"


def parse_pair_factor_map(raw: Any) -> dict[str, float]:
    if not isinstance(raw, dict):
        return {}
    parsed: dict[str, float] = {}
    for raw_key, raw_value in raw.items():
        factor = to_float(raw_value, float("nan"))
        if not math.isfinite(factor):
            continue
        factor = max(0.0, min(10.0, factor))
        key = str(raw_key).strip()
        parts: list[str]
        if "|" in key:
            parts = [part.strip() for part in key.split("|", 1)]
        elif "/" in key:
            parts = [part.strip() for part in key.split("/", 1)]
        elif "," in key:
            parts = [part.strip() for part in key.split(",", 1)]
        else:
            continue
        if len(parts) != 2 or not parts[0] or not parts[1]:
            continue
        parsed[policy_pair_key(parts[0], parts[1])] = factor
    return parsed


def parse_pair_factor_specs(specs: list[str]) -> dict[str, float]:
    parsed: dict[str, float] = {}
    for spec in specs or []:
        text = str(spec).strip()
        if not text:
            continue
        if "=" in text:
            pair_text, factor_text = text.rsplit("=", 1)
            if "|" in pair_text:
                node_id, item_id = [part.strip() for part in pair_text.split("|", 1)]
            elif "/" in pair_text:
                node_id, item_id = [part.strip() for part in pair_text.split("/", 1)]
            elif "," in pair_text:
                node_id, item_id = [part.strip() for part in pair_text.split(",", 1)]
            else:
                continue
        else:
            parts = [part.strip() for part in text.split(",")]
            if len(parts) != 3:
                continue
            node_id, item_id, factor_text = parts
        if not node_id or not item_id:
            continue
        factor = to_float(factor_text, float("nan"))
        if not math.isfinite(factor):
            continue
        parsed[policy_pair_key(node_id, item_id)] = max(0.0, min(10.0, factor))
    return parsed


def parse_pair_key_values(raw: Any) -> list[str]:
    if raw is None:
        return []
    if isinstance(raw, dict):
        values = list(raw.keys())
    elif isinstance(raw, (list, tuple, set)):
        values = list(raw)
    else:
        values = [raw]
    parsed: set[str] = set()
    for value in values:
        text = str(value).strip()
        if not text:
            continue
        if "|" in text:
            parts = [part.strip() for part in text.split("|", 1)]
        elif "/" in text:
            parts = [part.strip() for part in text.split("/", 1)]
        elif "," in text:
            parts = [part.strip() for part in text.split(",", 1)]
        else:
            continue
        if len(parts) != 2 or not parts[0] or not parts[1]:
            continue
        parsed.add(policy_pair_key(parts[0], parts[1]))
    return sorted(parsed)


def resolve_mrp_requirement_pair_modes(
    inherited_static_pairs: Any,
    cli_static_pairs: Any,
    cli_dynamic_pairs: Any,
) -> tuple[list[str], list[str]]:
    """Resolve additive static requests and targeted dynamic overrides."""

    static_pairs = set(parse_pair_key_values(inherited_static_pairs))
    static_pairs.update(parse_pair_key_values(cli_static_pairs))
    dynamic_pairs = set(parse_pair_key_values(cli_dynamic_pairs))
    static_pairs.difference_update(dynamic_pairs)
    return sorted(static_pairs), sorted(dynamic_pairs)


def normalize_optional_item_id(item_id: Any) -> str:
    text = str(item_id or "").strip()
    if not text or text == "*":
        return ""
    return text if text.startswith("item:") else f"item:{text}"


def normalize_supplier_risk_type(value: Any) -> str:
    text = str(value or "").strip().lower().replace("-", "_").replace(" ", "_")
    aliases = {
        "capacity": "capacity",
        "capacity_multiplier": "capacity",
        "supplier_capacity": "capacity",
        "debit": "capacity",
        "throughput": "capacity",
        "stock": "stock",
        "stock_multiplier": "stock",
        "supplier_stock": "stock",
        "available_stock": "stock",
        "lead": "lead_time",
        "lead_time": "lead_time",
        "leadtime": "lead_time",
        "lead_time_multiplier": "lead_time",
        "delay": "lead_time",
        "delai": "lead_time",
        "reliability": "reliability",
        "supplier_reliability": "reliability",
        "otif": "reliability",
        "availability": "availability",
        "availability_multiplier": "availability",
        "lane_availability": "availability",
        "quality": "quality_yield",
        "quality_yield": "quality_yield",
        "yield": "quality_yield",
        "receipt_yield": "quality_yield",
        "reject_rate": "quality_yield",
        "rejection": "quality_yield",
        "scrap": "quality_yield",
        "quality_delay": "quality_delay",
        "quality_release_delay": "quality_delay",
        "quarantine": "quality_delay",
        "quarantine_days": "quality_delay",
        "release_delay": "quality_delay",
        "lead_extra": "lead_time_extra_days",
        "lead_time_extra": "lead_time_extra_days",
        "lead_time_extra_days": "lead_time_extra_days",
        "delay_days": "lead_time_extra_days",
        "transport_delay": "lead_time_extra_days",
        "purchase_cost": "purchase_cost",
        "purchase_cost_multiplier": "purchase_cost",
        "price": "purchase_cost",
        "price_multiplier": "purchase_cost",
        "transport_cost": "transport_cost",
        "transport_cost_multiplier": "transport_cost",
        "freight_cost": "transport_cost",
        "freight_cost_multiplier": "transport_cost",
        "external_capacity": "external_capacity",
        "external_market_capacity": "external_capacity",
        "supplier_upstream_supply_capacity": "external_capacity",
        "upstream_supply_capacity": "external_capacity",
        "appro_amont_fournisseur_capacity": "external_capacity",
        "external_capacity_multiplier": "external_capacity",
        "market_capacity": "external_capacity",
        "spot_capacity": "external_capacity",
        "external_availability": "external_availability",
        "external_market_availability": "external_availability",
        "supplier_upstream_supply_availability": "external_availability",
        "upstream_supply_availability": "external_availability",
        "appro_amont_fournisseur_availability": "external_availability",
        "external_availability_multiplier": "external_availability",
        "market_availability": "external_availability",
        "external_lead_time": "external_lead_time",
        "external_market_lead_time": "external_lead_time",
        "supplier_upstream_supply_lead_time": "external_lead_time",
        "upstream_supply_lead_time": "external_lead_time",
        "appro_amont_fournisseur_lead_time": "external_lead_time",
        "external_lead_time_multiplier": "external_lead_time",
        "market_lead_time": "external_lead_time",
        "external_lead_extra": "external_lead_time_extra_days",
        "external_lead_time_extra": "external_lead_time_extra_days",
        "external_lead_time_extra_days": "external_lead_time_extra_days",
        "supplier_upstream_supply_lead_time_extra_days": "external_lead_time_extra_days",
        "upstream_supply_lead_time_extra_days": "external_lead_time_extra_days",
        "appro_amont_fournisseur_lead_time_extra_days": "external_lead_time_extra_days",
        "external_quality": "external_quality_yield",
        "external_quality_yield": "external_quality_yield",
        "external_market_quality_yield": "external_quality_yield",
        "supplier_upstream_supply_quality_yield": "external_quality_yield",
        "upstream_supply_quality_yield": "external_quality_yield",
        "appro_amont_fournisseur_quality_yield": "external_quality_yield",
        "external_rejection": "external_quality_yield",
        "external_cost": "external_cost",
        "external_market_cost": "external_cost",
        "supplier_upstream_supply_cost": "external_cost",
        "upstream_supply_cost": "external_cost",
        "appro_amont_fournisseur_cost": "external_cost",
        "external_cost_multiplier": "external_cost",
        "spot_cost": "external_cost",
        "stock_writeoff": "stock_writeoff",
        "stock_write_off": "stock_writeoff",
        "stock_loss": "stock_writeoff",
        "stock_writeoff_fraction": "stock_writeoff",
        "inventory_writeoff": "stock_writeoff",
    }
    return aliases.get(text, "")


def parse_supplier_risk_event_row(
    row: dict[str, Any],
    *,
    source: str,
    row_number: int,
) -> tuple[dict[str, Any] | None, str | None]:
    raw_risk_type = row.get("risk_type") or row.get("type") or row.get("parameter") or row.get("parameter_key")
    raw_risk_type_text = str(raw_risk_type or "").strip().lower().replace("-", "_").replace(" ", "_")
    risk_type = normalize_supplier_risk_type(raw_risk_type)
    if not risk_type:
        return None, f"{source}:{row_number}: unsupported or missing risk_type"

    supplier_id = str(
        row.get("supplier_id")
        or row.get("src_node_id")
        or row.get("node_id")
        or ""
    ).strip()
    if not supplier_id or supplier_id == "*":
        return None, f"{source}:{row_number}: supplier_id is required"

    start_day = int(round(to_float(row.get("start_day") or row.get("day_start") or row.get("start"), 0.0)))
    end_raw = row.get("end_day") or row.get("day_end") or row.get("end")
    end_day = int(round(to_float(end_raw, float(start_day))))
    if end_day < start_day:
        return None, f"{source}:{row_number}: end_day is before start_day"

    multiplier_raw = row.get("multiplier")
    if multiplier_raw is None or str(multiplier_raw).strip() == "":
        multiplier_raw = row.get("factor")
    if multiplier_raw is None or str(multiplier_raw).strip() == "":
        multiplier_raw = row.get("value")
    multiplier = to_float(multiplier_raw, 1.0)
    if not math.isfinite(multiplier):
        return None, f"{source}:{row_number}: multiplier is not numeric"
    if risk_type in {"quality_yield", "external_quality_yield"} and raw_risk_type_text in {
        "reject_rate",
        "rejection",
        "scrap",
        "external_rejection",
    }:
        multiplier = 1.0 - multiplier
    if risk_type in {
        "capacity",
        "stock",
        "availability",
        "external_capacity",
        "external_availability",
    }:
        multiplier = max(0.0, min(10.0, multiplier))
    elif risk_type in {"lead_time", "external_lead_time"}:
        multiplier = max(0.05, min(20.0, multiplier))
    elif risk_type in {
        "reliability",
        "quality_yield",
        "external_quality_yield",
    }:
        multiplier = max(0.01, min(10.0, multiplier))
    elif risk_type in {"lead_time_extra_days", "quality_delay", "external_lead_time_extra_days"}:
        multiplier = max(0.0, min(3650.0, multiplier))
    elif risk_type in {"purchase_cost", "transport_cost", "external_cost"}:
        multiplier = max(0.0, min(100.0, multiplier))
    elif risk_type == "stock_writeoff":
        multiplier = max(0.0, min(1.0, multiplier))

    event_id = str(row.get("event_id") or row.get("id") or f"{Path(source).stem}_{row_number}").strip()
    return (
        {
            "event_id": event_id,
            "risk_type": risk_type,
            "supplier_id": supplier_id,
            "item_id": normalize_optional_item_id(row.get("item_id")),
            "dst_node_id": str(row.get("dst_node_id") or row.get("destination_id") or "").strip(),
            "edge_id": str(row.get("edge_id") or "").strip(),
            "start_day": start_day,
            "end_day": end_day,
            "multiplier": multiplier,
            "source": source,
            "notes": str(row.get("notes") or row.get("comment") or "").strip(),
            "causal_root_id": str(
                row.get("causal_root_id")
                or row.get("root_event_id")
                or row.get("cascade_root_id")
                or event_id
            ).strip(),
        },
        None,
    )


def load_supplier_risk_events(
    *,
    csv_path: Path | None,
    scenario: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[str]]:
    events: list[dict[str, Any]] = []
    warnings: list[str] = []

    scenario_events = scenario.get("supplier_risk_events") or []
    if isinstance(scenario_events, list):
        for idx, raw in enumerate(scenario_events, start=1):
            if not isinstance(raw, dict):
                warnings.append(f"scenario:{idx}: event is not an object")
                continue
            event, warning = parse_supplier_risk_event_row(raw, source="scenario", row_number=idx)
            if warning:
                warnings.append(warning)
            elif event:
                events.append(event)

    if csv_path is not None and str(csv_path).strip():
        if not csv_path.exists():
            warnings.append(f"{csv_path}: file not found; supplier risk events ignored")
        else:
            with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                for idx, row in enumerate(reader, start=2):
                    event, warning = parse_supplier_risk_event_row(row, source=str(csv_path), row_number=idx)
                    if warning:
                        warnings.append(warning)
                    elif event:
                        events.append(event)

    events.sort(key=lambda e: (int(e["start_day"]), int(e["end_day"]), str(e["supplier_id"]), str(e["event_id"])))
    return events, warnings


def load_supplier_neutral_floor_overrides(
    csv_path: Path | None,
) -> tuple[dict[tuple[str, str], float], dict[tuple[str, str], float], list[str]]:
    capacity_overrides: dict[tuple[str, str], float] = {}
    stock_overrides: dict[tuple[str, str], float] = {}
    warnings: list[str] = []
    if csv_path is None or not csv_path.exists():
        return capacity_overrides, stock_overrides, warnings
    with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for row_number, row in enumerate(reader, start=2):
            supplier_id = str(row.get("supplier_id") or "").strip()
            item_id = str(row.get("item_id") or "").strip()
            if not supplier_id or not item_id:
                warnings.append(f"{csv_path}:{row_number}: missing supplier_id or item_id")
                continue
            pair = (supplier_id, item_id)
            cap = to_float(
                row.get("tested_capacity_floor_qty_per_day")
                if str(row.get("tested_capacity_floor_qty_per_day") or "").strip()
                else row.get("neutral_capacity_floor_qty_per_day"),
                -1.0,
            )
            if cap >= 0.0:
                capacity_overrides[pair] = max(0.0, cap)
            stock_floor = to_float(row.get("neutral_opening_stock_floor_qty"), -1.0)
            if stock_floor >= 0.0:
                stock_overrides[pair] = max(0.0, stock_floor)
    return capacity_overrides, stock_overrides, warnings


def load_factory_capacity_overrides(
    csv_path: Path | None,
) -> tuple[dict[tuple[str, str], float], list[str]]:
    capacity_overrides: dict[tuple[str, str], float] = {}
    warnings: list[str] = []
    if csv_path is None or not csv_path.exists():
        return capacity_overrides, warnings
    with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for row_number, row in enumerate(reader, start=2):
            node_id = str(row.get("node_id") or "").strip()
            item_id = str(row.get("output_item_id") or row.get("item_id") or "").strip()
            if not node_id or not item_id:
                warnings.append(f"{csv_path}:{row_number}: missing node_id or output_item_id")
                continue
            cap = to_float(
                row.get("industrial_nominal_capacity_qty_per_day")
                if str(row.get("industrial_nominal_capacity_qty_per_day") or "").strip()
                else row.get("capacity_qty_per_day"),
                -1.0,
            )
            if cap < 0.0:
                warnings.append(f"{csv_path}:{row_number}: missing nominal capacity")
                continue
            capacity_overrides[(node_id, item_id)] = max(0.0, cap)
    return capacity_overrides, warnings


def apply_factory_capacity_overrides(
    nodes: list[dict[str, Any]],
    capacity_overrides: dict[tuple[str, str], float],
) -> int:
    applied = 0
    if not capacity_overrides:
        return applied
    for node in nodes:
        node_id = str(node.get("id") or "")
        for proc in node.get("processes") or []:
            outputs = proc.get("outputs") or []
            if not outputs:
                continue
            item_id = str((outputs[0] or {}).get("item_id") or "")
            key = (node_id, item_id)
            if key not in capacity_overrides:
                continue
            cap_qty = max(0.0, capacity_overrides[key])
            capacity = proc.get("capacity")
            if not isinstance(capacity, dict):
                capacity = {}
                proc["capacity"] = capacity
            capacity["max_rate"] = cap_qty
            capacity["uom"] = capacity.get("uom") or str((outputs[0] or {}).get("uom") or "unit/day")
            capacity["is_default"] = False
            capacity["source"] = "factory_nominal_capacity_override_csv"
            applied += 1
    return applied


def supplier_risk_event_applies(
    event: dict[str, Any],
    lane: dict[str, Any],
    output_day: int,
) -> bool:
    if output_day < int(event.get("start_day", 0)) or output_day > int(event.get("end_day", 0)):
        return False
    if str(event.get("supplier_id") or "") != str(lane.get("src") or ""):
        return False
    item_id = str(event.get("item_id") or "")
    if item_id and item_id != str(lane.get("item_id") or ""):
        return False
    dst_node_id = str(event.get("dst_node_id") or "")
    if dst_node_id and dst_node_id != str(lane.get("dst") or ""):
        return False
    edge_id = str(event.get("edge_id") or "")
    if edge_id and edge_id != str(lane.get("edge_id") or ""):
        return False
    return True


def supplier_risk_multipliers_for_lane(
    events: list[dict[str, Any]],
    lane: dict[str, Any],
    output_day: int,
) -> dict[str, Any]:
    def empty_effects() -> dict[str, Any]:
        return {
            "stock": 1.0,
            "capacity": 1.0,
            "lead_time": 1.0,
            "lead_time_extra_days": 0.0,
            "quality_delay": 0.0,
            "reliability": 1.0,
            "quality_yield": 1.0,
            "availability": 1.0,
            "purchase_cost": 1.0,
            "transport_cost": 1.0,
            "external_capacity": 1.0,
            "external_availability": 1.0,
            "external_lead_time": 1.0,
            "external_lead_time_extra_days": 0.0,
            "external_quality_yield": 1.0,
            "external_cost": 1.0,
            "stock_writeoff_fraction": 0.0,
            "event_ids": [],
            "causal_root_ids": [],
        }

    def clamp_effects(effects: dict[str, Any], *, cap_state_dependent: bool) -> dict[str, Any]:
        out = dict(effects)
        out["stock"] = max(0.0, min(10.0, to_float(out.get("stock"), 1.0)))
        out["capacity"] = max(0.0, min(10.0, to_float(out.get("capacity"), 1.0)))
        out["availability"] = max(0.0, min(10.0, to_float(out.get("availability"), 1.0)))
        out["lead_time"] = max(0.05, min(20.0, to_float(out.get("lead_time"), 1.0)))
        out["reliability"] = max(0.01, min(10.0, to_float(out.get("reliability"), 1.0)))
        out["quality_yield"] = max(0.01, min(10.0, to_float(out.get("quality_yield"), 1.0)))
        out["purchase_cost"] = max(0.0, min(100.0, to_float(out.get("purchase_cost"), 1.0)))
        out["transport_cost"] = max(0.0, min(100.0, to_float(out.get("transport_cost"), 1.0)))
        out["external_capacity"] = max(0.0, min(10.0, to_float(out.get("external_capacity"), 1.0)))
        out["external_availability"] = max(0.0, min(10.0, to_float(out.get("external_availability"), 1.0)))
        out["external_lead_time"] = max(0.05, min(20.0, to_float(out.get("external_lead_time"), 1.0)))
        out["external_quality_yield"] = max(0.01, min(10.0, to_float(out.get("external_quality_yield"), 1.0)))
        out["external_cost"] = max(0.0, min(100.0, to_float(out.get("external_cost"), 1.0)))
        out["lead_time_extra_days"] = max(0.0, min(3650.0, to_float(out.get("lead_time_extra_days"), 0.0)))
        out["quality_delay"] = max(0.0, min(3650.0, to_float(out.get("quality_delay"), 0.0)))
        out["external_lead_time_extra_days"] = max(
            0.0,
            min(3650.0, to_float(out.get("external_lead_time_extra_days"), 0.0)),
        )
        out["stock_writeoff_fraction"] = max(0.0, min(1.0, to_float(out.get("stock_writeoff_fraction"), 0.0)))
        if cap_state_dependent:
            # Endogenous state-dependent signals are early warnings and mild
            # control perturbations. Keep those bounded without weakening
            # explicit exogenous crisis scenarios that may overlap the same lane.
            out["capacity"] = max(to_float(out.get("capacity"), 1.0), 0.70)
            out["availability"] = max(to_float(out.get("availability"), 1.0), 0.70)
            out["reliability"] = max(to_float(out.get("reliability"), 1.0), 0.75)
            out["quality_yield"] = max(to_float(out.get("quality_yield"), 1.0), 0.75)
            out["external_capacity"] = max(to_float(out.get("external_capacity"), 1.0), 0.70)
            out["external_availability"] = max(to_float(out.get("external_availability"), 1.0), 0.70)
            out["external_quality_yield"] = max(to_float(out.get("external_quality_yield"), 1.0), 0.75)
            out["lead_time"] = min(to_float(out.get("lead_time"), 1.0), 1.50)
            out["lead_time_extra_days"] = min(to_float(out.get("lead_time_extra_days"), 0.0), 10.0)
            out["external_lead_time"] = min(to_float(out.get("external_lead_time"), 1.0), 1.50)
            out["external_lead_time_extra_days"] = min(
                to_float(out.get("external_lead_time_extra_days"), 0.0),
                10.0,
            )
            out["external_cost"] = min(to_float(out.get("external_cost"), 1.0), 1.50)
            out["purchase_cost"] = min(to_float(out.get("purchase_cost"), 1.0), 1.50)
            out["transport_cost"] = min(to_float(out.get("transport_cost"), 1.0), 1.50)
        return out

    def apply_event(effects: dict[str, Any], event: dict[str, Any]) -> None:
        risk_type = str(event.get("risk_type") or "")
        multiplier = to_float(event.get("multiplier"), 1.0)
        if risk_type in {"lead_time_extra_days", "quality_delay", "external_lead_time_extra_days"}:
            effects[risk_type] = to_float(effects.get(risk_type), 0.0) + multiplier
            effects["event_ids"].append(str(event.get("event_id") or ""))
            effects["causal_root_ids"].append(
                str(event.get("causal_root_id") or event.get("event_id") or "")
            )
        elif risk_type == "stock_writeoff":
            current_fraction = max(0.0, min(1.0, to_float(effects.get("stock_writeoff_fraction"), 0.0)))
            event_fraction = max(0.0, min(1.0, multiplier))
            effects["stock_writeoff_fraction"] = 1.0 - ((1.0 - current_fraction) * (1.0 - event_fraction))
            effects["event_ids"].append(str(event.get("event_id") or ""))
            effects["causal_root_ids"].append(
                str(event.get("causal_root_id") or event.get("event_id") or "")
            )
        elif risk_type in effects and risk_type != "event_ids":
            effects[risk_type] = to_float(effects.get(risk_type), 1.0) * multiplier
            effects["event_ids"].append(str(event.get("event_id") or ""))
            effects["causal_root_ids"].append(
                str(event.get("causal_root_id") or event.get("event_id") or "")
            )

    out = empty_effects()
    if not events:
        return out

    scenario_out: dict[str, Any] = empty_effects()
    state_out: dict[str, Any] = empty_effects()
    state_dependent_applied = False
    for event in events:
        if not supplier_risk_event_applies(event, lane, output_day):
            continue
        if str(event.get("source") or "") == "state_dependent_supplier_risk":
            state_dependent_applied = True
            apply_event(state_out, event)
        else:
            apply_event(scenario_out, event)

    scenario_out = clamp_effects(scenario_out, cap_state_dependent=False)
    state_out = clamp_effects(state_out, cap_state_dependent=state_dependent_applied)
    multiplicative_fields = {
        "stock",
        "capacity",
        "lead_time",
        "reliability",
        "quality_yield",
        "availability",
        "purchase_cost",
        "transport_cost",
        "external_capacity",
        "external_availability",
        "external_lead_time",
        "external_quality_yield",
        "external_cost",
    }
    additive_fields = {"lead_time_extra_days", "quality_delay", "external_lead_time_extra_days"}
    out = empty_effects()
    for field in multiplicative_fields:
        out[field] = to_float(scenario_out.get(field), 1.0) * to_float(state_out.get(field), 1.0)
    for field in additive_fields:
        out[field] = to_float(scenario_out.get(field), 0.0) + to_float(state_out.get(field), 0.0)
    scenario_writeoff = max(0.0, min(1.0, to_float(scenario_out.get("stock_writeoff_fraction"), 0.0)))
    state_writeoff = max(0.0, min(1.0, to_float(state_out.get("stock_writeoff_fraction"), 0.0)))
    out["stock_writeoff_fraction"] = 1.0 - ((1.0 - scenario_writeoff) * (1.0 - state_writeoff))
    out["event_ids"] = [
        event_id
        for event_id in [*(scenario_out.get("event_ids") or []), *(state_out.get("event_ids") or [])]
        if str(event_id)
    ]
    out["causal_root_ids"] = [
        event_id
        for event_id in [
            *(scenario_out.get("causal_root_ids") or []),
            *(state_out.get("causal_root_ids") or []),
        ]
        if str(event_id)
    ]
    return clamp_effects(out, cap_state_dependent=False)


def supplier_risk_event_applies_to_pair(
    event: dict[str, Any],
    supplier_id: str,
    item_id: str,
    output_day: int,
) -> bool:
    if output_day < int(event.get("start_day", 0)) or output_day > int(event.get("end_day", 0)):
        return False
    if str(event.get("supplier_id") or "") != str(supplier_id or ""):
        return False
    event_item_id = str(event.get("item_id") or "")
    if event_item_id and event_item_id != str(item_id or ""):
        return False
    return True


def supplier_risk_effects_for_pair(
    events: list[dict[str, Any]],
    supplier_id: str,
    item_id: str,
    output_day: int,
) -> dict[str, Any]:
    lane_like = {
        "src": supplier_id,
        "dst": "",
        "item_id": item_id,
        "edge_id": "",
    }
    scoped_events = [
        event
        for event in events
        if supplier_risk_event_applies_to_pair(event, supplier_id, item_id, output_day)
    ]
    return supplier_risk_multipliers_for_lane(scoped_events, lane_like, output_day)


def supplier_risk_applied_row(
    *,
    day: int,
    supplier_id: str,
    dst_node_id: str,
    item_id: str,
    edge_id: str,
    effects: dict[str, Any],
) -> dict[str, Any]:
    return {
        "day": day,
        "supplier_id": supplier_id,
        "dst_node_id": dst_node_id,
        "item_id": item_id,
        "edge_id": edge_id,
        "event_ids": ",".join(str(x) for x in effects.get("event_ids", [])),
        "causal_root_ids": ",".join(
            str(x) for x in effects.get("causal_root_ids", effects.get("event_ids", []))
        ),
        "stock_multiplier": round(to_float(effects.get("stock"), 1.0), 6),
        "capacity_multiplier": round(to_float(effects.get("capacity"), 1.0), 6),
        "lead_time_multiplier": round(to_float(effects.get("lead_time"), 1.0), 6),
        "lead_time_extra_days": round(to_float(effects.get("lead_time_extra_days"), 0.0), 6),
        "quality_delay_days": round(to_float(effects.get("quality_delay"), 0.0), 6),
        "reliability_multiplier": round(to_float(effects.get("reliability"), 1.0), 6),
        "quality_yield_multiplier": round(to_float(effects.get("quality_yield"), 1.0), 6),
        "availability_multiplier": round(to_float(effects.get("availability"), 1.0), 6),
        "purchase_cost_multiplier": round(to_float(effects.get("purchase_cost"), 1.0), 6),
        "transport_cost_multiplier": round(to_float(effects.get("transport_cost"), 1.0), 6),
        "external_capacity_multiplier": round(to_float(effects.get("external_capacity"), 1.0), 6),
        "external_availability_multiplier": round(to_float(effects.get("external_availability"), 1.0), 6),
        "external_lead_time_multiplier": round(to_float(effects.get("external_lead_time"), 1.0), 6),
        "external_lead_time_extra_days": round(to_float(effects.get("external_lead_time_extra_days"), 0.0), 6),
        "external_quality_yield_multiplier": round(to_float(effects.get("external_quality_yield"), 1.0), 6),
        "external_cost_multiplier": round(to_float(effects.get("external_cost"), 1.0), 6),
        "stock_writeoff_fraction": round(to_float(effects.get("stock_writeoff_fraction"), 0.0), 6),
    }


def opening_purchase_order_shipment_id(source_row: Any, fallback_index: int) -> str:
    """Return a stable shipment identifier tied to the observed source row."""

    raw = str(source_row if str(source_row or "").strip() else fallback_index).strip()
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", raw).strip("_") or str(fallback_index)
    return f"opening_po_sr{safe}"


def opening_purchase_order_risk_overlay(
    *,
    planned_qty: float,
    planned_physical_delivery_day: int,
    planned_usable_day: int,
    release_day: int,
    lane: dict[str, Any],
    supplier_risk_events: list[dict[str, Any]],
) -> dict[str, Any]:
    """Apply exogenous supplier risks to one observed *planned* opening PO.

    The event selection date is the source order book's planned physical
    delivery day.  Transport effects move both physical delivery and usable
    receipt; quality release delay moves only usable receipt.  A firm order's
    pulled quantity is preserved, while availability/reliability reduce the
    physical shipment and quality yield reduces the usable receipt.

    Capacity, supplier-stock and upstream-market effects deliberately are not
    converted into a fictitious PO delay: doing so requires a dated supplier
    capacity calendar that the source order book does not provide.  They are
    retained in the audit as unsupported effects.
    """

    decision_day = int(planned_physical_delivery_day)
    active_events = [
        event
        for event in supplier_risk_events
        if supplier_risk_event_applies(event, lane, decision_day)
    ]
    effects = supplier_risk_multipliers_for_lane(
        active_events,
        lane,
        decision_day,
    )
    risk_types = sorted(
        {
            str(event.get("risk_type") or "")
            for event in active_events
            if str(event.get("risk_type") or "")
        }
    )
    supported_types = {
        "availability",
        "reliability",
        "quality_yield",
        "lead_time",
        "lead_time_extra_days",
        "quality_delay",
    }
    unsupported_types = sorted(set(risk_types) - supported_types)

    pulled_qty = max(0.0, to_float(planned_qty, 0.0))
    availability_multiplier = min(
        1.0,
        max(0.0, to_float(effects.get("availability"), 1.0)),
    )
    reliability_multiplier = min(
        1.0,
        max(0.0, to_float(effects.get("reliability"), 1.0)),
    )
    quality_yield_multiplier = min(
        1.0,
        max(0.0, to_float(effects.get("quality_yield"), 1.0)),
    )
    physical_shipped_qty = (
        pulled_qty * availability_multiplier * reliability_multiplier
    )
    usable_qty = physical_shipped_qty * quality_yield_multiplier

    transport_days_before = max(
        0,
        int(planned_physical_delivery_day) - int(release_day),
    )
    lead_time_multiplier = max(
        0.05,
        to_float(effects.get("lead_time"), 1.0),
    )
    lead_time_extra_days = max(
        0.0,
        to_float(effects.get("lead_time_extra_days"), 0.0),
    )
    transport_days_after = max(
        0,
        int(
            math.ceil(
                transport_days_before * lead_time_multiplier
                + lead_time_extra_days
                - 1e-12
            )
        ),
    )
    physical_delivery_day_after = max(
        0,
        int(release_day) + transport_days_after,
    )
    source_release_gap_days = max(
        0,
        int(planned_usable_day) - int(planned_physical_delivery_day),
    )
    quality_delay_days = max(
        0,
        int(math.ceil(to_float(effects.get("quality_delay"), 0.0) - 1e-12)),
    )
    usable_day_after = (
        physical_delivery_day_after
        + source_release_gap_days
        + quality_delay_days
    )
    return {
        "risk_decision_day": decision_day,
        "event_ids": [str(value) for value in effects.get("event_ids", [])],
        "risk_types": risk_types,
        "unsupported_risk_types": unsupported_types,
        "effects": effects,
        "pulled_qty": pulled_qty,
        "physical_shipped_qty": physical_shipped_qty,
        "usable_qty": usable_qty,
        "physical_delivery_day": physical_delivery_day_after,
        "usable_day": usable_day_after,
        "receipt_release_days": source_release_gap_days + quality_delay_days,
        "transport_delay_days": (
            physical_delivery_day_after - int(planned_physical_delivery_day)
        ),
        "quality_release_delay_days": quality_delay_days,
    }


def make_opening_purchase_order_lot_marker(
    *,
    source_row: Any,
    source_file: str,
    supplier_id: str,
    edge_id: str,
    shipment_id: str,
    risk_decision_day: int,
    risk_event_ids: str,
) -> str:
    source_name = Path(str(source_file or "opening_open_orders_metadata")).name
    payload = {
        "edge_id": str(edge_id or ""),
        "risk_decision_day": int(risk_decision_day),
        "risk_event_ids": str(risk_event_ids or ""),
        "shipment_id": str(shipment_id),
        "source_file": source_name,
        "source_row": str(source_row or ""),
        "supplier_id": str(supplier_id or ""),
    }
    return OPENING_PURCHASE_ORDER_LANE_PREFIX + json.dumps(
        payload,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )


def parse_opening_purchase_order_lot_marker(value: Any) -> dict[str, Any] | None:
    marker = str(value or "")
    if not marker.startswith(OPENING_PURCHASE_ORDER_LANE_PREFIX):
        return None
    try:
        payload = json.loads(marker[len(OPENING_PURCHASE_ORDER_LANE_PREFIX) :])
    except (TypeError, ValueError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def materialize_opening_purchase_order_receipt_lot(
    lot_ledger: LotLedger,
    *,
    day: int,
    node_id: str,
    item_id: str,
    qty: float,
    uom: str,
    marker: Any,
) -> str:
    """Create a receipt lot whose source order and supplier remain explicit."""

    payload = parse_opening_purchase_order_lot_marker(marker)
    if payload is None or qty <= LOT_TRACE_EPS:
        return ""
    source_row = str(payload.get("source_row") or "")
    supplier_id = str(payload.get("supplier_id") or "")
    source_file = str(payload.get("source_file") or "opening_open_orders_metadata")
    source_id = f"{source_file}:row:{source_row};supplier:{supplier_id}"
    return lot_ledger.create_lot(
        day=int(day),
        node_id=str(node_id),
        item_id=str(item_id),
        qty=max(0.0, to_float(qty, 0.0)),
        source_type="opening_purchase_order_receipt",
        source_id=source_id,
        shipment_id=str(payload.get("shipment_id") or ""),
        risk_decision_day=payload.get("risk_decision_day", ""),
        risk_event_ids=str(payload.get("risk_event_ids") or ""),
        uom=str(uom or ""),
        event_type="opening_purchase_order_receipt",
        notes=(
            "Observed planned opening purchase order replay; "
            f"supplier={supplier_id}; source_row={source_row}."
        ),
        source_row=source_row,
        supplier_id=supplier_id,
    )


def active_state_dependent_events(
    events: list[dict[str, Any]],
    output_day: int,
) -> list[dict[str, Any]]:
    if not events:
        return []
    return [
        event
        for event in events
        if int(event.get("start_day", 0)) <= output_day <= int(event.get("end_day", 0))
    ]


def make_state_dependent_supplier_event(
    *,
    event_id: str,
    trigger_day: int,
    supplier_id: str,
    item_id: str,
    risk_family: str,
    risk_type: str,
    multiplier: float,
    start_day: int,
    duration_days: int,
    trigger_metric: str,
    trigger_value: float,
    threshold: float,
    consecutive_days: int,
    effect: str,
    notes: str,
    dst_node_id: str = "",
    edge_id: str = "",
) -> tuple[dict[str, Any], dict[str, Any]]:
    end_day = start_day + max(1, int(duration_days)) - 1
    event = {
        "event_id": event_id,
        "causal_root_id": event_id,
        "risk_family": risk_family,
        "risk_type": risk_type,
        "supplier_id": supplier_id,
        "item_id": item_id,
        "dst_node_id": dst_node_id,
        "edge_id": edge_id,
        "start_day": int(start_day),
        "end_day": int(end_day),
        "multiplier": multiplier,
        "source": "state_dependent_supplier_risk",
        "notes": notes,
    }
    row = {
        "event_id": event_id,
        "causal_root_id": event_id,
        "trigger_day": int(trigger_day),
        "start_day": int(start_day),
        "end_day": int(end_day),
        "supplier_id": supplier_id,
        "item_id": item_id,
        "dst_node_id": dst_node_id,
        "edge_id": edge_id,
        "risk_family": risk_family,
        "risk_type": risk_type,
        "multiplier": round(multiplier, 6),
        "trigger_metric": trigger_metric,
        "trigger_value": round(trigger_value, 6),
        "threshold": round(threshold, 6),
        "consecutive_days": int(consecutive_days),
        "effect": effect,
        "notes": notes,
    }
    return event, row


def scenario_initialization_policy(
    scenario: dict[str, Any],
    *,
    review_period_days: int,
    safety_stock_days: float,
) -> dict[str, Any]:
    raw = scenario.get("initialization_policy")
    if not isinstance(raw, dict):
        raw = {}
    safety_days = max(0, int(math.ceil(safety_stock_days)))
    review_days = max(1, int(review_period_days))
    mode = str(raw.get("mode", "legacy_bootstrap")).strip().lower() or "legacy_bootstrap"
    if mode not in {"legacy_bootstrap", "explicit_state"}:
        mode = "legacy_bootstrap"
    return {
        "mode": mode,
        "state_scale": max(0.0, to_float(raw.get("state_scale"), 1.0)),
        "factory_input_on_hand_days": max(
            0.0,
            to_float(raw.get("factory_input_on_hand_days"), float(max(review_days + safety_days, 10))),
        ),
        "supplier_output_on_hand_days": max(
            0.0,
            to_float(raw.get("supplier_output_on_hand_days"), float(max(review_days + safety_days, 10))),
        ),
        "distribution_center_on_hand_days": max(
            0.0,
            to_float(raw.get("distribution_center_on_hand_days"), float(max(review_days + safety_days + 2, 12))),
        ),
        "customer_on_hand_days": max(
            0.0,
            to_float(raw.get("customer_on_hand_days"), 0.0),
        ),
        "seed_safety_time_on_hand": (
            raw.get("seed_safety_time_on_hand")
            if isinstance(raw.get("seed_safety_time_on_hand"), bool)
            else str(raw.get("seed_safety_time_on_hand", "true")).strip().lower() in {"1", "true", "yes", "y", "on"}
        ),
        "seed_estimated_source_on_hand": (
            raw.get("seed_estimated_source_on_hand")
            if isinstance(raw.get("seed_estimated_source_on_hand"), bool)
            else str(raw.get("seed_estimated_source_on_hand", "true")).strip().lower()
            in {"1", "true", "yes", "y", "on"}
        ),
        "seed_in_transit": (
            raw.get("seed_in_transit")
            if isinstance(raw.get("seed_in_transit"), bool)
            else str(raw.get("seed_in_transit", "true")).strip().lower() in {"1", "true", "yes", "y", "on"}
        ),
        "in_transit_fill_ratio": max(
            0.0,
            to_float(raw.get("in_transit_fill_ratio"), 1.0),
        ),
        "seed_estimated_source_pipeline": (
            raw.get("seed_estimated_source_pipeline")
            if isinstance(raw.get("seed_estimated_source_pipeline"), bool)
            else str(raw.get("seed_estimated_source_pipeline", "true")).strip().lower() in {"1", "true", "yes", "y", "on"}
        ),
        "opening_production_order_bom_issue_mode": (
            str(raw.get("opening_production_order_bom_issue_mode") or "receipt").strip().lower()
            if str(raw.get("opening_production_order_bom_issue_mode") or "receipt").strip().lower()
            in {"receipt", "release", "wip"}
            else "receipt"
        ),
        "restore_opening_stock_after_warmup": (
            raw.get("restore_opening_stock_after_warmup")
            if isinstance(raw.get("restore_opening_stock_after_warmup"), bool)
            else str(raw.get("restore_opening_stock_after_warmup", "false")).strip().lower()
            in {"1", "true", "yes", "y", "on"}
        ),
        "seed_open_orders_from_january_snapshot": (
            raw.get("seed_open_orders_from_january_snapshot")
            if isinstance(raw.get("seed_open_orders_from_january_snapshot"), bool)
            else str(raw.get("seed_open_orders_from_january_snapshot", "false")).strip().lower()
            in {"1", "true", "yes", "y", "on"}
        ),
        "opening_open_orders_horizon_days": max(
            0,
            int(round(max(0.0, to_float(raw.get("opening_open_orders_horizon_days"), 0.0)))),
        ),
        "opening_open_orders_demand_multiplier": max(
            0.0,
            to_float(raw.get("opening_open_orders_demand_multiplier"), 1.0),
        ),
        "use_bom_demand_signal_for_mrp": (
            raw.get("use_bom_demand_signal_for_mrp")
            if isinstance(raw.get("use_bom_demand_signal_for_mrp"), bool)
            else str(raw.get("use_bom_demand_signal_for_mrp", "false")).strip().lower()
            in {"1", "true", "yes", "y", "on"}
        ),
        "mrp_demand_signal_source": (
            str(raw.get("mrp_demand_signal_source") or "demand").strip().lower()
            if str(raw.get("mrp_demand_signal_source") or "demand").strip().lower()
            in {"demand", "mps_lotified"}
            else "demand"
        ),
        "mrp_demand_signal_smoothing_days": max(
            1,
            int(round(max(1.0, to_float(raw.get("mrp_demand_signal_smoothing_days"), 1.0)))),
        ),
        "mrp_static_fallback_for_propagated_pairs": (
            raw.get("mrp_static_fallback_for_propagated_pairs")
            if isinstance(raw.get("mrp_static_fallback_for_propagated_pairs"), bool)
            else str(raw.get("mrp_static_fallback_for_propagated_pairs", "true")).strip().lower()
            in {"1", "true", "yes", "y", "on"}
        ),
        "mrp_static_requirement_pairs": parse_pair_key_values(raw.get("mrp_static_requirement_pairs")),
        "mrp_enforce_physical_safety_floor": (
            raw.get("mrp_enforce_physical_safety_floor")
            if isinstance(raw.get("mrp_enforce_physical_safety_floor"), bool)
            else str(raw.get("mrp_enforce_physical_safety_floor", "false")).strip().lower()
            in {"1", "true", "yes", "y", "on"}
        ),
        "mrp_strict_safety_floor_from_safety_time": (
            raw.get("mrp_strict_safety_floor_from_safety_time")
            if isinstance(raw.get("mrp_strict_safety_floor_from_safety_time"), bool)
            else str(raw.get("mrp_strict_safety_floor_from_safety_time", "false")).strip().lower()
            in {"1", "true", "yes", "y", "on"}
        ),
        "soft_safety_time_stock_target_factor": max(
            0.0,
            min(10.0, to_float(raw.get("soft_safety_time_stock_target_factor"), 1.0)),
        ),
        "soft_safety_time_stock_target_factor_by_pair": parse_pair_factor_map(
            raw.get("soft_safety_time_stock_target_factor_by_pair")
        ),
        "mrp_base_stock_floor_factor": max(
            0.0,
            min(10.0, to_float(raw.get("mrp_base_stock_floor_factor"), 1.0)),
        ),
        "mrp_base_stock_floor_factor_by_pair": parse_pair_factor_map(
            raw.get("mrp_base_stock_floor_factor_by_pair")
        ),
    }


def seed_lane_pipeline_uniform(
    pipeline: dict[int, list[tuple[str, str, float, str]]],
    in_transit: dict[tuple[str, str], float],
    *,
    dst: str,
    item_id: str,
    qty: float,
    edge_id: str,
    lead_days: int,
    uom: str = "",
) -> None:
    qty = physical_execution_quantity(qty, uom)
    if qty <= 1e-9:
        return
    lead_days = max(1, int(lead_days))
    per_day = qty / float(lead_days)
    for offset in range(lead_days):
        per_day = (physical_execution_quantity(qty * (offset + 1) / lead_days, uom)
                   - physical_execution_quantity(qty * offset / lead_days, uom))
        pipeline[offset].append((dst, item_id, per_day, edge_id))
    in_transit[(dst, item_id)] += qty


def seed_external_pipeline_uniform(
    pipeline: dict[int, list[tuple[str, str, float, str, str, str]]],
    in_transit: dict[tuple[str, str], float],
    *,
    node_id: str,
    item_id: str,
    qty: float,
    lead_days: int,
    uom: str = "",
) -> None:
    qty = physical_execution_quantity(qty, uom)
    if qty <= 1e-9:
        return
    lead_days = max(1, int(lead_days))
    per_day = qty / float(lead_days)
    for offset in range(lead_days):
        per_day = (physical_execution_quantity(qty * (offset + 1) / lead_days, uom)
                   - physical_execution_quantity(qty * offset / lead_days, uom))
        pipeline[offset].append((node_id, item_id, per_day, "", "", ""))
    in_transit[(node_id, item_id)] += qty


def seed_estimated_source_pipeline_uniform(
    pipeline: dict[int, list[tuple[str, str, float]]],
    in_transit: dict[tuple[str, str], float],
    *,
    node_id: str,
    item_id: str,
    qty: float,
    lead_days: int,
    uom: str = "",
) -> None:
    qty = physical_execution_quantity(qty, uom)
    if qty <= 1e-9:
        return
    lead_days = max(1, int(lead_days))
    per_day = qty / float(lead_days)
    for offset in range(lead_days):
        per_day = (physical_execution_quantity(qty * (offset + 1) / lead_days, uom)
                   - physical_execution_quantity(qty * offset / lead_days, uom))
        pipeline[offset].append((node_id, item_id, per_day))
    in_transit[(node_id, item_id)] += qty


def seed_open_orders_from_opening_snapshot(
    pipeline: dict[int, list[tuple[str, str, float, str]]],
    in_transit: dict[tuple[str, str], float],
    *,
    lanes: list[dict[str, Any]],
    lanes_by_dest_item: dict[tuple[str, str], list[dict[str, Any]]],
    opening_stock_source_snapshot: dict[tuple[str, str], float],
    pair_mrp_safety_time_days: dict[tuple[str, str], float],
    pair_mrp_safety_stock_qty: dict[tuple[str, str], float],
    demand_profiles: dict[tuple[str, str], list[dict[str, Any]]],
    required_daily_input_by_pair: dict[tuple[str, str], float],
    process_input_requirements_by_output_pair: dict[tuple[str, str], list[tuple[tuple[str, str], float]]],
    opening_open_orders_demand_multiplier: float,
    demand_pairs: list[tuple[str, str]],
    stochastic_lead_times: bool,
    horizon_cap_days: int,
    initialization_pipeline_rows: list[dict[str, Any]],
    assumptions_ledger_rows: list[dict[str, Any]],
) -> tuple[float, list[dict[str, Any]], dict[tuple[str, str], int]]:
    if horizon_cap_days <= 0:
        return 0.0, [], {}

    inbound_pairs = sorted(lanes_by_dest_item.keys())
    if not inbound_pairs:
        return 0.0, [], {}

    daily_signals_by_pair: dict[tuple[str, str], list[float]] = {
        pair: [0.0] * horizon_cap_days for pair in inbound_pairs
    }
    safety_daily_signals_by_pair: dict[tuple[str, str], list[float]] = {
        pair: [0.0] * horizon_cap_days for pair in inbound_pairs
    }
    for day in range(horizon_cap_days):
        demand_target_today = {
            pair: max(0.0, profile_value(profile, day))
            for pair, profile in demand_profiles.items()
        }
        propagated_demand_today = propagate_supply_demand_rates(
            demand_target_today,
            lanes,
            process_input_requirements_by_output_pair,
        )
        for pair in inbound_pairs:
            dynamic_req = max(0.0, propagated_demand_today.get(pair, 0.0))
            static_req = max(0.0, required_daily_input_by_pair.get(pair, 0.0))
            daily_signals_by_pair[pair][day] = (
                dynamic_req * opening_open_orders_demand_multiplier
                if dynamic_req > 1e-9
                else static_req
            )
            safety_daily_signals_by_pair[pair][day] = max(
                static_req,
                dynamic_req if dynamic_req > 1e-9 else 0.0,
            )

    seeded_total_qty = 0.0
    open_order_rows: list[dict[str, Any]] = []
    bridge_days_by_pair: dict[tuple[str, str], int] = {}

    for pair in inbound_pairs:
        lane_list = list(lanes_by_dest_item.get(pair, []))
        if not lane_list:
            continue
        opening_qty = max(0.0, opening_stock_source_snapshot.get(pair, 0.0))
        safety_qty = 0.0
        safety_days = int(math.ceil(max(0.0, pair_mrp_safety_time_days.get(pair, 0.0))))
        min_lead_days = min(max(1, int(to_float(lane.get("lead_days"), 1.0))) for lane in lane_list)
        bridge_horizon_days = max(1, min(horizon_cap_days, min_lead_days + safety_days))
        bridge_days_by_pair[pair] = bridge_horizon_days
        daily_signals = daily_signals_by_pair.get(pair, [])
        safety_daily_signals = safety_daily_signals_by_pair.get(pair, daily_signals)
        opening_safety_floor_qty = max(
            safety_qty,
            sum(max(0.0, safety_daily_signals[day]) for day in range(min(safety_days, len(safety_daily_signals)))),
        )
        first_day_need_qty = max(0.0, safety_daily_signals[0]) if safety_daily_signals else 0.0
        opening_safety_gap_qty = max(0.0, opening_safety_floor_qty + first_day_need_qty - opening_qty)
        bridge_need_qty = sum(max(0.0, daily_signals[day]) for day in range(bridge_horizon_days))
        gap_qty = max(0.0, safety_qty + bridge_need_qty - opening_qty, opening_safety_gap_qty)
        if gap_qty <= 1e-9:
            continue

        positive_shares = [max(0.0, to_float(lane.get("mrp_share"), 0.0)) for lane in lane_list]
        share_total = sum(positive_shares)
        if share_total <= 1e-9:
            positive_shares = [1.0] * len(lane_list)
            share_total = float(len(lane_list))

        for lane, share in zip(lane_list, positive_shares):
            lane_gap_qty = gap_qty * (share / share_total)
            lane_opening_safety_gap_qty = opening_safety_gap_qty * (share / share_total)
            if lane_gap_qty <= 1e-9:
                continue
            lead_days = max(1, int(to_float(lane.get("lead_days"), 1.0)))
            order_frequency_days = max(1, int(round(max(1.0, to_float(lane.get("order_frequency_days"), 1.0)))))
            standard_order_qty = max(0.0, to_float(lane.get("standard_order_qty"), 0.0))
            lane_horizon_days = max(1, min(bridge_horizon_days, lead_days + safety_days))
            cadence_order_count = max(1, int(math.ceil(lane_horizon_days / float(order_frequency_days))))
            early_receipts: list[tuple[int, float]] = []
            order_count = cadence_order_count
            if standard_order_qty > 1e-9:
                order_units = max(1, int(math.ceil((lane_gap_qty / standard_order_qty) - 1e-9)))
                opening_safety_units = min(
                    order_units,
                    max(0, int(math.ceil((lane_opening_safety_gap_qty / standard_order_qty) - 1e-9))),
                )
                if opening_safety_units > 0:
                    early_window_days = max(1, min(max(1, safety_days), lane_horizon_days))
                    early_day_count = min(opening_safety_units, early_window_days)
                    base_units = max(1, opening_safety_units // early_day_count)
                    remainder_units = opening_safety_units % early_day_count
                    for idx in range(early_day_count):
                        units = base_units + (1 if idx < remainder_units else 0)
                        early_receipts.append((idx * order_frequency_days, units * standard_order_qty))
                remaining_units = max(0, order_units - opening_safety_units)
                order_count = min(cadence_order_count, remaining_units)
                qty_by_order = []
                if order_count > 0:
                    base_units = max(1, remaining_units // order_count)
                    remainder_units = remaining_units % order_count
                    for idx in range(order_count):
                        units = base_units + (1 if idx < remainder_units else 0)
                        qty_by_order.append(units * standard_order_qty)
            else:
                opening_safety_receipt = min(lane_gap_qty, lane_opening_safety_gap_qty)
                if opening_safety_receipt > 1e-9:
                    early_receipts.append((0, opening_safety_receipt))
                remaining_gap_qty = max(0.0, lane_gap_qty - opening_safety_receipt)
                if remaining_gap_qty > 1e-9:
                    qty_per_order = remaining_gap_qty / float(order_count)
                    qty_by_order = [qty_per_order] * order_count
                else:
                    qty_by_order = []

            if order_count <= 0:
                arrival_days = []
            elif order_count == 1:
                arrival_days = [max(1, lane_horizon_days - 1)]
            else:
                latest_arrival_day = max(1, lane_horizon_days - 1)
                order_count = min(order_count, latest_arrival_day)
                arrival_days = []
                cursor = latest_arrival_day
                for _ in range(order_count):
                    arrival_days.append(max(1, cursor))
                    cursor -= order_frequency_days
                if len(set(arrival_days)) < len(arrival_days):
                    arrival_days = [
                        max(1, int(round(idx * latest_arrival_day / float(order_count - 1))))
                        for idx in range(order_count)
                    ]
                arrival_days = sorted(arrival_days)

            if early_receipts and order_count > 0:
                latest_arrival_day = max(1, lane_horizon_days - 1)
                arrival_days = [
                    min(latest_arrival_day, 1 + idx * order_frequency_days)
                    for idx in range(order_count)
                ]

            if early_receipts:
                arrival_days = [day for day, _ in early_receipts] + arrival_days
                qty_by_order = [qty for _, qty in early_receipts] + qty_by_order

            for arrival_day, receipt_qty in zip(arrival_days, qty_by_order):
                if receipt_qty <= 1e-9:
                    continue
                pipeline[arrival_day].append((pair[0], pair[1], receipt_qty, str(lane.get("edge_id", ""))))
                in_transit[pair] += receipt_qty
                seeded_total_qty += receipt_qty
                release_day_imt = arrival_day - lead_days
                initialization_pipeline_rows.append(
                    {
                        "node_id": pair[0],
                        "item_id": pair[1],
                        "category": "opening_open_order_book",
                        "seeded_pipeline_qty": round(receipt_qty, 6),
                        "lead_days": int(lead_days),
                        "lane_src": str(lane.get("src", "")),
                    }
                )
                row = {
                    "node_id": pair[0],
                    "item_id": pair[1],
                    "src_node_id": str(lane.get("src", "")),
                    "edge_id": str(lane.get("edge_id", "")),
                    "arrival_day": int(arrival_day),
                    "release_day_imt": int(release_day_imt),
                    "receipt_qty": round(receipt_qty, 6),
                    "lead_days": int(lead_days),
                    "order_frequency_days": int(order_frequency_days),
                    "standard_order_qty": round(standard_order_qty, 6),
                    "safety_time_days": round(float(safety_days), 6),
                    "opening_safety_floor_qty": round(opening_safety_floor_qty, 6),
                    "opening_safety_gap_qty": round(opening_safety_gap_qty, 6),
                    "bridge_horizon_days": int(bridge_horizon_days),
                    "opening_stock_qty": round(opening_qty, 6),
                    "bridge_need_qty": round(bridge_need_qty, 6),
                    "gap_qty": round(gap_qty, 6),
                }
                open_order_rows.append(row)
                assumptions_ledger_rows.append(
                    {
                        "category": "opening_open_order_book",
                        "node_id": pair[0],
                        "item_id": pair[1],
                        "edge_id": str(lane.get("edge_id", "")),
                        "source": "mrp_open_orders_reconstruction",
                        "payload_json": json.dumps(row, ensure_ascii=False, sort_keys=True),
                    }
                )

    open_order_rows.sort(key=lambda row: (row["node_id"], row["item_id"], row["arrival_day"], row["src_node_id"]))
    return seeded_total_qty, open_order_rows, bridge_days_by_pair


def seed_open_orders_from_metadata(
    pipeline: dict[int, list[tuple[str, str, float, str]]],
    in_transit: dict[tuple[str, str], float],
    *,
    opening_open_orders_payload: dict[str, Any],
    lanes_by_dest_item: dict[tuple[str, str], list[dict[str, Any]]],
    item_unit_map: dict[str, str],
    pair_mrp_safety_time_days: dict[tuple[str, str], float],
    total_timeline_days: int,
    warmup_days: int,
    opening_production_bom_issues_by_day: dict[int, list[dict[str, Any]]] | None,
    opening_production_order_bom_issue_mode: str,
    mrp_order_rows: list[dict[str, Any]],
    supplier_shipment_rows: list[dict[str, Any]],
    initialization_pipeline_rows: list[dict[str, Any]],
    assumptions_ledger_rows: list[dict[str, Any]],
    apply_supplier_risks_to_opening_purchase_orders: bool = False,
    supplier_risk_events: list[dict[str, Any]] | None = None,
    opening_purchase_order_risk_audit_rows: list[dict[str, Any]] | None = None,
    opening_purchase_order_risk_warnings: list[str] | None = None,
    supplier_risk_applied_rows: list[dict[str, Any]] | None = None,
    dated_purchase_availability: bool = False,
) -> tuple[float, list[dict[str, Any]], dict[tuple[str, str], int]]:
    rows = opening_open_orders_payload.get("rows") if isinstance(opening_open_orders_payload, dict) else []
    if not isinstance(rows, list) or not rows:
        return 0.0, [], {}

    opening_production_order_bom_issue_mode = (
        opening_production_order_bom_issue_mode
        if opening_production_order_bom_issue_mode in {"receipt", "release", "wip"}
        else "receipt"
    )
    seeded_total_qty = 0.0
    open_order_rows: list[dict[str, Any]] = []
    bridge_days_by_pair: dict[tuple[str, str], int] = {}

    for metadata_index, raw in enumerate(rows, start=1):
        if not isinstance(raw, dict):
            continue
        dst = str(raw.get("dst_node_id") or "")
        item_id = str(raw.get("item_id") or "")
        src = str(raw.get("src_node_id") or "")
        if not dst or not item_id:
            continue
        pair = (dst, item_id)
        if dated_purchase_availability and raw.get("order_type") == "purchase_open_order":
            raw_g, raw_i = raw.get("physical_delivery_day"), raw.get("usable_day")
            if (type(raw_g) is not int or type(raw_i) is not int or raw_g < 0 or raw_i < raw_g):
                raise ValueError("Dated opening purchase requires explicit integer dates 0 <= G <= I")
            if isinstance(raw.get("quantity"), bool):
                raise ValueError("Boolean is not a source opening purchase quantity")
            try:
                require_physical_integer(raw.get("quantity"), raw.get("uom"))
            except (TypeError, ValueError) as exc:
                raise ValueError("Invalid source opening purchase quantity") from exc
        qty = max(0.0, to_float(raw.get("quantity"), 0.0))
        if qty <= 1e-9:
            continue
        raw_uom = normalize_unit(raw.get("uom"))
        item_uom = normalize_unit(item_unit_map.get(item_id, raw_uom))
        if raw_uom and item_uom and can_convert_units(raw_uom, item_uom):
            qty = convert_quantity(qty, raw_uom, item_uom)
        order_type = str(raw.get("order_type") or "opening_open_order")
        source_mode = (
            "opening_purchase_order"
            if order_type == "purchase_open_order"
            else "opening_production_order"
            if order_type == "production_open_order"
            else "opening_open_order"
        )

        usable_day = max(0, int(round(to_float(raw.get("usable_day"), 0.0))))
        physical_delivery_day = max(0, int(round(to_float(raw.get("physical_delivery_day"), usable_day))))
        receipt_release_days = max(0, int(round(to_float(raw.get("receipt_release_days"), 0.0))))
        arrival_day = warmup_days + usable_day
        if arrival_day >= total_timeline_days:
            receipt_status = "firm_receipt_outside_horizon"
            actual_receipt_day: int | str = ""
        else:
            receipt_status = "firm_receipt"
            actual_receipt_day = usable_day

        lane_list = lanes_by_dest_item.get(pair, [])
        selected_lane = None
        if src:
            for lane in lane_list:
                if str(lane.get("src")) == src:
                    selected_lane = lane
                    break
        if selected_lane is None and lane_list:
            selected_lane = lane_list[0]

        edge_id = str(selected_lane.get("edge_id", "")) if selected_lane else ""
        lead_reference_days = (
            max(0, int(round(to_float(selected_lane.get("lead_days"), 0.0))))
            if selected_lane
            else 0
        )
        if lead_reference_days > 0:
            release_day = physical_delivery_day - lead_reference_days
        else:
            release_day = physical_delivery_day
        planned_qty_before_risk = qty
        planned_physical_delivery_day = physical_delivery_day
        planned_usable_day = usable_day
        planned_receipt_release_days = receipt_release_days
        opening_purchase_order_overlay: dict[str, Any] | None = None
        opening_purchase_order_shipment = ""
        opening_purchase_order_event_ids = ""
        if (
            apply_supplier_risks_to_opening_purchase_orders
            and source_mode == "opening_purchase_order"
            and src
        ):
            risk_lane = dict(selected_lane or {})
            risk_lane.update(
                {
                    "src": src,
                    "dst": dst,
                    "item_id": item_id,
                    "edge_id": edge_id,
                }
            )
            opening_purchase_order_overlay = opening_purchase_order_risk_overlay(
                planned_qty=planned_qty_before_risk,
                planned_physical_delivery_day=planned_physical_delivery_day,
                planned_usable_day=planned_usable_day,
                release_day=release_day,
                lane=risk_lane,
                supplier_risk_events=list(supplier_risk_events or []),
            )
            qty = max(
                0.0,
                to_float(opening_purchase_order_overlay.get("usable_qty"), 0.0),
            )
            physical_delivery_day = int(
                opening_purchase_order_overlay["physical_delivery_day"]
            )
            usable_day = int(opening_purchase_order_overlay["usable_day"])
            receipt_release_days = int(
                opening_purchase_order_overlay["receipt_release_days"]
            )
            arrival_day = warmup_days + usable_day
            if arrival_day >= total_timeline_days:
                receipt_status = "firm_receipt_outside_horizon"
                actual_receipt_day = ""
            else:
                receipt_status = "firm_receipt"
                actual_receipt_day = usable_day
            opening_purchase_order_shipment = opening_purchase_order_shipment_id(
                raw.get("source_row"),
                metadata_index,
            )
            opening_purchase_order_event_ids = ",".join(
                opening_purchase_order_overlay.get("event_ids") or []
            )
            effects = dict(opening_purchase_order_overlay.get("effects") or {})
            unsupported_types = list(
                opening_purchase_order_overlay.get("unsupported_risk_types") or []
            )
            if unsupported_types and opening_purchase_order_risk_warnings is not None:
                warning = (
                    "opening purchase-order replay does not operationalize "
                    + ",".join(unsupported_types)
                    + "; a dated supplier capacity/stock/cost model is required"
                )
                if warning not in opening_purchase_order_risk_warnings:
                    opening_purchase_order_risk_warnings.append(warning)
            if opening_purchase_order_risk_audit_rows is not None:
                opening_purchase_order_risk_audit_rows.append(
                    {
                        "source_row": raw.get("source_row", ""),
                        "source_file": str(
                            opening_open_orders_payload.get("source_file") or ""
                        ),
                        "shipment_id": opening_purchase_order_shipment,
                        "risk_decision_day": int(planned_physical_delivery_day),
                        "supplier_id": src,
                        "dst_node_id": dst,
                        "item_id": item_id,
                        "edge_id": edge_id,
                        "risk_event_ids": opening_purchase_order_event_ids,
                        "risk_types": ",".join(
                            opening_purchase_order_overlay.get("risk_types") or []
                        ),
                        "unsupported_risk_types": ",".join(unsupported_types),
                        "planned_qty_before": round(planned_qty_before_risk, 6),
                        "pulled_qty_after": round(
                            to_float(opening_purchase_order_overlay.get("pulled_qty"), 0.0),
                            6,
                        ),
                        "physical_shipped_qty_after": round(
                            to_float(
                                opening_purchase_order_overlay.get("physical_shipped_qty"),
                                0.0,
                            ),
                            6,
                        ),
                        "usable_qty_after": round(qty, 6),
                        "quantity_loss_before_physical_qty": round(
                            planned_qty_before_risk
                            - to_float(
                                opening_purchase_order_overlay.get("physical_shipped_qty"),
                                0.0,
                            ),
                            6,
                        ),
                        "quantity_loss_at_quality_release_qty": round(
                            to_float(
                                opening_purchase_order_overlay.get("physical_shipped_qty"),
                                0.0,
                            )
                            - qty,
                            6,
                        ),
                        "physical_delivery_day_before": int(
                            planned_physical_delivery_day
                        ),
                        "physical_delivery_day_after": int(physical_delivery_day),
                        "usable_day_before": int(planned_usable_day),
                        "usable_day_after": int(usable_day),
                        "release_day": int(release_day),
                        "transport_delay_days": int(
                            opening_purchase_order_overlay.get("transport_delay_days", 0)
                        ),
                        "quality_release_delay_days": int(
                            opening_purchase_order_overlay.get(
                                "quality_release_delay_days",
                                0,
                            )
                        ),
                        "availability_multiplier": round(
                            min(1.0, to_float(effects.get("availability"), 1.0)),
                            6,
                        ),
                        "reliability_multiplier": round(
                            min(1.0, to_float(effects.get("reliability"), 1.0)),
                            6,
                        ),
                        "quality_yield_multiplier": round(
                            min(1.0, to_float(effects.get("quality_yield"), 1.0)),
                            6,
                        ),
                        "lead_time_multiplier": round(
                            to_float(effects.get("lead_time"), 1.0),
                            6,
                        ),
                        "lead_time_extra_days": round(
                            to_float(effects.get("lead_time_extra_days"), 0.0),
                            6,
                        ),
                        "quality_delay_days": round(
                            to_float(effects.get("quality_delay"), 0.0),
                            6,
                        ),
                        "capacity_multiplier": round(
                            to_float(effects.get("capacity"), 1.0),
                            6,
                        ),
                        "purchase_cost_multiplier": round(
                            to_float(effects.get("purchase_cost"), 1.0),
                            6,
                        ),
                        "transport_cost_multiplier": round(
                            to_float(effects.get("transport_cost"), 1.0),
                            6,
                        ),
                        "interpretation": (
                            "observed_planned_order_with_simulated_risk_overlay;"
                            "not_observed_actual_supplier_otif"
                        ),
                    }
                )
            if supplier_risk_applied_rows is not None and opening_purchase_order_event_ids:
                supplier_risk_applied_rows.append(
                    supplier_risk_applied_row(
                        day=int(planned_physical_delivery_day),
                        supplier_id=src,
                        dst_node_id=dst,
                        item_id=item_id,
                        edge_id=edge_id,
                        effects=effects,
                    )
                )
        lead_days = max(0, usable_day - release_day)
        lead_cover_days = max(lead_days, lead_reference_days + receipt_release_days)
        safety_time_days = max(0.0, pair_mrp_safety_time_days.get(pair, 0.0))
        standard_order_qty = max(0.0, to_float(selected_lane.get("standard_order_qty"), 0.0)) if selected_lane else 0.0
        mrp_share = max(0.0, to_float(selected_lane.get("mrp_share"), 0.0)) if selected_lane else 0.0
        source_marker = ""
        if source_mode == "opening_production_order":
            source_marker = (
                f"{OPENING_PRODUCTION_ORDER_LANE_PREFIX}"
                f"source_row={raw.get('source_row', '')};"
                f"release_day={int(release_day)};"
                f"usable_day={int(usable_day)}"
            )
        elif (
            source_mode == "opening_purchase_order"
            and apply_supplier_risks_to_opening_purchase_orders
        ):
            source_marker = make_opening_purchase_order_lot_marker(
                source_row=raw.get("source_row", ""),
                source_file=str(opening_open_orders_payload.get("source_file") or ""),
                supplier_id=src,
                edge_id=edge_id,
                shipment_id=opening_purchase_order_shipment,
                risk_decision_day=int(planned_physical_delivery_day),
                risk_event_ids=opening_purchase_order_event_ids,
            )
        if dated_purchase_availability and source_mode == "opening_purchase_order":
            source_marker = OpeningPurchaseAvailability.marker_for(
                str(opening_open_orders_payload.get("source_file") or ""), raw.get("source_row", ""),
            )
        if actual_receipt_day != "" or (dated_purchase_availability and source_mode == "opening_purchase_order"):
            pipeline[arrival_day].append((dst, item_id, qty, source_marker))
            in_transit[pair] += qty
            seeded_total_qty += qty
        if (
            source_mode == "opening_production_order"
            and opening_production_order_bom_issue_mode == "release"
            and opening_production_bom_issues_by_day is not None
        ):
            issue_day = warmup_days + max(0, int(release_day))
            if issue_day < total_timeline_days:
                opening_production_bom_issues_by_day[issue_day].append(
                    {
                        "node_id": dst,
                        "item_id": item_id,
                        "qty": qty,
                        "source_id": source_marker,
                        "release_day": int(release_day),
                        "usable_day": int(usable_day),
                        "source_row": raw.get("source_row", ""),
                    }
                )
        row = {
            "day": 0,
            "node_id": dst,
            "item_id": item_id,
            "order_type": source_mode,
            "src_node_id": src if src else dst,
            "dst_node_id": dst,
            "edge_id": edge_id,
            "planning_status": "opening_firm_order",
            "release_status": "released_before_or_at_j0" if release_day <= 0 else "released",
            "receipt_status": receipt_status,
            "order_status_end_of_run": "received" if actual_receipt_day != "" else "released_in_transit",
            "release_qty": round(
                planned_qty_before_risk
                if opening_purchase_order_overlay is not None
                else qty,
                6,
            ),
            "planned_receipt_qty": round(qty, 6),
            "release_day": int(release_day),
            "order_date_imt": int(release_day),
            "arrival_day": int(usable_day),
            "actual_receipt_day": actual_receipt_day,
            "implied_cover_need_day": int(usable_day + math.ceil(safety_time_days)),
            "lead_days": int(lead_days),
            "lead_reference_days": int(lead_reference_days),
            "lead_cover_days": int(lead_cover_days),
            "safety_time_days": round(safety_time_days, 6),
            "reliability": 1.0,
            "standard_order_qty": round(standard_order_qty, 6),
            "mrp_share": round(mrp_share, 6),
        }
        if opening_purchase_order_overlay is not None:
            row.update(
                {
                    "source_row": raw.get("source_row", ""),
                    "source_file": str(
                        opening_open_orders_payload.get("source_file") or ""
                    ),
                    "shipment_id": opening_purchase_order_shipment,
                    "risk_decision_day": int(planned_physical_delivery_day),
                    "risk_event_ids": opening_purchase_order_event_ids,
                    "planned_physical_delivery_day_before_risk": int(
                        planned_physical_delivery_day
                    ),
                    "planned_usable_day_before_risk": int(planned_usable_day),
                    "planned_receipt_qty_before_risk": round(
                        planned_qty_before_risk,
                        6,
                    ),
                }
            )
        if dated_purchase_availability and source_mode == "opening_purchase_order":
            row.update({
                "physical_delivery_day": physical_delivery_day, "available_day": usable_day,
                "actual_physical_receipt_day": physical_delivery_day if physical_delivery_day < total_timeline_days else "",
                "actual_available_day": actual_receipt_day,
                "source_row": raw.get("source_row", ""),
                "source_file": str(opening_open_orders_payload.get("source_file") or ""),
                "mrp_order_id": source_marker, "baseline_reference_id": source_marker,
                "order_status_end_of_run": (
                    "available" if actual_receipt_day != "" else
                    "held_pending_availability" if physical_delivery_day < total_timeline_days else "awaiting_physical_delivery"
                ),
            })
        mrp_order_rows.append(row)

        if source_mode == "opening_purchase_order" and src:
            opening_shipment_row = {
                "day": int(release_day),
                "src_node_id": src,
                "dst_node_id": dst,
                "item_id": item_id,
                "shipped_qty": round(qty, 6),
                "pulled_qty": round(
                    planned_qty_before_risk
                    if opening_purchase_order_overlay is not None
                    else qty,
                    6,
                ),
                "lead_days": int(physical_delivery_day - release_day) if dated_purchase_availability else int(lead_days),
                "arrival_day": int(physical_delivery_day) if dated_purchase_availability else int(usable_day),
                "reliability": 1.0,
                "uom": item_unit_map.get(item_id, raw_uom),
                "transport_cost_basis": "opening_order_book",
                "source_inventory_reserved": 0,
                "transport_cost_units": 0.0,
                "transport_cost": 0.0,
            }
            if opening_purchase_order_overlay is not None:
                opening_shipment_row.update(
                    {
                        "shipment_id": opening_purchase_order_shipment,
                        "risk_decision_day": int(planned_physical_delivery_day),
                        "risk_event_ids": opening_purchase_order_event_ids,
                        "edge_id": edge_id,
                    }
                )
            supplier_shipment_rows.append(opening_shipment_row)

        init_row = {
            "node_id": dst,
            "item_id": item_id,
            "category": "opening_open_order_book_real",
            "seeded_pipeline_qty": round(qty, 6) if actual_receipt_day != "" or (dated_purchase_availability and source_mode == "opening_purchase_order") else 0.0,
            "lead_days": int(lead_days),
            "lane_src": src,
            "source_file": str(opening_open_orders_payload.get("source_file") or ""),
            "planning_element": str(raw.get("planning_element") or ""),
            "physical_delivery_day": int(physical_delivery_day),
            "usable_day": int(usable_day),
            "receipt_release_days": int(receipt_release_days),
        }
        if opening_purchase_order_overlay is not None:
            init_row.update(
                {
                    "source_row": raw.get("source_row", ""),
                    "supplier_id": src,
                    "shipment_id": opening_purchase_order_shipment,
                    "risk_decision_day": int(planned_physical_delivery_day),
                    "risk_event_ids": opening_purchase_order_event_ids,
                    "planned_qty_before_risk": round(planned_qty_before_risk, 6),
                    "physical_delivery_day_before_risk": int(
                        planned_physical_delivery_day
                    ),
                    "usable_day_before_risk": int(planned_usable_day),
                    "receipt_release_days_before_risk": int(
                        planned_receipt_release_days
                    ),
                }
            )
        initialization_pipeline_rows.append(init_row)
        open_order_row = {
                "node_id": dst,
                "item_id": item_id,
                "src_node_id": src,
                "edge_id": edge_id,
                "arrival_day": int(usable_day),
                "physical_delivery_day": int(physical_delivery_day),
                "receipt_qty": round(qty, 6),
                "lead_reference_days": int(lead_reference_days),
                "receipt_release_days": int(receipt_release_days),
                "source_row": raw.get("source_row", ""),
                "source_file": str(opening_open_orders_payload.get("source_file") or ""),
                "order_type": source_mode,
            }
        if opening_purchase_order_overlay is not None:
            open_order_row.update(
                {
                    "shipment_id": opening_purchase_order_shipment,
                    "risk_decision_day": int(planned_physical_delivery_day),
                    "risk_event_ids": opening_purchase_order_event_ids,
                    "planned_receipt_qty_before_risk": round(
                        planned_qty_before_risk,
                        6,
                    ),
                    "physical_delivery_day_before_risk": int(
                        planned_physical_delivery_day
                    ),
                    "usable_day_before_risk": int(planned_usable_day),
                }
            )
        open_order_rows.append(open_order_row)
        assumptions_ledger_rows.append(
            {
                "category": "opening_open_order_book_real",
                "node_id": dst,
                "item_id": item_id,
                "edge_id": edge_id,
                "source": str(opening_open_orders_payload.get("source_file") or "opening_open_orders_metadata"),
                "payload_json": json.dumps(init_row, ensure_ascii=False, sort_keys=True),
            }
        )

        bridge_days = max(1, min(usable_day, max(lead_cover_days, lead_reference_days)))
        bridge_days_by_pair[pair] = max(bridge_days_by_pair.get(pair, 0), bridge_days)

    open_order_rows.sort(key=lambda row: (row["node_id"], row["item_id"], row["arrival_day"], row["src_node_id"]))
    return seeded_total_qty, open_order_rows, bridge_days_by_pair


def derive_supplier_daily_capacity_by_pair(
    *,
    nodes: list[dict[str, Any]],
    supplier_node_ids: set[str],
    lanes_by_src_item: dict[tuple[str, str], list[dict[str, Any]]],
    required_daily_input_by_pair: dict[tuple[str, str], float],
    propagated_demand_today: dict[tuple[str, str], float],
    item_unit_map: dict[str, str],
    stock: dict[tuple[str, str], float],
    default_review_period_days: int,
    stochastic_lead_times: bool,
    lead_time_distribution_mode: str,
    dynamic_requirement_pair_keys: set[str] | None = None,
) -> tuple[dict[tuple[str, str], float], list[dict[str, Any]]]:
    node_by_id = {str(n.get("id")): n for n in nodes}
    capacity_by_pair: dict[tuple[str, str], float] = {}
    metadata_rows: list[dict[str, Any]] = []

    for src_pair, lane_list in sorted(lanes_by_src_item.items()):
        src, item_id = src_pair
        if src not in supplier_node_ids:
            continue

        node = node_by_id.get(src, {})
        review_days = node_review_period_days(node, default_review_period_days)
        sim_constraints = node.get("simulation_constraints") or {}
        node_capacity_scale = max(0.01, to_float(sim_constraints.get("supplier_capacity_scale"), 1.0))
        item_capacity_scale_map = sim_constraints.get("supplier_item_capacity_scale") or {}
        item_capacity_scale = max(
            0.01,
            to_float(item_capacity_scale_map.get(item_id), 1.0),
        )
        explicit_capacity_map = sim_constraints.get("supplier_item_capacity_qty_per_day") or {}
        explicit_capacity = max(0.0, to_float(explicit_capacity_map.get(item_id), 0.0))
        initial_stock = max(0.0, stock.get(src_pair, 0.0))
        inventory_fallback = initial_stock / max(1.0, float(review_days))
        process_capacity = process_output_capacity_by_item(node, item_unit_map).get(item_id, 0.0)

        downstream_requirement = 0.0
        downstream_signal = 0.0
        standard_hints: list[float] = []
        standard_lot_floor = 0.0
        for lane in lane_list:
            dst_pair = (str(lane["dst"]), item_id)
            downstream_requirement += max(0.0, required_daily_input_by_pair.get(dst_pair, 0.0))
            downstream_signal += max(0.0, propagated_demand_today.get(dst_pair, 0.0))
            standard_qty = max(0.0, to_float(lane.get("standard_order_qty"), 0.0))
            if standard_qty > 0:
                standard_lot_floor = max(standard_lot_floor, standard_qty)
                hint_days = max(
                    1.0,
                    float(review_days),
                    float(lane.get("order_frequency_days", 1)),
                    float(lead_time_cover_days(lane, stochastic_lead_times, lead_time_distribution_mode)),
                )
                standard_hints.append(standard_qty / hint_days)

        dynamic_requirement_pair_keys = dynamic_requirement_pair_keys or set()
        has_dynamic_destination = any(
            policy_pair_key(str(lane.get("dst")), item_id)
            in dynamic_requirement_pair_keys
            for lane in lane_list
        )
        demand_anchor = (
            downstream_signal
            if has_dynamic_destination
            else max(downstream_requirement, downstream_signal)
        )
        if explicit_capacity > 0:
            nominal_capacity = explicit_capacity
            basis = "explicit_capacity"
        elif process_capacity > 0:
            nominal_capacity = process_capacity
            basis = "process_capacity"
        elif demand_anchor > 0:
            nominal_capacity = max(demand_anchor * 1.25, inventory_fallback, 1.0)
            basis = (
                "propagated_dynamic_demand"
                if has_dynamic_destination
                else "downstream_requirement"
            )
        else:
            nominal_capacity = max(inventory_fallback, 1.0)
            basis = "inventory_fallback"

        if standard_hints and nominal_capacity > 0:
            plausible_hints = [
                hint
                for hint in standard_hints
                if nominal_capacity * 0.25 <= hint <= nominal_capacity * 4.0
            ]
            if plausible_hints:
                nominal_capacity = max(nominal_capacity, sum(plausible_hints) / len(plausible_hints))
                basis += "+fia_hint"

        scaled_capacity = max(
            0.01,
            nominal_capacity * node_capacity_scale * item_capacity_scale,
        )
        if explicit_capacity <= 0.0 and standard_lot_floor > 0.0 and scaled_capacity < standard_lot_floor:
            # Inferred supplier capacity is a planning heuristic; it must not
            # make a standard order lot physically impossible to ship.
            scaled_capacity = standard_lot_floor
            basis += "+standard_lot_floor"
        capacity_by_pair[src_pair] = scaled_capacity
        metadata_rows.append(
            {
                "node_id": src,
                "item_id": item_id,
                "review_period_days": review_days,
                "initial_stock_qty": round(initial_stock, 6),
                "inventory_fallback_qty_per_day": round(inventory_fallback, 6),
                "downstream_requirement_qty_per_day": round(downstream_requirement, 6),
                "downstream_signal_qty_per_day": round(downstream_signal, 6),
                "explicit_capacity_qty_per_day": round(explicit_capacity, 6),
                "process_capacity_qty_per_day": round(process_capacity, 6),
                "nominal_capacity_qty_per_day": round(nominal_capacity, 6),
                "applied_capacity_scale": round(node_capacity_scale, 6),
                "applied_item_capacity_scale": round(item_capacity_scale, 6),
                "effective_capacity_qty_per_day": round(scaled_capacity, 6),
                "basis": basis,
            }
        )

    return capacity_by_pair, metadata_rows


def allocate_shared_downstream_pull(
    *,
    src_pair: tuple[str, str],
    lanes_by_src_item: dict[tuple[str, str], list[dict[str, Any]]],
    externally_sourced_pairs: list[tuple[str, str]],
    supplier_daily_capacity_by_pair: dict[tuple[str, str], float],
    downstream_values_by_pair: dict[tuple[str, str], float],
) -> float:
    """Allocate downstream pull across alternative upstream sources for the same dst/item."""
    allocated = 0.0
    for lane in lanes_by_src_item.get(src_pair, []):
        dst_pair = (str(lane.get("dst")), src_pair[1])
        downstream_value = max(0.0, downstream_values_by_pair.get(dst_pair, 0.0))
        if downstream_value <= 0.0:
            continue
        candidate_pairs: list[tuple[str, str]] = []
        for candidate_src_pair in externally_sourced_pairs:
            if candidate_src_pair[1] != src_pair[1]:
                continue
            for candidate_lane in lanes_by_src_item.get(candidate_src_pair, []):
                if str(candidate_lane.get("dst")) == dst_pair[0]:
                    candidate_pairs.append(candidate_src_pair)
                    break
        if not candidate_pairs:
            allocated += downstream_value
            continue
        total_capacity = sum(max(0.0, supplier_daily_capacity_by_pair.get(pair, 0.0)) for pair in candidate_pairs)
        if total_capacity > 1e-9:
            share = max(0.0, supplier_daily_capacity_by_pair.get(src_pair, 0.0)) / total_capacity
        else:
            share = 1.0 / float(len(candidate_pairs))
        allocated += downstream_value * share
    return allocated


def derive_unmodeled_supplier_source_policies(
    *,
    externally_sourced_pairs: list[tuple[str, str]],
    nodes: list[dict[str, Any]],
    lanes_by_src_item: dict[tuple[str, str], list[dict[str, Any]]],
    supplier_daily_capacity_by_pair: dict[tuple[str, str], float],
    base_stock: dict[tuple[str, str], float],
    required_daily_input_by_pair: dict[tuple[str, str], float],
    propagated_demand_today: dict[tuple[str, str], float],
    item_unit_map: dict[str, str],
    default_review_period_days: int,
    safety_stock_days: float,
    stochastic_lead_times: bool,
    lead_time_distribution_mode: str,
    dynamic_requirement_pair_keys: set[str] | None = None,
) -> tuple[dict[tuple[str, str], dict[str, Any]], list[dict[str, Any]]]:
    node_by_id = {str(n.get("id")): n for n in nodes}
    policies: dict[tuple[str, str], dict[str, Any]] = {}
    metadata_rows: list[dict[str, Any]] = []

    for src_pair in externally_sourced_pairs:
        lane_list = lanes_by_src_item.get(src_pair, [])
        if not lane_list or src_pair not in supplier_daily_capacity_by_pair:
            continue
        src, item_id = src_pair
        node = node_by_id.get(src, {})
        review_days = node_review_period_days(node, default_review_period_days)
        lead_cover_days = max(
            [lead_time_cover_days(lane, stochastic_lead_times, lead_time_distribution_mode) for lane in lane_list]
            or [1]
        )
        planned_material_lead_days = max([lead_time_reference_days(lane) for lane in lane_list] or [1])
        order_frequency_days = max(
            [int(round(max(1.0, to_float(lane.get("order_frequency_days"), 1.0)))) for lane in lane_list] or [1]
        )
        raw_replenishment_lead_days = max(
            float(review_days),
            float(order_frequency_days),
            0.5 * float(lead_cover_days),
        )
        replenishment_lead_days = int(min(21.0, max(2.0, math.ceil(raw_replenishment_lead_days))))
        target_cover_days = max(
            int(math.ceil(safety_stock_days)),
            replenishment_lead_days + review_days,
            order_frequency_days,
        )
        external_procurement_target_cover_days = max(
            int(math.ceil(safety_stock_days)),
            int(math.ceil(planned_material_lead_days)) + review_days,
            order_frequency_days,
        )
        downstream_requirement = allocate_shared_downstream_pull(
            src_pair=src_pair,
            lanes_by_src_item=lanes_by_src_item,
            externally_sourced_pairs=externally_sourced_pairs,
            supplier_daily_capacity_by_pair=supplier_daily_capacity_by_pair,
            downstream_values_by_pair=required_daily_input_by_pair,
        )
        downstream_signal = allocate_shared_downstream_pull(
            src_pair=src_pair,
            lanes_by_src_item=lanes_by_src_item,
            externally_sourced_pairs=externally_sourced_pairs,
            supplier_daily_capacity_by_pair=supplier_daily_capacity_by_pair,
            downstream_values_by_pair=propagated_demand_today,
        )
        dynamic_requirement_pair_keys = dynamic_requirement_pair_keys or set()
        has_dynamic_destination = any(
            policy_pair_key(str(lane.get("dst")), item_id)
            in dynamic_requirement_pair_keys
            for lane in lane_list
        )
        demand_anchor = (
            downstream_signal
            if has_dynamic_destination
            else max(downstream_requirement, downstream_signal)
        )
        downstream_lot_floor = max(
            [max(0.0, to_float(lane.get("standard_order_qty"), 0.0)) for lane in lane_list] or [0.0]
        )
        supplier_name = str(node.get("name") or src)
        lane_uom = next(
            (str(lane.get("standard_order_uom") or "") for lane in lane_list if str(lane.get("standard_order_uom") or "")),
            "",
        )
        item_uom = item_unit_map.get(item_id, lane_uom)
        upstream_capacity_target_utilization, upstream_capacity_profile = supplier_industrial_capacity_target(
            supplier_name=supplier_name,
            uom=item_uom,
            planned_lead_time_days=planned_material_lead_days,
        )
        lot_daily_denominator_days = max(
            1.0,
            float(review_days),
            float(order_frequency_days),
            float(lead_cover_days),
        )
        lot_daily_need = (
            downstream_lot_floor / lot_daily_denominator_days
            if downstream_lot_floor > 0.0
            else 0.0
        )
        external_procurement_daily_need_qty = max(demand_anchor, lot_daily_need)
        external_procurement_nominal_capacity_qty = (
            external_procurement_daily_need_qty / upstream_capacity_target_utilization
            if external_procurement_daily_need_qty > 1e-9 and upstream_capacity_target_utilization > 1e-9
            else 0.0
        )
        external_procurement_pipeline_target_qty = (
            external_procurement_daily_need_qty * max(1.0, float(planned_material_lead_days))
        )
        external_procurement_capacity_basis = "max_downstream_pull_or_lot_over_logistic_cover_div_target_utilization"
        target_stock_qty = max(
            base_stock.get(src_pair, 0.0),
            downstream_lot_floor,
            demand_anchor * float(target_cover_days),
        )
        reorder_point_qty = max(
            base_stock.get(src_pair, 0.0),
            downstream_lot_floor,
            demand_anchor * float(replenishment_lead_days),
        )
        daily_capacity = max(0.0, supplier_daily_capacity_by_pair.get(src_pair, 0.0))
        policies[src_pair] = {
            "replenishment_lead_days": replenishment_lead_days,
            "raw_replenishment_lead_days": raw_replenishment_lead_days,
            "planned_material_lead_days": planned_material_lead_days,
            "source_material_lead_cover_days": lead_cover_days,
            "external_procurement_lead_days": planned_material_lead_days,
            "external_procurement_lead_basis": "source_material_lead_reference_days",
            "external_procurement_target_cover_days": external_procurement_target_cover_days,
            "target_cover_days": target_cover_days,
            "review_period_days": review_days,
            "order_frequency_days": order_frequency_days,
            "downstream_requirement_qty_per_day": downstream_requirement,
            "downstream_signal_qty_per_day": downstream_signal,
            "downstream_lot_floor_qty": downstream_lot_floor,
            "external_procurement_daily_need_qty": external_procurement_daily_need_qty,
            "external_procurement_nominal_capacity_qty_per_day": external_procurement_nominal_capacity_qty,
            "external_procurement_target_utilization": upstream_capacity_target_utilization,
            "external_procurement_capacity_profile": upstream_capacity_profile,
            "external_procurement_capacity_basis": external_procurement_capacity_basis,
            "external_procurement_pipeline_target_qty": external_procurement_pipeline_target_qty,
            "external_procurement_initial_pipeline_seed_qty": 0.0,
            "target_stock_qty_day0": target_stock_qty,
            "reorder_point_qty_day0": reorder_point_qty,
            "daily_capacity_qty": daily_capacity,
        }
        metadata_rows.append(
            {
                "node_id": src,
                "item_id": item_id,
                "replenishment_lead_days": replenishment_lead_days,
                "raw_replenishment_lead_days": round(raw_replenishment_lead_days, 6),
                "planned_material_lead_days": planned_material_lead_days,
                "source_material_lead_cover_days": lead_cover_days,
                "external_procurement_lead_days": planned_material_lead_days,
                "external_procurement_lead_basis": "source_material_lead_reference_days",
                "external_procurement_target_cover_days": external_procurement_target_cover_days,
                "target_cover_days": target_cover_days,
                "review_period_days": review_days,
                "order_frequency_days": order_frequency_days,
                "downstream_requirement_qty_per_day": round(downstream_requirement, 6),
                "downstream_signal_qty_per_day": round(downstream_signal, 6),
                "downstream_lot_floor_qty": round(downstream_lot_floor, 6),
                "external_procurement_daily_need_qty": round(external_procurement_daily_need_qty, 6),
                "external_procurement_nominal_capacity_qty_per_day": round(
                    external_procurement_nominal_capacity_qty,
                    6,
                ),
                "external_procurement_target_utilization": round(upstream_capacity_target_utilization, 6),
                "external_procurement_capacity_profile": upstream_capacity_profile,
                "external_procurement_capacity_basis": external_procurement_capacity_basis,
                "external_procurement_pipeline_target_qty": round(external_procurement_pipeline_target_qty, 6),
                "external_procurement_initial_pipeline_seed_qty": 0.0,
                "reorder_point_qty_day0": round(reorder_point_qty, 6),
                "target_stock_qty_day0": round(target_stock_qty, 6),
                "daily_capacity_qty": round(daily_capacity, 6),
            }
        )
    return policies, metadata_rows


def supplier_industrial_capacity_target(
    *,
    supplier_name: str,
    uom: str,
    planned_lead_time_days: float,
) -> tuple[float, str]:
    name = supplier_name.lower()
    if "packaging" in name:
        return 0.75, "packaging_qualified_pharma"
    if planned_lead_time_days >= 90.0:
        return 0.65, "raw_material_high_lead_qualified"
    if normalize_unit(uom) in {"KG", "G"}:
        return 0.70, "raw_material_qualified_pharma"
    return 0.70, "supplier_material_default_pharma"


def factory_industrial_capacity_target(
    *,
    node_name: str,
    node_type: str,
) -> tuple[float, str]:
    name = node_name.lower()
    if "semi-finished" in name or "intermediate" in name:
        return FACTORY_NOMINAL_TARGET_UTILIZATION, "internal_semifinished_pharma"
    if node_type == "factory":
        return FACTORY_NOMINAL_TARGET_UTILIZATION, "gmp_multi_product_factory"
    return FACTORY_NOMINAL_TARGET_UTILIZATION, "process_node_pharma_default"


def build_supplier_nominal_parameter_rows(
    *,
    nodes: list[dict[str, Any]],
    supplier_node_ids: set[str],
    lanes: list[dict[str, Any]],
    supplier_capacity_metadata_rows: list[dict[str, Any]],
    estimated_source_policies: dict[tuple[str, str], dict[str, Any]],
    item_unit_map: dict[str, str],
    opening_stock_source_snapshot: dict[tuple[str, str], float],
    stock: dict[tuple[str, str], float],
    base_stock: dict[tuple[str, str], float],
    supplier_shipment_rows: list[dict[str, Any]],
    supplier_stock_rows: list[dict[str, Any]],
    supplier_capacity_daily_rows: list[dict[str, Any]],
    stochastic_lead_times: bool,
    lead_time_distribution_mode: str,
) -> list[dict[str, Any]]:
    node_name_by_id = {str(n.get("id") or ""): str(n.get("name") or n.get("id") or "") for n in nodes}
    capacity_meta_by_pair = {
        (str(row.get("node_id") or ""), str(row.get("item_id") or "")): row
        for row in supplier_capacity_metadata_rows
    }

    shipment_stats: dict[tuple[str, str, str], dict[str, Any]] = defaultdict(
        lambda: {
            "total_shipped_qty": 0.0,
            "total_pulled_qty": 0.0,
            "shipment_rows": 0,
            "first_shipment_day": None,
            "last_shipment_day": None,
        }
    )
    for row in supplier_shipment_rows:
        key = (
            str(row.get("src_node_id") or ""),
            str(row.get("dst_node_id") or ""),
            str(row.get("item_id") or ""),
        )
        stats = shipment_stats[key]
        shipped_qty = max(0.0, to_float(row.get("shipped_qty"), 0.0))
        pulled_qty = max(0.0, to_float(row.get("pulled_qty"), shipped_qty))
        day = int(round(to_float(row.get("day"), 0.0)))
        stats["total_shipped_qty"] += shipped_qty
        stats["total_pulled_qty"] += pulled_qty
        stats["shipment_rows"] += 1
        first_day = stats.get("first_shipment_day")
        last_day = stats.get("last_shipment_day")
        stats["first_shipment_day"] = day if first_day is None else min(int(first_day), day)
        stats["last_shipment_day"] = day if last_day is None else max(int(last_day), day)

    stock_stats: dict[tuple[str, str], dict[str, Any]] = defaultdict(
        lambda: {"sum": 0.0, "count": 0, "min": None, "final_day": None, "final": 0.0}
    )
    for row in supplier_stock_rows:
        key = (str(row.get("node_id") or ""), str(row.get("item_id") or ""))
        value = max(0.0, to_float(row.get("stock_end_of_day"), 0.0))
        day = int(round(to_float(row.get("day"), 0.0)))
        stats = stock_stats[key]
        stats["sum"] += value
        stats["count"] += 1
        stats["min"] = value if stats["min"] is None else min(to_float(stats["min"], value), value)
        if stats["final_day"] is None or day >= int(stats["final_day"]):
            stats["final_day"] = day
            stats["final"] = value

    capacity_stats: dict[tuple[str, str], dict[str, Any]] = defaultdict(
        lambda: {
            "sum_util": 0.0,
            "count": 0,
            "max_util": 0.0,
            "active_days": 0,
            "max_used_qty": 0.0,
        }
    )
    for row in supplier_capacity_daily_rows:
        key = (str(row.get("node_id") or ""), str(row.get("item_id") or ""))
        util = max(0.0, to_float(row.get("utilization"), 0.0))
        used_qty = max(0.0, to_float(row.get("used_qty"), 0.0))
        stats = capacity_stats[key]
        stats["sum_util"] += util
        stats["count"] += 1
        stats["max_util"] = max(to_float(stats["max_util"], 0.0), util)
        stats["max_used_qty"] = max(to_float(stats["max_used_qty"], 0.0), used_qty)
        if used_qty > 1e-9:
            stats["active_days"] += 1

    rows: list[dict[str, Any]] = []
    for lane in sorted(
        lanes,
        key=lambda l: (str(l.get("src")), str(l.get("item_id")), str(l.get("dst")), str(l.get("edge_id"))),
    ):
        supplier_id = str(lane.get("src") or "")
        if supplier_id not in supplier_node_ids:
            continue
        item_id = str(lane.get("item_id") or "")
        dst_node_id = str(lane.get("dst") or "")
        supplier_name = node_name_by_id.get(supplier_id, supplier_id)
        src_pair = (supplier_id, item_id)
        lane_key = (supplier_id, dst_node_id, item_id)
        cap_meta = capacity_meta_by_pair.get(src_pair, {})
        source_policy = estimated_source_policies.get(src_pair, {})
        ship = shipment_stats.get(lane_key, {})
        stock_stat = stock_stats.get(src_pair, {})
        cap_stat = capacity_stats.get(src_pair, {})
        stock_count = int(stock_stat.get("count") or 0)
        cap_count = int(cap_stat.get("count") or 0)
        simulated_opening_stock_qty = max(0.0, stock.get(src_pair, 0.0))
        min_stock_end_of_day = to_float(stock_stat.get("min"), 0.0) if stock_count else None
        neutral_stock_reducible_qty = (
            min(simulated_opening_stock_qty, max(0.0, min_stock_end_of_day or 0.0))
            if min_stock_end_of_day is not None
            else 0.0
        )
        neutral_opening_stock_floor_qty = max(
            0.0,
            simulated_opening_stock_qty - neutral_stock_reducible_qty,
        )
        neutral_opening_stock_scale = (
            neutral_opening_stock_floor_qty / simulated_opening_stock_qty
            if simulated_opening_stock_qty > 1e-9
            else 0.0
        )
        effective_capacity_qty_per_day = to_float(cap_meta.get("effective_capacity_qty_per_day"), 0.0)
        max_capacity_used_qty_per_day = to_float(cap_stat.get("max_used_qty"), 0.0)
        neutral_capacity_floor_qty_per_day = max(0.0, max_capacity_used_qty_per_day)
        planned_lead_time_days = to_float(lane.get("lead_days_mean"), lane.get("lead_days", 1.0))
        capacity_target_utilization, capacity_target_profile = supplier_industrial_capacity_target(
            supplier_name=supplier_name,
            uom=item_unit_map.get(item_id, ""),
            planned_lead_time_days=planned_lead_time_days,
        )
        industrial_nominal_capacity_qty_per_day = (
            neutral_capacity_floor_qty_per_day / capacity_target_utilization
            if neutral_capacity_floor_qty_per_day > 1e-9 and capacity_target_utilization > 1e-9
            else 0.0
        )
        industrial_peak_utilization_if_nominal = (
            neutral_capacity_floor_qty_per_day / industrial_nominal_capacity_qty_per_day
            if industrial_nominal_capacity_qty_per_day > 1e-9
            else 0.0
        )
        current_capacity_headroom_vs_industrial_nominal = (
            effective_capacity_qty_per_day / industrial_nominal_capacity_qty_per_day
            if industrial_nominal_capacity_qty_per_day > 1e-9
            else ""
        )
        tested_capacity_floor_qty_per_day = (
            max(
                neutral_capacity_floor_qty_per_day * SUPPLIER_FUNCTIONAL_CAPACITY_HEADROOM_FACTOR,
                industrial_nominal_capacity_qty_per_day,
            )
            if neutral_capacity_floor_qty_per_day > 1e-9
            else 0.0
        )
        current_capacity_headroom_factor = (
            effective_capacity_qty_per_day / neutral_capacity_floor_qty_per_day
            if neutral_capacity_floor_qty_per_day > 1e-9
            else ""
        )
        current_capacity_headroom_vs_tested_floor = (
            effective_capacity_qty_per_day / tested_capacity_floor_qty_per_day
            if tested_capacity_floor_qty_per_day > 1e-9
            else ""
        )
        capacity_floor_basis = (
            f"max_daily_pulled_qty_observed_x{SUPPLIER_FUNCTIONAL_CAPACITY_HEADROOM_FACTOR:g}_tested"
            if neutral_capacity_floor_qty_per_day > 1e-9
            else "no_observed_supplier_pull"
        )
        tested_capacity_floor_factor = (
            SUPPLIER_FUNCTIONAL_CAPACITY_HEADROOM_FACTOR
            if neutral_capacity_floor_qty_per_day > 1e-9
            else 0.0
        )
        if str(cap_meta.get("basis") or "") == "supplier_capacity_override_from_csv":
            tested_capacity_floor_qty_per_day = effective_capacity_qty_per_day
            tested_capacity_floor_factor = (
                effective_capacity_qty_per_day / neutral_capacity_floor_qty_per_day
                if neutral_capacity_floor_qty_per_day > 1e-9
                else 0.0
            )
            current_capacity_headroom_vs_tested_floor = (
                effective_capacity_qty_per_day / tested_capacity_floor_qty_per_day
                if tested_capacity_floor_qty_per_day > 1e-9
                else ""
            )
            capacity_floor_basis = "supplier_capacity_override_from_csv"
        rows.append(
            {
                "supplier_id": supplier_id,
                "supplier_name": supplier_name,
                "item_id": item_id,
                "dst_node_id": dst_node_id,
                "edge_id": str(lane.get("edge_id") or ""),
                "uom": item_unit_map.get(item_id, ""),
                "input_initial_stock_qty": round(max(0.0, opening_stock_source_snapshot.get(src_pair, 0.0)), 6),
                "simulated_opening_stock_qty": round(simulated_opening_stock_qty, 6),
                "base_stock_qty": round(max(0.0, base_stock.get(src_pair, 0.0)), 6),
                "min_stock_end_of_day": round(to_float(stock_stat.get("min"), 0.0), 6) if stock_count else "",
                "avg_stock_end_of_day": round(to_float(stock_stat.get("sum"), 0.0) / stock_count, 6) if stock_count else "",
                "final_stock_end_of_day": round(to_float(stock_stat.get("final"), 0.0), 6) if stock_count else "",
                "neutral_opening_stock_floor_qty": round(neutral_opening_stock_floor_qty, 6),
                "neutral_opening_stock_reducible_qty": round(neutral_stock_reducible_qty, 6),
                "neutral_opening_stock_scale": round(neutral_opening_stock_scale, 6),
                "nominal_capacity_qty_per_day": round(to_float(cap_meta.get("nominal_capacity_qty_per_day"), 0.0), 6),
                "effective_capacity_qty_per_day": round(effective_capacity_qty_per_day, 6),
                "capacity_basis": str(cap_meta.get("basis") or ""),
                "applied_capacity_scale": round(to_float(cap_meta.get("applied_capacity_scale"), 1.0), 6),
                "explicit_capacity_qty_per_day": round(to_float(cap_meta.get("explicit_capacity_qty_per_day"), 0.0), 6),
                "process_capacity_qty_per_day": round(to_float(cap_meta.get("process_capacity_qty_per_day"), 0.0), 6),
                "downstream_requirement_qty_per_day": round(to_float(cap_meta.get("downstream_requirement_qty_per_day"), 0.0), 6),
                "downstream_signal_qty_per_day": round(to_float(cap_meta.get("downstream_signal_qty_per_day"), 0.0), 6),
                "external_procurement_daily_need_qty": round(
                    to_float(source_policy.get("external_procurement_daily_need_qty"), 0.0),
                    6,
                ),
                "external_procurement_nominal_capacity_qty_per_day": round(
                    to_float(source_policy.get("external_procurement_nominal_capacity_qty_per_day"), 0.0),
                    6,
                ),
                "external_procurement_target_utilization": round(
                    to_float(source_policy.get("external_procurement_target_utilization"), 0.0),
                    6,
                ),
                "external_procurement_capacity_profile": str(
                    source_policy.get("external_procurement_capacity_profile") or ""
                ),
                "external_procurement_capacity_basis": str(
                    source_policy.get("external_procurement_capacity_basis") or ""
                ),
                "external_procurement_lead_days": round(
                    to_float(source_policy.get("external_procurement_lead_days"), 0.0),
                    6,
                ),
                "external_procurement_pipeline_target_qty": round(
                    to_float(source_policy.get("external_procurement_pipeline_target_qty"), 0.0),
                    6,
                ),
                "external_procurement_initial_pipeline_seed_qty": round(
                    to_float(source_policy.get("external_procurement_initial_pipeline_seed_qty"), 0.0),
                    6,
                ),
                "avg_capacity_utilization": round(to_float(cap_stat.get("sum_util"), 0.0) / cap_count, 6) if cap_count else "",
                "max_capacity_utilization": round(to_float(cap_stat.get("max_util"), 0.0), 6) if cap_count else "",
                "capacity_active_days": int(cap_stat.get("active_days") or 0),
                "max_capacity_used_qty_per_day": round(max_capacity_used_qty_per_day, 6),
                "neutral_capacity_floor_qty_per_day": round(neutral_capacity_floor_qty_per_day, 6),
                "industrial_capacity_target_utilization": round(capacity_target_utilization, 6),
                "industrial_capacity_profile": capacity_target_profile,
                "industrial_nominal_capacity_qty_per_day": round(industrial_nominal_capacity_qty_per_day, 6),
                "industrial_peak_utilization_if_nominal": round(industrial_peak_utilization_if_nominal, 6),
                "current_capacity_headroom_vs_industrial_nominal": (
                    round(current_capacity_headroom_vs_industrial_nominal, 6)
                    if isinstance(current_capacity_headroom_vs_industrial_nominal, float)
                    else ""
                ),
                "tested_capacity_floor_qty_per_day": round(tested_capacity_floor_qty_per_day, 6),
                "tested_capacity_floor_factor": (
                    round(tested_capacity_floor_factor, 6)
                    if neutral_capacity_floor_qty_per_day > 1e-9
                    else 0.0
                ),
                "neutral_capacity_scale_if_nominal": 1.0 if neutral_capacity_floor_qty_per_day > 1e-9 else 0.0,
                "current_capacity_headroom_factor": (
                    round(current_capacity_headroom_factor, 6)
                    if isinstance(current_capacity_headroom_factor, float)
                    else ""
                ),
                "current_capacity_headroom_vs_tested_floor": (
                    round(current_capacity_headroom_vs_tested_floor, 6)
                    if isinstance(current_capacity_headroom_vs_tested_floor, float)
                    else ""
                ),
                "capacity_floor_basis": capacity_floor_basis,
                "planned_lead_time_days": round(planned_lead_time_days, 6),
                "lead_time_type": str(lane.get("lead_time_type") or ""),
                "lead_time_stages": int(round(max(1.0, to_float(lane.get("lead_stages"), 1.0)))),
                "lead_time_source": str(lane.get("lead_time_source") or ""),
                "lead_time_is_default": bool(lane.get("lead_time_is_default")),
                "lead_reference_days": lead_time_reference_days(lane),
                "lead_cover_days": lead_time_cover_days(lane, stochastic_lead_times, lead_time_distribution_mode),
                "delay_step_limit": int(round(max(1.0, to_float(lane.get("delay_step_limit"), 999.0)))),
                "nominal_reliability_otif": round(to_float(lane.get("reliability"), 1.0), 6),
                "reliability_source": str(lane.get("reliability_source") or ""),
                "standard_order_qty": round(max(0.0, to_float(lane.get("standard_order_qty"), 0.0)), 6),
                "standard_order_uom": str(lane.get("standard_order_uom") or ""),
                "mrp_share": round(max(0.0, to_float(lane.get("mrp_share"), 0.0)), 6),
                "mrp_rank": int(round(max(0.0, to_float(lane.get("mrp_rank"), 0.0)))),
                "mrp_share_basis": str(lane.get("mrp_share_basis") or ""),
                "mrp_landed_unit_cost": round(max(0.0, to_float(lane.get("mrp_landed_unit_cost"), 0.0)), 6),
                "mrp_cost_penalty": round(max(0.0, to_float(lane.get("mrp_cost_penalty"), 0.0)), 6),
                "mrp_lead_penalty": round(max(0.0, to_float(lane.get("mrp_lead_penalty"), 0.0)), 6),
                "mrp_reliability_penalty": round(max(0.0, to_float(lane.get("mrp_reliability_penalty"), 0.0)), 6),
                "mrp_variability_penalty": round(max(0.0, to_float(lane.get("mrp_variability_penalty"), 0.0)), 6),
                "mrp_allocation_penalty": round(max(0.0, to_float(lane.get("mrp_allocation_penalty"), 0.0)), 6),
                "unit_purchase_cost": round(max(0.0, to_float(lane.get("unit_purchase_cost"), 0.0)), 6),
                "unit_transport_cost": round(max(0.0, to_float(lane.get("unit_transport_cost"), 0.0)), 6),
                "total_shipped_qty": round(to_float(ship.get("total_shipped_qty"), 0.0), 6),
                "total_pulled_qty": round(to_float(ship.get("total_pulled_qty"), 0.0), 6),
                "shipment_rows": int(ship.get("shipment_rows") or 0),
                "first_shipment_day": "" if ship.get("first_shipment_day") is None else int(ship["first_shipment_day"]),
                "last_shipment_day": "" if ship.get("last_shipment_day") is None else int(ship["last_shipment_day"]),
            }
        )
    return rows


def build_factory_nominal_capacity_rows(
    *,
    nodes: list[dict[str, Any]],
    production_constraint_rows: list[dict[str, Any]],
    item_unit_map: dict[str, str],
) -> list[dict[str, Any]]:
    node_by_id = {str(node.get("id") or ""): node for node in nodes}
    rows_by_pair: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in production_constraint_rows:
        node_id = str(row.get("node_id") or "")
        item_id = str(row.get("output_item_id") or "")
        if node_id and item_id:
            rows_by_pair[(node_id, item_id)].append(row)

    out: list[dict[str, Any]] = []
    for node in sorted(nodes, key=lambda n: str(n.get("id") or "")):
        node_id = str(node.get("id") or "")
        node_name = str(node.get("name") or node_id)
        node_type = str(node.get("type") or "")
        for proc in node.get("processes") or []:
            outputs = proc.get("outputs") or []
            if not outputs:
                continue
            output = outputs[0] or {}
            item_id = str(output.get("item_id") or "")
            if not item_id:
                continue
            pair_rows = rows_by_pair.get((node_id, item_id), [])
            if not pair_rows:
                continue
            current_capacity = max(0.0, to_float(((proc.get("capacity") or {}).get("max_rate")), 0.0))
            capacity_source = str(((proc.get("capacity") or {}).get("source")) or "")
            capacity_modes = sorted({str(row.get("capacity_limit_mode") or "n/a") for row in pair_rows})
            max_actual = max(max(0.0, to_float(row.get("actual_qty"), 0.0)) for row in pair_rows)
            max_planned = max(max(0.0, to_float(row.get("planned_qty_after_lot_rule"), 0.0)) for row in pair_rows)
            max_desired = max(max(0.0, to_float(row.get("desired_qty"), 0.0)) for row in pair_rows)
            total_actual = sum(max(0.0, to_float(row.get("actual_qty"), 0.0)) for row in pair_rows)
            active_days = sum(1 for row in pair_rows if max(0.0, to_float(row.get("actual_qty"), 0.0)) > 1e-9)
            capacity_binding_days = sum(1 for row in pair_rows if str(row.get("binding_cause") or "") == "capacity")
            input_shortage_days = sum(1 for row in pair_rows if str(row.get("binding_cause") or "") == "input_shortage")
            avg_actual_active = total_actual / active_days if active_days > 0 else 0.0
            target_utilization, target_profile = factory_industrial_capacity_target(
                node_name=node_name,
                node_type=node_type,
            )
            industrial_nominal_capacity = (
                max_actual / target_utilization
                if max_actual > 1e-9 and target_utilization > 1e-9
                else 0.0
            )
            industrial_peak_util = (
                max_actual / industrial_nominal_capacity
                if industrial_nominal_capacity > 1e-9
                else 0.0
            )
            current_headroom = (
                current_capacity / industrial_nominal_capacity
                if current_capacity > 1e-9 and industrial_nominal_capacity > 1e-9
                else ""
            )
            current_avg_util = (
                (total_actual / max(1, len(pair_rows))) / current_capacity
                if current_capacity > 1e-9
                else ""
            )
            current_max_util = max_actual / current_capacity if current_capacity > 1e-9 else ""
            first_row = pair_rows[0]
            out.append(
                {
                    "node_id": node_id,
                    "node_name": node_name,
                    "node_type": node_type,
                    "process_id": str(proc.get("id") or ""),
                    "output_item_id": item_id,
                    "uom": item_unit_map.get(item_id, normalize_unit(output.get("uom"))),
                    "current_capacity_qty_per_day": round(current_capacity, 6),
                    "current_capacity_limit_mode": "+".join(capacity_modes),
                    "capacity_source": capacity_source,
                    "industrial_capacity_target_utilization": round(target_utilization, 6),
                    "industrial_capacity_profile": target_profile,
                    "industrial_nominal_capacity_qty_per_day": round(industrial_nominal_capacity, 6),
                    "industrial_peak_utilization_if_nominal": round(industrial_peak_util, 6),
                    "current_capacity_headroom_vs_industrial_nominal": (
                        round(current_headroom, 6) if isinstance(current_headroom, float) else ""
                    ),
                    "max_actual_qty_per_day": round(max_actual, 6),
                    "max_planned_qty_after_lot_rule": round(max_planned, 6),
                    "max_desired_qty_per_day": round(max_desired, 6),
                    "total_actual_qty": round(total_actual, 6),
                    "avg_actual_qty_per_active_day": round(avg_actual_active, 6),
                    "active_days": active_days,
                    "constraint_rows": len(pair_rows),
                    "current_avg_utilization": (
                        round(current_avg_util, 6) if isinstance(current_avg_util, float) else ""
                    ),
                    "current_max_utilization": (
                        round(current_max_util, 6) if isinstance(current_max_util, float) else ""
                    ),
                    "capacity_binding_days": capacity_binding_days,
                    "input_shortage_days": input_shortage_days,
                    "lot_policy_mode": str(first_row.get("lot_policy_mode") or ""),
                    "lot_fixed_qty": round(to_float(first_row.get("lot_fixed_qty"), 0.0), 6),
                    "lot_min_qty": round(to_float(first_row.get("lot_min_qty"), 0.0), 6),
                    "lot_max_qty": round(to_float(first_row.get("lot_max_qty"), 0.0), 6),
                    "lot_multiple_qty": round(to_float(first_row.get("lot_multiple_qty"), 0.0), 6),
                    "max_lots_per_week": int(round(to_float(first_row.get("max_lots_per_week"), 0.0))),
                }
            )
    return out


def build_supplier_nominal_audit_report(
    *,
    rows: list[dict[str, Any]],
    supplier_risk_events: list[dict[str, Any]],
    supplier_risk_warnings: list[str],
) -> str:
    supplier_count = len({str(row.get("supplier_id") or "") for row in rows if row.get("supplier_id")})
    item_count = len({str(row.get("item_id") or "") for row in rows if row.get("item_id")})
    default_reliability = [row for row in rows if str(row.get("reliability_source") or "") == "default_1.0"]
    inferred_capacity = [
        row
        for row in rows
        if str(row.get("capacity_basis") or "").split("+", 1)[0] not in {"explicit_capacity", "process_capacity"}
    ]
    zero_opening = [row for row in rows if to_float(row.get("simulated_opening_stock_qty"), 0.0) <= 1e-9]
    high_lead = sorted(
        [row for row in rows if to_float(row.get("planned_lead_time_days"), 0.0) >= 90.0],
        key=lambda row: (-to_float(row.get("planned_lead_time_days"), 0.0), str(row.get("supplier_id") or "")),
    )
    high_util = sorted(
        [row for row in rows if to_float(row.get("max_capacity_utilization"), 0.0) >= 0.80],
        key=lambda row: (-to_float(row.get("max_capacity_utilization"), 0.0), str(row.get("supplier_id") or "")),
    )
    scaled_capacity_rows = [
        row for row in rows if to_float(row.get("applied_capacity_scale"), 1.0) > 1.000001
    ]
    neutral_capacity_rows = sorted(
        [
            row
            for row in rows
            if to_float(row.get("neutral_capacity_floor_qty_per_day"), 0.0) > 1e-9
        ],
        key=lambda row: (
            -to_float(row.get("current_capacity_headroom_factor"), 0.0),
            str(row.get("supplier_id") or ""),
        ),
    )
    neutral_stock_rows = sorted(
        [
            row
            for row in rows
            if to_float(row.get("neutral_opening_stock_reducible_qty"), 0.0) > 1e-9
        ],
        key=lambda row: (
            -to_float(row.get("neutral_opening_stock_reducible_qty"), 0.0),
            str(row.get("supplier_id") or ""),
        ),
    )
    basis_counts: dict[str, int] = defaultdict(int)
    reliability_counts: dict[str, int] = defaultdict(int)
    for row in rows:
        basis_counts[str(row.get("capacity_basis") or "n/a")] += 1
        reliability_counts[str(row.get("reliability_source") or "n/a")] += 1

    def count_lines(counts: dict[str, int]) -> str:
        if not counts:
            return "- n/a"
        return "\n".join(
            f"- {key}: {value}"
            for key, value in sorted(counts.items(), key=lambda item: (-item[1], item[0]))
        )

    def preview_table(preview_rows: list[dict[str, Any]], columns: list[str], limit: int = 10) -> str:
        if not preview_rows:
            return "Aucun cas."
        out = [
            "| " + " | ".join(columns) + " |",
            "| " + " | ".join("---" for _ in columns) + " |",
        ]
        for row in preview_rows[:limit]:
            out.append("| " + " | ".join(str(row.get(col, "")) for col in columns) + " |")
        return "\n".join(out)

    warnings_md = "\n".join(f"- {warning}" for warning in supplier_risk_warnings) if supplier_risk_warnings else "- aucune"
    return f"""# Supplier nominal parameters audit

## Scope
- Supplier lanes: {len(rows)}
- Suppliers: {supplier_count}
- Items: {item_count}
- Supplier risk events loaded: {len(supplier_risk_events)}

## Nominal value sources
- Stock fournisseur: input inventory states, then simulated opening stock after initialization.
- Debit/capacite fournisseur: `derive_supplier_daily_capacity_by_pair`.
- Lead time fournisseur: edge `lead_time` copied into lane records.
- Fiabilite fournisseur: edge `service_level.otif` or `otif`; default is `1.0`.
- Criticite locale fournisseur: diagnostic/ranking generated by the map builder, not a physical nominal parameter.

## Capacity basis counts
{count_lines(basis_counts)}

## Reliability source counts
{count_lines(reliability_counts)}

## Audit signals
- Reliability default 1.0 rows: {len(default_reliability)}
- Inferred capacity rows: {len(inferred_capacity)}
- Applied capacity scale > x1 rows: {len(scaled_capacity_rows)}
- Zero simulated opening stock rows: {len(zero_opening)}
- Lead time >= 90 days rows: {len(high_lead)}
- Max capacity utilization >= 80% rows: {len(high_util)}

## Neutral capacity floor preview
Seuil analytique calcule depuis le run courant: max journalier de capacite fournisseur reellement consommee (`used_qty`). Si un fichier d'overrides est actif, `tested_capacity_floor_qty_per_day` reprend la capacite appliquee; sinon le seuil teste ajoute un facteur {SUPPLIER_FUNCTIONAL_CAPACITY_HEADROOM_FACTOR:g} pour absorber la premiere passe de sourcing MRP.

{preview_table(neutral_capacity_rows, ["supplier_id", "item_id", "dst_node_id", "effective_capacity_qty_per_day", "neutral_capacity_floor_qty_per_day", "tested_capacity_floor_qty_per_day", "current_capacity_headroom_vs_tested_floor", "capacity_floor_basis"])}

## Neutral opening stock floor preview
Seuil calcule depuis le run courant: stock d'ouverture simule moins le stock minimum de fin de jour observe. C'est le stock initial minimal analytique qui laisse les expeditions observees faisables, hors re-optimisation des politiques de reapprovisionnement amont.

{preview_table(neutral_stock_rows, ["supplier_id", "item_id", "dst_node_id", "simulated_opening_stock_qty", "neutral_opening_stock_floor_qty", "neutral_opening_stock_reducible_qty", "neutral_opening_stock_scale"])}

## High lead time preview
{preview_table(high_lead, ["supplier_id", "item_id", "dst_node_id", "planned_lead_time_days", "lead_time_type"])}

## High utilization preview
{preview_table(high_util, ["supplier_id", "item_id", "dst_node_id", "max_capacity_utilization", "capacity_basis"])}

## Risk event warnings
{warnings_md}
"""


def try_generate_plots(
    input_stock_rows: list[dict[str, Any]],
    output_prod_rows: list[dict[str, Any]],
    supplier_shipment_rows: list[dict[str, Any]],
    supplier_factory_items: dict[str, set[tuple[str, str]]] | None,
    dc_factory_items: dict[str, set[tuple[str, str]]] | None,
    dc_node_ids: set[str] | None,
    output_dir: Path,
    item_unit_map: dict[str, str] | None = None,
) -> dict[str, str]:
    try:
        import matplotlib.pyplot as plt  # type: ignore
    except Exception:
        return {}

    plot_root = output_dir / "plots"
    factory_input_dir = plot_root / "factories" / "input_stocks"
    factory_output_dir = plot_root / "factories" / "output_products"
    supplier_input_dir = plot_root / "suppliers" / "input_stocks"
    dc_output_dir = plot_root / "distribution_centers" / "factory_outputs"
    for plot_dir in (
        factory_input_dir,
        factory_output_dir,
        supplier_input_dir,
        dc_output_dir,
    ):
        plot_dir.mkdir(parents=True, exist_ok=True)

    generated: dict[str, str] = {}

    # Plot 1: raw-material input stocks by material for each factory.
    by_factory_item_day: dict[str, dict[str, dict[int, float]]] = defaultdict(lambda: defaultdict(dict))
    for r in input_stock_rows:
        day = int(r["day"])
        factory = str(r["node_id"])
        item = str(r["item_id"])
        val = r.get("stock_end_of_day", r.get("stock_before_production", 0.0))
        by_factory_item_day[factory][item][day] = to_float(val, 0.0)

    item_unit_map = item_unit_map or {}
    unit_axes_order = ("KG", "G", "UN")
    unit_cmap = {
        "KG": plt.cm.Blues,
        "G": plt.cm.Oranges,
        "UN": plt.cm.Greens,
    }

    def plot_stock_multiaxis(
        item_map: dict[str, dict[int, float]],
        title: str,
        out_path: Path,
        y_label_prefix: str = "Stock",
        unit_by_item: dict[str, str] | None = None,
        legend_label_by_item: dict[str, str] | None = None,
    ) -> bool:
        if not item_map:
            return False
        all_days = sorted({d for values in item_map.values() for d in values.keys()})
        if not all_days:
            return False

        unit_by_item = unit_by_item or {}
        legend_label_by_item = legend_label_by_item or {}
        items_by_unit: dict[str, list[str]] = {u: [] for u in unit_axes_order}
        for item in sorted(item_map.keys()):
            unit = normalize_unit(unit_by_item.get(item, item_unit_map.get(item, "")))
            target_unit = unit if unit in items_by_unit else "KG"
            items_by_unit[target_unit].append(item)

        present_units = [u for u in unit_axes_order if items_by_unit[u]]
        if not present_units:
            return False

        fig, ax_primary = plt.subplots(figsize=(14, 7))
        axis_for_unit: dict[str, Any] = {}
        for idx, unit in enumerate(present_units):
            if idx == 0:
                axis_for_unit[unit] = ax_primary
            else:
                axis = ax_primary.twinx()
                if idx >= 2:
                    axis.spines["right"].set_position(("outward", 62 * (idx - 1)))
                axis_for_unit[unit] = axis

        color_by_item: dict[str, Any] = {}
        for unit in present_units:
            items = items_by_unit[unit]
            cmap = unit_cmap[unit]
            n = len(items)
            for idx, item in enumerate(items):
                t = 0.40 if n == 1 else 0.35 + (0.55 * idx / (n - 1))
                color_by_item[item] = cmap(t)

        lines_by_axis: dict[str, list[Any]] = {u: [] for u in present_units}
        labels_by_axis: dict[str, list[str]] = {u: [] for u in present_units}

        for item in sorted(item_map.keys()):
            series = [item_map[item].get(d, 0.0) for d in all_days]
            unit = normalize_unit(unit_by_item.get(item, item_unit_map.get(item, "")))
            target_unit = unit if unit in axis_for_unit else present_units[0]
            axis = axis_for_unit[target_unit]
            line = axis.plot(
                all_days,
                series,
                marker="o",
                linewidth=1.4,
                color=color_by_item.get(item),
            )[0]
            lines_by_axis[target_unit].append(line)
            legend_label = legend_label_by_item.get(item, item)
            labels_by_axis[target_unit].append(f"{legend_label} [{target_unit}]")

        ax_primary.set_title(title)
        ax_primary.set_xlabel("Jour")
        ax_primary.grid(alpha=0.3)
        for unit in present_units:
            axis_for_unit[unit].set_ylabel(f"{y_label_prefix} ({unit})")

        if len(present_units) == 1:
            x_positions = [0.50]
        elif len(present_units) == 2:
            x_positions = [0.30, 0.70]
        else:
            x_positions = [0.17, 0.50, 0.83]
        legend_positions = {unit: (x_positions[idx], 0.02) for idx, unit in enumerate(present_units)}

        for unit in present_units:
            unit_lines = lines_by_axis[unit]
            unit_labels = labels_by_axis[unit]
            if not unit_lines:
                continue
            fig.legend(
                unit_lines,
                unit_labels,
                ncol=1,
                fontsize=8,
                title=unit,
                title_fontsize=9,
                loc="lower center",
                bbox_to_anchor=legend_positions[unit],
                frameon=True,
            )

        right_by_count = {1: 0.95, 2: 0.90, 3: 0.83}
        fig.subplots_adjust(right=right_by_count.get(len(present_units), 0.83), bottom=0.34)
        fig.savefig(out_path, dpi=150)
        plt.close(fig)
        return True

    for factory, item_map in sorted(by_factory_item_day.items()):
        if not item_map:
            continue
        all_days = sorted({d for values in item_map.values() for d in values.keys()})
        if not all_days:
            continue
        fig, ax_kg = plt.subplots(figsize=(14, 7))
        ax_g = ax_kg.twinx()
        ax_un = ax_kg.twinx()
        ax_un.spines["right"].set_position(("outward", 62))

        axis_for_unit = {
            "KG": ax_kg,
            "G": ax_g,
            "UN": ax_un,
        }
        unit_cmap = {
            "KG": plt.cm.Blues,
            "G": plt.cm.Oranges,
            "UN": plt.cm.Greens,
        }
        lines_by_axis: dict[str, list[Any]] = {u: [] for u in unit_axes_order}
        labels_by_axis: dict[str, list[str]] = {u: [] for u in unit_axes_order}
        items_by_unit: dict[str, list[str]] = {u: [] for u in unit_axes_order}

        for item in sorted(item_map.keys()):
            unit = normalize_unit(item_unit_map.get(item, ""))
            target_unit = unit if unit in axis_for_unit else "KG"
            items_by_unit[target_unit].append(item)

        color_by_item: dict[str, Any] = {}
        for unit in unit_axes_order:
            items = items_by_unit[unit]
            if not items:
                continue
            cmap = unit_cmap[unit]
            n = len(items)
            for idx, item in enumerate(items):
                # Keep colors in a readable mid/high range for each unit palette.
                t = 0.40 if n == 1 else 0.35 + (0.55 * idx / (n - 1))
                color_by_item[item] = cmap(t)

        for item in sorted(item_map.keys()):
            series = [item_map[item].get(d, 0.0) for d in all_days]
            unit = normalize_unit(item_unit_map.get(item, ""))
            target_unit = unit if unit in axis_for_unit else "KG"
            axis = axis_for_unit[target_unit]
            line = axis.plot(
                all_days,
                series,
                marker="o",
                linewidth=1.4,
                color=color_by_item.get(item),
            )[0]
            lines_by_axis[target_unit].append(line)
            labels_by_axis[target_unit].append(f"{item} [{target_unit}]")

        ax_kg.set_title(f"Stocks de fin de journee des matieres premieres - {factory}")
        ax_kg.set_xlabel("Jour")
        ax_kg.set_ylabel("Stock (KG)")
        ax_g.set_ylabel("Stock (G)")
        ax_un.set_ylabel("Stock (UN)")
        ax_kg.grid(alpha=0.3)

        legend_positions = {
            "KG": (0.17, 0.02),
            "G": (0.50, 0.02),
            "UN": (0.83, 0.02),
        }
        for unit in unit_axes_order:
            unit_lines = lines_by_axis[unit]
            unit_labels = labels_by_axis[unit]
            if not unit_lines:
                continue
            fig.legend(
                unit_lines,
                unit_labels,
                ncol=1,
                fontsize=8,
                title=unit,
                title_fontsize=9,
                loc="lower center",
                bbox_to_anchor=legend_positions[unit],
                frameon=True,
            )
        fig.subplots_adjust(right=0.83, bottom=0.34)
        safe_factory = re.sub(r"[^A-Za-z0-9_-]+", "_", factory)
        out = factory_input_dir / f"production_input_stocks_by_material_{safe_factory}.png"
        fig.savefig(out, dpi=150)
        plt.close(fig)
        generated[f"production_input_stocks_by_material_{factory}"] = str(out)

    # Plot 2: production of output products.
    by_pair: dict[str, list[tuple[int, float]]] = defaultdict(list)
    by_factory_pair: dict[str, dict[str, list[tuple[int, float]]]] = defaultdict(lambda: defaultdict(list))
    for r in output_prod_rows:
        factory = str(r["node_id"])
        item_id = str(r["item_id"])
        day = int(r["day"])
        qty = to_float(r["produced_qty"], 0.0)
        label = pair_label(factory, item_id)
        by_pair[label].append((day, qty))
        by_factory_pair[factory][item_id].append((day, qty))

    if by_pair:
        plt.figure(figsize=(12, 6))
        for label in sorted(by_pair.keys()):
            points = sorted(by_pair[label], key=lambda x: x[0])
            days = [p[0] for p in points]
            vals = [p[1] for p in points]
            plt.plot(days, vals, marker="o", linewidth=1.8, label=label)
        plt.title("Production journaliere des produits finis (sortie)")
        plt.xlabel("Jour")
        plt.ylabel("Production (unites/jour)")
        plt.grid(alpha=0.3)
        plt.legend()
        plt.tight_layout()
        out = factory_output_dir / "production_output_products.png"
        plt.savefig(out, dpi=150)
        plt.close()
        generated["production_output_products_png"] = str(out)

    for factory, item_map in sorted(by_factory_pair.items()):
        if not item_map:
            continue
        plt.figure(figsize=(12, 6))
        for item_id in sorted(item_map.keys()):
            points = sorted(item_map[item_id], key=lambda x: x[0])
            days = [p[0] for p in points]
            vals = [p[1] for p in points]
            plt.plot(days, vals, marker="o", linewidth=1.8, label=item_id)
        plt.title(f"Production journaliere des produits finis - {factory}")
        plt.xlabel("Jour")
        plt.ylabel("Production (unites/jour)")
        plt.grid(alpha=0.3)
        plt.legend()
        plt.tight_layout()
        safe_factory = re.sub(r"[^A-Za-z0-9_-]+", "_", factory)
        out = factory_output_dir / f"production_output_products_by_factory_{safe_factory}.png"
        plt.savefig(out, dpi=150)
        plt.close()
        generated[f"production_output_products_by_factory_{factory}"] = str(out)

    # Plot 3: supplier view = downstream process-node input stocks on supplier-related items.
    supplier_factory_items = supplier_factory_items or {}
    for supplier, scoped_pairs in sorted(supplier_factory_items.items()):
        item_map: dict[str, dict[int, float]] = {}
        unit_by_item: dict[str, str] = {}
        legend_label_by_item: dict[str, str] = {}
        for factory, item in sorted(scoped_pairs):
            factory_series = by_factory_item_day.get(factory, {}).get(item)
            if not factory_series:
                continue
            series_key = f"{factory}|{item}"
            item_map[series_key] = dict(factory_series)
            unit_by_item[series_key] = normalize_unit(item_unit_map.get(item, ""))
            legend_label_by_item[series_key] = f"{item} ({factory})"
        if not item_map:
            continue
        safe_supplier = re.sub(r"[^A-Za-z0-9_-]+", "_", supplier)
        out = supplier_input_dir / f"production_supplier_input_stocks_by_material_{safe_supplier}.png"
        if plot_stock_multiaxis(
            item_map,
            f"Stocks d'entree du noeud aval (produits du fournisseur) - {supplier}",
            out,
            y_label_prefix="Stock",
            unit_by_item=unit_by_item,
            legend_label_by_item=legend_label_by_item,
        ):
            generated[f"production_supplier_input_stocks_by_material_{supplier}"] = str(out)

    # Plot 4: distribution center view = upstream factory output series for DC-related items.
    dc_factory_items = dc_factory_items or {}
    by_factory_output_item_day: dict[str, dict[str, dict[int, float]]] = defaultdict(lambda: defaultdict(dict))
    for r in output_prod_rows:
        day = int(r["day"])
        factory = str(r["node_id"])
        item = str(r["item_id"])
        val = to_float(r.get("produced_qty"), 0.0)
        by_factory_output_item_day[factory][item][day] = val

    for dc_node, scoped_pairs in sorted(dc_factory_items.items()):
        item_map: dict[str, dict[int, float]] = {}
        unit_by_item: dict[str, str] = {}
        legend_label_by_item: dict[str, str] = {}
        for factory, item in sorted(scoped_pairs):
            factory_series = by_factory_output_item_day.get(factory, {}).get(item)
            if not factory_series:
                continue
            series_key = f"{factory}|{item}"
            item_map[series_key] = dict(factory_series)
            unit_by_item[series_key] = normalize_unit(item_unit_map.get(item, ""))
            legend_label_by_item[series_key] = f"{item} ({factory})"
        if not item_map:
            continue
        safe_dc = re.sub(r"[^A-Za-z0-9_-]+", "_", dc_node)
        out = dc_output_dir / f"production_dc_factory_outputs_by_material_{safe_dc}.png"
        if plot_stock_multiaxis(
            item_map,
            f"Productions usines liees au distribution center - {dc_node}",
            out,
            y_label_prefix="Production",
            unit_by_item=unit_by_item,
            legend_label_by_item=legend_label_by_item,
        ):
            generated[f"production_dc_factory_outputs_by_material_{dc_node}"] = str(out)

    return generated


def main() -> None:
    args = parse_args()
    input_path = Path(args.input)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    ensure_standard_dirs(output_dir)

    input_sha256 = hashlib.sha256(input_path.read_bytes()).hexdigest()
    data = json.loads(input_path.read_text(encoding="utf-8"))
    from etudecas.knowledge_graph.schema import validate_graph_contract
    contract_errors = [issue for issue in validate_graph_contract(data) if issue["level"] == "error"]
    if contract_errors:
        raise ValueError(f"Invalid simulation graph: {contract_errors}")
    nodes = data.get("nodes", []) or []
    edges = data.get("edges", []) or []
    graph_meta = data.get("meta") if isinstance(data.get("meta"), dict) else {}
    opening_open_orders_payload = (
        graph_meta.get("opening_open_orders")
        if isinstance(graph_meta.get("opening_open_orders"), dict)
        else {}
    )
    node_by_id = {str(n.get("id")): n for n in nodes}
    mrp_snapshot_pairs = {
        (str(n.get("id")), str(state.get("item_id")))
        for n in nodes
        for state in (((n.get("inventory") or {}).get("states") or []))
        if str(state.get("initial_source") or "").strip().lower().startswith("mrp_snapshot")
    }
    item_unit_map = infer_item_unit_map(nodes, edges)
    assumed_supplier_nodes_set = {
        str(n.get("id"))
        for n in nodes
        if bool(n.get("is_invented"))
        or bool((n.get("assumptions") or {}).get("is_invented"))
        or bool(n.get("is_assumed"))
        or bool((n.get("assumptions") or {}).get("is_assumed"))
    }
    assumed_supply_edges_set: set[str] = set()
    for e in edges:
        is_assumed_edge = (
            bool(e.get("is_invented"))
            or str(e.get("source") or "").startswith("simulation_prep_invented_supplier_assumption")
            or bool(e.get("is_assumed"))
            or str(e.get("source") or "").startswith("simulation_prep_gaillac_question_mark_assumption")
        )
        if not is_assumed_edge:
            continue
        assumed_supply_edges_set.add(str(e.get("id")))
        assumed_supplier_nodes_set.add(str(e.get("from")))
    assumed_supplier_nodes = sorted(assumed_supplier_nodes_set)
    assumed_supply_edges = sorted(assumed_supply_edges_set)

    scenario = choose_scenario(data, args.scenario_id)
    supplier_risk_events_path = (
        Path(args.supplier_risk_events_csv)
        if args.supplier_risk_events_csv
        else None
    )
    supplier_risk_events_sha256 = (
        hashlib.sha256(supplier_risk_events_path.read_bytes()).hexdigest()
        if supplier_risk_events_path is not None
        and supplier_risk_events_path.exists()
        else ""
    )
    supplier_risk_events, supplier_risk_warnings = load_supplier_risk_events(
        csv_path=supplier_risk_events_path,
        scenario=scenario,
    )
    (
        supplier_capacity_floor_overrides,
        supplier_stock_floor_overrides,
        supplier_floor_warnings,
    ) = load_supplier_neutral_floor_overrides(
        Path(args.supplier_neutral_floors_csv) if args.supplier_neutral_floors_csv else None
    )
    factory_capacity_overrides, factory_capacity_override_warnings = load_factory_capacity_overrides(
        Path(args.factory_nominal_capacities_csv) if args.factory_nominal_capacities_csv else None
    )
    factory_capacity_override_applied = apply_factory_capacity_overrides(nodes, factory_capacity_overrides)
    default_days = int(to_float(((scenario.get("horizon") or {}).get("steps_to_run")), 30))
    sim_days = args.days if args.days > 0 else (default_days if default_days > 0 else 30)
    warmup_days = (
        max(0, int(args.warmup_days))
        if args.warmup_days is not None
        else max(0, int(round(scenario_policy_value(scenario, "warmup_days", 0.0))))
    )
    reset_backlog_after_warmup = scenario_policy_bool(scenario, "reset_backlog_after_warmup", False)
    total_timeline_days = warmup_days + sim_days
    safety_stock_days = max(0.0, scenario_policy_value(scenario, "safety_stock_days", 7.0))
    review_period_days = max(1, int(round(scenario_policy_value(scenario, "review_period_days", 1.0))))
    mrp_review_period_days = (
        max(1, int(args.mrp_review_period_days))
        if args.mrp_review_period_days and args.mrp_review_period_days > 0
        else review_period_days
    )
    mrp_target_bucket_days = (
        max(1, int(args.mrp_target_bucket_days))
        if args.mrp_target_bucket_days and args.mrp_target_bucket_days > 0
        else 1
    )
    fg_target_days = max(0.0, scenario_policy_value(scenario, "fg_target_days", 0.0))
    demand_stock_target_days = max(0.0, scenario_policy_value(scenario, "demand_stock_target_days", 0.0))
    production_gap_gain = max(0.0, scenario_policy_value(scenario, "production_gap_gain", 0.25))
    production_smoothing = min(0.95, max(0.0, scenario_policy_value(scenario, "production_smoothing", 0.20)))
    initialization_policy = scenario_initialization_policy(
        scenario,
        review_period_days=review_period_days,
        safety_stock_days=safety_stock_days,
    )
    if args.mrp_strict_safety_floor_from_safety_time is not None:
        initialization_policy["mrp_strict_safety_floor_from_safety_time"] = bool(
            args.mrp_strict_safety_floor_from_safety_time
        )
    if args.restore_opening_stock_after_warmup is not None:
        initialization_policy["restore_opening_stock_after_warmup"] = bool(
            args.restore_opening_stock_after_warmup
        )
    if args.initial_state_scale is not None:
        initialization_policy["state_scale"] = max(0.0, float(args.initial_state_scale))
    if args.initial_factory_input_on_hand_days is not None:
        initialization_policy["factory_input_on_hand_days"] = max(
            0.0,
            float(args.initial_factory_input_on_hand_days),
        )
    if args.initial_supplier_output_on_hand_days is not None:
        initialization_policy["supplier_output_on_hand_days"] = max(
            0.0,
            float(args.initial_supplier_output_on_hand_days),
        )
    if args.initial_distribution_center_on_hand_days is not None:
        initialization_policy["distribution_center_on_hand_days"] = max(
            0.0,
            float(args.initial_distribution_center_on_hand_days),
        )
    if args.initial_customer_on_hand_days is not None:
        initialization_policy["customer_on_hand_days"] = max(
            0.0,
            float(args.initial_customer_on_hand_days),
        )
    if args.initial_seed_safety_time_on_hand is not None:
        initialization_policy["seed_safety_time_on_hand"] = bool(
            args.initial_seed_safety_time_on_hand
        )
    if args.initial_seed_estimated_source_on_hand is not None:
        initialization_policy["seed_estimated_source_on_hand"] = bool(
            args.initial_seed_estimated_source_on_hand
        )
    if args.initial_seed_in_transit is not None:
        initialization_policy["seed_in_transit"] = bool(args.initial_seed_in_transit)
    if args.initial_in_transit_fill_ratio is not None:
        initialization_policy["in_transit_fill_ratio"] = max(
            0.0,
            float(args.initial_in_transit_fill_ratio),
        )
    if args.initial_seed_estimated_source_pipeline is not None:
        initialization_policy["seed_estimated_source_pipeline"] = bool(
            args.initial_seed_estimated_source_pipeline
        )
    if args.initial_seed_open_orders_from_january_snapshot is not None:
        initialization_policy["seed_open_orders_from_january_snapshot"] = bool(
            args.initial_seed_open_orders_from_january_snapshot
        )
    if args.opening_production_order_bom_issue_mode is not None:
        initialization_policy["opening_production_order_bom_issue_mode"] = str(
            args.opening_production_order_bom_issue_mode
        )
    if args.use_bom_demand_signal_for_mrp is not None:
        initialization_policy["use_bom_demand_signal_for_mrp"] = bool(args.use_bom_demand_signal_for_mrp)
    if args.mrp_demand_signal_source is not None:
        initialization_policy["mrp_demand_signal_source"] = str(args.mrp_demand_signal_source)
    if args.mrp_demand_signal_smoothing_days and args.mrp_demand_signal_smoothing_days > 0:
        initialization_policy["mrp_demand_signal_smoothing_days"] = max(
            1,
            int(args.mrp_demand_signal_smoothing_days),
        )
    if args.mrp_static_fallback_for_propagated_pairs is not None:
        initialization_policy["mrp_static_fallback_for_propagated_pairs"] = bool(
            args.mrp_static_fallback_for_propagated_pairs
        )
    (
        initialization_policy["mrp_static_requirement_pairs"],
        initialization_policy["mrp_dynamic_requirement_pairs"],
    ) = resolve_mrp_requirement_pair_modes(
        initialization_policy["mrp_static_requirement_pairs"],
        args.mrp_static_requirement_pair,
        args.mrp_dynamic_requirement_pair,
    )
    initialization_policy["mrp_smoothed_cover_requirement_pairs"] = (
        parse_pair_key_values(args.mrp_smoothed_cover_requirement_pair)
    )
    if args.soft_safety_time_stock_target_factor is not None:
        initialization_policy["soft_safety_time_stock_target_factor"] = max(
            0.0,
            min(10.0, float(args.soft_safety_time_stock_target_factor)),
        )
    cli_pair_factors = parse_pair_factor_specs(args.soft_safety_time_stock_target_factor_pair)
    if cli_pair_factors:
        merged_pair_factors = dict(initialization_policy["soft_safety_time_stock_target_factor_by_pair"])
        merged_pair_factors.update(cli_pair_factors)
        initialization_policy["soft_safety_time_stock_target_factor_by_pair"] = merged_pair_factors
    cli_base_floor_factors = parse_pair_factor_specs(args.mrp_base_stock_floor_factor_pair)
    if cli_base_floor_factors:
        merged_base_floor_factors = dict(initialization_policy["mrp_base_stock_floor_factor_by_pair"])
        merged_base_floor_factors.update(cli_base_floor_factors)
        initialization_policy["mrp_base_stock_floor_factor_by_pair"] = merged_base_floor_factors
    if args.mrp_base_stock_floor_factor is not None:
        initialization_policy["mrp_base_stock_floor_factor"] = max(
            0.0,
            min(10.0, to_float(args.mrp_base_stock_floor_factor, 1.0)),
        )

    def soft_safety_factor_for_pair(pair: tuple[str, str]) -> float:
        pair_factors = initialization_policy["soft_safety_time_stock_target_factor_by_pair"]
        return max(
            0.0,
            to_float(
                pair_factors.get(policy_pair_key(pair[0], pair[1])),
                initialization_policy["soft_safety_time_stock_target_factor"],
            ),
        )

    def base_stock_floor_factor_for_pair(pair: tuple[str, str]) -> float:
        pair_factors = initialization_policy["mrp_base_stock_floor_factor_by_pair"]
        return max(
            0.0,
            to_float(
                pair_factors.get(policy_pair_key(pair[0], pair[1])),
                initialization_policy["mrp_base_stock_floor_factor"],
            ),
        )

    static_requirement_pair_keys = set(initialization_policy["mrp_static_requirement_pairs"])
    dynamic_requirement_pair_keys = set(initialization_policy["mrp_dynamic_requirement_pairs"])
    smoothed_cover_requirement_pair_keys = set(
        initialization_policy["mrp_smoothed_cover_requirement_pairs"]
    )
    nonbinding_standard_order_pair_keys = set(parse_pair_key_values(args.mrp_nonbinding_standard_order_pair))
    if any(not parse_pair_key_values([value]) for value in args.mrp_nonbinding_standard_order_pair):
        raise ValueError("Nonbinding standard order pairs must use NODE,ITEM")
    forecast_production_signal = args.production_signal_source == "forecast"
    dated_mrp_execution = args.mrp_execution_mode != "historical"
    dated_component_planning = args.mrp_execution_mode == "dated"
    record_production_planning = args.production_mrp_safety_targets or forecast_production_signal

    def static_requirement_for_pair(pair: tuple[str, str]) -> bool:
        return policy_pair_key(pair[0], pair[1]) in static_requirement_pair_keys

    def dynamic_requirement_for_pair(pair: tuple[str, str]) -> bool:
        return policy_pair_key(pair[0], pair[1]) in dynamic_requirement_pair_keys

    def smoothed_cover_requirement_for_pair(pair: tuple[str, str]) -> bool:
        return (
            policy_pair_key(pair[0], pair[1])
            in smoothed_cover_requirement_pair_keys
        )

    def source_has_dynamic_destination(src_pair: tuple[str, str]) -> bool:
        return any(
            dynamic_requirement_for_pair((str(lane.get("dst")), src_pair[1]))
            for lane in lanes_by_src_item.get(src_pair, [])
        )

    lead_time_policy_cfg = scenario_policy_dict(scenario, "lead_time_policy")
    lead_time_distribution_mode = normalize_lead_time_distribution_mode(
        args.lead_time_distribution_mode
        or lead_time_policy_cfg.get("distribution_mode")
        or "erlang"
    )
    economic_policy_cfg = scenario_policy_dict(scenario, "economic_policy")
    production_cost_target_share = to_float(
        economic_policy_cfg.get("production_cost_target_share_of_total"),
        0.30,
    )
    if production_cost_target_share > 1.0:
        production_cost_target_share /= 100.0
    production_cost_target_share = max(0.0, min(0.80, production_cost_target_share))
    default_production_cost_line_shares = {
        policy_pair_key(node_id, item_id): share
        for (node_id, item_id), share in DEFAULT_PRODUCTION_COST_LINE_SHARES.items()
    }
    default_production_cost_line_profiles = {
        policy_pair_key(node_id, item_id): profile
        for (node_id, item_id), profile in DEFAULT_PRODUCTION_COST_LINE_PROFILES.items()
    }
    default_production_cost_unit_rates = {
        policy_pair_key(node_id, item_id): rate
        for (node_id, item_id), rate in DEFAULT_PRODUCTION_COST_UNIT_RATES.items()
    }
    raw_production_cost_line_shares = economic_policy_cfg.get("production_cost_line_shares")
    production_cost_line_shares = dict(default_production_cost_line_shares)
    if isinstance(raw_production_cost_line_shares, dict):
        for raw_key, raw_value in raw_production_cost_line_shares.items():
            share = to_float(raw_value, float("nan"))
            if not math.isfinite(share):
                continue
            if share > 1.0:
                share /= 100.0
            production_cost_line_shares[str(raw_key).strip()] = max(0.0, share)
    raw_production_cost_line_profiles = economic_policy_cfg.get("production_cost_line_profiles")
    production_cost_line_profiles = dict(default_production_cost_line_profiles)
    if isinstance(raw_production_cost_line_profiles, dict):
        for raw_key, raw_value in raw_production_cost_line_profiles.items():
            production_cost_line_profiles[str(raw_key).strip()] = str(raw_value or "").strip() or "production"
    raw_production_cost_unit_rates = economic_policy_cfg.get("production_cost_unit_rates")
    production_cost_unit_rates = dict(default_production_cost_unit_rates)
    if isinstance(raw_production_cost_unit_rates, dict):
        for raw_key, raw_value in raw_production_cost_unit_rates.items():
            rate = to_float(raw_value, float("nan"))
            if math.isfinite(rate) and rate >= 0.0:
                production_cost_unit_rates[str(raw_key).strip()] = rate
    production_cost_mode = str(
        economic_policy_cfg.get("production_cost_mode")
        or ("fixed_unit_rate" if production_cost_unit_rates else "target_share")
    ).strip().lower()
    if production_cost_mode not in {"fixed_unit_rate", "target_share"}:
        production_cost_mode = "fixed_unit_rate" if production_cost_unit_rates else "target_share"
    unmodeled_supplier_source_mode = str(scenario.get("unmodeled_supplier_source_mode", "external_procurement")).strip().lower()
    if unmodeled_supplier_source_mode not in {
        "external_procurement",
        "estimated_capacity",
        "estimated_replenishment",
    }:
        unmodeled_supplier_source_mode = "external_procurement"
    economic_policy = {
        "transport_cost_floor_per_unit": max(
            0.0,
            to_float(economic_policy_cfg.get("transport_cost_floor_per_unit"), 0.02),
        ),
        "transport_cost_per_km_per_unit": max(
            0.0,
            to_float(economic_policy_cfg.get("transport_cost_per_km_per_unit"), 0.00008),
        ),
        "purchase_cost_floor_per_unit": max(
            0.0,
            to_float(economic_policy_cfg.get("purchase_cost_floor_per_unit"), 0.01),
        ),
        "holding_cost_scale": max(
            0.0,
            to_float(economic_policy_cfg.get("holding_cost_scale"), 1.0),
        ),
        # Benchmark-inspired decomposition for pharma-like supply economics:
        # raw per-item holding cost is reallocated between capital tied-up,
        # warehouse/compliance operations, and inventory risk/obsolescence.
        "inventory_capital_cost_share_of_raw_holding": max(
            0.0,
            to_float(economic_policy_cfg.get("inventory_capital_cost_share_of_raw_holding"), 0.35),
        ),
        "warehouse_operating_cost_share_of_raw_holding": max(
            0.0,
            to_float(economic_policy_cfg.get("warehouse_operating_cost_share_of_raw_holding"), 0.45),
        ),
        "inventory_risk_cost_share_of_raw_holding": max(
            0.0,
            to_float(economic_policy_cfg.get("inventory_risk_cost_share_of_raw_holding"), 0.20),
        ),
        "transport_cost_realism_multiplier": max(
            0.1,
            to_float(economic_policy_cfg.get("transport_cost_realism_multiplier"), 8.0),
        ),
        "purchase_cost_realism_multiplier": max(
            0.1,
            to_float(economic_policy_cfg.get("purchase_cost_realism_multiplier"), 1.0),
        ),
        "production_cost_enabled": (
            economic_policy_cfg.get("production_cost_enabled")
            if isinstance(economic_policy_cfg.get("production_cost_enabled"), bool)
            else str(economic_policy_cfg.get("production_cost_enabled", True)).strip().lower()
            in {"1", "true", "yes", "y", "on"}
        ),
        "production_cost_target_share_of_total": production_cost_target_share,
        "production_cost_mode": production_cost_mode,
        "production_cost_basis": str(
            economic_policy_cfg.get("production_cost_basis")
            or (
                "baseline_calibrated_fixed_unit_rate"
                if production_cost_mode == "fixed_unit_rate"
                else "pharma_standard_target_share_allocated_on_actual_production"
            )
        ),
        "production_cost_line_shares": production_cost_line_shares,
        "production_cost_line_profiles": production_cost_line_profiles,
        "production_cost_unit_rates": production_cost_unit_rates,
        "external_procurement_enabled": (
            economic_policy_cfg.get("external_procurement_enabled")
            if isinstance(economic_policy_cfg.get("external_procurement_enabled"), bool)
            else str(
                economic_policy_cfg.get(
                    "external_procurement_enabled",
                    scenario_policy_bool(scenario, "external_procurement_enabled", True),
                )
            ).strip().lower()
            in {"1", "true", "yes", "y", "on"}
        ),
        "external_procurement_proactive_replenishment": (
            economic_policy_cfg.get("external_procurement_proactive_replenishment")
            if isinstance(economic_policy_cfg.get("external_procurement_proactive_replenishment"), bool)
            else str(
                economic_policy_cfg.get(
                    "external_procurement_proactive_replenishment",
                    scenario_policy_bool(scenario, "external_procurement_proactive_replenishment", True),
                )
            ).strip().lower()
            in {"1", "true", "yes", "y", "on"}
        ),
        "supplier_risk_loss_gross_up": (
            economic_policy_cfg.get("supplier_risk_loss_gross_up")
            if isinstance(economic_policy_cfg.get("supplier_risk_loss_gross_up"), bool)
            else str(
                economic_policy_cfg.get("supplier_risk_loss_gross_up", "true")
            ).strip().lower()
            in {"1", "true", "yes", "y", "on"}
        ),
        "external_procurement_lead_days": max(
            0,
            int(round(to_float(economic_policy_cfg.get("external_procurement_lead_days"), 4.0))),
        ),
        "external_procurement_lead_mode": str(
            economic_policy_cfg.get("external_procurement_lead_mode") or "supplier_material"
        ).strip().lower().replace("-", "_"),
        "external_procurement_lead_time_scale": max(
            0.01,
            to_float(economic_policy_cfg.get("external_procurement_lead_time_scale"), 1.0),
        ),
        "external_procurement_capacity_mode": str(
            economic_policy_cfg.get("external_procurement_capacity_mode") or "supplier_nominal"
        ).strip().lower().replace("-", "_"),
        "external_procurement_nominal_capacity_scale": max(
            0.0,
            to_float(economic_policy_cfg.get("external_procurement_nominal_capacity_scale"), 1.0),
        ),
        "external_procurement_upstream_pipeline_fill_ratio": max(
            0.0,
            to_float(economic_policy_cfg.get("external_procurement_upstream_pipeline_fill_ratio"), 1.0),
        ),
        "external_procurement_seed_upstream_pipeline": (
            economic_policy_cfg.get("external_procurement_seed_upstream_pipeline")
            if isinstance(economic_policy_cfg.get("external_procurement_seed_upstream_pipeline"), bool)
            else str(
                economic_policy_cfg.get("external_procurement_seed_upstream_pipeline", "true")
            ).strip().lower()
            in {"1", "true", "yes", "y", "on"}
        ),
        "external_procurement_daily_cap_days": max(
            0.0,
            to_float(economic_policy_cfg.get("external_procurement_daily_cap_days"), 2.0),
        ),
        "external_procurement_min_daily_cap_qty": max(
            0.0,
            to_float(economic_policy_cfg.get("external_procurement_min_daily_cap_qty"), 0.0),
        ),
        "external_procurement_unit_cost": max(
            0.0,
            to_float(economic_policy_cfg.get("external_procurement_unit_cost"), 0.0),
        ),
        "external_procurement_cost_multiplier": max(
            0.0,
            to_float(economic_policy_cfg.get("external_procurement_cost_multiplier"), 2.0),
        ),
        "external_procurement_transport_cost_per_unit": max(
            0.0,
            to_float(economic_policy_cfg.get("external_procurement_transport_cost_per_unit"), 0.04),
        ),
    }
    if args.external_procurement_enabled is not None:
        economic_policy["external_procurement_enabled"] = bool(args.external_procurement_enabled)
    if args.external_procurement_proactive_replenishment is not None:
        economic_policy["external_procurement_proactive_replenishment"] = bool(
            args.external_procurement_proactive_replenishment
        )
    if args.supplier_risk_loss_gross_up is not None:
        economic_policy["supplier_risk_loss_gross_up"] = bool(
            args.supplier_risk_loss_gross_up
        )
    if economic_policy["external_procurement_lead_mode"] not in {"supplier_material", "policy_fixed"}:
        economic_policy["external_procurement_lead_mode"] = "supplier_material"
    if args.external_procurement_lead_mode:
        economic_policy["external_procurement_lead_mode"] = args.external_procurement_lead_mode
    if economic_policy["external_procurement_capacity_mode"] not in {"supplier_nominal", "policy_cap"}:
        economic_policy["external_procurement_capacity_mode"] = "supplier_nominal"
    if args.external_procurement_capacity_mode:
        economic_policy["external_procurement_capacity_mode"] = args.external_procurement_capacity_mode
    if args.external_procurement_nominal_capacity_scale is not None:
        economic_policy["external_procurement_nominal_capacity_scale"] = max(
            0.0,
            float(args.external_procurement_nominal_capacity_scale),
        )
    if args.external_procurement_upstream_pipeline_fill_ratio is not None:
        economic_policy["external_procurement_upstream_pipeline_fill_ratio"] = max(
            0.0,
            float(args.external_procurement_upstream_pipeline_fill_ratio),
        )
    if args.external_procurement_lead_days and args.external_procurement_lead_days > 0:
        economic_policy["external_procurement_lead_days"] = max(1, int(args.external_procurement_lead_days))
        if not args.external_procurement_lead_mode:
            economic_policy["external_procurement_lead_mode"] = "policy_fixed"
            economic_policy["external_procurement_lead_time_scale"] = 1.0
    if args.external_procurement_daily_cap_days is not None:
        economic_policy["external_procurement_daily_cap_days"] = max(
            0.0,
            float(args.external_procurement_daily_cap_days),
        )
    if args.external_procurement_min_daily_cap_qty is not None:
        economic_policy["external_procurement_min_daily_cap_qty"] = max(
            0.0,
            float(args.external_procurement_min_daily_cap_qty),
        )
    if args.external_procurement_cost_multiplier is not None:
        economic_policy["external_procurement_cost_multiplier"] = max(
            0.0,
            float(args.external_procurement_cost_multiplier),
        )
    inventory_cost_share_sum = (
        economic_policy["inventory_capital_cost_share_of_raw_holding"]
        + economic_policy["warehouse_operating_cost_share_of_raw_holding"]
        + economic_policy["inventory_risk_cost_share_of_raw_holding"]
    )
    if inventory_cost_share_sum <= 1e-9:
        economic_policy["inventory_capital_cost_share_of_raw_holding"] = 0.35
        economic_policy["warehouse_operating_cost_share_of_raw_holding"] = 0.45
        economic_policy["inventory_risk_cost_share_of_raw_holding"] = 0.20
        inventory_cost_share_sum = 1.0
    economic_policy["inventory_capital_cost_share_of_raw_holding"] /= inventory_cost_share_sum
    economic_policy["warehouse_operating_cost_share_of_raw_holding"] /= inventory_cost_share_sum
    economic_policy["inventory_risk_cost_share_of_raw_holding"] /= inventory_cost_share_sum
    rng = random.Random(args.seed)

    opening_observed_stock_global_scale_requested = (
        args.opening_observed_stock_scale is not None
    )
    opening_observed_stock_scale_csv_requested = bool(
        str(args.opening_observed_stock_scale_csv or "").strip()
    )
    if (
        opening_observed_stock_global_scale_requested
        and opening_observed_stock_scale_csv_requested
    ):
        raise SystemExit(
            "--opening-observed-stock-scale and "
            "--opening-observed-stock-scale-csv are mutually exclusive"
        )
    opening_observed_stock_scale_requested = (
        opening_observed_stock_global_scale_requested
        or opening_observed_stock_scale_csv_requested
    )
    opening_observed_stock_scale = (
        float(args.opening_observed_stock_scale)
        if opening_observed_stock_global_scale_requested
        else 1.0
    )
    observed_graph_inventory_pairs = {
        (str(node.get("id")), str(state.get("item_id")))
        for node in nodes
        for state in (((node.get("inventory") or {}).get("states") or []))
    }
    opening_observed_stock_scale_csv_path = (
        Path(args.opening_observed_stock_scale_csv).resolve()
        if opening_observed_stock_scale_csv_requested
        else None
    )
    opening_observed_stock_scale_overrides: dict[tuple[str, str], float] = {}
    opening_observed_stock_scale_csv_sha256 = ""
    if opening_observed_stock_scale_csv_path is not None:
        try:
            (
                opening_observed_stock_scale_overrides,
                opening_observed_stock_scale_csv_sha256,
            ) = load_opening_observed_stock_scale_overrides(
                opening_observed_stock_scale_csv_path,
                valid_pairs=observed_graph_inventory_pairs,
            )
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
    measurement_start_stock_scale_csv_path = (
        Path(args.measurement_start_stock_scale_csv).resolve()
        if str(args.measurement_start_stock_scale_csv or "").strip()
        else None
    )
    measurement_start_stock_scale_overrides: dict[tuple[str, str], float] = {}
    measurement_start_stock_scale_csv_sha256 = ""
    if measurement_start_stock_scale_csv_path is not None:
        try:
            (
                measurement_start_stock_scale_overrides,
                measurement_start_stock_scale_csv_sha256,
            ) = load_measurement_start_stock_scale_overrides(
                measurement_start_stock_scale_csv_path,
                valid_pairs=observed_graph_inventory_pairs,
            )
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
    measurement_start_in_transit_scale_csv_path = (
        Path(args.measurement_start_in_transit_scale_csv).resolve()
        if str(args.measurement_start_in_transit_scale_csv or "").strip()
        else None
    )
    measurement_start_in_transit_scale_overrides: dict[
        tuple[str, str], float
    ] = {}
    measurement_start_in_transit_scale_csv_sha256 = ""
    opening_observed_stock_totals_by_uom: dict[str, dict[str, float]] = defaultdict(
        lambda: {"source_qty": 0.0, "effective_qty": 0.0}
    )
    opening_observed_stock_scaled_positive_state_count = 0
    stock: dict[tuple[str, str], float] = defaultdict(float)
    holding_cost: dict[tuple[str, str], float] = defaultdict(float)
    holding_cost_unknown_reasons: dict[tuple[str, str], str] = {}
    unknown_inventory_quantity_days: dict[tuple[str, str], float] = defaultdict(float)
    base_stock: dict[tuple[str, str], float] = defaultdict(float)
    pair_mrp_safety_time_days: dict[tuple[str, str], float] = defaultdict(float)
    pair_mrp_safety_source_days: dict[tuple[str, str], float] = defaultdict(float)
    safety_calendar = safety_calendar_anchor(data, scenario)
    safety_calendar["mode"] = args.safety_time_calendar
    safety_calendar["working_weekdays"] = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
    safety_calendar["scope"] = "safety_cover_only_no_physical_closure"
    safety_calendar["source_day_count_preserved"] = True
    pair_mrp_safety_stock_qty: dict[tuple[str, str], float] = defaultdict(float)
    observed_opening_stock_rows: list[dict[str, Any]] = []
    node_type_lookup_for_opening = {str(n.get("id")): str(n.get("type") or "") for n in nodes}
    for n in nodes:
        nid = str(n.get("id"))
        inv = n.get("inventory") or {}
        for st in (inv.get("states") or []):
            item_id = str(st.get("item_id"))
            key = (nid, item_id)
            input_initial = to_float(st.get("initial"), 0.0)
            pair_opening_stock_scale = opening_observed_stock_scale_overrides.get(
                key,
                opening_observed_stock_scale,
            )
            initial = (
                input_initial * pair_opening_stock_scale
                if opening_observed_stock_scale_requested
                else input_initial
            )
            require_physical_integer(input_initial, st.get("uom") or item_unit_map.get(item_id, ""))
            initial = physical_execution_quantity(initial, item_unit_map.get(item_id, ""))
            stock[key] = initial
            if input_initial > 1e-9:
                stock_uom = normalize_unit(st.get("uom") or item_unit_map.get(item_id, ""))
                observed_row = {
                    "node_id": nid,
                    "node_type": str(n.get("type") or ""),
                    "item_id": item_id,
                    "opening_stock_qty": round(initial, 6),
                    "uom": stock_uom,
                    "source": str(st.get("initial_source") or st.get("source") or "graph_inventory_initial"),
                }
                if opening_observed_stock_scale_requested:
                    observed_row.update(
                        {
                            "input_opening_stock_qty": round(input_initial, 6),
                            "opening_observed_stock_scale": round(
                                pair_opening_stock_scale,
                                9,
                            ),
                            "effective_opening_stock_qty": round(initial, 6),
                            "base_stock_qty_after_scale": round(
                                0.0 if key in mrp_snapshot_pairs else initial,
                                6,
                            ),
                            "mrp_snapshot_state_only": int(key in mrp_snapshot_pairs),
                        }
                    )
                    opening_observed_stock_totals_by_uom[stock_uom][
                        "source_qty"
                    ] += input_initial
                    opening_observed_stock_totals_by_uom[stock_uom][
                        "effective_qty"
                    ] += initial
                    if abs(pair_opening_stock_scale - 1.0) > 1e-12:
                        opening_observed_stock_scaled_positive_state_count += 1
                observed_opening_stock_rows.append(observed_row)
            # An MRP snapshot is an opening position, not a standing reorder target.
            # Keeping the opening stock as perpetual base stock forces some seeded
            # supplier pairs into daily capped replenishment even when downstream
            # demand is variable and current stock is already ample.
            if key in mrp_snapshot_pairs:
                base_stock[key] = 0.0
            else:
                base_stock[key] = initial
            hc = st.get("holding_cost") or {}
            rate, rate_status = inventory_holding_rate(hc)
            if rate is None:
                holding_cost_unknown_reasons[key] = rate_status
            holding_cost[key] = (rate or 0.0) * economic_policy["holding_cost_scale"]
            mrp_policy = st.get("mrp_policy") or {}
            if isinstance(mrp_policy, dict):
                pair_mrp_safety_source_days[key] = max(0.0, to_float(mrp_policy.get("safety_time_days"), 0.0))
                pair_mrp_safety_time_days[key] = safety_calendar_days(
                    pair_mrp_safety_source_days[key], day=-warmup_days,
                    anchor_weekday=safety_calendar["weekday"], calendar=args.safety_time_calendar,
                )
                pair_mrp_safety_stock_qty[key] = max(0.0, to_float(mrp_policy.get("safety_stock_qty"), 0.0))

    reference_transition_stock_rows: list[dict[str, Any]] = []
    reference_substitutes_by_pair: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for transition in REFERENCE_TRANSITIONS:
        if not isinstance(transition, dict):
            continue
        node_id = str(transition.get("node_id") or transition.get("dst_node_id") or "").strip()
        new_item_id = str(transition.get("new_item_id") or "").strip()
        old_item_id = str(transition.get("old_item_id") or "").strip()
        if not node_id or not new_item_id or not old_item_id:
            continue
        old_key = (node_id, old_item_id)
        new_key = (node_id, new_item_id)
        initial_transition_stock = max(0.0, to_float(transition.get("initial_stock_qty"), 0.0))
        transition_uom = normalize_unit(transition.get("uom") or item_unit_map.get(new_item_id, ""))
        if transition_uom:
            item_unit_map.setdefault(old_item_id, transition_uom)
        else:
            item_unit_map.setdefault(old_item_id, item_unit_map.get(new_item_id, ""))
        if initial_transition_stock > 1e-9:
            stock[old_key] += initial_transition_stock
            base_stock[old_key] = 0.0
            holding_cost[old_key] = holding_cost.get(new_key, holding_cost.get(old_key, 0.0))
            if new_key in holding_cost_unknown_reasons:
                holding_cost_unknown_reasons[old_key] = holding_cost_unknown_reasons[new_key]
            observed_opening_stock_rows.append(
                {
                    "node_id": node_id,
                    "node_type": node_type_lookup_for_opening.get(node_id, ""),
                    "item_id": old_item_id,
                    "opening_stock_qty": round(initial_transition_stock, 6),
                    "uom": item_unit_map.get(old_item_id, transition_uom),
                    "source": "reference_transition_opening_stock",
                }
            )
        normalized_transition = dict(transition)
        normalized_transition["node_id"] = node_id
        normalized_transition["new_item_id"] = new_item_id
        normalized_transition["old_item_id"] = old_item_id
        normalized_transition["start_day"] = int(to_float(transition.get("start_day"), 0.0))
        normalized_transition["end_day"] = int(to_float(transition.get("end_day"), sim_days))
        normalized_transition["consume_policy"] = str(
            transition.get("consume_policy") or "use_old_until_new_stock_available"
        )
        reference_substitutes_by_pair[new_key].append(normalized_transition)
        reference_transition_stock_rows.append(
            {
                "node_id": node_id,
                "new_item_id": new_item_id,
                "old_item_id": old_item_id,
                "initial_stock_qty": round(initial_transition_stock, 6),
                "uom": item_unit_map.get(old_item_id, transition_uom),
                "consume_policy": normalized_transition["consume_policy"],
                "start_day": normalized_transition["start_day"],
                "end_day": normalized_transition["end_day"],
                "note": str(transition.get("note") or ""),
            }
        )
    opening_stock_source_snapshot = dict(stock)
    opening_observed_stock_scale_audit = {
        "enabled": bool(opening_observed_stock_scale_requested),
        "mode": (
            "pair_csv_overrides"
            if opening_observed_stock_scale_csv_requested
            else "global_factor"
        ),
        "factor": round(opening_observed_stock_scale, 9),
        "default_unlisted_pair_factor": round(opening_observed_stock_scale, 9),
        "source_csv": str(opening_observed_stock_scale_csv_path or ""),
        "source_csv_sha256": opening_observed_stock_scale_csv_sha256,
        "pair_overrides": [
            {
                "node_id": pair[0],
                "item_id": pair[1],
                "factor": round(factor, 9),
            }
            for pair, factor in sorted(
                opening_observed_stock_scale_overrides.items()
            )
        ],
        "application_stage": "graph_inventory_initial_before_warmup",
        "scope": (
            "listed_observed_graph_inventory_states_only"
            if opening_observed_stock_scale_csv_requested
            else "all_observed_graph_inventory_states"
        ),
        "observed_positive_state_count": len(observed_opening_stock_rows),
        "scaled_positive_state_count": (
            opening_observed_stock_scaled_positive_state_count
        ),
        "base_stock_alignment": (
            "scaled_for_non_mrp_pairs_mrp_snapshot_pairs_remain_state_only"
        ),
        "quantities_by_uom": {
            uom or "unspecified": {
                "source_qty": round(values["source_qty"], 6),
                "effective_qty": round(values["effective_qty"], 6),
            }
            for uom, values in sorted(opening_observed_stock_totals_by_uom.items())
        },
        "scientific_interpretation": (
            "pair_scoped_sensitivity_stress_test_not_calibrated_opening_state"
            if opening_observed_stock_scale_csv_requested
            else "global_sensitivity_stress_test_not_calibrated_opening_state"
        ),
    }

    lanes, lanes_by_dest_item = lane_records(
        edges,
        economic_policy=economic_policy,
        mrp_multisource_policy=args.mrp_multisource_policy,
    )
    lanes_with_fallback_transport_cost = sum(1 for l in lanes if bool(l.get("transport_cost_is_fallback")))
    lanes_with_explicit_transport_cost = len(lanes) - lanes_with_fallback_transport_cost
    lanes_by_src_item: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for lane in lanes:
        lanes_by_src_item[(str(lane["src"]), str(lane["item_id"]))].append(lane)
    node_type_by_id = {str(n.get("id")): str(n.get("type") or "") for n in nodes}
    supplier_node_ids = {
        node_id
        for node_id, node_type in node_type_by_id.items()
        if node_type == "supplier_dc"
    }
    dc_node_ids = {
        node_id
        for node_id, node_type in node_type_by_id.items()
        if node_type == "distribution_center"
    }
    for lane in lanes:
        if not bool(lane.get("purchase_cost_is_fallback")):
            continue
        src_type = node_type_by_id.get(str(lane.get("src")), "")
        dst_type = node_type_by_id.get(str(lane.get("dst")), "")
        if src_type in {"factory", "distribution_center"} or dst_type in {"distribution_center", "customer"}:
            lane["unit_purchase_cost"] = 0.0
            lane["purchase_cost_suppressed_reason"] = "internal_or_finished_goods_lane_without_purchase_price"
    supplier_factory_items: dict[str, set[tuple[str, str]]] = defaultdict(set)
    process_node_ids = {
        str(n.get("id"))
        for n in nodes
        if n.get("processes")
    }
    control_schedule_path = (
        Path(args.control_schedule_csv).resolve()
        if args.control_schedule_csv
        else None
    )
    control_probe_schedule_path = (
        Path(args.control_probe_schedule_csv).resolve()
        if args.control_probe_schedule_csv
        else None
    )
    control_policy_path = (
        Path(args.control_policy_json).resolve()
        if args.control_policy_json
        else None
    )
    control_policy_v2_path = (
        Path(args.control_policy_v2_json).resolve()
        if args.control_policy_v2_json
        else None
    )
    control_policy_v3_path = (
        Path(args.control_policy_v3_json).resolve()
        if args.control_policy_v3_json
        else None
    )
    selected_control_interfaces = sum(
        path is not None
        for path in (
            control_schedule_path,
            control_policy_path,
            control_policy_v2_path,
            control_policy_v3_path,
        )
    )
    if (
        control_schedule_path is not None
        and control_policy_path is not None
        and control_policy_v2_path is None
        and control_policy_v3_path is None
    ):
        raise SystemExit(
            "--control-schedule-csv and --control-policy-json are mutually exclusive."
        )
    if selected_control_interfaces > 1:
        if control_policy_v3_path is None:
            raise SystemExit(
                "--control-schedule-csv, --control-policy-json and "
                "--control-policy-v2-json are mutually exclusive."
            )
        raise SystemExit(
            "--control-schedule-csv, --control-policy-json, "
            "--control-policy-v2-json and --control-policy-v3-json are "
            "mutually exclusive."
        )
    if (
        control_probe_schedule_path is not None
        and control_policy_v2_path is None
        and control_policy_v3_path is None
    ):
        raise SystemExit(
            "--control-probe-schedule-csv requires "
            "--control-policy-v2-json or --control-policy-v3-json."
        )
    if (
        args.controller_prime_during_warmup
        and control_policy_v2_path is None
        and control_policy_v3_path is None
    ):
        raise SystemExit(
            "--controller-prime-during-warmup requires --control-policy-v2-json."
        )
    if args.controller_prime_during_warmup and warmup_days <= 0:
        raise SystemExit(
            "--controller-prime-during-warmup requires --warmup-days > 0."
        )
    known_item_ids = (
        set(item_unit_map)
        | {item_id for _, item_id in stock}
        | {str(lane.get("item_id") or "") for lane in lanes}
    )
    control_catalog = ControlCatalog(
        node_ids=set(node_by_id),
        supplier_ids=supplier_node_ids,
        item_ids={item_id for item_id in known_item_ids if item_id},
        dst_node_ids=set(node_by_id),
    )
    try:
        control_schedule = load_control_schedule(
            control_schedule_path,
            catalog=control_catalog,
        )
    except ControlScheduleError as exc:
        raise SystemExit(f"Invalid --control-schedule-csv: {exc}") from exc
    feedback_control: StateFeedbackControlProvider | None = None
    if control_policy_path is not None:
        try:
            feedback_control = load_state_feedback_control_provider(
                control_policy_path,
                catalog=control_catalog,
            )
        except ControlProviderError as exc:
            raise SystemExit(f"Invalid --control-policy-json: {exc}") from exc
    elif control_policy_v2_path is not None:
        try:
            feedback_control = load_state_feedback_control_provider_v2(
                control_policy_v2_path,
                catalog=control_catalog,
            )
        except ControlProviderError as exc:
            raise SystemExit(f"Invalid --control-policy-v2-json: {exc}") from exc
    elif control_policy_v3_path is not None:
        try:
            feedback_control = load_state_feedback_control_provider_v3(
                control_policy_v3_path,
                catalog=control_catalog,
            )
        except ControlProviderError as exc:
            raise SystemExit(f"Invalid --control-policy-v3-json: {exc}") from exc
    control_probe = None
    if control_probe_schedule_path is not None:
        try:
            control_probe = load_control_probe_schedule(
                control_probe_schedule_path,
                catalog=control_catalog,
            )
        except ControlProbeError as exc:
            raise SystemExit(
                f"Invalid --control-probe-schedule-csv: {exc}"
            ) from exc
    feedback_control_is_v2 = bool(control_policy_v2_path is not None)
    feedback_control_is_v3 = bool(control_policy_v3_path is not None)
    feedback_control_supports_priming = bool(
        feedback_control_is_v2 or feedback_control_is_v3
    )
    control_provider = feedback_control or control_schedule
    for warning in control_schedule.warnings:
        print(f"[WARN] control schedule: {warning}", file=sys.stderr)
    if feedback_control is not None:
        for warning in feedback_control.warnings:
            print(f"[WARN] state-feedback control: {warning}", file=sys.stderr)
    if control_probe is not None:
        for warning in control_probe.warnings:
            print(f"[WARN] control probe: {warning}", file=sys.stderr)
    control_schedule_sha256 = (
        hashlib.sha256(control_schedule_path.read_bytes()).hexdigest()
        if control_schedule_path is not None
        else ""
    )
    control_probe_schedule_sha256 = (
        hashlib.sha256(control_probe_schedule_path.read_bytes()).hexdigest()
        if control_probe_schedule_path is not None
        else ""
    )
    control_action_ledger_rows: list[dict[str, Any]] = []
    control_probe_composition_rows: dict[
        tuple[int, str, str, str, str, str], dict[str, Any]
    ] = {}
    control_applied_source_lines: set[int] = set()
    control_applied_actions: set[tuple[int, str]] = set()
    feedback_demand_history: deque[float] = deque(maxlen=28)
    feedback_previous_order_by_pair: dict[tuple[str, str], float] | None = None
    paired_rng_invocations: dict[str, int] = defaultdict(int)

    def feedback_audit_metadata_for_day(day: int) -> dict[str, Any]:
        if feedback_control is None:
            return {}
        metadata = dict(feedback_control.audit_metadata_for_day(day))
        command_audit = getattr(
            feedback_control,
            "command_audit_metadata_for_day",
            None,
        )
        if callable(command_audit):
            metadata.update(dict(command_audit(day)))
        return metadata

    def record_control_resolution(
        resolved: ResolvedControl,
        *,
        stage: str,
        action_names: tuple[str, ...],
        status: str = "applied",
        executed_control_volume_qty: float | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        """Append only the levers actually used at this operational stage.

        A resolved schedule contains all eight neutral-or-active values, but an
        MRP ordering stage does not, for example, execute a production-capacity
        lever.  Keeping the stage/action relationship explicit prevents the
        action ledger and downstream KPIs from counting scheduled controls as
        physical executions.
        """

        if not resolved.enabled:
            return
        payload = {
            "action_stage": stage,
            "executed_control_volume_qty": (
                round(max(0.0, executed_control_volume_qty), 6)
                if executed_control_volume_qty is not None
                else ""
            ),
            **feedback_audit_metadata_for_day(resolved.day),
            **(extra or {}),
        }
        selected_actions = set(action_names)
        rows = [
            row
            for row in resolved.to_ledger_rows(status=status, extra=payload)
            if str(row.get("action") or "") in selected_actions
        ]
        control_action_ledger_rows.extend(rows)
        control_applied_source_lines.update(
            int(row["source_line"])
            for row in rows
            if str(row.get("source_line") or "").strip()
        )
        control_applied_actions.update(
            (
                int(row["source_line"]),
                str(row["action"]),
            )
            for row in rows
            if str(row.get("source_line") or "").strip()
        )

    def paired_lane_rng(
        *,
        measured_day: int,
        lane: Mapping[str, Any],
        source_mode: str,
    ) -> random.Random:
        """Return a stable lane/day stream for common-random-number replays."""

        if not args.common_random_numbers:
            return rng
        identity = _paired_lead_time_identity(
            seed=int(args.seed),
            measured_day=int(measured_day),
            lane=lane,
            source_mode=source_mode,
        )
        # One lane can be sampled several times on the same day (for example
        # separate lots).  Key the nth invocation, rather than returning the
        # exact same variate for every call, while preserving nth-to-nth pairing
        # across policy replays that exercise the same physical path.
        invocation_ordinal = paired_rng_invocations[identity]
        paired_rng_invocations[identity] += 1
        return random.Random(
            _paired_lead_time_seed(identity, invocation_ordinal)
        )

    for lane in lanes:
        src = str(lane["src"])
        dst = str(lane["dst"])
        item_id = str(lane["item_id"])
        if src in supplier_node_ids and dst in process_node_ids:
            supplier_factory_items[src].add((dst, item_id))
    dc_factory_items: dict[str, set[tuple[str, str]]] = defaultdict(set)
    for lane in lanes:
        src = str(lane["src"])
        dst = str(lane["dst"])
        item_id = str(lane["item_id"])
        if dst in dc_node_ids and node_type_by_id.get(src) == "factory":
            dc_factory_items[dst].add((src, item_id))
    inbound_pairs = set(lanes_by_dest_item.keys())
    if measurement_start_in_transit_scale_csv_path is not None:
        try:
            (
                measurement_start_in_transit_scale_overrides,
                measurement_start_in_transit_scale_csv_sha256,
            ) = load_measurement_start_in_transit_scale_overrides(
                measurement_start_in_transit_scale_csv_path,
                valid_pairs=inbound_pairs,
            )
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
    outbound_pairs = {(str(l["src"]), str(l["item_id"])) for l in lanes}
    produced_pairs = {
        (str(n.get("id")), str((out or {}).get("item_id")))
        for n in nodes
        for p in (n.get("processes") or [])
        for out in (p.get("outputs") or [])
        if (out or {}).get("item_id") is not None
    }
    process_tau_days_by_pair: dict[tuple[str, str], float] = {}
    for n in nodes:
        nid = str(n.get("id"))
        for p in (n.get("processes") or []):
            tau_days = max(0.0, to_float(((p.get("wip") or {}).get("tau_process")), 0.0))
            for out in (p.get("outputs") or []):
                item_id = str((out or {}).get("item_id"))
                if not item_id:
                    continue
                key = (nid, item_id)
                process_tau_days_by_pair[key] = max(process_tau_days_by_pair.get(key, 0.0), tau_days)
    process_input_requirements_by_output_pair = build_process_input_requirements_by_output_pair(nodes, item_unit_map)
    production_lot_reference_qty_by_pair: dict[tuple[str, str], float] = {}
    production_lot_policy_by_pair: dict[tuple[str, str], dict[str, Any]] = {}
    process_capacity_by_output_pair: dict[tuple[str, str], float] = {}
    for node in nodes:
        node_id = str(node.get("id"))
        for proc in node.get("processes") or []:
            cap_raw = max(0.0, to_float(((proc.get("capacity") or {}).get("max_rate")), 0.0))
            for out in proc.get("outputs") or []:
                out_item = str((out or {}).get("item_id") or "")
                if not out_item:
                    continue
                lot_policy = process_lot_policy(proc, out_item=out_item, item_unit_map=item_unit_map)
                out_pair = (node_id, out_item)
                production_lot_policy_by_pair[out_pair] = lot_policy
                if cap_raw > 1e-9:
                    process_capacity_by_output_pair[out_pair] = max(
                        process_capacity_by_output_pair.get(out_pair, 0.0),
                        cap_raw,
                    )
                ref_qty = lot_reference_qty(lot_policy)
                if ref_qty > 1e-9:
                    production_lot_reference_qty_by_pair[out_pair] = max(
                        production_lot_reference_qty_by_pair.get(out_pair, 0.0),
                        ref_qty,
                    )
    # If a (node,item) can ship downstream but has no modeled inbound/production source,
    # treat missing upstream as supplier upstream supply to avoid artificial source depletion.
    externally_sourced_pairs = sorted(outbound_pairs - inbound_pairs - produced_pairs)
    externally_sourced_pairs_set = set(externally_sourced_pairs)
    source_boundary_policies: dict[tuple[str, str], dict[str, Any]] = {}
    if forecast_production_signal and graph_meta.get("source_boundary_supplies") is not None:
        if warmup_days:
            raise ValueError("Source boundary supply experiment requires no warmup")
        if unmodeled_supplier_source_mode != "external_procurement" or not economic_policy["external_procurement_enabled"]:
            raise ValueError("Source boundary supply requires the explicit external-supply mode")
        source_boundary_policies = source_boundary_supply_policies(
            graph_meta["source_boundary_supplies"],
            eligible_pairs={pair for pair in externally_sourced_pairs if pair[0] in process_node_ids},
            item_unit_map=item_unit_map,
        )
    source_boundary_order_ids: set[str] = set()
    demand_rows = scenario.get("demand", []) or []
    demand_pairs = [(str(d.get("node_id")), str(d.get("item_id"))) for d in demand_rows]
    finished_good_item_ids = {item_id for _, item_id in demand_pairs}
    demand_profiles = {
        (str(d.get("node_id")), str(d.get("item_id"))): (d.get("profile") or [])
        for d in demand_rows
    }
    # Fresh for every run, including repeated main() calls in one process.
    # Profiles are retained by demand_profiles and are not mutated during a run.
    demand_profile_value_cache: dict[tuple[int, int], float] = {}
    unknown_nonbinding_pairs = nonbinding_standard_order_pair_keys - {
        policy_pair_key(*pair) for pair in lanes_by_dest_item
    }
    if unknown_nonbinding_pairs:
        raise ValueError(f"Nonbinding standard order pairs have no incoming transport: {sorted(unknown_nonbinding_pairs)}")
    forecast_demand_pair_by_item = {
        item: next(pair for pair in demand_pairs if pair[1] == item)
        for item in {pair[1] for pair in demand_pairs}
        if sum(pair[1] == item for pair in demand_pairs) == 1
    }
    mrp_source_forecasts: RollingMrpForecast | None = None
    if args.mrp_forecast_source == "source":
        if warmup_days or args.warmup_profile_mode != "restart":
            raise ValueError("Source MRP forecasts require no warmup and the absolute restart timeline")
        mrp_source_forecasts = RollingMrpForecast(
            graph_meta.get("mrp_forecasts"), demand_pairs=set(demand_pairs),
            origin_date=safety_calendar["start_date"],
        )

    def planning_forecast_window(
        pair: tuple[str, str], *, decision_day: int, target_day: int, window_days: int,
    ) -> tuple[float, dict[str, Any]]:
        """Planning-only overlay: never write to the physical demand profiles."""
        assert mrp_source_forecasts is not None
        fallback = [
            max(0.0, _cached_profile_value(demand_profiles[pair], target_day + offset, demand_profile_value_cache))
            for offset in range(window_days)
        ]
        return mrp_source_forecasts.window(
            pair, decision_day=decision_day, target_day=target_day, fallback_daily_values=fallback,
        )

    def planning_demand_targets_for_day(
        decision_day: int, target_day: int, *, window_days: int,
    ) -> dict[tuple[str, str], float]:
        if mrp_source_forecasts is None:
            return demand_targets_for_day(
                demand_profiles, target_day, window_days=window_days, value_cache=demand_profile_value_cache,
            )
        return {pair: planning_forecast_window(
            pair, decision_day=decision_day, target_day=target_day, window_days=window_days,
        )[0] for pair in demand_profiles}

    demand_perturbation_path = (
        Path(args.demand_perturbation_csv).resolve()
        if args.demand_perturbation_csv
        else None
    )
    try:
        demand_perturbation = load_demand_perturbation_schedule(
            demand_perturbation_path,
            demand_pairs=set(demand_pairs),
            measured_days=sim_days,
        )
    except DemandPerturbationError as exc:
        raise SystemExit(f"Invalid --demand-perturbation-csv: {exc}") from exc
    demand_perturbation_sha256 = (
        hashlib.sha256(demand_perturbation_path.read_bytes()).hexdigest()
        if demand_perturbation_path is not None
        else ""
    )
    demand_perturbation_audit_rows: list[dict[str, Any]] = []
    demand_perturbation_applied_keys: set[tuple[int, str, str]] = set()
    pipeline_meta = (
        graph_meta.get("generated_by_pipeline")
        if isinstance(graph_meta.get("generated_by_pipeline"), dict)
        else {}
    )
    demand_profile_cycle_days = int(round(max(0.0, to_float(pipeline_meta.get("repeat_period_days"), 0.0))))
    if demand_profile_cycle_days <= 0:
        demand_profile_cycle_days = max(
            [
                int(to_float(point.get("t"), -1)) + 1
                for profile in demand_profiles.values()
                for point in profile
                if isinstance(point, dict)
            ]
            or [sim_days]
        )
    demand_profile_cycle_days = max(1, demand_profile_cycle_days)
    mrp_signal_smoothing_days = (
        initialization_policy["mrp_demand_signal_smoothing_days"]
        if initialization_policy["use_bom_demand_signal_for_mrp"]
        else 1
    )
    mrp_demand_signal_source = (
        initialization_policy["mrp_demand_signal_source"]
        if initialization_policy["use_bom_demand_signal_for_mrp"]
        else "demand"
    )
    demand_target_daily = demand_targets_for_day(
        demand_profiles,
        0,
        window_days=mrp_signal_smoothing_days,
        value_cache=demand_profile_value_cache,
    )
    if mrp_source_forecasts is not None:
        demand_target_daily = planning_demand_targets_for_day(0, 0, window_days=mrp_signal_smoothing_days)
    if (
        initialization_policy["use_bom_demand_signal_for_mrp"]
        and mrp_demand_signal_source == "mps_lotified"
    ):
        same_item_demand_daily = propagate_demand_rates(demand_target_daily, lanes)
        if forecast_production_signal:
            same_item_demand_daily = propagate_supply_demand_rates(
                demand_target_daily, lanes, process_input_requirements_by_output_pair,
            )
        mps_component_signal_daily, _mps_output_signal_daily = lotified_mps_component_signal(
            same_item_demand_daily,
            day=0,
            process_input_requirements_by_output_pair=process_input_requirements_by_output_pair,
            production_lot_policy_by_pair=production_lot_policy_by_pair,
            process_capacity_by_output_pair=process_capacity_by_output_pair,
            mps_open_campaign_qty_by_pair=defaultdict(float),
            mps_started_lots_by_week_pair=defaultdict(int),
            expand_internal_outputs=not forecast_production_signal,
        )
        # The multilevel forecast seeds each manufacturing process. Only the
        # same-item PF flow is retained here before adding its lotified needs;
        # retaining the exploded forecast too would double count components.
        propagated_demand_daily = (
            propagate_demand_rates(demand_target_daily, lanes)
            if forecast_production_signal else dict(same_item_demand_daily)
        )
        for pair, qty in propagate_demand_rates(mps_component_signal_daily, lanes).items():
            propagated_demand_daily[pair] = propagated_demand_daily.get(pair, 0.0) + qty
    elif initialization_policy["use_bom_demand_signal_for_mrp"]:
        propagated_demand_daily = propagate_supply_demand_rates(
            demand_target_daily,
            lanes,
            process_input_requirements_by_output_pair,
        )
    else:
        propagated_demand_daily = propagate_demand_rates(demand_target_daily, lanes)
    if initialization_policy["use_bom_demand_signal_for_mrp"]:
        propagated_mrp_signal_pairs = set(
            propagate_supply_demand_rates(
                {pair: 1.0 for pair in demand_profiles},
                lanes,
                process_input_requirements_by_output_pair,
            )
        )
    else:
        propagated_mrp_signal_pairs = set()

    # Small safety target for pairs with demand signal if base stock is absent.
    for pair, d0 in propagated_demand_daily.items():
        if pair not in inbound_pairs:
            continue
        if base_stock.get(pair, 0.0) <= 0:
            base_stock[pair] = max(50.0, 7.0 * d0)

    backlog: dict[tuple[str, str], float] = defaultdict(float)
    pipeline: dict[int, list[tuple[str, str, float, str]]] = defaultdict(list)
    external_pipeline: dict[int, list[tuple[str, str, float, str, str, str]]] = defaultdict(list)
    estimated_source_pipeline: dict[int, list[tuple[str, str, float]]] = defaultdict(list)
    in_transit: dict[tuple[str, str], float] = defaultdict(float)
    external_in_transit: dict[tuple[str, str], float] = defaultdict(float)
    estimated_source_in_transit: dict[tuple[str, str], float] = defaultdict(float)
    dated_receipt_netting = args.mrp_receipt_netting_mode == "within_cover"
    pending_receipt_calendar = DatedReceiptCalendar() if dated_receipt_netting else None
    if dated_component_planning and (dated_receipt_netting or not forecast_production_signal):
        raise ValueError("Dated execution requires the forecast production signal and all_future commitment mode")
    planning_commitments_by_pair: dict = defaultdict(dict)
    supplier_delivery_orders: dict[str, dict[str, Any]] = {}
    dated_plan_daily_rows: list[dict[str, Any]] = []
    dated_plan_weekly_rows: list[dict[str, Any]] = []
    if dated_receipt_netting and measurement_start_in_transit_scale_csv_path:
        raise ValueError("Dated receipt netting cannot be combined with measurement-start pipeline scaling")

    total_demand = 0.0
    total_served = 0.0
    measurement_starting_backlog = 0.0
    warmup_backlog_cleared_qty = 0.0
    total_shipped = 0.0
    total_arrived = 0.0
    total_produced = 0.0
    total_transport_cost = 0.0
    total_holding_cost = 0.0
    total_warehouse_operating_cost = 0.0
    total_inventory_risk_cost = 0.0
    total_legacy_raw_holding_cost = 0.0
    total_external_procured = 0.0
    total_external_procured_arrived = 0.0
    total_external_procured_rejected = 0.0
    total_external_quality_rejected = 0.0
    external_quality_loss_by_pair: dict[tuple[str, str], float] = defaultdict(float)
    total_unreliable_loss_qty = 0.0
    total_purchase_cost = 0.0
    total_production_cost = 0.0
    total_external_procurement_cost = 0.0
    total_estimated_source_replenished = 0.0
    total_estimated_source_ordered = 0.0
    total_estimated_source_rejected = 0.0

    daily_rows: list[dict[str, Any]] = []
    input_stock_rows: list[dict[str, Any]] = []
    output_prod_rows: list[dict[str, Any]] = []
    input_consumption_rows: list[dict[str, Any]] = []
    opening_production_consumption_rows: list[dict[str, Any]] = []
    input_arrival_rows: list[dict[str, Any]] = []
    input_shipment_rows: list[dict[str, Any]] = []
    supplier_shipment_rows: list[dict[str, Any]] = []
    supplier_shipment_sequence = 0
    supplier_stock_rows: list[dict[str, Any]] = []
    supplier_stock_flow_rows: list[dict[str, Any]] = []
    dc_stock_rows: list[dict[str, Any]] = []
    demand_pair_rows: list[dict[str, Any]] = []
    production_constraint_rows: list[dict[str, Any]] = []
    production_plan_event_rows: list[dict[str, Any]] = []
    mrp_trace_rows: list[dict[str, Any]] = []
    mrp_order_rows: list[dict[str, Any]] = []
    production_cost_qty_by_day_pair: dict[tuple[int, str, str], float] = defaultdict(float)

    production_input_pairs: list[tuple[str, str]] = []
    production_output_pairs: list[tuple[str, str]] = []
    unconstrained_input_pairs: list[tuple[str, str]] = []
    input_unit_conversions_applied: set[tuple[str, str, str, str]] = set()
    input_unit_mismatch_not_converted: set[tuple[str, str, str, str]] = set()
    seen_input_pairs: set[tuple[str, str]] = set()
    seen_output_pairs: set[tuple[str, str]] = set()
    seen_unconstrained: set[tuple[str, str]] = set()
    stock_pairs = set(stock.keys())
    supplier_stock_pairs = sorted(
        {
            pair
            for pair in (stock_pairs | outbound_pairs)
            if pair[0] in supplier_node_ids
        }
    )
    dc_stock_pairs = sorted(
        {
            pair
            for pair in (stock_pairs | inbound_pairs | outbound_pairs)
            if pair[0] in dc_node_ids
        }
    )
    for n in nodes:
        nid = str(n.get("id"))
        for p in (n.get("processes") or []):
            for inp in (p.get("inputs") or []):
                key = (nid, str(inp.get("item_id")))
                # "Input production" means components that actually arrive via supply relations.
                if key in inbound_pairs and key not in seen_input_pairs:
                    seen_input_pairs.add(key)
                    production_input_pairs.append(key)
                # Inputs not represented by relations/inventory are treated as external/non-modeled.
                if key not in inbound_pairs and key not in stock_pairs and key not in seen_unconstrained:
                    seen_unconstrained.add(key)
                    unconstrained_input_pairs.append(key)
            for out in (p.get("outputs") or []):
                key = (nid, str(out.get("item_id")))
                if key not in seen_output_pairs:
                    seen_output_pairs.add(key)
                    production_output_pairs.append(key)
    for new_key, transitions in reference_substitutes_by_pair.items():
        if new_key not in seen_input_pairs and new_key not in inbound_pairs:
            continue
        for transition in transitions:
            old_key = (new_key[0], str(transition.get("old_item_id") or ""))
            if old_key in stock_pairs and old_key not in seen_input_pairs:
                seen_input_pairs.add(old_key)
                production_input_pairs.append(old_key)
    production_input_pairs = sorted(production_input_pairs)
    production_output_pairs = sorted(production_output_pairs)
    mrp_trace_pairs = sorted(
        stock_pairs
        | inbound_pairs
        | set(demand_pairs)
        | produced_pairs
        | set(production_input_pairs)
        | set(production_output_pairs)
        | set(externally_sourced_pairs)
        | set(mrp_snapshot_pairs)
    )
    cum_output_by_pair: dict[tuple[str, str], float] = defaultdict(float)
    prev_production_command_by_pair: dict[tuple[str, str], float] = {}
    open_production_campaign_qty_by_pair: dict[tuple[str, str], float] = defaultdict(float)
    open_production_campaign_id_by_pair: dict[tuple[str, str], str] = {}
    production_campaign_started_day_by_pair: dict[tuple[str, str], int] = {}
    production_campaign_requested_qty_by_pair: dict[tuple[str, str], float] = {}
    production_campaign_target_qty_by_pair: dict[tuple[str, str], float] = {}
    production_batch_wip_by_pair: dict[tuple[str, str], ProductionBatchWip] = {}
    production_batch_sequence_by_campaign: dict[str, int] = defaultdict(int)
    pending_production_campaign_id_by_pair: dict[tuple[str, str], str] = {}
    production_campaign_causality_by_id: dict[str, dict[str, str]] = {}
    started_production_lots_by_week_pair: dict[tuple[int, tuple[str, str]], int] = defaultdict(int)
    mps_prev_production_command_by_pair: dict[tuple[str, str], float] = {}
    mps_open_campaign_qty_by_pair: dict[tuple[str, str], float] = defaultdict(float)
    mps_started_lots_by_week_pair: dict[tuple[int, tuple[str, str]], int] = defaultdict(int)
    pair_max_lead_days: dict[tuple[str, str], int] = {}
    pair_stock_cover_days: dict[tuple[str, str], int] = {}
    for pair, lane_list in lanes_by_dest_item.items():
        pair_max_lead_days[pair] = max(int(to_float(l.get("lead_days"), 1.0)) for l in lane_list) if lane_list else 1
        max_cover = (
            max(lead_time_cover_days(l, args.stochastic_lead_times, lead_time_distribution_mode) for l in lane_list)
            if lane_list
            else 1
        )
        pair_stock_cover_days[pair] = (
            max_cover + review_period_days + int(math.ceil(pair_mrp_safety_time_days.get(pair, 0.0)))
        )

    mrp_target_cutover_context_days = max(0, int(args.mrp_target_cutover_context_days or 0))
    mrp_target_demand_floor_cache: dict[tuple[Any, ...], dict[tuple[str, str], float]] = {}

    def mrp_target_demand_floor_by_pair(
        target_profile_day: int,
        window_days: int,
        *,
        include_cutover_context: bool = False,
    ) -> dict[tuple[str, str], float]:
        """Forward-looking demand floor used to size MRP targets.

        The short daily MRP signal is useful for order cadence, but safety and
        cover targets must not collapse at the beginning of the horizon when
        demand ramps up a few days later. This floor averages demand over the
        actual cover horizon and propagates it through the network.
        """
        effective_window_days = max(1, int(math.ceil(max(float(window_days), float(mrp_signal_smoothing_days)))))
        profile_day_int = int(target_profile_day)
        cache_key = (profile_day_int, effective_window_days, bool(include_cutover_context))
        if mrp_source_forecasts is not None:
            cache_key += (mrp_source_forecasts.selection(output_day),)
        cached = mrp_target_demand_floor_cache.get(cache_key)
        if cached is not None:
            return cached

        def propagated_floor_for_window(window_start_day: int) -> dict[tuple[str, str], float]:
            demand_target_floor = demand_targets_for_day(
                demand_profiles,
                int(window_start_day),
                window_days=effective_window_days,
                value_cache=demand_profile_value_cache,
            )
            if mrp_source_forecasts is not None:
                demand_target_floor = planning_demand_targets_for_day(
                    output_day, int(window_start_day), window_days=effective_window_days,
                )
            if not initialization_policy["use_bom_demand_signal_for_mrp"]:
                return propagate_demand_rates(demand_target_floor, lanes)
            propagated_floor = propagate_supply_demand_rates(
                demand_target_floor,
                lanes,
                process_input_requirements_by_output_pair,
            )
            if mrp_demand_signal_source == "mps_lotified":
                same_item_floor = propagate_demand_rates(demand_target_floor, lanes)
                for floor_pair, qty in same_item_floor.items():
                    propagated_floor[floor_pair] = max(propagated_floor.get(floor_pair, 0.0), qty)
            return propagated_floor

        propagated_floor = propagated_floor_for_window(profile_day_int)
        if include_cutover_context and 0 <= profile_day_int < mrp_target_cutover_context_days:
            carry_in_floor = propagated_floor_for_window(profile_day_int - mrp_target_cutover_context_days)
            for floor_pair, qty in carry_in_floor.items():
                propagated_floor[floor_pair] = max(propagated_floor.get(floor_pair, 0.0), qty)

        mrp_target_demand_floor_cache[cache_key] = propagated_floor
        return propagated_floor

    # Legacy bootstrap or explicit initial state preparation.
    opening_stock_bootstrap_rows: list[dict[str, Any]] = []
    total_opening_stock_bootstrap = 0.0
    initialization_state_rows: list[dict[str, Any]] = []
    initialization_pipeline_rows: list[dict[str, Any]] = []
    total_initialization_stock_added = 0.0
    total_initialization_pipeline_seeded = 0.0
    opening_open_order_rows: list[dict[str, Any]] = []
    total_opening_open_order_qty = 0.0
    opening_open_order_bridge_days_by_pair: dict[tuple[str, str], int] = {}
    opening_open_order_source = "none"
    opening_purchase_order_risk_audit_rows: list[dict[str, Any]] = []
    opening_purchase_order_risk_warnings: list[str] = []
    supplier_risk_applied_rows: list[dict[str, Any]] = []
    assumptions_ledger_rows: list[dict[str, Any]] = []
    if opening_observed_stock_global_scale_requested:
        assumptions_ledger_rows.append(
            {
                "category": "opening_observed_stock_scale",
                "node_id": "",
                "item_id": "",
                "edge_id": "",
                "source": "cli_sensitivity_assumption",
                "payload_json": json.dumps(
                    opening_observed_stock_scale_audit,
                    ensure_ascii=False,
                    sort_keys=True,
                ),
            }
        )
    elif opening_observed_stock_scale_csv_requested:
        for pair, factor in sorted(
            opening_observed_stock_scale_overrides.items()
        ):
            assumptions_ledger_rows.append(
                {
                    "category": "opening_observed_stock_scale",
                    "node_id": pair[0],
                    "item_id": pair[1],
                    "edge_id": "",
                    "source": str(opening_observed_stock_scale_csv_path),
                    "payload_json": json.dumps(
                        {
                            "node_id": pair[0],
                            "item_id": pair[1],
                            "factor": round(factor, 9),
                            "application_stage": (
                                "graph_inventory_initial_before_warmup"
                            ),
                            "source_csv_sha256": (
                                opening_observed_stock_scale_csv_sha256
                            ),
                            "scientific_interpretation": (
                                "pair_scoped_sensitivity_stress_test_not_"
                                "calibrated_opening_state"
                            ),
                        },
                        ensure_ascii=False,
                        sort_keys=True,
                    ),
                }
            )
    for row in reference_transition_stock_rows:
        assumptions_ledger_rows.append(
            {
                "category": "reference_transition_stock",
                "node_id": str(row.get("node_id") or ""),
                "item_id": str(row.get("new_item_id") or ""),
                "edge_id": "",
                "source": "case_config_reference_transitions",
                "payload_json": json.dumps(row, ensure_ascii=False, sort_keys=True),
            }
        )
    for lane in lanes:
        note = str(lane.get("standard_order_qty_note") or "")
        if note:
            assumptions_ledger_rows.append(
                {
                    "category": "data_quality_override",
                    "node_id": str(lane.get("dst", "")),
                    "item_id": str(lane.get("item_id", "")),
                    "edge_id": str(lane.get("edge_id", "")),
                    "source": "simulation_lane_standard_order_qty_override",
                    "payload_json": json.dumps(
                        {
                            "src_node_id": str(lane.get("src", "")),
                            "dst_node_id": str(lane.get("dst", "")),
                            "item_id": str(lane.get("item_id", "")),
                            "standard_order_qty": round(max(0.0, to_float(lane.get("standard_order_qty"), 0.0)), 6),
                            "standard_order_uom": str(lane.get("standard_order_uom", "")),
                            "note": note,
                        },
                        ensure_ascii=False,
                        sort_keys=True,
                    ),
                }
            )
        physical_dispatch_multiple = max(
            0.0,
            to_float(lane.get("physical_dispatch_multiple"), 0.0),
        )
        if physical_dispatch_multiple > 1e-9:
            assumptions_ledger_rows.append(
                {
                    "category": "internal_physical_dispatch_policy",
                    "node_id": str(lane.get("dst", "")),
                    "item_id": str(lane.get("item_id", "")),
                    "edge_id": str(lane.get("edge_id", "")),
                    "source": str(
                        lane.get("physical_dispatch_policy_source")
                        or "production_lot_policy"
                    ),
                    "payload_json": json.dumps(
                        {
                            "src_node_id": str(lane.get("src", "")),
                            "dst_node_id": str(lane.get("dst", "")),
                            "item_id": str(lane.get("item_id", "")),
                            "physical_dispatch_multiple": round(
                                physical_dispatch_multiple,
                                6,
                            ),
                            "physical_dispatch_uom": str(
                                lane.get("physical_dispatch_uom", "")
                            ),
                            "scope": str(
                                lane.get("physical_dispatch_policy_scope", "")
                            ),
                            "confidence": str(
                                lane.get("physical_dispatch_policy_confidence", "")
                            ),
                            "mrp_standard_order_qty_unchanged": True,
                        },
                        ensure_ascii=False,
                        sort_keys=True,
                    ),
                }
            )
    opening_stock_bootstrap_scale = max(
        0.0,
        to_float(scenario.get("opening_stock_bootstrap_scale", 1.0), 1.0),
    )
    required_daily_input_by_pair: dict[tuple[str, str], float] = defaultdict(float)
    for n in nodes:
        nid = str(n.get("id"))
        for p in (n.get("processes") or []):
            cap = to_float(((p.get("capacity") or {}).get("max_rate")), 0.0)
            if cap <= 0:
                continue
            batch_size = to_float(p.get("batch_size"), 1000.0)
            if batch_size <= 0:
                batch_size = 1000.0
            for inp in (p.get("inputs") or []):
                in_item = str(inp.get("item_id"))
                key = (nid, in_item)
                modeled_input = key in inbound_pairs or key in stock_pairs
                if not modeled_input:
                    continue
                ratio = to_float(inp.get("ratio_per_batch"), 0.0)
                req_per_unit_raw = ratio / batch_size if batch_size > 0 else 0.0
                input_unit = normalize_unit(inp.get("ratio_unit"))
                item_unit = normalize_unit(item_unit_map.get(in_item, input_unit))
                req_per_unit = convert_quantity(req_per_unit_raw, input_unit, item_unit)
                if req_per_unit > 0:
                    required_daily_input_by_pair[key] += cap * req_per_unit

    if initialization_policy["mode"] == "legacy_bootstrap":
        for pair, daily_req in required_daily_input_by_pair.items():
            cover_days = pair_stock_cover_days.get(pair, pair_max_lead_days.get(pair, 1) + review_period_days)
            target = max(
                base_stock.get(pair, 0.0),
                daily_req * float(cover_days),
                safety_stock_days * daily_req,
            )
            current = stock.get(pair, 0.0)
            target *= opening_stock_bootstrap_scale
            if target > current + 1e-9:
                add_qty = physical_execution_quantity(target - current, item_unit_map.get(pair[1], ""))
                stock[pair] = current + add_qty
                base_stock[pair] = target
                total_opening_stock_bootstrap += add_qty
                opening_stock_bootstrap_rows.append(
                    {
                        "node_id": pair[0],
                        "item_id": pair[1],
                        "lead_days": pair_max_lead_days.get(pair, 1),
                        "cover_days": cover_days,
                        "daily_req_at_cap": round(daily_req, 6),
                        "added_opening_qty": round(add_qty, 6),
                        "target_opening_stock": round(target, 6),
                    }
                )

    # Supplier/process nodes shipping an internally manufactured intermediate also need a finished-goods buffer.
    # Otherwise the simulation falls into pure JIT after a few days and the supplier stock chart suggests a false rupture.
    output_daily_signal_by_pair: dict[tuple[str, str], float] = defaultdict(float)
    for pair in sorted(produced_pairs & outbound_pairs):
        for lane in lanes_by_src_item.get(pair, []):
            dst_pair = (str(lane.get("dst")), pair[1])
            output_daily_signal_by_pair[pair] += required_daily_input_by_pair.get(dst_pair, 0.0)

    if initialization_policy["mode"] == "legacy_bootstrap":
        for pair, daily_signal in sorted(output_daily_signal_by_pair.items()):
            node_id, item_id = pair
            if node_id not in supplier_node_ids or daily_signal <= 0:
                continue
            downstream_cover_days = max(
                [
                    lead_time_cover_days(l, args.stochastic_lead_times, lead_time_distribution_mode)
                    for l in lanes_by_src_item.get(pair, [])
                ]
                or [1]
            )
            process_tau_days = process_tau_days_by_pair.get(pair, 0.0)
            cover_days = max(
                downstream_cover_days + review_period_days,
                int(math.ceil(process_tau_days)) + review_period_days,
                int(math.ceil(safety_stock_days)),
            )
            target = max(base_stock.get(pair, 0.0), daily_signal * float(cover_days))
            target *= opening_stock_bootstrap_scale
            current = stock.get(pair, 0.0)
            if target > current + 1e-9:
                add_qty = physical_execution_quantity(target - current, item_unit_map.get(pair[1], ""))
                stock[pair] = current + add_qty
                base_stock[pair] = target
                total_opening_stock_bootstrap += add_qty
                opening_stock_bootstrap_rows.append(
                    {
                        "node_id": node_id,
                        "item_id": item_id,
                        "lead_days": downstream_cover_days,
                        "cover_days": cover_days,
                        "daily_req_at_cap": round(daily_signal, 6),
                        "added_opening_qty": round(add_qty, 6),
                        "target_opening_stock": round(target, 6),
                        "bootstrap_kind": "process_output_fg",
                    }
                )
    opening_stock_bootstrap_rows.sort(key=lambda r: (r["node_id"], r["item_id"]))

    supplier_daily_capacity_by_pair, supplier_capacity_metadata_rows = derive_supplier_daily_capacity_by_pair(
        nodes=nodes,
        supplier_node_ids=supplier_node_ids,
        lanes_by_src_item=lanes_by_src_item,
        required_daily_input_by_pair=required_daily_input_by_pair,
        propagated_demand_today=propagated_demand_daily,
        item_unit_map=item_unit_map,
        stock=stock,
        default_review_period_days=review_period_days,
        stochastic_lead_times=args.stochastic_lead_times,
        lead_time_distribution_mode=lead_time_distribution_mode,
        dynamic_requirement_pair_keys=dynamic_requirement_pair_keys,
    )
    if supplier_capacity_floor_overrides:
        capacity_meta_by_pair = {
            (str(row.get("node_id") or ""), str(row.get("item_id") or "")): row
            for row in supplier_capacity_metadata_rows
        }
        for src_pair, capacity_floor in supplier_capacity_floor_overrides.items():
            if src_pair[0] not in supplier_node_ids:
                continue
            if src_pair not in supplier_daily_capacity_by_pair:
                continue
            supplier_daily_capacity_by_pair[src_pair] = max(0.0, capacity_floor)
            meta = capacity_meta_by_pair.get(src_pair)
            if meta is not None:
                meta["nominal_capacity_qty_per_day"] = round(max(0.0, capacity_floor), 6)
                meta["applied_capacity_scale"] = 1.0 if capacity_floor > 1e-9 else 0.0
                meta["effective_capacity_qty_per_day"] = round(max(0.0, capacity_floor), 6)
                meta["basis"] = "supplier_capacity_override_from_csv"

    def apply_supplier_stock_floor_overrides() -> None:
        if not supplier_stock_floor_overrides:
            return
        for src_pair, stock_floor in supplier_stock_floor_overrides.items():
            if src_pair[0] not in supplier_node_ids:
                continue
            if src_pair not in stock:
                continue
            floor_qty = physical_execution_quantity(stock_floor, item_unit_map.get(src_pair[1], ""))
            stock[src_pair] = floor_qty
            base_stock[src_pair] = min(max(0.0, base_stock.get(src_pair, floor_qty)), floor_qty)

    apply_supplier_stock_floor_overrides()
    estimated_source_policies, estimated_source_policy_rows = derive_unmodeled_supplier_source_policies(
        externally_sourced_pairs=externally_sourced_pairs,
        nodes=nodes,
        lanes_by_src_item=lanes_by_src_item,
        supplier_daily_capacity_by_pair=supplier_daily_capacity_by_pair,
        base_stock=base_stock,
        required_daily_input_by_pair=required_daily_input_by_pair,
        propagated_demand_today=propagated_demand_daily,
        item_unit_map=item_unit_map,
        default_review_period_days=review_period_days,
        safety_stock_days=safety_stock_days,
        stochastic_lead_times=args.stochastic_lead_times,
        lead_time_distribution_mode=lead_time_distribution_mode,
        dynamic_requirement_pair_keys=dynamic_requirement_pair_keys,
    )
    estimated_source_policy_rows_by_pair = {
        (str(row.get("node_id") or ""), str(row.get("item_id") or "")): row
        for row in estimated_source_policy_rows
    }
    if initialization_policy["mode"] == "explicit_state":
        state_scale = initialization_policy["state_scale"]

        def ensure_stock_target(
            pair: tuple[str, str],
            target: float,
            *,
            category: str,
            daily_signal: float,
            cover_days: float,
        ) -> None:
            nonlocal total_initialization_stock_added
            raw_target = max(0.0, target)
            if raw_target <= 1e-9:
                return
            # Estimated upstream supplier sources need their opening buffer at full scale.
            # If we also shrink them with state_scale, the supplier can remain artificially
            # pinned at zero stock while shipping at full daily capacity.
            if category == "estimated_source_on_hand":
                target = max(base_stock.get(pair, 0.0), raw_target)
            else:
                target = max(base_stock.get(pair, 0.0), raw_target * state_scale)
            current = stock.get(pair, 0.0)
            if target <= current + 1e-9:
                base_stock[pair] = max(base_stock.get(pair, 0.0), target)
                return
            add_qty = physical_execution_quantity(target - current, item_unit_map.get(pair[1], ""))
            stock[pair] = current + add_qty
            base_stock[pair] = target
            total_initialization_stock_added += add_qty
            initialization_state_rows.append(
                {
                    "node_id": pair[0],
                    "item_id": pair[1],
                    "category": category,
                    "daily_signal": round(daily_signal, 6),
                    "cover_days": round(cover_days, 6),
                    "added_opening_qty": round(add_qty, 6),
                    "target_opening_stock": round(target, 6),
                }
            )

        def ensure_seeded_in_transit(
            pair: tuple[str, str],
            lane_list: list[dict[str, Any]],
            daily_signal: float,
            *,
            category: str,
        ) -> None:
            nonlocal total_initialization_pipeline_seeded
            if not initialization_policy["seed_in_transit"] or daily_signal <= 1e-9 or not lane_list:
                return
            fill_ratio = initialization_policy["in_transit_fill_ratio"]
            for lane in lane_list:
                lead_days = lead_time_cover_days(lane, args.stochastic_lead_times, lead_time_distribution_mode)
                if lead_days <= 0:
                    continue
                share = max(0.0, to_float(lane.get("mrp_share"), 0.0))
                if share <= 0:
                    share = 1.0 / float(len(lane_list))
                transit_qty = daily_signal * share * float(lead_days) * fill_ratio
                if transit_qty <= 1e-9:
                    continue
                transit_qty = physical_execution_quantity(transit_qty, item_unit_map.get(pair[1], ""))
                seed_lane_pipeline_uniform(
                    pipeline,
                    in_transit,
                    dst=pair[0],
                    item_id=pair[1],
                    qty=transit_qty,
                    edge_id=str(lane.get("edge_id", "")),
                    lead_days=lead_days,
                    uom=item_unit_map.get(pair[1], ""),
                )
                total_initialization_pipeline_seeded += transit_qty
                initialization_pipeline_rows.append(
                    {
                        "node_id": pair[0],
                        "item_id": pair[1],
                        "category": category,
                        "seeded_pipeline_qty": round(transit_qty, 6),
                        "lead_days": int(lead_days),
                        "lane_src": str(lane.get("src", "")),
                    }
                )

        for pair, daily_req in sorted(required_daily_input_by_pair.items()):
            if pair[0] not in process_node_ids or daily_req <= 1e-9:
                continue
            category_prefix = "factory" if node_type_by_id.get(pair[0]) == "factory" else "process_node"
            safety_cover_days = (
                pair_mrp_safety_time_days.get(pair, 0.0)
                if initialization_policy["seed_safety_time_on_hand"]
                else 0.0
            )
            cover_days = (
                initialization_policy["factory_input_on_hand_days"]
                + safety_cover_days
            )
            ensure_stock_target(
                pair,
                daily_req * cover_days,
                category=f"{category_prefix}_input_on_hand",
                daily_signal=daily_req,
                cover_days=cover_days,
            )
            ensure_seeded_in_transit(
                pair,
                lanes_by_dest_item.get(pair, []),
                daily_req,
                category=f"{category_prefix}_input_in_transit",
            )

        for pair, daily_signal in sorted(output_daily_signal_by_pair.items()):
            node_id, _item_id = pair
            if node_id not in supplier_node_ids or daily_signal <= 1e-9:
                continue
            if initialization_policy["seed_safety_time_on_hand"]:
                cover_days = max(
                    initialization_policy["supplier_output_on_hand_days"],
                    float(review_period_days)
                    + process_tau_days_by_pair.get(pair, 0.0)
                    + pair_mrp_safety_time_days.get(pair, 0.0),
                )
            else:
                cover_days = initialization_policy["supplier_output_on_hand_days"]
            ensure_stock_target(
                pair,
                daily_signal * cover_days,
                category="supplier_output_on_hand",
                daily_signal=daily_signal,
                cover_days=cover_days,
            )

        dc_pairs = sorted({pair for pair in outbound_pairs if pair[0] in dc_node_ids})
        for pair in dc_pairs:
            daily_signal = max(0.0, propagated_demand_daily.get(pair, 0.0))
            if daily_signal <= 1e-9:
                continue
            safety_cover_days = (
                pair_mrp_safety_time_days.get(pair, 0.0)
                if initialization_policy["seed_safety_time_on_hand"]
                else 0.0
            )
            cover_days = (
                initialization_policy["distribution_center_on_hand_days"]
                + safety_cover_days
            )
            ensure_stock_target(
                pair,
                daily_signal * cover_days,
                category="distribution_center_on_hand",
                daily_signal=daily_signal,
                cover_days=cover_days,
            )
            ensure_seeded_in_transit(
                pair,
                lanes_by_dest_item.get(pair, []),
                daily_signal,
                category="distribution_center_in_transit",
            )

        customer_days = initialization_policy["customer_on_hand_days"]
        if customer_days > 0:
            for pair in sorted(demand_pairs):
                daily_signal = max(0.0, demand_target_daily.get(pair, 0.0))
                if daily_signal <= 1e-9:
                    continue
                ensure_stock_target(
                    pair,
                    daily_signal * customer_days,
                    category="customer_on_hand",
                    daily_signal=daily_signal,
                    cover_days=customer_days,
                )

        if initialization_policy["seed_estimated_source_on_hand"]:
            for src_pair, policy in sorted(estimated_source_policies.items()):
                if src_pair in supplier_stock_floor_overrides:
                    continue
                ensure_stock_target(
                    src_pair,
                    to_float(policy.get("target_stock_qty_day0"), 0.0),
                    category="estimated_source_on_hand",
                    daily_signal=to_float(policy.get("daily_capacity_qty"), 0.0),
                    cover_days=to_float(policy.get("target_cover_days"), 0.0),
                )
        if initialization_policy["seed_estimated_source_pipeline"]:
            for src_pair, policy in sorted(estimated_source_policies.items()):
                daily_capacity = max(0.0, to_float(policy.get("daily_capacity_qty"), 0.0))
                lead_days = max(1, int(to_float(policy.get("replenishment_lead_days"), 1.0)))
                transit_qty = daily_capacity * float(lead_days) * initialization_policy["in_transit_fill_ratio"] * state_scale
                if transit_qty <= 1e-9:
                    continue
                transit_qty = physical_execution_quantity(transit_qty, item_unit_map.get(src_pair[1], ""))
                seed_estimated_source_pipeline_uniform(
                    estimated_source_pipeline,
                    estimated_source_in_transit,
                    node_id=src_pair[0],
                    item_id=src_pair[1],
                    qty=transit_qty,
                    lead_days=lead_days,
                    uom=item_unit_map.get(src_pair[1], ""),
                )
                total_initialization_pipeline_seeded += transit_qty
                initialization_pipeline_rows.append(
                    {
                        "node_id": src_pair[0],
                        "item_id": src_pair[1],
                        "category": "estimated_source_in_transit",
                        "seeded_pipeline_qty": round(transit_qty, 6),
                        "lead_days": int(lead_days),
                        "lane_src": "unmodeled_source",
                    }
                )
        if (
            unmodeled_supplier_source_mode == "external_procurement"
            and economic_policy["external_procurement_enabled"]
            and economic_policy["external_procurement_seed_upstream_pipeline"]
            and economic_policy["external_procurement_capacity_mode"] == "supplier_nominal"
            and initialization_policy["seed_estimated_source_pipeline"]
        ):
            fill_ratio = max(0.0, to_float(economic_policy.get("external_procurement_upstream_pipeline_fill_ratio"), 1.0))
            for src_pair, policy in sorted(estimated_source_policies.items()):
                daily_need = max(0.0, to_float(policy.get("external_procurement_daily_need_qty"), 0.0))
                lead_days = max(1, int(math.ceil(to_float(policy.get("external_procurement_lead_days"), 1.0))))
                transit_qty = daily_need * float(lead_days) * fill_ratio
                policy["external_procurement_initial_pipeline_seed_qty"] = transit_qty
                policy_row = estimated_source_policy_rows_by_pair.get(src_pair)
                if policy_row is not None:
                    policy_row["external_procurement_initial_pipeline_seed_qty"] = round(transit_qty, 6)
                if transit_qty <= 1e-9:
                    continue
                transit_qty = physical_execution_quantity(transit_qty, item_unit_map.get(src_pair[1], ""))
                seed_external_pipeline_uniform(
                    external_pipeline,
                    external_in_transit,
                    node_id=src_pair[0],
                    item_id=src_pair[1],
                    qty=transit_qty,
                    lead_days=lead_days,
                    uom=item_unit_map.get(src_pair[1], ""),
                )
                total_initialization_pipeline_seeded += transit_qty
                initialization_pipeline_rows.append(
                    {
                        "node_id": src_pair[0],
                        "item_id": src_pair[1],
                        "category": "external_procurement_in_transit",
                        "seeded_pipeline_qty": round(transit_qty, 6),
                        "lead_days": int(lead_days),
                        "lane_src": SUPPLIER_UPSTREAM_SUPPLY_NODE_ID,
                    }
                )

        initialization_state_rows.sort(key=lambda r: (r["node_id"], r["item_id"], r["category"]))
        initialization_pipeline_rows.sort(key=lambda r: (r["node_id"], r["item_id"], r["category"]))
    opening_production_bom_issues_by_day: dict[int, list[dict[str, Any]]] = defaultdict(list)
    opening_production_order_bom_issue_mode = str(
        initialization_policy.get("opening_production_order_bom_issue_mode", "receipt")
    ).strip().lower()
    if opening_production_order_bom_issue_mode not in {"receipt", "release", "wip"}:
        opening_production_order_bom_issue_mode = "receipt"
    initialization_policy["opening_production_order_bom_issue_mode"] = opening_production_order_bom_issue_mode

    if initialization_policy["seed_open_orders_from_january_snapshot"]:
        horizon_cap_days = initialization_policy["opening_open_orders_horizon_days"]
        if horizon_cap_days <= 0:
            inferred_horizon_candidates = [
                max(
                    1,
                    int(to_float(lane.get("lead_days"), 1.0))
                    + int(math.ceil(max(0.0, pair_mrp_safety_time_days.get((str(lane["dst"]), str(lane["item_id"])), 0.0)))),
                )
                for lane in lanes
            ]
            horizon_cap_days = max(inferred_horizon_candidates or [30])
        real_open_order_rows = opening_open_orders_payload.get("rows") if isinstance(opening_open_orders_payload, dict) else []
        if isinstance(real_open_order_rows, list) and real_open_order_rows:
            (
                total_opening_open_order_qty,
                opening_open_order_rows,
                opening_open_order_bridge_days_by_pair,
            ) = seed_open_orders_from_metadata(
                pipeline,
                in_transit,
                opening_open_orders_payload=opening_open_orders_payload,
                lanes_by_dest_item=lanes_by_dest_item,
                item_unit_map=item_unit_map,
                pair_mrp_safety_time_days=pair_mrp_safety_time_days,
                total_timeline_days=total_timeline_days,
                warmup_days=warmup_days,
                opening_production_bom_issues_by_day=opening_production_bom_issues_by_day,
                opening_production_order_bom_issue_mode=opening_production_order_bom_issue_mode,
                mrp_order_rows=mrp_order_rows,
                supplier_shipment_rows=supplier_shipment_rows,
                initialization_pipeline_rows=initialization_pipeline_rows,
                assumptions_ledger_rows=assumptions_ledger_rows,
                apply_supplier_risks_to_opening_purchase_orders=bool(
                    args.supplier_risk_events_apply_to_opening_purchase_orders
                ),
                supplier_risk_events=supplier_risk_events,
                opening_purchase_order_risk_audit_rows=(
                    opening_purchase_order_risk_audit_rows
                ),
                opening_purchase_order_risk_warnings=(
                    opening_purchase_order_risk_warnings
                ),
                supplier_risk_applied_rows=supplier_risk_applied_rows,
                dated_purchase_availability=dated_mrp_execution,
            )
            opening_open_order_source = str(opening_open_orders_payload.get("source_file") or "metadata")
        else:
            (
                total_opening_open_order_qty,
                opening_open_order_rows,
                opening_open_order_bridge_days_by_pair,
            ) = seed_open_orders_from_opening_snapshot(
                pipeline,
                in_transit,
                lanes=lanes,
                lanes_by_dest_item=lanes_by_dest_item,
                opening_stock_source_snapshot=opening_stock_source_snapshot,
                pair_mrp_safety_time_days=pair_mrp_safety_time_days,
                pair_mrp_safety_stock_qty=pair_mrp_safety_stock_qty,
                demand_profiles=demand_profiles,
                required_daily_input_by_pair=required_daily_input_by_pair,
                process_input_requirements_by_output_pair=process_input_requirements_by_output_pair,
                opening_open_orders_demand_multiplier=initialization_policy["opening_open_orders_demand_multiplier"],
                demand_pairs=demand_pairs,
                stochastic_lead_times=args.stochastic_lead_times,
                horizon_cap_days=horizon_cap_days,
                initialization_pipeline_rows=initialization_pipeline_rows,
                assumptions_ledger_rows=assumptions_ledger_rows,
            )
            opening_open_order_source = "reconstructed_january_snapshot"
        total_initialization_pipeline_seeded += total_opening_open_order_qty
        initialization_pipeline_rows.sort(key=lambda r: (r["node_id"], r["item_id"], r["category"], r.get("lane_src", "")))
    apply_supplier_stock_floor_overrides()
    simulated_opening_stock_snapshot = dict(stock)
    if pending_receipt_calendar is not None:
        for initial_calendar in (pipeline, external_pipeline, estimated_source_pipeline):
            for receipt_day, receipt_rows in initial_calendar.items():
                for receipt in receipt_rows:
                    pending_receipt_calendar.add((receipt[0], receipt[1]), receipt_day, receipt[2])
    supplier_capacity_daily_rows: list[dict[str, Any]] = []
    supplier_state_risk_event_rows: list[dict[str, Any]] = []
    supplier_state_risk_events: list[dict[str, Any]] = []
    supplier_state_risk_open_until_by_key: dict[tuple[str, str, str, str], int] = {}
    supplier_state_risk_counters: dict[tuple[str, str, str], int] = defaultdict(int)
    supplier_state_risk_metric_windows: dict[tuple[str, str, str], deque[float]] = {}
    mrp_order_ordinal_by_scope: dict[tuple[str, str, str, str], int] = defaultdict(int)
    total_supplier_capacity_binding_qty = 0.0
    scheduled_lane_release_metrics: dict[int, list[tuple[tuple[str, str], float, float, float, float, bool]]] = defaultdict(list)
    receipt_lead_observations = ReceiptLeadObservations()
    mrp_multisource_min_annual_lot_enabled = args.mrp_multisource_policy in {
        "portfolio_annual_min_lot",
        "portfolio_cost_risk",
    }
    mrp_multisource_min_annual_lot_window_days = max(
        1,
        min(365, int(args.mrp_multisource_min_annual_lot_window_days or 28)),
    )
    mrp_multisource_annual_lane_orders: set[tuple[int, str]] = set()
    lot_ledger = LotLedger(
        enabled=bool(args.lot_trace),
        scenario_id=str(scenario.get("id") or args.scenario_id or ""),
    )
    lot_ledger.seed_opening_stock(
        day=-warmup_days,
        stock=stock,
        item_unit_map=item_unit_map,
    )
    initial_stock_availability: InitialStockAvailability | None = None
    stock_availability_daily_rows: list[dict[str, Any]] = []
    if args.initial_stock_availability:
        if (warmup_days or opening_observed_stock_scale_requested
                or measurement_start_stock_scale_csv_path
                or measurement_start_in_transit_scale_csv_path
                or initialization_policy["state_scale"] != 1.0
                or opening_stock_bootstrap_scale != 1.0):
            raise ValueError("Initial stock availability cannot be combined with warmup or stock scaling")
        initial_stock_availability = InitialStockAvailability(
            graph_meta.get("initial_stock_availability"), stock=opening_stock_source_snapshot,
            item_unit_map=item_unit_map, origin_date=safety_calendar.get("start_date"),
        )
        for pair in initial_stock_availability.held_by_pair:
            if abs(stock.get(pair, 0.0) - opening_stock_source_snapshot[pair]) > 1e-9:
                raise ValueError(f"Initial stock availability requires unchanged physical opening stock: {pair}")
        initial_stock_availability.initialize(stock=stock, ledger=lot_ledger)
    opening_purchase_availability: OpeningPurchaseAvailability | None = None
    if dated_mrp_execution:
        if (warmup_days or opening_observed_stock_scale_requested
                or measurement_start_stock_scale_csv_path or measurement_start_in_transit_scale_csv_path
                or initialization_policy["state_scale"] != 1.0 or opening_stock_bootstrap_scale != 1.0):
            raise ValueError("Dated MRP execution requires no warmup or initial state scaling")
        if (args.supplier_risk_events_apply_to_opening_purchase_orders or args.supplier_state_dependent_risks
                or args.supplier_risk_events_csv or str(scenario.get("id")) != "scn:BASE"):
            raise ValueError("Dated opening purchase execution is currently qualified only for BASE without risk overlays")
        if initialization_policy["seed_open_orders_from_january_snapshot"] and opening_open_order_source == "reconstructed_january_snapshot":
            raise ValueError("Dated opening purchase execution requires explicit source G and I dates")
        opening_purchase_availability = OpeningPurchaseAvailability(
            opening_open_order_rows, item_unit_map=item_unit_map,
        )
    network_transport_sources: dict = {}
    network_leads: dict = {}
    network_lots: dict = {}
    network_covers: dict = {}
    aggregate_supplier_pairs: set = set()
    aggregate_delivery_pairs: set = set()
    supplier_receipt_policies: dict = {}
    dated_action_pairs = (set(production_input_pairs) & set(lanes_by_dest_item)) | set(source_boundary_policies)
    if dated_component_planning:
        if unmodeled_supplier_source_mode != "external_procurement":
            raise ValueError("Dated component planning requires explicit external procurement boundaries")
        for pair, incoming in lanes_by_dest_item.items():
            weights = [max(0.0, to_float(lane.get("mrp_share"), 0.0)) for lane in incoming]
            if sum(weights) <= 0:
                weights = [1.0] * len(incoming)
            aggregate = pair in dated_action_pairs and all(
                (lane["src"], pair[1]) in externally_sourced_pairs_set
                and lane["src"] in supplier_node_ids for lane in incoming
            )
            if aggregate:
                aggregate_supplier_pairs.update((lane["src"], pair[1]) for lane in incoming)
                aggregate_delivery_pairs.add(pair)
            else:
                network_transport_sources[pair] = [
                    ((lane["src"], pair[1]), weight / sum(weights))
                    for lane, weight in zip(incoming, weights) if weight > 0
                ]
            network_leads[pair] = max(lead_time_reference_days(lane) for lane in incoming)
        receipt_payload = graph_meta.get("supplier_delivery_receipt_policy")
        if (not isinstance(receipt_payload, dict) or type(receipt_payload.get("schema_version")) is not int or receipt_payload.get("schema_version") != 1
                or receipt_payload.get("calendar") != "monday_friday" or not isinstance(receipt_payload.get("rows"), list)):
            raise ValueError("Dated supplier deliveries require an explicit supplier_delivery_receipt_policy")
        for receipt_policy in receipt_payload["rows"]:
            receipt_pair = (receipt_policy.get("node_id"), receipt_policy.get("item_id"))
            if receipt_pair not in aggregate_delivery_pairs:
                continue
            if (type(receipt_policy.get("receipt_days")) is not int or receipt_policy["receipt_days"] < 0
                    or not receipt_policy.get("source_file") or not receipt_policy.get("source_cells")):
                raise ValueError("Supplier receipt policy requires integer days and source provenance")
            if receipt_pair in supplier_receipt_policies:
                raise ValueError("Duplicate supplier receipt policy")
            supplier_receipt_policies[receipt_pair] = receipt_policy
        if aggregate_delivery_pairs - set(supplier_receipt_policies):
            raise ValueError(f"Missing supplier receipt policy: {sorted(aggregate_delivery_pairs - set(supplier_receipt_policies))}")
        for pair in produced_pairs:
            network_leads[pair] = max(1, int(math.ceil(process_tau_days_by_pair.get(pair, 0.0))))
        for pair, lot_policy in production_lot_policy_by_pair.items():
            fixed = lot_policy["fixed_lot_qty"]
            network_lots[pair] = LotSizing(
                minimum=fixed or lot_policy["min_lot_qty"],
                multiple=fixed or lot_policy["lot_multiple_qty"],
                maximum=fixed or lot_policy["max_lot_qty"] or None,
                integer=normalize_unit(item_unit_map.get(pair[1], "")) == "UN",
            )
        for pair, boundary in source_boundary_policies.items():
            network_leads[pair] = boundary["lead_days"]
            network_lots[pair] = LotSizing(minimum=boundary["fixed_lot_qty"], multiple=boundary["fixed_lot_qty"])
        for pair in set(network_leads) | set(process_input_requirements_by_output_pair):
            network_lots.setdefault(pair, LotSizing(integer=normalize_unit(item_unit_map.get(pair[1], "")) == "UN"))
            network_covers[pair] = max(1, int(math.ceil(pair_stock_cover_days.get(pair, network_leads.get(pair, 1) + 1))))
        for calendar_name, calendar in (("lane", pipeline), ("external", external_pipeline), ("estimated", estimated_source_pipeline)):
            for receipt_day, rows in calendar.items():
                for ordinal, receipt in enumerate(rows):
                    marker = str(receipt[3]) if calendar_name == "lane" else ""
                    receipt_id = marker if marker in opening_purchase_availability.by_marker else f"initial:{calendar_name}:{receipt_day}:{ordinal}"
                    origin = "production" if marker.startswith(OPENING_PRODUCTION_ORDER_LANE_PREFIX) else calendar_name
                    planning_commitments_by_pair[(receipt[0], receipt[1])][receipt_id] = (receipt_day, receipt[2], origin)
        if initial_stock_availability is not None:
            for row in initial_stock_availability.rows:
                planning_commitments_by_pair[(row["node_id"], row["item_id"])]["held:" + row["source_row"]] = (
                    row["release_day"], row["quantity"], "held",
                )
    lot_arrivals_pipeline: dict[int, list[dict[str, Any]]] = defaultdict(list)
    lot_departure_pipeline: dict[int, list[dict[str, Any]]] = defaultdict(list)

    def next_mrp_order_identity(
        *,
        source_mode: str,
        src_node_id: str,
        dst_node_id: str,
        item_id: str,
    ) -> str:
        scope = (
            str(source_mode),
            str(src_node_id),
            str(dst_node_id),
            str(item_id),
        )
        mrp_order_ordinal_by_scope[scope] += 1
        return stable_reference_id(
            "MRPREQ",
            *scope,
            mrp_order_ordinal_by_scope[scope],
        )

    def lane_transport_cost_for_chunk(
        lane: dict[str, Any],
        item_id: str,
        pull_qty: float,
        delivered_qty: float,
    ) -> tuple[float, str, float]:
        return transport_charge(lane, pull_qty, delivered_qty)

    def schedule_lot_arrival(
        *,
        arrival_day: int,
        departure_day: int,
        dst_node_id: str,
        item_id: str,
        qty: float,
        lane_id: str,
        source_type: str,
        source_id: str,
        shipment_id: str = "",
        risk_decision_day: int | str = "",
        risk_event_ids: str = "",
        parent_allocations: list[dict[str, Any]],
        link_type: str,
        notes: str = "",
        handling_unit_id: str = "",
        trace_status: str = "traced",
        trace_reason: str = "",
        causal_event_ids: Any = "",
        causal_root_ids: Any = "",
        planned_order_id: str = "",
        baseline_reference_id: str = "",
    ) -> None:
        if not lot_ledger.enabled or qty <= 1e-9:
            return
        lot_arrivals_pipeline[int(arrival_day)].append(
            {
                "dst_node_id": str(dst_node_id),
                "item_id": str(item_id),
                "qty": max(0.0, qty),
                "departure_day": int(departure_day),
                "arrival_day": int(arrival_day - warmup_days),
                "lane_id": str(lane_id),
                "source_type": source_type,
                "source_id": source_id,
                "shipment_id": shipment_id,
                "risk_decision_day": risk_decision_day,
                "risk_event_ids": risk_event_ids,
                "parent_allocations": parent_allocations,
                "link_type": link_type,
                "notes": notes,
                "shipment_id": shipment_id,
                "handling_unit_id": handling_unit_id,
                "trace_status": trace_status,
                "trace_reason": trace_reason,
                "causal_event_ids": join_ids(causal_event_ids),
                "causal_root_ids": join_ids(causal_root_ids) or join_ids(causal_event_ids),
                "planned_order_id": planned_order_id,
                "baseline_reference_id": baseline_reference_id or planned_order_id,
            }
        )

    def eligible_reference_transition_substitutes(node_id: str, item_id: str, output_day: int) -> list[dict[str, Any]]:
        transitions = reference_substitutes_by_pair.get((str(node_id), str(item_id)), [])
        if not transitions:
            return []
        eligible: list[dict[str, Any]] = []
        for transition in transitions:
            start_day = int(to_float(transition.get("start_day"), 0.0))
            end_day = int(to_float(transition.get("end_day"), sim_days))
            if output_day < start_day or output_day > end_day:
                continue
            eligible.append(transition)
        return eligible

    def available_bom_input_qty(node_id: str, item_id: str, output_day: int) -> float:
        key = (str(node_id), str(item_id))
        new_stock_qty = max(0.0, stock.get(key, 0.0))
        total_available = new_stock_qty
        for transition in eligible_reference_transition_substitutes(node_id, item_id, output_day):
            old_item_id = str(transition.get("old_item_id") or "")
            if not old_item_id:
                continue
            consume_policy = str(transition.get("consume_policy") or "")
            if consume_policy == "use_old_until_new_stock_available" and new_stock_qty > 1e-9:
                continue
            total_available += max(0.0, stock.get((str(node_id), old_item_id), 0.0))
        return total_available

    def consume_bom_input_with_reference_transition(
        *,
        output_day: int,
        node_id: str,
        item_id: str,
        qty: float,
        event_type: str,
        source_id: str,
        production_campaign_id: str,
        consumed_today_by_pair: dict[tuple[str, str], float],
    ) -> list[dict[str, Any]]:
        remaining = max(0.0, qty)
        if remaining <= 1e-9:
            return []
        allocations: list[dict[str, Any]] = []
        key = (str(node_id), str(item_id))
        new_stock_before = max(0.0, stock.get(key, 0.0))
        if new_stock_before > 1e-9:
            take = min(new_stock_before, remaining)
            stock[key] = max(0.0, new_stock_before - take)
            consumed_today_by_pair[key] += take
            allocations.extend(
                lot_ledger.consume(
                    day=output_day,
                    node_id=node_id,
                    item_id=item_id,
                    qty=take,
                    event_type=event_type,
                    source_id=source_id,
                    production_campaign_id=production_campaign_id,
                    uom=item_unit_map.get(item_id, ""),
                    planned_order_id=lot_ledger.planned_order_id(production_campaign_id),
                    baseline_reference_id=lot_ledger.planned_order_id(production_campaign_id),
                    required_item_id=item_id,
                    consumed_item_id=item_id,
                )
            )
            remaining -= take
        if remaining <= 1e-9:
            return allocations
        for transition in eligible_reference_transition_substitutes(node_id, item_id, output_day):
            consume_policy = str(transition.get("consume_policy") or "")
            if consume_policy == "use_old_until_new_stock_available" and new_stock_before > 1e-9:
                continue
            old_item_id = str(transition.get("old_item_id") or "")
            old_key = (str(node_id), old_item_id)
            old_available = max(0.0, stock.get(old_key, 0.0))
            if old_available <= 1e-9:
                continue
            take = min(old_available, remaining)
            stock[old_key] = max(0.0, old_available - take)
            consumed_today_by_pair[old_key] += take
            transition_id = str(
                transition.get("transition_id")
                or stable_reference_id(
                    "TRANSITION",
                    node_id,
                    old_item_id,
                    item_id,
                    transition.get("start_day"),
                    transition.get("end_day"),
                )
            )
            allocations.extend(
                lot_ledger.consume(
                    day=output_day,
                    node_id=node_id,
                    item_id=old_item_id,
                    qty=take,
                    event_type=f"{event_type}_reference_transition",
                    source_id=f"{source_id}|substitute_for={item_id}",
                    production_campaign_id=production_campaign_id,
                    uom=item_unit_map.get(old_item_id, item_unit_map.get(item_id, "")),
                    planned_order_id=lot_ledger.planned_order_id(production_campaign_id),
                    baseline_reference_id=lot_ledger.planned_order_id(production_campaign_id),
                    required_item_id=item_id,
                    consumed_item_id=old_item_id,
                    replacement_reason="approved_reference_transition",
                    replacement_transition_id=transition_id,
                )
            )
            remaining -= take
            if remaining <= 1e-9:
                break
        if remaining > 1e-6:
            raise RuntimeError(
                "BOM input consumption exceeded available stock after transition check: "
                f"{node_id} {item_id} missing {remaining}"
            )
        return allocations

    def next_receipt_day_for_pair(pair: tuple[str, str], current_day: int) -> str:
        node_id, item_id = pair
        candidates: list[int] = []
        for arrival_day, rows in pipeline.items():
            if arrival_day < current_day:
                continue
            if any(str(dst) == node_id and str(it) == item_id and qty > 1e-9 for dst, it, qty, _lane_id in rows):
                candidates.append(int(arrival_day - warmup_days))
        for arrival_day, rows in external_pipeline.items():
            if arrival_day < current_day:
                continue
            if any(
                str(row[0]) == node_id and str(row[1]) == item_id and row[2] > 1e-9
                for row in rows
            ):
                candidates.append(int(arrival_day - warmup_days))
        for arrival_day, rows in estimated_source_pipeline.items():
            if arrival_day < current_day:
                continue
            if any(str(dst) == node_id and str(it) == item_id and qty > 1e-9 for dst, it, qty in rows):
                candidates.append(int(arrival_day - warmup_days))
        return "" if not candidates else str(min(candidates))

    def register_state_dependent_supplier_event(
        *,
        trigger_day: int,
        supplier_id: str,
        item_id: str,
        risk_family: str,
        risk_type: str,
        multiplier: float,
        trigger_metric: str,
        trigger_value: float,
        threshold: float,
        consecutive_days: int,
        effect: str,
        notes: str,
        dst_node_id: str = "",
        edge_id: str = "",
        duration_days: int = 14,
        cooldown_days: int = 14,
    ) -> None:
        observation_warmup_days = max(0, int(args.supplier_state_risk_observation_warmup_days or 0))
        if not args.supplier_state_dependent_risks or trigger_day < observation_warmup_days:
            return
        if risk_family not in args.supplier_state_risk_families:
            return
        key = (risk_family, trigger_metric, supplier_id, item_id, dst_node_id, edge_id)
        if trigger_day <= supplier_state_risk_open_until_by_key.get(key, -1):
            return
        safe_supplier = re.sub(r"[^A-Za-z0-9]+", "_", supplier_id).strip("_")
        safe_item = re.sub(r"[^A-Za-z0-9]+", "_", item_id).strip("_")
        safe_dst = re.sub(r"[^A-Za-z0-9]+", "_", dst_node_id).strip("_")
        safe_edge = re.sub(r"[^A-Za-z0-9]+", "_", edge_id).strip("_")
        safe_metric = re.sub(r"[^A-Za-z0-9]+", "_", trigger_metric).strip("_")
        scope_parts = [safe_supplier, safe_item]
        if safe_dst:
            scope_parts.append(safe_dst)
        if safe_edge:
            scope_parts.append(safe_edge[:40])
        event_id = f"state_{risk_family}_{safe_metric}_{'_'.join(scope_parts)}_d{trigger_day}"
        start_day = trigger_day + 1
        event, row = make_state_dependent_supplier_event(
            event_id=event_id,
            trigger_day=trigger_day,
            supplier_id=supplier_id,
            item_id=item_id,
            dst_node_id=dst_node_id,
            edge_id=edge_id,
            risk_family=risk_family,
            risk_type=risk_type,
            multiplier=multiplier,
            start_day=start_day,
            duration_days=duration_days,
            trigger_metric=trigger_metric,
            trigger_value=trigger_value,
            threshold=threshold,
            consecutive_days=consecutive_days,
            effect=effect,
            notes=notes,
        )
        supplier_state_risk_events.append(event)
        supplier_state_risk_event_rows.append(row)
        supplier_state_risk_open_until_by_key[key] = int(row["end_day"]) + max(0, int(cooldown_days))

    def update_state_risk_counter_and_register(
        *,
        trigger_day: int,
        supplier_id: str,
        item_id: str,
        counter_family: str,
        risk_family: str,
        risk_type: str,
        multiplier: float,
        trigger_metric: str,
        trigger_value: float,
        threshold: float,
        triggered: bool,
        required_consecutive_days: int,
        effect: str,
        notes: str,
        dst_node_id: str = "",
        edge_id: str = "",
        duration_days: int = 14,
        cooldown_days: int = 14,
    ) -> None:
        counter_key = (counter_family, supplier_id, item_id, dst_node_id, edge_id)
        if triggered:
            supplier_state_risk_counters[counter_key] += 1
        else:
            supplier_state_risk_counters[counter_key] = 0
        if supplier_state_risk_counters[counter_key] >= max(1, int(required_consecutive_days)):
            register_state_dependent_supplier_event(
                trigger_day=trigger_day,
                supplier_id=supplier_id,
                item_id=item_id,
                dst_node_id=dst_node_id,
                edge_id=edge_id,
                risk_family=risk_family,
                risk_type=risk_type,
                multiplier=multiplier,
                trigger_metric=trigger_metric,
                trigger_value=trigger_value,
                threshold=threshold,
                consecutive_days=supplier_state_risk_counters[counter_key],
                effect=effect,
                notes=notes,
                duration_days=duration_days,
                cooldown_days=cooldown_days,
            )

    def update_state_risk_metric_window(
        metric_key: tuple[str, str, str],
        value: float,
        window_days: int,
    ) -> float:
        window_days = max(1, int(window_days))
        window = supplier_state_risk_metric_windows.get(metric_key)
        if window is None or window.maxlen != window_days:
            previous_values = list(window)[-(window_days - 1) :] if window is not None and window_days > 1 else []
            window = deque(previous_values, maxlen=window_days)
            supplier_state_risk_metric_windows[metric_key] = window
        window.append(float(value))
        return sum(window) / len(window)

    def candidate_supply_lanes_for_factory_input(
        dst_node_id: str,
        item_id: str,
        *,
        limit: int = 2,
    ) -> list[dict[str, Any]]:
        candidate_lanes = [
            lane
            for lane in lanes_by_dest_item.get((dst_node_id, item_id), [])
            if str(lane.get("src") or "").strip() and str(lane.get("item_id") or "") == item_id
        ]
        if not candidate_lanes:
            return []

        def source_priority(lane: dict[str, Any]) -> tuple[int, float, float, str]:
            src = str(lane.get("src") or "")
            node_type = node_type_by_id.get(src, "")
            if src in supplier_node_ids:
                type_rank = 0
            elif node_type in {"factory", "distribution_center"}:
                type_rank = 1
            else:
                type_rank = 2
            share = max(0.0, to_float(lane.get("mrp_share"), 0.0))
            lead_days = max(1.0, to_float(lane.get("lead_days_mean"), lane.get("lead_days")) or 1.0)
            return (type_rank, -share, lead_days, src)

        return sorted(candidate_lanes, key=source_priority)[: max(1, int(limit))]

    warmup_boundary_state_audit: dict[str, Any] = {}
    measurement_start_stock_adjustment_rows: list[dict[str, Any]] = []
    measurement_start_stock_scale_audit: dict[str, Any] = {
        "enabled": bool(measurement_start_stock_scale_csv_path),
        "source_csv": str(measurement_start_stock_scale_csv_path or ""),
        "source_csv_sha256": measurement_start_stock_scale_csv_sha256,
        "audit_csv": "data/measurement_start_stock_adjustments.csv",
        "application_stage": (
            "after_warmup_and_optional_restore_before_j0_boundary_audit"
        ),
        "measured_application_day": 0,
        "scope": "listed_observed_graph_inventory_states_only",
        "pair_overrides": [
            {
                "node_id": pair[0],
                "item_id": pair[1],
                "factor": round(factor, 9),
            }
            for pair, factor in sorted(
                measurement_start_stock_scale_overrides.items()
            )
        ],
        "adjustment_rows": 0,
        "quantities_by_uom": {},
        "lot_trace_enabled": bool(lot_ledger.enabled),
        "lot_balance_reconciled_to_aggregate_stock": bool(lot_ledger.enabled),
        "restart_checkpoint_available": False,
        "scientific_interpretation": (
            "pair_scoped_j0_sensitivity_stress_test_not_calibrated_state_or_"
            "restart_checkpoint"
        ),
    }
    measurement_start_in_transit_adjustment_rows: list[dict[str, Any]] = []
    measurement_start_in_transit_scale_audit: dict[str, Any] = {
        "enabled": bool(measurement_start_in_transit_scale_csv_path),
        "source_csv": str(measurement_start_in_transit_scale_csv_path or ""),
        "source_csv_sha256": measurement_start_in_transit_scale_csv_sha256,
        "audit_csv": "data/measurement_start_in_transit_adjustments.csv",
        "application_stage": "after_warmup_before_j0_boundary_audit",
        "measured_application_day": 0,
        "scope": "listed_native_standard_pipeline_pairs_only",
        "pair_overrides": [
            {
                "node_id": pair[0],
                "item_id": pair[1],
                "factor": round(factor, 9),
            }
            for pair, factor in sorted(
                measurement_start_in_transit_scale_overrides.items()
            )
        ],
        "adjustment_rows": 0,
        "quantities_by_uom": {},
        "external_pipeline_unchanged": True,
        "estimated_source_pipeline_unchanged": True,
        "lot_arrivals_pipeline_scaled_proportionally": bool(lot_ledger.enabled),
        "restart_checkpoint_available": False,
        "scientific_interpretation": (
            "pair_scoped_j0_standard_pipeline_sensitivity_stress_test_not_"
            "calibrated_state_or_restart_checkpoint"
        ),
    }

    def production_shortage_causal_context(
        *,
        dst_node_id: str,
        item_id: str,
        current_day: int,
        output_day: int,
        active_risk_events: list[dict[str, Any]],
    ) -> dict[str, str]:
        """Find explicit upstream causes that can explain an input shortage.

        The nearest affected receipt is preferred. Active lane risks are also
        retained because they can prevent or delay creation of that receipt.
        Empty causes mean the shortage is nominal and must not be attributed to
        a scenario event.
        """

        event_ids = ""
        root_ids = ""
        for lane in candidate_supply_lanes_for_factory_input(dst_node_id, item_id, limit=8):
            effects = supplier_risk_multipliers_for_lane(
                active_risk_events,
                lane,
                output_day,
            )
            event_ids = join_ids(event_ids, effects.get("event_ids"))
            root_ids = join_ids(root_ids, effects.get("causal_root_ids"))

        matching_arrivals: list[tuple[int, dict[str, Any]]] = []
        for arrival_day, payloads in lot_arrivals_pipeline.items():
            if int(arrival_day) < int(current_day):
                continue
            for payload in payloads:
                if (
                    str(payload.get("dst_node_id") or "") == str(dst_node_id)
                    and str(payload.get("item_id") or "") == str(item_id)
                ):
                    matching_arrivals.append((int(arrival_day), payload))
        if matching_arrivals:
            nearest_day = min(arrival_day for arrival_day, _payload in matching_arrivals)
            for arrival_day, payload in matching_arrivals:
                if arrival_day != nearest_day:
                    continue
                event_ids = join_ids(event_ids, payload.get("causal_event_ids"))
                root_ids = join_ids(root_ids, payload.get("causal_root_ids"))

        return {
            "causal_event_ids": event_ids,
            "causal_root_ids": root_ids or event_ids,
            "causal_status": causal_status(event_ids, root_ids=root_ids),
        }

    for day in range(total_timeline_days):
        record_day = day >= warmup_days
        output_day = day - warmup_days
        production_safety_decisions: dict[tuple[str, str], dict[str, Any]] = {}
        source_boundary_decisions: dict[tuple[str, str], dict[str, Any]] = {}
        for safety_pair, source_days in pair_mrp_safety_source_days.items():
            pair_mrp_safety_time_days[safety_pair] = safety_calendar_days(
                source_days, day=output_day, anchor_weekday=safety_calendar["weekday"],
                calendar=args.safety_time_calendar,
            )
        planned_release_today_by_pair: dict[tuple[str, str], float] = defaultdict(float)
        planned_receipt_today_by_pair: dict[tuple[str, str], float] = defaultdict(float)
        planned_order_count_by_pair: dict[tuple[str, str], int] = defaultdict(int)
        planned_receipt_min_day_by_pair: dict[tuple[str, str], int] = {}
        planned_receipt_max_day_by_pair: dict[tuple[str, str], int] = {}

        def register_mrp_order(
            trace_pair: tuple[str, str],
            *,
            source_mode: str,
            src_node_id: str,
            dst_node_id: str,
            item_id: str,
            release_qty: float,
            receipt_qty: float,
            arrival_day: int,
            safety_time_days: float,
            lead_days: int,
            lead_cover_days: int | None = None,
            lead_reference_days: int | None = None,
            edge_id: str = "",
            reliability: float = 1.0,
            standard_order_qty: float = 0.0,
            mrp_share: float = 0.0,
            physical_release_day: int | None = None,
            source_inventory_reserved: bool | None = None,
            mrp_order_id: str = "",
            shipment_id: str = "",
            causal_event_ids: Any = "",
            causal_root_ids: Any = "",
        ) -> str:
            resolved_mrp_order_id = str(mrp_order_id or next_mrp_order_identity(
                source_mode=source_mode,
                src_node_id=src_node_id,
                dst_node_id=dst_node_id,
                item_id=item_id,
            ))
            if dated_component_planning:
                if resolved_mrp_order_id in planning_commitments_by_pair[trace_pair]:
                    raise ValueError("Dated MRP commitment identity is already registered")
                planning_commitments_by_pair[trace_pair][resolved_mrp_order_id] = (arrival_day, receipt_qty, source_mode)
            planned_release_today_by_pair[trace_pair] += max(0.0, release_qty)
            planned_receipt_today_by_pair[trace_pair] += max(0.0, receipt_qty)
            planned_order_count_by_pair[trace_pair] += 1
            previous_min = planned_receipt_min_day_by_pair.get(trace_pair)
            previous_max = planned_receipt_max_day_by_pair.get(trace_pair)
            planned_receipt_min_day_by_pair[trace_pair] = (
                arrival_day if previous_min is None else min(previous_min, arrival_day)
            )
            planned_receipt_max_day_by_pair[trace_pair] = (
                arrival_day if previous_max is None else max(previous_max, arrival_day)
            )
            if not record_day:
                return resolved_mrp_order_id
            safety_days_int = int(math.ceil(max(0.0, safety_time_days)))
            cover_need_day = arrival_day + safety_days_int
            effective_lead_cover_days = int(max(1, lead_cover_days if lead_cover_days is not None else lead_days))
            effective_lead_reference_days = int(max(1, lead_reference_days if lead_reference_days is not None else lead_days))
            order_date_imt = cover_need_day - safety_days_int - effective_lead_cover_days
            release_day_for_output = (
                int(physical_release_day) if physical_release_day is not None else day
            )
            release_day_output = int(release_day_for_output - warmup_days)
            order_day_output = int(output_day)
            if source_mode.startswith("lane_release") and edge_id and order_day_output >= 0:
                mrp_multisource_annual_lane_orders.add((order_day_output // 365, str(edge_id)))
            order_status_end_of_run = shipment_execution_state(
                release_day_for_output, arrival_day, total_timeline_days - 1,
                reserved=(source_mode.startswith("lane_release") if source_inventory_reserved is None else source_inventory_reserved),
            )
            actual_receipt_day = int(arrival_day - warmup_days) if arrival_day >= warmup_days and arrival_day < total_timeline_days else ""
            mrp_order_rows.append(
                {
                    "day": output_day,
                    "node_id": trace_pair[0],
                    "item_id": item_id,
                    "order_type": source_mode,
                    "src_node_id": src_node_id,
                    "dst_node_id": dst_node_id,
                    "edge_id": edge_id,
                    "planning_status": "planned_and_reserved" if order_status_end_of_run == "reserved_pending_departure" else ("planned" if order_status_end_of_run == "planned_pending_departure" else "planned_and_released"),
                    "release_status": "reserved_pending_departure" if order_status_end_of_run == "reserved_pending_departure" else ("planned_pending_departure" if order_status_end_of_run == "planned_pending_departure" else "released"),
                    "receipt_status": "firm_receipt" if arrival_day < total_timeline_days else "firm_receipt_outside_horizon",
                    "order_status_end_of_run": order_status_end_of_run,
                    "release_qty": round(release_qty, 6),
                    "planned_receipt_qty": round(receipt_qty, 6),
                    "release_day": release_day_output,
                    "order_date_imt": int(order_date_imt - warmup_days),
                    "arrival_day": int(arrival_day - warmup_days),
                    "actual_receipt_day": actual_receipt_day,
                    "implied_cover_need_day": int(cover_need_day - warmup_days),
                    "lead_days": int(lead_days),
                    "lead_reference_days": int(effective_lead_reference_days),
                    "lead_cover_days": int(effective_lead_cover_days),
                    "safety_time_days": round(max(0.0, safety_time_days), 6),
                    "reliability": round(reliability, 6),
                    "standard_order_qty": round(max(0.0, standard_order_qty), 6),
                    "mrp_share": round(max(0.0, mrp_share), 6),
                    "mrp_order_id": resolved_mrp_order_id,
                    "shipment_id": shipment_id,
                    "scenario_id": str(scenario.get("id") or args.scenario_id or ""),
                    "causal_event_ids": join_ids(causal_event_ids),
                    "causal_root_ids": join_ids(causal_root_ids) or join_ids(causal_event_ids),
                    "causal_status": causal_status(
                        causal_event_ids,
                        root_ids=causal_root_ids,
                    ),
                    "baseline_reference_id": resolved_mrp_order_id,
                    }
                )
            return resolved_mrp_order_id

        output_prod_day_start = len(output_prod_rows)
        production_constraint_day_start = len(production_constraint_rows)
        supplier_capacity_day_start = len(supplier_capacity_daily_rows)
        feedback_warmup_production_utilization_values: list[float] = []

        def resolve_daily_control(
            *,
            node_id: str = "",
            supplier_id: str = "",
            item_id: str = "",
            dst_node_id: str = "",
        ) -> ResolvedControl | None:
            if not record_day or not control_provider.enabled:
                return None
            resolved = control_provider.resolve(
                int(output_day),
                node_id=node_id,
                supplier_id=supplier_id,
                item_id=item_id,
                dst_node_id=dst_node_id,
            )
            if control_probe is not None:
                probe_resolved = control_probe.resolve(
                    int(output_day),
                    node_id=node_id,
                    supplier_id=supplier_id,
                    item_id=item_id,
                    dst_node_id=dst_node_id,
                )
                resolved = compose_feedback_with_probe(
                    resolved,
                    probe_resolved,
                )
                if isinstance(resolved, ProbeResolvedControl):
                    controller_audit = feedback_audit_metadata_for_day(
                        int(output_day)
                    )
                    for composition_row in resolved.composition_rows():
                        composition_row.update(controller_audit)
                        key = (
                            int(composition_row["day"]),
                            str(composition_row["resolved_node_id"]),
                            str(composition_row["resolved_supplier_id"]),
                            str(composition_row["resolved_item_id"]),
                            str(composition_row["resolved_dst_node_id"]),
                            str(composition_row["action"]),
                        )
                        control_probe_composition_rows.setdefault(
                            key,
                            composition_row,
                        )
            if feedback_control is not None and not resolved.enabled:
                return None
            return resolved

        supplier_risk_events_today = supplier_risk_events + active_state_dependent_events(
            supplier_state_risk_events,
            output_day,
        )
        supplier_state_lead_observations_today_by_pair = receipt_lead_observations.observe(day)
        supplier_state_stock_cover_today_by_pair: dict[tuple[str, str], float] = {}
        if day < warmup_days and args.warmup_profile_mode == "preperiod":
            profile_day = (day - warmup_days) % demand_profile_cycle_days
        else:
            profile_day = day if day < warmup_days else output_day
        if (
            day == warmup_days
            and warmup_days > 0
            and initialization_policy.get("restore_opening_stock_after_warmup")
        ):
            for pair in list(set(stock.keys()) | set(opening_stock_source_snapshot.keys())):
                stock[pair] = max(0.0, opening_stock_source_snapshot.get(pair, 0.0))
        if day == warmup_days and reset_backlog_after_warmup:
            warmup_backlog_cleared_qty = sum(max(0.0, val) for val in backlog.values())
            for pair in list(backlog.keys()):
                backlog[pair] = 0.0
        if day == warmup_days and measurement_start_stock_scale_overrides:
            measurement_totals_by_uom: dict[str, dict[str, float]] = defaultdict(
                lambda: {
                    "stock_before_qty": 0.0,
                    "stock_after_qty": 0.0,
                    "stock_removed_qty": 0.0,
                    "stock_added_qty": 0.0,
                }
            )
            for pair, factor in sorted(
                measurement_start_stock_scale_overrides.items()
            ):
                stock_before_qty = max(0.0, stock.get(pair, 0.0))
                stock_after_qty = physical_execution_quantity(stock_before_qty * factor, item_unit_map.get(pair[1], ""))
                stock_removed_qty = max(0.0, stock_before_qty - stock_after_qty)
                stock_added_qty = max(0.0, stock_after_qty - stock_before_qty)
                stock[pair] = stock_after_qty
                unit = normalize_unit(item_unit_map.get(pair[1], ""))
                lot_result = lot_ledger.reconcile_pair_to_stock(
                    day=0,
                    node_id=pair[0],
                    item_id=pair[1],
                    target_qty=stock_after_qty,
                    source_id="measurement_start_stock_scale_csv",
                    uom=unit,
                    notes=(
                        "Pair-scoped measured-day-0 stock sensitivity; FIFO lot "
                        "balance reconciled to adjusted aggregate stock."
                    ),
                )
                adjustment_row = {
                    "measured_day": 0,
                    "node_id": pair[0],
                    "item_id": pair[1],
                    "uom": unit,
                    "scale": round(factor, 9),
                    "stock_before_qty": round(stock_before_qty, 6),
                    "stock_after_qty": round(stock_after_qty, 6),
                    "stock_removed_qty": round(stock_removed_qty, 6),
                    "stock_added_qty": round(stock_added_qty, 6),
                    "lot_trace_enabled": int(lot_ledger.enabled),
                    "lot_balance_before_qty": round(
                        to_float(lot_result.get("balance_before_qty"), 0.0),
                        6,
                    ),
                    "lot_balance_after_qty": round(
                        to_float(lot_result.get("balance_after_qty"), 0.0),
                        6,
                    ),
                    "lot_removed_qty": round(
                        to_float(lot_result.get("removed_qty"), 0.0),
                        6,
                    ),
                    "lot_added_qty": round(
                        to_float(lot_result.get("added_qty"), 0.0),
                        6,
                    ),
                    "lot_balance_matches_stock_after": (
                        int(
                            abs(
                                to_float(
                                    lot_result.get("balance_after_qty"),
                                    0.0,
                                )
                                - stock_after_qty
                            )
                            <= LOT_TRACE_EPS
                        )
                        if lot_ledger.enabled
                        else ""
                    ),
                    "source_csv": str(measurement_start_stock_scale_csv_path),
                    "source_csv_sha256": (
                        measurement_start_stock_scale_csv_sha256
                    ),
                }
                measurement_start_stock_adjustment_rows.append(adjustment_row)
                totals = measurement_totals_by_uom[unit or "unspecified"]
                totals["stock_before_qty"] += stock_before_qty
                totals["stock_after_qty"] += stock_after_qty
                totals["stock_removed_qty"] += stock_removed_qty
                totals["stock_added_qty"] += stock_added_qty
                assumptions_ledger_rows.append(
                    {
                        "category": "measurement_start_stock_scale",
                        "node_id": pair[0],
                        "item_id": pair[1],
                        "edge_id": "",
                        "source": str(measurement_start_stock_scale_csv_path),
                        "payload_json": json.dumps(
                            adjustment_row,
                            ensure_ascii=False,
                            sort_keys=True,
                        ),
                    }
                )
            measurement_start_stock_scale_audit["adjustment_rows"] = len(
                measurement_start_stock_adjustment_rows
            )
            measurement_start_stock_scale_audit["quantities_by_uom"] = {
                unit: {
                    key: round(value, 6)
                    for key, value in values.items()
                }
                for unit, values in sorted(measurement_totals_by_uom.items())
            }
        if day == warmup_days and measurement_start_in_transit_scale_overrides:
            transit_totals_by_uom: dict[str, dict[str, float]] = defaultdict(
                lambda: {
                    "in_transit_before_qty": 0.0,
                    "in_transit_after_qty": 0.0,
                    "in_transit_removed_qty": 0.0,
                    "lot_pipeline_before_qty": 0.0,
                    "lot_pipeline_after_qty": 0.0,
                    "lot_pipeline_removed_qty": 0.0,
                }
            )
            for pair, factor in sorted(
                measurement_start_in_transit_scale_overrides.items()
            ):
                arrival_details: dict[int, dict[str, float | int]] = {}
                standard_before_qty = 0.0
                standard_after_qty = 0.0
                standard_row_count = 0
                for arrival_day in sorted(list(pipeline.keys())):
                    rewritten_rows: list[tuple[str, str, float, str]] = []
                    for dst_node_id, item_id, qty, edge_id in pipeline[arrival_day]:
                        before_qty = max(0.0, to_float(qty, 0.0))
                        if (str(dst_node_id), str(item_id)) != pair:
                            rewritten_rows.append(
                                (dst_node_id, item_id, before_qty, edge_id)
                            )
                            continue
                        after_qty = physical_execution_quantity(before_qty * factor, item_unit_map.get(pair[1], ""))
                        standard_before_qty += before_qty
                        standard_after_qty += after_qty
                        standard_row_count += 1
                        detail = arrival_details.setdefault(
                            int(arrival_day),
                            {
                                "pipeline_row_count": 0,
                                "pipeline_before_qty": 0.0,
                                "pipeline_after_qty": 0.0,
                                "lot_payload_count": 0,
                                "lot_before_qty": 0.0,
                                "lot_after_qty": 0.0,
                            },
                        )
                        detail["pipeline_row_count"] = int(
                            detail["pipeline_row_count"]
                        ) + 1
                        detail["pipeline_before_qty"] = float(
                            detail["pipeline_before_qty"]
                        ) + before_qty
                        detail["pipeline_after_qty"] = float(
                            detail["pipeline_after_qty"]
                        ) + after_qty
                        if after_qty > LOT_TRACE_EPS:
                            rewritten_rows.append(
                                (dst_node_id, item_id, after_qty, edge_id)
                            )
                    pipeline[arrival_day] = rewritten_rows

                lot_before_qty = 0.0
                lot_after_qty = 0.0
                lot_payload_count = 0
                for arrival_day in sorted(list(lot_arrivals_pipeline.keys())):
                    for payload in lot_arrivals_pipeline[arrival_day]:
                        if (
                            str(payload.get("dst_node_id") or ""),
                            str(payload.get("item_id") or ""),
                        ) != pair:
                            continue
                        before_qty = max(0.0, to_float(payload.get("qty"), 0.0))
                        after_qty = physical_execution_quantity(before_qty * factor, item_unit_map.get(pair[1], ""))
                        payload["qty"] = after_qty
                        payload["parent_allocations"] = scale_physical_allocations(
                            list(payload.get("parent_allocations") or []), factor,
                            item_unit_map.get(pair[1], ""),
                        )
                        lot_before_qty += before_qty
                        lot_after_qty += after_qty
                        lot_payload_count += 1
                        detail = arrival_details.setdefault(
                            int(arrival_day),
                            {
                                "pipeline_row_count": 0,
                                "pipeline_before_qty": 0.0,
                                "pipeline_after_qty": 0.0,
                                "lot_payload_count": 0,
                                "lot_before_qty": 0.0,
                                "lot_after_qty": 0.0,
                            },
                        )
                        detail["lot_payload_count"] = int(
                            detail["lot_payload_count"]
                        ) + 1
                        detail["lot_before_qty"] = float(
                            detail["lot_before_qty"]
                        ) + before_qty
                        detail["lot_after_qty"] = float(
                            detail["lot_after_qty"]
                        ) + after_qty
                    lot_arrivals_pipeline[arrival_day] = [
                        payload
                        for payload in lot_arrivals_pipeline[arrival_day]
                        if (
                            str(payload.get("dst_node_id") or ""),
                            str(payload.get("item_id") or ""),
                        )
                        != pair
                        or max(0.0, to_float(payload.get("qty"), 0.0))
                        > LOT_TRACE_EPS
                    ]

                in_transit_before_qty = max(0.0, in_transit.get(pair, 0.0))
                in_transit_after_qty = in_transit_before_qty * factor
                in_transit[pair] = in_transit_after_qty
                unit = normalize_unit(item_unit_map.get(pair[1], ""))
                arrival_days_payload = [
                    {
                        "arrival_day_internal": int(arrival_day),
                        "arrival_day_measured": int(arrival_day - warmup_days),
                        **{
                            key: round(float(value), 6)
                            if key.endswith("_qty")
                            else int(value)
                            for key, value in detail.items()
                        },
                    }
                    for arrival_day, detail in sorted(arrival_details.items())
                ]
                adjustment_row = {
                    "measured_day": 0,
                    "node_id": pair[0],
                    "item_id": pair[1],
                    "uom": unit,
                    "scale": round(factor, 9),
                    "in_transit_before_qty": round(in_transit_before_qty, 6),
                    "in_transit_after_qty": round(in_transit_after_qty, 6),
                    "in_transit_removed_qty": round(
                        in_transit_before_qty - in_transit_after_qty, 6
                    ),
                    "standard_pipeline_before_qty": round(
                        standard_before_qty, 6
                    ),
                    "standard_pipeline_after_qty": round(standard_after_qty, 6),
                    "standard_pipeline_removed_qty": round(
                        standard_before_qty - standard_after_qty, 6
                    ),
                    "standard_pipeline_row_count": standard_row_count,
                    "lot_trace_enabled": int(lot_ledger.enabled),
                    "lot_pipeline_before_qty": round(lot_before_qty, 6),
                    "lot_pipeline_after_qty": round(lot_after_qty, 6),
                    "lot_pipeline_removed_qty": round(
                        lot_before_qty - lot_after_qty, 6
                    ),
                    "lot_payload_count": lot_payload_count,
                    "arrival_day_count": len(arrival_days_payload),
                    "arrival_days_json": json.dumps(
                        arrival_days_payload,
                        ensure_ascii=False,
                        sort_keys=True,
                    ),
                    "pipeline_matches_in_transit_before": int(
                        abs(standard_before_qty - in_transit_before_qty)
                        <= LOT_TRACE_EPS
                    ),
                    "pipeline_matches_in_transit_after": int(
                        abs(standard_after_qty - in_transit_after_qty)
                        <= LOT_TRACE_EPS
                    ),
                    "external_in_transit_unchanged_qty": round(
                        max(0.0, external_in_transit.get(pair, 0.0)), 6
                    ),
                    "estimated_source_in_transit_unchanged_qty": round(
                        max(0.0, estimated_source_in_transit.get(pair, 0.0)), 6
                    ),
                    "source_csv": str(
                        measurement_start_in_transit_scale_csv_path
                    ),
                    "source_csv_sha256": (
                        measurement_start_in_transit_scale_csv_sha256
                    ),
                }
                measurement_start_in_transit_adjustment_rows.append(
                    adjustment_row
                )
                totals = transit_totals_by_uom[unit or "unspecified"]
                for key in totals:
                    totals[key] += float(adjustment_row[key])
                assumptions_ledger_rows.append(
                    {
                        "category": "measurement_start_in_transit_scale",
                        "node_id": pair[0],
                        "item_id": pair[1],
                        "edge_id": "",
                        "source": str(
                            measurement_start_in_transit_scale_csv_path
                        ),
                        "payload_json": json.dumps(
                            adjustment_row,
                            ensure_ascii=False,
                            sort_keys=True,
                        ),
                    }
                )
            measurement_start_in_transit_scale_audit["adjustment_rows"] = len(
                measurement_start_in_transit_adjustment_rows
            )
            measurement_start_in_transit_scale_audit["quantities_by_uom"] = {
                unit: {
                    key: round(value, 6)
                    for key, value in values.items()
                }
                for unit, values in sorted(transit_totals_by_uom.items())
            }
        if day == warmup_days and args.warmup_boundary_audit:
            boundary_components = {
                "stock": dict(stock),
                "backlog": dict(backlog),
                "pipeline": dict(pipeline),
                "external_pipeline": dict(external_pipeline),
                "estimated_source_pipeline": dict(estimated_source_pipeline),
                "in_transit": dict(in_transit),
                "external_in_transit": dict(external_in_transit),
                "estimated_source_in_transit": dict(estimated_source_in_transit),
                "cumulative_output": dict(cum_output_by_pair),
                "previous_production_command": dict(
                    prev_production_command_by_pair
                ),
                "open_production_campaign_qty": dict(
                    open_production_campaign_qty_by_pair
                ),
                "open_production_campaign_id": dict(
                    open_production_campaign_id_by_pair
                ),
                "started_production_lots_by_week": dict(
                    started_production_lots_by_week_pair
                ),
                "mps_previous_production_command": dict(
                    mps_prev_production_command_by_pair
                ),
                "mps_open_campaign_qty": dict(mps_open_campaign_qty_by_pair),
                "mps_started_lots_by_week": dict(
                    mps_started_lots_by_week_pair
                ),
                "scheduled_lane_release_metrics": dict(
                    scheduled_lane_release_metrics
                ),
                "mrp_multisource_annual_lane_orders": set(
                    mrp_multisource_annual_lane_orders
                ),
                "mrp_target_demand_floor_cache": dict(
                    mrp_target_demand_floor_cache
                ),
                "supplier_state_risk_events": list(supplier_state_risk_events),
                "supplier_state_risk_open_until": dict(
                    supplier_state_risk_open_until_by_key
                ),
                "supplier_state_risk_counters": dict(
                    supplier_state_risk_counters
                ),
                "supplier_state_risk_metric_windows": {
                    key: list(window)
                    for key, window in supplier_state_risk_metric_windows.items()
                },
                "lot_arrivals_pipeline": dict(lot_arrivals_pipeline),
                "lot_ledger": {
                    "enabled": bool(lot_ledger.enabled),
                    "lot_seq": int(lot_ledger._lot_seq),
                    "event_seq": int(lot_ledger._event_seq),
                    "campaign_seq": int(lot_ledger._campaign_seq),
                    "lots_by_pair": {
                        key: list(queue)
                        for key, queue in lot_ledger.lots_by_pair.items()
                    },
                    "lots": dict(lot_ledger.lots),
                },
                "rng_state": rng.getstate(),
                "paired_rng_invocations": dict(paired_rng_invocations),
            }
            component_hashes = {
                name: _warmup_boundary_sha256(component)
                for name, component in sorted(boundary_components.items())
            }
            warmup_boundary_state_audit = {
                "schema_version": "etudecas.engine_warmup_boundary_audit.v1",
                "method": "deterministic_paired_burn_in_replay",
                "scope": "core_dynamic_engine_state_not_restart_checkpoint",
                "physical_warmup_days": int(warmup_days),
                "measured_cutover_day": 0,
                "core_state_sha256": _warmup_boundary_sha256(
                    boundary_components
                ),
                "component_sha256": component_hashes,
                "restart_checkpoint_available": False,
                **(
                    {
                        "opening_observed_stock_scale": (
                            opening_observed_stock_scale_audit
                        )
                    }
                    if opening_observed_stock_scale_requested
                    else {}
                ),
                **(
                    {
                        "measurement_start_stock_scale": (
                            measurement_start_stock_scale_audit
                        )
                    }
                    if measurement_start_stock_scale_csv_path
                    else {}
                ),
                **(
                    {
                        "measurement_start_in_transit_scale": (
                            measurement_start_in_transit_scale_audit
                        )
                    }
                    if measurement_start_in_transit_scale_csv_path
                    else {}
                ),
            }
        availability_released_today = (
            initial_stock_availability.release(output_day, stock=stock, ledger=lot_ledger)
            if initial_stock_availability is not None else {}
        )
        supplier_stock_start_by_pair = (
            {pair: max(0.0, stock.get(pair, 0.0)) for pair in supplier_stock_pairs}
            if record_day
            else {}
        )
        backlog_start_of_day_by_pair = {
            pair: max(0.0, backlog.get(pair, 0.0))
            for pair in mrp_trace_pairs
        }
        raw_demand_target_today = demand_targets_for_day(
            demand_profiles,
            profile_day,
            window_days=1,
            value_cache=demand_profile_value_cache,
        )
        demand_target_today = demand_targets_for_day(
            demand_profiles,
            profile_day,
            window_days=mrp_signal_smoothing_days,
            value_cache=demand_profile_value_cache,
        )
        base_physical_demand_target_today = raw_demand_target_today
        if record_day and demand_perturbation.enabled:
            raw_demand_target_today = demand_perturbation.apply(
                output_day,
                raw_demand_target_today,
            )
            demand_target_today = demand_perturbation.apply(
                output_day,
                demand_target_today,
            )
        mrp_target_profile_day = (
            (profile_day // mrp_target_bucket_days) * mrp_target_bucket_days
            if mrp_target_bucket_days > 1
            else profile_day
        )
        mrp_raw_demand_target_today = (
            demand_targets_for_day(
                demand_profiles,
                mrp_target_profile_day,
                window_days=1,
                value_cache=demand_profile_value_cache,
            )
            if mrp_target_bucket_days > 1
            else raw_demand_target_today
        )
        mrp_demand_target_today = (
            demand_targets_for_day(
                demand_profiles,
                mrp_target_profile_day,
                window_days=mrp_signal_smoothing_days,
                value_cache=demand_profile_value_cache,
            )
            if mrp_target_bucket_days > 1
            else demand_target_today
        )
        if (
            record_day
            and demand_perturbation.enabled
            and mrp_target_bucket_days > 1
        ):
            mrp_raw_demand_target_today = demand_perturbation.apply(
                output_day,
                mrp_raw_demand_target_today,
            )
            mrp_demand_target_today = demand_perturbation.apply(
                output_day,
                mrp_demand_target_today,
            )
        if record_day and demand_perturbation.enabled:
            for perturbation_row in demand_perturbation.rows_for_day(output_day):
                base_demand_qty = max(
                    0.0,
                    float(
                        base_physical_demand_target_today.get(
                            perturbation_row.pair,
                            0.0,
                        )
                    ),
                )
                perturbed_demand_qty = max(
                    0.0,
                    float(
                        raw_demand_target_today.get(
                            perturbation_row.pair,
                            0.0,
                        )
                    ),
                )
                demand_perturbation_audit_rows.append(
                    {
                        "day": int(output_day),
                        "node_id": perturbation_row.node_id,
                        "item_id": perturbation_row.item_id,
                        "demand_multiplier": perturbation_row.demand_multiplier,
                        "base_demand_qty": round(base_demand_qty, 6),
                        "perturbed_demand_qty": round(
                            perturbed_demand_qty,
                            6,
                        ),
                        "demand_delta_qty": round(
                            perturbed_demand_qty - base_demand_qty,
                            6,
                        ),
                        "source_line": perturbation_row.source_line,
                        "status": "applied",
                    }
                )
                demand_perturbation_applied_keys.add(
                    (
                        int(output_day),
                        perturbation_row.node_id,
                        perturbation_row.item_id,
                    )
                )
        if mrp_source_forecasts is not None:
            mrp_raw_demand_target_today = planning_demand_targets_for_day(
                output_day, mrp_target_profile_day, window_days=1,
            )
            mrp_demand_target_today = planning_demand_targets_for_day(
                output_day, mrp_target_profile_day, window_days=mrp_signal_smoothing_days,
            )
        production_reference_signal_today = (
            propagate_supply_demand_rates(
                mrp_demand_target_today, lanes, process_input_requirements_by_output_pair,
            ) if forecast_production_signal else output_daily_signal_by_pair
        )
        if (
            initialization_policy["use_bom_demand_signal_for_mrp"]
            and mrp_demand_signal_source == "mps_lotified"
        ):
            raw_propagated_demand_today = propagate_supply_demand_rates(
                mrp_raw_demand_target_today,
                lanes,
                process_input_requirements_by_output_pair,
            )
            same_item_demand_today = propagate_demand_rates(mrp_demand_target_today, lanes)
            mps_output_command_today: dict[tuple[str, str], float] = {}
            mps_capacity_today = dict(process_capacity_by_output_pair)
            for out_pair in process_input_requirements_by_output_pair:
                out_signal = max(
                    0.0,
                    same_item_demand_today.get(out_pair, 0.0),
                    production_reference_signal_today.get(out_pair, 0.0),
                )
                out_stock = max(0.0, stock[out_pair])
                if initial_stock_availability is not None:
                    out_stock += initial_stock_availability.planning_quantity(
                        out_pair, decision_day=output_day,
                        through_day=output_day + max(0, int(math.ceil(fg_target_days)) - 1),
                    )
                base_out_target = max(
                    base_stock.get(out_pair, 0.0),
                    fg_target_days * out_signal,
                )
                historical_out_target = base_out_target
                production_safety_enabled = args.production_mrp_safety_targets and out_pair in mrp_snapshot_pairs
                if production_safety_enabled:
                    base_out_target = production_mrp_safety_target(
                        historical_out_target, out_signal,
                        pair_mrp_safety_time_days.get(out_pair, 0.0),
                        pair_mrp_safety_stock_qty.get(out_pair, 0.0),
                    )
                production_control = resolve_daily_control(
                    node_id=out_pair[0],
                    item_id=out_pair[1],
                )
                target_multiplier = (
                    production_control.production_target_multiplier
                    if production_control is not None
                    else 1.0
                )
                capacity_multiplier = (
                    production_control.capacity_multiplier
                    if production_control is not None
                    else 1.0
                )
                out_target = base_out_target * target_multiplier
                if record_production_planning:
                    production_safety_decisions.setdefault(out_pair, {}).update({
                        "mps_mrp_safety_enabled": int(production_safety_enabled),
                        "mps_target_signal_qty": round(out_signal, 6),
                        "mps_historical_target_qty": round(historical_out_target, 6),
                        "mps_safety_floor_qty": round(production_mrp_safety_target(
                            0.0, out_signal, pair_mrp_safety_time_days.get(out_pair, 0.0),
                            pair_mrp_safety_stock_qty.get(out_pair, 0.0),
                        ), 6) if production_safety_enabled else 0.0,
                        "mps_applied_target_qty": round(out_target, 6),
                        "mps_safety_time_days": round(pair_mrp_safety_time_days.get(out_pair, 0.0), 6),
                        "mps_safety_stock_qty": round(pair_mrp_safety_stock_qty.get(out_pair, 0.0), 6),
                        "mps_target_multiplier": round(target_multiplier, 6),
                        "mps_stock_position_qty": round(out_stock, 6),
                        "mps_reference_signal_basis": "multilevel_forecast" if forecast_production_signal else "historical_capacity",
                        "mps_reference_signal_qty": round(production_reference_signal_today.get(out_pair, 0.0), 6),
                    })
                if out_pair in mps_capacity_today:
                    mps_capacity_today[out_pair] = max(
                        0.0,
                        mps_capacity_today[out_pair] * capacity_multiplier,
                    )
                raw_command = out_signal + production_gap_gain * (out_target - out_stock)
                if out_signal <= 1e-9 and out_pair not in lanes_by_src_item:
                    raw_command = 0.0
                prev_cmd = mps_prev_production_command_by_pair.get(out_pair, raw_command)
                desired_qty = production_smoothing * prev_cmd + (1.0 - production_smoothing) * raw_command
                desired_qty = max(0.0, desired_qty)
                lot_policy = production_lot_policy_by_pair.get(out_pair, {"enabled": False})
                mps_campaign_remaining_qty = max(0.0, mps_open_campaign_qty_by_pair.get(out_pair, 0.0))
                if (
                    lot_policy.get("enabled")
                    and mps_campaign_remaining_qty <= 1e-9
                    and (
                        raw_command <= 1e-9
                        or should_defer_new_lot_for_stock_position(
                            desired_qty=desired_qty,
                            lot_policy=lot_policy,
                            stock_qty=out_stock,
                            target_qty=out_target,
                        )
                    )
                ):
                    # A residual smoothed command must not launch a fresh fixed lot
                    # when the current inventory position already covers the target
                    # band for the next lot.
                    desired_qty = 0.0
                mps_prev_production_command_by_pair[out_pair] = desired_qty
                if desired_qty > 1e-9:
                    mps_output_command_today[out_pair] = desired_qty
                if production_control is not None:
                    mps_control_actions = [
                        "production_target_multiplier"
                    ]
                    if out_pair in mps_capacity_today:
                        mps_control_actions.append(
                            "capacity_multiplier"
                        )
                    record_control_resolution(
                        production_control,
                        stage="mps_target_before_lotification",
                        action_names=tuple(mps_control_actions),
                        executed_control_volume_qty=desired_qty,
                        extra={
                            "quantity_uom": item_unit_map.get(out_pair[1], ""),
                            "q_target_base_qty": round(base_out_target, 6),
                            "q_target_controlled_qty": round(out_target, 6),
                            "q_command_before_lotification_qty": round(
                                desired_qty,
                                6,
                            ),
                            "capacity_base_qty_per_day": round(
                                process_capacity_by_output_pair.get(
                                    out_pair,
                                    0.0,
                                ),
                                6,
                            ),
                            "capacity_controlled_qty_per_day": round(
                                mps_capacity_today.get(out_pair, 0.0),
                                6,
                            ),
                        },
                    )
            mps_component_signal_today, _mps_output_signal_today = lotified_mps_component_signal(
                mps_output_command_today,
                day=day,
                process_input_requirements_by_output_pair=process_input_requirements_by_output_pair,
                production_lot_policy_by_pair=production_lot_policy_by_pair,
                process_capacity_by_output_pair=mps_capacity_today,
                mps_open_campaign_qty_by_pair=mps_open_campaign_qty_by_pair,
                mps_started_lots_by_week_pair=mps_started_lots_by_week_pair,
                expand_internal_outputs=not forecast_production_signal,
            )
            propagated_demand_today = dict(same_item_demand_today)
            for pair, qty in propagate_demand_rates(mps_component_signal_today, lanes).items():
                propagated_demand_today[pair] = propagated_demand_today.get(pair, 0.0) + qty
        elif initialization_policy["use_bom_demand_signal_for_mrp"]:
            raw_propagated_demand_today = propagate_supply_demand_rates(
                mrp_raw_demand_target_today,
                lanes,
                process_input_requirements_by_output_pair,
            )
            propagated_demand_today = propagate_supply_demand_rates(
                mrp_demand_target_today,
                lanes,
                process_input_requirements_by_output_pair,
            )
        else:
            raw_propagated_demand_today = propagate_demand_rates(mrp_raw_demand_target_today, lanes)
            propagated_demand_today = propagate_demand_rates(mrp_demand_target_today, lanes)

        def mrp_target_requirement_for_pair(
            pair: tuple[str, str],
            current_daily_req: float,
            pair_review_period_days: int,
        ) -> tuple[float, float, int, float]:
            effective_cover_days = float(pair_stock_cover_days.get(pair, pair_review_period_days + 1))
            if initialization_policy["seed_open_orders_from_january_snapshot"]:
                effective_cover_days = mrp_opening_order_cover_days(
                    effective_cover_days,
                    opening_open_order_bridge_days_by_pair.get(pair, 0),
                    quantity_netting_only=forecast_production_signal,
                )
            target_window_days = max(
                1,
                int(math.ceil(effective_cover_days)),
                int(math.ceil(max(0.0, pair_mrp_safety_time_days.get(pair, 0.0)))),
                int(math.ceil(max(0.0, safety_stock_days))),
                int(math.ceil(max(0.0, demand_stock_target_days))) if pair in demand_pairs else 1,
            )
            floor_req = max(
                0.0,
                mrp_target_demand_floor_by_pair(mrp_target_profile_day, target_window_days).get(pair, 0.0),
            )
            # For explicitly dynamic component pairs, the current lotified MPS
            # signal can be a large one-day batch.  Sizing the whole lead-time
            # cover from that single spike repeatedly over-orders and builds a
            # fictitious multi-year buffer.  Use the forward cover-window mean
            # for the stock target; the daily signal still drives order cadence.
            target_daily_req = max(max(0.0, current_daily_req), floor_req)
            if smoothed_cover_requirement_for_pair(pair) and floor_req > 1e-9:
                target_daily_req = floor_req
            return target_daily_req, floor_req, target_window_days, effective_cover_days

        arrivals_today = pipeline.pop(day, [])
        external_arrivals_today = external_pipeline.pop(day, [])
        estimated_source_arrivals_today = estimated_source_pipeline.pop(day, [])
        dated_receipt_decisions: dict[tuple[str, str], dict[str, Any]] = {}
        if pending_receipt_calendar is not None:
            # These receipts are credited to physical stock below, before MRP
            # decisions. Removing them now prevents counting them twice.
            for received_rows in (arrivals_today, external_arrivals_today, estimated_source_arrivals_today):
                for receipt in received_rows:
                    pending_receipt_calendar.remove((receipt[0], receipt[1]), day, receipt[2])
        lot_departures_today = lot_departure_pipeline.pop(day, [])
        lot_arrivals_today = lot_arrivals_pipeline.pop(day, [])
        arrivals_qty = 0.0
        external_arrivals_qty = 0.0
        estimated_source_arrivals_qty = 0.0
        arrivals_today_by_pair: dict[tuple[str, str], float] = defaultdict(float)
        external_arrivals_today_by_pair: dict[tuple[str, str], float] = defaultdict(float)
        estimated_source_arrivals_today_by_pair: dict[tuple[str, str], float] = defaultdict(float)
        estimated_capacity_replenished_today_by_pair: dict[tuple[str, str], float] = defaultdict(float)
        supplier_stock_writeoff_today_by_pair: dict[tuple[str, str], float] = defaultdict(float)
        produced_today = 0.0
        produced_today_by_pair: dict[tuple[str, str], float] = defaultdict(float)
        production_executed_today_by_pair: dict[tuple[str, str], float] = defaultdict(float)
        consumed_today_by_pair: dict[tuple[str, str], float] = defaultdict(float)
        lot_arrivals_by_key: dict[tuple[str, str, str], deque[dict[str, Any]]] = defaultdict(deque)
        for departure_payload in lot_departures_today:
            departure_allocations = departure_payload.get("parent_allocations")
            if not isinstance(departure_allocations, list):
                departure_allocations = []
            if bool(departure_payload.get("materialize_backorder_origin")):
                source_lot_id = lot_ledger.create_lot(
                    day=output_day,
                    node_id=str(departure_payload.get("src_node_id") or ""),
                    item_id=str(departure_payload.get("item_id") or ""),
                    qty=max(0.0, to_float(departure_payload.get("qty"), 0.0)),
                    source_type="supplier_backorder_fulfillment",
                    source_id=str(departure_payload.get("source_id") or ""),
                    uom=str(departure_payload.get("uom") or ""),
                    event_type="supplier_backorder_fulfillment",
                    notes=(
                        "Modeled upstream fulfillment created at physical departure; "
                        "source business batch is unavailable."
                    ),
                    shipment_id=str(departure_payload.get("shipment_id") or ""),
                    risk_decision_day=departure_payload.get("risk_decision_day", ""),
                    risk_event_ids=str(departure_payload.get("risk_event_ids") or ""),
                    departure_day=output_day,
                    arrival_day=departure_payload.get("arrival_day", ""),
                    trace_status="modeled_backorder_origin",
                    trace_reason="supplier_source_batch_not_available_in_model",
                    causal_event_ids=departure_payload.get("causal_event_ids"),
                    causal_root_ids=departure_payload.get("causal_root_ids"),
                    planned_order_id=str(
                        departure_payload.get("planned_order_id") or ""
                    ),
                    baseline_reference_id=str(
                        departure_payload.get("baseline_reference_id") or ""
                    ),
                )
                if source_lot_id:
                    departure_allocations.extend(
                        lot_ledger.consume(
                            day=output_day,
                            node_id=str(departure_payload.get("src_node_id") or ""),
                            item_id=str(departure_payload.get("item_id") or ""),
                            qty=max(0.0, to_float(departure_payload.get("qty"), 0.0)),
                            event_type="lane_ship",
                            source_id=str(departure_payload.get("source_id") or ""),
                            uom=str(departure_payload.get("uom") or ""),
                            shipment_id=str(
                                departure_payload.get("shipment_id") or ""
                            ),
                            risk_decision_day=departure_payload.get("risk_decision_day", ""),
                            risk_event_ids=str(departure_payload.get("risk_event_ids") or ""),
                            departure_day=output_day,
                            arrival_day=departure_payload.get("arrival_day", ""),
                            trace_status="modeled_backorder_origin",
                            trace_reason="supplier_source_batch_not_available_in_model",
                            causal_event_ids=departure_payload.get(
                                "causal_event_ids"
                            ),
                            causal_root_ids=departure_payload.get(
                                "causal_root_ids"
                            ),
                            planned_order_id=str(
                                departure_payload.get("planned_order_id") or ""
                            ),
                            baseline_reference_id=str(
                                departure_payload.get("baseline_reference_id") or ""
                            ),
                        )
                    )
            else:
                lot_ledger.record_allocation_event(
                    day=output_day,
                    event_type="lane_ship",
                    parent_allocations=departure_allocations,
                    source_id=str(departure_payload.get("source_id") or ""),
                    shipment_id=str(departure_payload.get("shipment_id") or ""),
                    risk_decision_day=departure_payload.get("risk_decision_day", ""),
                    risk_event_ids=str(departure_payload.get("risk_event_ids") or ""),
                    departure_day=output_day,
                    arrival_day=departure_payload.get("arrival_day", ""),
                    handling_unit_id=str(
                        departure_payload.get("handling_unit_id") or ""
                    ),
                    notes="Physical departure after an earlier stock reservation.",
                    trace_status=str(
                        departure_payload.get("trace_status") or "traced"
                    ),
                    trace_reason=str(
                        departure_payload.get("trace_reason") or ""
                    ),
                    planned_order_id=str(
                        departure_payload.get("planned_order_id") or ""
                    ),
                    baseline_reference_id=str(
                        departure_payload.get("baseline_reference_id") or ""
                    ),
                )
        for lot_payload in lot_arrivals_today:
            lot_arrivals_by_key[
                (
                    str(lot_payload.get("dst_node_id") or ""),
                    str(lot_payload.get("item_id") or ""),
                    str(lot_payload.get("lane_id") or ""),
                )
            ].append(dict(lot_payload))

        def scaled_lot_allocations(parent_allocations: list[dict[str, Any]], factor: float) -> list[dict[str, Any]]:
            factor = max(0.0, min(1.0, factor))
            return [
                {
                    **alloc,
                    "qty": max(0.0, to_float(alloc.get("qty"), 0.0)) * factor,
                }
                for alloc in parent_allocations
                if max(0.0, to_float(alloc.get("qty"), 0.0)) * factor > 1e-9
            ]

        def record_lane_lot_receipt(dst_node_id: str, item_id: str, qty: float, lane_id: str) -> None:
            if not lot_ledger.enabled or qty <= 1e-9:
                return
            output_day_for_lot = int(day - warmup_days)
            remaining = max(0.0, qty)
            key = (str(dst_node_id), str(item_id), str(lane_id))
            queue = lot_arrivals_by_key.get(key)
            while remaining > 1e-9 and queue:
                payload = queue[0]
                payload_qty = max(0.0, to_float(payload.get("qty"), 0.0))
                if payload_qty <= 1e-9:
                    queue.popleft()
                    continue
                take = min(remaining, payload_qty)
                factor = take / payload_qty if payload_qty > 1e-9 else 0.0
                parents = scaled_lot_allocations(payload.get("parent_allocations") or [], factor)
                lot_ledger.create_child_lot(
                    day=output_day_for_lot,
                    node_id=dst_node_id,
                    item_id=item_id,
                    qty=take,
                    source_type=str(payload.get("source_type") or "lane_receipt"),
                    source_id=str(payload.get("source_id") or lane_id),
                    shipment_id=str(payload.get("shipment_id") or ""),
                    risk_decision_day=payload.get("risk_decision_day", ""),
                    risk_event_ids=str(payload.get("risk_event_ids") or ""),
                    parent_allocations=parents,
                    link_type=str(payload.get("link_type") or "transport"),
                    uom=item_unit_map.get(item_id, ""),
                    notes=str(payload.get("notes") or ""),
                    departure_day=payload.get("departure_day", ""),
                    arrival_day=payload.get("arrival_day", output_day_for_lot),
                    handling_unit_id=str(payload.get("handling_unit_id") or ""),
                    trace_status=str(payload.get("trace_status") or "traced"),
                    trace_reason=str(payload.get("trace_reason") or ""),
                    causal_event_ids=payload.get("causal_event_ids") or "",
                    causal_root_ids=payload.get("causal_root_ids") or "",
                    planned_order_id=str(payload.get("planned_order_id") or ""),
                    baseline_reference_id=str(payload.get("baseline_reference_id") or ""),
                )
                remaining -= take
                payload["qty"] = payload_qty - take
                if payload["qty"] <= 1e-9:
                    queue.popleft()
            if remaining > 1e-9:
                lot_ledger.create_lot(
                    day=output_day_for_lot,
                    node_id=dst_node_id,
                    item_id=item_id,
                    qty=remaining,
                    source_type="lane_receipt",
                    source_id=lane_id,
                    uom=item_unit_map.get(item_id, ""),
                    event_type="lane_receipt",
                    notes="Receipt existed in aggregate pipeline without scheduled parent lot detail.",
                    arrival_day=output_day_for_lot,
                    trace_status="untraced_origin",
                    trace_reason="aggregate_pipeline_without_scheduled_lot_detail",
                )

        def issue_opening_production_order_components(
            dst_node_id: str,
            item_id: str,
            qty: float,
            source_id: str,
            *,
            issue_day_for_record: int,
            receipt_day_for_record: int | str,
            mode: str,
        ) -> list[dict[str, Any]]:
            """Issue BOM components for source O.Proc rows and record the reconciliation.

            In a source-truth run, O.Proc rows represent firm manufacturing orders.
            The component issue belongs to the order/release date, while the output
            receipt belongs to the entry date.  When mode is ``wip``, components are
            treated as already issued before the simulation cut-over and do not
            consume free stock.
            """

            if qty <= 1e-9:
                return []
            output_pair = (str(dst_node_id), str(item_id))
            parent_allocations: list[dict[str, Any]] = []
            input_requirements = process_input_requirements_by_output_pair.get(output_pair, [])
            for input_pair, req_per_output_unit in input_requirements:
                required_qty = max(0.0, qty * req_per_output_unit)
                if required_qty <= 1e-9:
                    continue
                available_qty = available_bom_input_qty(input_pair[0], input_pair[1], int(issue_day_for_record))
                if mode == "wip":
                    consumed_qty = 0.0
                    assumed_wip_qty = required_qty
                    shortage_qty = 0.0
                else:
                    consumed_qty = min(required_qty, available_qty)
                    assumed_wip_qty = 0.0
                    shortage_qty = max(0.0, required_qty - consumed_qty)
                if consumed_qty > 1e-9:
                    parent_allocations.extend(
                        consume_bom_input_with_reference_transition(
                            output_day=issue_day_for_record,
                            node_id=input_pair[0],
                            item_id=input_pair[1],
                            qty=consumed_qty,
                            event_type="opening_production_consume",
                            source_id=source_id,
                            production_campaign_id="",
                            consumed_today_by_pair=consumed_today_by_pair,
                        )
                    )
                opening_production_consumption_rows.append(
                    {
                        "day": issue_day_for_record,
                        "issue_day": issue_day_for_record,
                        "receipt_day": receipt_day_for_record,
                        "node_id": output_pair[0],
                        "output_item_id": output_pair[1],
                        "component_node_id": input_pair[0],
                        "component_item_id": input_pair[1],
                        "bom_issue_mode": mode,
                        "opening_production_qty": round(qty, 6),
                        "required_component_qty": round(required_qty, 6),
                        "consumed_from_stock_qty": round(consumed_qty, 6),
                        "assumed_initial_wip_qty": round(assumed_wip_qty, 6),
                        "shortage_assumed_wip_or_source_gap_qty": round(shortage_qty, 6),
                        "source_id": source_id,
                    }
                )
            return parent_allocations

        def record_opening_production_order_receipt(dst_node_id: str, item_id: str, qty: float, source_id: str) -> None:
            """Materialize an opening production order output receipt.

            The BOM issue can be handled at receipt (legacy), at release date
            (source-truth), or as opening WIP.  The output receipt remains dated
            by the source entry/usable day.
            """

            nonlocal produced_today
            if qty <= 1e-9:
                return
            output_pair = (str(dst_node_id), str(item_id))
            output_day_for_lot = int(day - warmup_days)
            parent_allocations: list[dict[str, Any]] = []
            if opening_production_order_bom_issue_mode in {"receipt", "wip"}:
                issue_day_for_record = (
                    -1
                    if opening_production_order_bom_issue_mode == "wip"
                    else output_day_for_lot
                )
                parent_allocations = issue_opening_production_order_components(
                    dst_node_id,
                    item_id,
                    qty,
                    source_id,
                    issue_day_for_record=issue_day_for_record,
                    receipt_day_for_record=output_day_for_lot,
                    mode=opening_production_order_bom_issue_mode,
                )
            lot_ledger.create_child_lot(
                day=output_day_for_lot,
                node_id=output_pair[0],
                item_id=output_pair[1],
                qty=qty,
                source_type="opening_production_order",
                source_id=source_id,
                parent_allocations=parent_allocations,
                link_type="production",
                uom=item_unit_map.get(output_pair[1], ""),
                notes="Opening production order received from source order book.",
            )
            produced_today += qty
            produced_today_by_pair[output_pair] += qty

        for issue_payload in opening_production_bom_issues_by_day.pop(day, []):
            issue_opening_production_order_components(
                str(issue_payload.get("node_id") or ""),
                str(issue_payload.get("item_id") or ""),
                max(0.0, to_float(issue_payload.get("qty"), 0.0)),
                str(issue_payload.get("source_id") or ""),
                issue_day_for_record=int(day - warmup_days),
                receipt_day_for_record=int(to_float(issue_payload.get("usable_day"), day - warmup_days)),
                mode="release",
            )

        opening_usable_releases_today: dict[tuple[str, str], float] = defaultdict(float)
        if opening_purchase_availability is not None:
            for receipt_pair, received_qty in opening_purchase_availability.receive_physical(
                output_day, ledger=lot_ledger,
            ).items():
                aggregate_qty = sum(row["quantity"] for row in opening_purchase_availability.by_delivery_day.get(output_day, ())
                                    if row["order_type"] == "external_procurement_supplier_delivery"
                                    and (row["node_id"], row["item_id"]) == receipt_pair)
                arrivals_qty += received_qty - aggregate_qty
                arrivals_today_by_pair[receipt_pair] += received_qty - aggregate_qty
                external_arrivals_qty += aggregate_qty
                external_arrivals_today_by_pair[receipt_pair] += aggregate_qty
        for dst, item_id, qty, _lane_id in arrivals_today:
            if opening_purchase_availability is not None and _lane_id in opening_purchase_availability.by_marker:
                opening_purchase_availability.release(_lane_id, output_day, qty, ledger=lot_ledger)
                stock[(dst, item_id)] += qty
                in_transit[(dst, item_id)] -= qty
                opening_usable_releases_today[(dst, item_id)] += qty
                continue
            is_opening_production_receipt = str(_lane_id).startswith(OPENING_PRODUCTION_ORDER_LANE_PREFIX)
            is_opening_purchase_receipt = str(_lane_id).startswith(
                OPENING_PURCHASE_ORDER_LANE_PREFIX
            )
            stock[(dst, item_id)] += qty
            in_transit[(dst, item_id)] -= qty
            if is_opening_production_receipt:
                record_opening_production_order_receipt(dst, item_id, qty, str(_lane_id))
            else:
                arrivals_qty += qty
                arrivals_today_by_pair[(dst, item_id)] += qty
                if is_opening_purchase_receipt:
                    materialize_opening_purchase_order_receipt_lot(
                        lot_ledger,
                        day=int(day - warmup_days),
                        node_id=dst,
                        item_id=item_id,
                        qty=qty,
                        uom=item_unit_map.get(item_id, ""),
                        marker=_lane_id,
                    )
                else:
                    record_lane_lot_receipt(dst, item_id, qty, _lane_id)
        for (
            src,
            item_id,
            qty,
            arrival_causal_events,
            arrival_causal_roots,
            arrival_planned_order_id,
        ) in external_arrivals_today:
            if arrival_planned_order_id in supplier_delivery_orders:
                opening_purchase_availability.release(arrival_planned_order_id, output_day, qty, ledger=lot_ledger)
                stock[(src, item_id)] += qty
                external_in_transit[(src, item_id)] -= qty
                opening_usable_releases_today[(src, item_id)] += qty
                continue
            is_source_boundary = arrival_planned_order_id in source_boundary_order_ids
            receipt_batches = [qty]
            if is_source_boundary:
                fixed_lot = source_boundary_policies[(src, item_id)]["fixed_lot_qty"]
                batch_count = round(qty / fixed_lot)
                if abs(qty - batch_count * fixed_lot) > LOT_TRACE_EPS:
                    raise ValueError("Source boundary receipt must preserve its fixed physical batch quantity")
                receipt_batches = [fixed_lot] * batch_count
            stock[(src, item_id)] += qty
            external_in_transit[(src, item_id)] -= qty
            external_arrivals_qty += qty
            external_arrivals_today_by_pair[(src, item_id)] += qty
            for receipt_batch_qty in receipt_batches:
                lot_ledger.create_lot(
                    day=int(day - warmup_days),
                    node_id=src,
                    item_id=item_id,
                    qty=receipt_batch_qty,
                    source_type="source_boundary_receipt" if is_source_boundary else "external_procurement_receipt",
                    source_id="SOURCE_BOUNDARY_SUPPLY" if is_source_boundary else SUPPLIER_UPSTREAM_SUPPLY_NODE_ID,
                    uom=item_unit_map.get(item_id, ""),
                    event_type="external_procurement_receipt",
                    causal_event_ids=arrival_causal_events,
                    causal_root_ids=arrival_causal_roots,
                    planned_order_id=arrival_planned_order_id,
                    baseline_reference_id=arrival_planned_order_id,
                    **({"trace_status": "untraced_before_boundary",
                        "trace_reason": "upstream_manufacturing_bom_and_capacity_not_modeled",
                        "notes": "Aggregate source boundary receipt; source fixed lot; calendar-day receipt convention; not modeled fabrication."}
                       if is_source_boundary else {}),
                )
        for src, item_id, qty in estimated_source_arrivals_today:
            stock[(src, item_id)] += qty
            estimated_source_in_transit[(src, item_id)] -= qty
            estimated_source_arrivals_qty += qty
            estimated_source_arrivals_today_by_pair[(src, item_id)] += qty
            lot_ledger.create_lot(
                day=int(day - warmup_days),
                node_id=src,
                item_id=item_id,
                qty=qty,
                source_type="estimated_source_receipt",
                source_id="estimated_source",
                uom=item_unit_map.get(item_id, ""),
                event_type="estimated_source_receipt",
            )
        if record_day:
            total_arrived += arrivals_qty
            total_external_procured_arrived += external_arrivals_qty
            total_estimated_source_replenished += estimated_source_arrivals_qty

        estimated_source_ordered_today = 0.0
        estimated_source_rejected_today = 0.0
        if unmodeled_supplier_source_mode == "estimated_replenishment":
            for src_pair, policy in estimated_source_policies.items():
                downstream_requirement = allocate_shared_downstream_pull(
                    src_pair=src_pair,
                    lanes_by_src_item=lanes_by_src_item,
                    externally_sourced_pairs=externally_sourced_pairs,
                    supplier_daily_capacity_by_pair=supplier_daily_capacity_by_pair,
                    downstream_values_by_pair=required_daily_input_by_pair,
                )
                downstream_signal = allocate_shared_downstream_pull(
                    src_pair=src_pair,
                    lanes_by_src_item=lanes_by_src_item,
                    externally_sourced_pairs=externally_sourced_pairs,
                    supplier_daily_capacity_by_pair=supplier_daily_capacity_by_pair,
                    downstream_values_by_pair=propagated_demand_today,
                )
                demand_anchor = (
                    downstream_signal
                    if source_has_dynamic_destination(src_pair)
                    else max(downstream_requirement, downstream_signal)
                )
                target_stock_qty = max(
                    base_stock.get(src_pair, 0.0),
                    demand_anchor * float(policy["target_cover_days"]),
                )
                inventory_position = stock.get(src_pair, 0.0) + estimated_source_in_transit.get(src_pair, 0.0)
                if initial_stock_availability is not None:
                    inventory_position += initial_stock_availability.planning_quantity(
                        src_pair, decision_day=output_day,
                        through_day=output_day + max(0, int(math.ceil(float(policy["target_cover_days"]))) - 1),
                    )
                desired_order_qty = max(0.0, target_stock_qty - inventory_position)
                daily_capacity = max(0.0, to_float(policy.get("daily_capacity_qty"), 0.0))
                order_qty = physical_execution_quantity(min(desired_order_qty, daily_capacity), item_unit_map.get(src_pair[1], ""))
                if order_qty > 1e-9:
                    arrival_day = day + int(policy["replenishment_lead_days"])
                    estimated_source_pipeline[arrival_day].append((src_pair[0], src_pair[1], order_qty))
                    if pending_receipt_calendar is not None:
                        pending_receipt_calendar.add(src_pair, arrival_day, order_qty)
                    estimated_source_in_transit[src_pair] += order_qty
                    register_mrp_order(
                        src_pair,
                        source_mode="estimated_source",
                        src_node_id="ESTIMATED_SOURCE",
                        dst_node_id=src_pair[0],
                        item_id=src_pair[1],
                        release_qty=order_qty,
                        receipt_qty=order_qty,
                        arrival_day=arrival_day,
                        safety_time_days=pair_mrp_safety_time_days.get(src_pair, 0.0),
                        lead_days=int(policy["replenishment_lead_days"]),
                        lead_cover_days=int(policy["replenishment_lead_days"]),
                        lead_reference_days=int(policy["replenishment_lead_days"]),
                    )
                    estimated_source_ordered_today += order_qty
                estimated_source_rejected_today += max(0.0, desired_order_qty - order_qty)
        elif unmodeled_supplier_source_mode == "estimated_capacity":
            for src_pair in externally_sourced_pairs:
                if src_pair not in supplier_daily_capacity_by_pair:
                    continue
                replenished_qty = physical_execution_quantity(supplier_daily_capacity_by_pair.get(src_pair, 0.0), item_unit_map.get(src_pair[1], ""))
                if replenished_qty <= 1e-9:
                    continue
                stock[src_pair] += replenished_qty
                estimated_capacity_replenished_today_by_pair[src_pair] += replenished_qty
                estimated_source_arrivals_qty += replenished_qty
                total_estimated_source_replenished += replenished_qty
                lot_ledger.create_lot(
                    day=int(day - warmup_days),
                    node_id=src_pair[0],
                    item_id=src_pair[1],
                    qty=replenished_qty,
                    source_type="estimated_capacity_receipt",
                    source_id="estimated_capacity",
                    uom=item_unit_map.get(src_pair[1], ""),
                    event_type="estimated_capacity_receipt",
                )
        if record_day:
            total_estimated_source_ordered += estimated_source_ordered_today
            total_estimated_source_rejected += estimated_source_rejected_today

        if args.supplier_state_dependent_risks and record_day:
            for src_pair in supplier_stock_pairs:
                downstream_requirement = allocate_shared_downstream_pull(
                    src_pair=src_pair,
                    lanes_by_src_item=lanes_by_src_item,
                    externally_sourced_pairs=externally_sourced_pairs,
                    supplier_daily_capacity_by_pair=supplier_daily_capacity_by_pair,
                    downstream_values_by_pair=required_daily_input_by_pair,
                )
                downstream_signal = allocate_shared_downstream_pull(
                    src_pair=src_pair,
                    lanes_by_src_item=lanes_by_src_item,
                    externally_sourced_pairs=externally_sourced_pairs,
                    supplier_daily_capacity_by_pair=supplier_daily_capacity_by_pair,
                    downstream_values_by_pair=propagated_demand_today,
                )
                demand_anchor = max(0.0, downstream_requirement, downstream_signal)
                if demand_anchor <= 1e-9:
                    supplier_state_risk_counters[("stock_watch", src_pair[0], src_pair[1])] = 0
                    supplier_state_risk_counters[("stock", src_pair[0], src_pair[1])] = 0
                    supplier_state_risk_counters[("stock_zero", src_pair[0], src_pair[1])] = 0
                    continue
                stock_cover_days = max(0.0, stock.get(src_pair, 0.0)) / demand_anchor
                supplier_state_stock_cover_today_by_pair[src_pair] = stock_cover_days
                update_state_risk_counter_and_register(
                    trigger_day=output_day,
                    supplier_id=src_pair[0],
                    item_id=src_pair[1],
                    counter_family="stock_watch",
                    risk_family="stock",
                    risk_type="availability",
                    multiplier=0.95,
                    trigger_metric="stock_cover_below_5d",
                    trigger_value=stock_cover_days,
                    threshold=5.0,
                    triggered=stock_cover_days < 5.0,
                    required_consecutive_days=5,
                    effect="Disponibilite fournisseur x0.95 pendant 7 jours",
                    notes=(
                        "Alerte legere: declenche quand le stock fournisseur couvre moins de "
                        "5 jours de besoin pendant 5 jours consecutifs."
                    ),
                    duration_days=7,
                    cooldown_days=21,
                )
                update_state_risk_counter_and_register(
                    trigger_day=output_day,
                    supplier_id=src_pair[0],
                    item_id=src_pair[1],
                    counter_family="stock",
                    risk_family="stock",
                    risk_type="availability",
                    multiplier=0.85,
                    trigger_metric="stock_cover_below_3d",
                    trigger_value=stock_cover_days,
                    threshold=3.0,
                    triggered=stock_cover_days < 3.0,
                    required_consecutive_days=2,
                    effect="Disponibilite fournisseur x0.85 pendant 14 jours",
                    notes=(
                        "Tension stock: declenche quand le stock fournisseur couvre moins "
                        "de 3 jours de besoin pendant 2 jours consecutifs."
                    ),
                )
                update_state_risk_counter_and_register(
                    trigger_day=output_day,
                    supplier_id=src_pair[0],
                    item_id=src_pair[1],
                    counter_family="stock_zero",
                    risk_family="stock",
                    risk_type="availability",
                    multiplier=0.70,
                    trigger_metric="stock_cover_zero",
                    trigger_value=stock_cover_days,
                    threshold=0.25,
                    triggered=stock_cover_days <= 0.25,
                    required_consecutive_days=1,
                    effect="Disponibilite fournisseur x0.70 pendant 21 jours",
                    notes=(
                        "Rupture stock locale: declenche quand le stock fournisseur couvre "
                        "moins d'un quart de jour de besoin."
                    ),
                    duration_days=21,
                    cooldown_days=21,
                )

        for src_pair in supplier_stock_pairs:
            supplier_id, stocked_item_id = src_pair
            stock_risk = supplier_risk_effects_for_pair(
                supplier_risk_events_today,
                str(supplier_id),
                str(stocked_item_id),
                output_day,
            )
            writeoff_fraction = max(0.0, min(1.0, to_float(stock_risk.get("stock_writeoff_fraction"), 0.0)))
            if writeoff_fraction <= 1e-9:
                continue
            stock_before_writeoff = max(0.0, stock.get(src_pair, 0.0))
            writeoff_qty = physical_execution_quantity(stock_before_writeoff * writeoff_fraction, item_unit_map.get(stocked_item_id, ""))
            if writeoff_qty <= 1e-9:
                continue
            stock[src_pair] = max(0.0, stock_before_writeoff - writeoff_qty)
            lot_ledger.consume(
                day=output_day,
                node_id=supplier_id,
                item_id=stocked_item_id,
                qty=writeoff_qty,
                event_type="writeoff",
                source_id="supplier_state_stock_writeoff",
                uom=item_unit_map.get(stocked_item_id, ""),
                causal_event_ids=stock_risk.get("event_ids"),
                causal_root_ids=stock_risk.get("causal_root_ids"),
            )
            supplier_stock_writeoff_today_by_pair[src_pair] += writeoff_qty
            if record_day and stock_risk.get("event_ids"):
                supplier_risk_applied_rows.append(
                    supplier_risk_applied_row(
                        day=output_day,
                        supplier_id=str(supplier_id),
                        dst_node_id="",
                        item_id=str(stocked_item_id),
                        edge_id="STOCK_WRITEOFF",
                        effects=stock_risk,
                    )
                )

        # Snapshot: raw material stocks at production input before production starts.
        day_input_rows_by_pair: dict[tuple[str, str], dict[str, Any]] = {}
        if record_day:
            for node_id, item_id in production_input_pairs:
                row = {
                    "day": output_day,
                    "node_id": node_id,
                    "item_id": item_id,
                    "stock_before_production": round(stock[(node_id, item_id)], 6),
                    "stock_end_of_day": 0.0,
                }
                input_stock_rows.append(row)
                day_input_rows_by_pair[(node_id, item_id)] = row
                input_arrival_rows.append(
                    {
                        "day": output_day,
                        "node_id": node_id,
                        "item_id": item_id,
                        "arrived_qty": round(arrivals_today_by_pair[(node_id, item_id)], 6),
                        "uom": item_unit_map.get(item_id, ""),
                    }
                )

        # Production/transformation
        for n in nodes:
            nid = str(n.get("id"))
            for p in (n.get("processes") or []):
                outputs = p.get("outputs") or []
                if not outputs:
                    continue
                out_item = str((outputs[0] or {}).get("item_id"))
                cap_raw = to_float(((p.get("capacity") or {}).get("max_rate")), 0.0)
                has_capacity_limit = cap_raw > 0.0
                production_control = resolve_daily_control(
                    node_id=nid,
                    item_id=out_item,
                )
                capacity_multiplier = (
                    production_control.capacity_multiplier
                    if production_control is not None
                    else 1.0
                )
                # Missing capacity data means "capacity not modeled", not "zero capacity".
                # Lot rules, input availability and demand signal still constrain execution.
                cap = (
                    cap_raw * capacity_multiplier
                    if has_capacity_limit
                    else float("inf")
                )

                batch_size = to_float(p.get("batch_size"), 1000.0)
                if batch_size <= 0:
                    batch_size = 1000.0

                input_limits = []
                for inp in (p.get("inputs") or []):
                    in_item = str(inp.get("item_id"))
                    key = (nid, in_item)
                    modeled_input = key in inbound_pairs or key in stock_pairs
                    if not modeled_input:
                        # Input not present in Relations_acteurs/stock model: do not constrain run.
                        continue
                    ratio = to_float(inp.get("ratio_per_batch"), 0.0)
                    req_per_unit_raw = ratio / batch_size if batch_size > 0 else 0.0
                    input_unit = normalize_unit(inp.get("ratio_unit"))
                    item_unit = normalize_unit(item_unit_map.get(in_item, input_unit))
                    if input_unit and item_unit and input_unit != item_unit:
                        if can_convert_units(input_unit, item_unit):
                            input_unit_conversions_applied.add((nid, in_item, input_unit, item_unit))
                        else:
                            input_unit_mismatch_not_converted.add((nid, in_item, input_unit, item_unit))
                    req_per_unit = convert_quantity(req_per_unit_raw, input_unit, item_unit)
                    if req_per_unit > 0:
                        physically_available = available_component_quantity(
                            available_bom_input_qty(nid, in_item, output_day),
                            item_unit,
                        )
                        input_limits.append(physically_available / req_per_unit)

                max_from_inputs = min(input_limits) if input_limits else cap
                out_pair = (nid, out_item)
                lot_policy = process_lot_policy(p, out_item=out_item, item_unit_map=item_unit_map)
                # For internally manufactured intermediates, rely on downstream
                # process requirements as well as customer-demand propagation.
                out_signal = max(
                    0.0,
                    propagated_demand_today.get(out_pair, 0.0),
                    production_reference_signal_today.get(out_pair, 0.0),
                )
                out_stock = max(0.0, stock[out_pair])
                if initial_stock_availability is not None:
                    out_stock += initial_stock_availability.planning_quantity(
                        out_pair, decision_day=output_day,
                        through_day=output_day + max(0, int(math.ceil(fg_target_days)) - 1),
                    )
                base_out_target = max(
                    base_stock.get(out_pair, 0.0),
                    fg_target_days * out_signal,
                )
                historical_out_target = base_out_target
                production_safety_enabled = args.production_mrp_safety_targets and out_pair in mrp_snapshot_pairs
                if production_safety_enabled:
                    base_out_target = production_mrp_safety_target(
                        historical_out_target, out_signal,
                        pair_mrp_safety_time_days.get(out_pair, 0.0),
                        pair_mrp_safety_stock_qty.get(out_pair, 0.0),
                    )
                target_multiplier = (
                    production_control.production_target_multiplier
                    if production_control is not None
                    else 1.0
                )
                out_target = base_out_target * target_multiplier
                if record_production_planning:
                    production_safety_decisions.setdefault(out_pair, {}).update({
                        "production_mrp_safety_enabled": int(production_safety_enabled),
                        "production_target_signal_qty": round(out_signal, 6),
                        "production_historical_target_qty": round(historical_out_target, 6),
                        "production_safety_floor_qty": round(production_mrp_safety_target(
                            0.0, out_signal, pair_mrp_safety_time_days.get(out_pair, 0.0),
                            pair_mrp_safety_stock_qty.get(out_pair, 0.0),
                        ), 6) if production_safety_enabled else 0.0,
                        "production_applied_target_qty": round(out_target, 6),
                        "production_safety_time_days": round(pair_mrp_safety_time_days.get(out_pair, 0.0), 6),
                        "production_safety_stock_qty": round(pair_mrp_safety_stock_qty.get(out_pair, 0.0), 6),
                        "production_target_multiplier": round(target_multiplier, 6),
                        "production_stock_position_qty": round(out_stock, 6),
                        "production_reference_signal_basis": "multilevel_forecast" if forecast_production_signal else "historical_capacity",
                        "production_reference_signal_qty": round(production_reference_signal_today.get(out_pair, 0.0), 6),
                    })
                out_gap = out_target - out_stock
                raw_command = out_signal + production_gap_gain * out_gap

                if out_signal <= 1e-9 and out_pair not in lanes_by_src_item:
                    # The historical isolated-process fallback remains opt-out;
                    # forecast planning never turns idle capacity into demand.
                    raw_command = cap if has_capacity_limit and not forecast_production_signal else 0.0

                prev_cmd = prev_production_command_by_pair.get(out_pair, raw_command)
                desired_qty = production_smoothing * prev_cmd + (1.0 - production_smoothing) * raw_command
                desired_qty = max(0.0, desired_qty)
                campaign_remaining_start_qty = max(0.0, open_production_campaign_qty_by_pair.get(out_pair, 0.0))
                if (
                    lot_policy["enabled"]
                    and campaign_remaining_start_qty <= 1e-9
                    and (
                        raw_command <= 1e-9
                        or should_defer_new_lot_for_stock_position(
                            desired_qty=desired_qty,
                            lot_policy=lot_policy,
                            stock_qty=out_stock,
                            target_qty=out_target,
                        )
                    )
                ):
                    # Do not convert smoothing inertia into a new full lot. If the
                    # current stock is still inside the lot band, wait until there
                    # is enough room to consume the next campaign realistically.
                    desired_qty = 0.0
                prev_production_command_by_pair[out_pair] = desired_qty
                campaign_started_qty = max(0.0, production_campaign_target_qty_by_pair.get(out_pair, 0.0))
                campaign_requested_qty = max(0.0, production_campaign_requested_qty_by_pair.get(out_pair, 0.0))
                lot_planned_qty = desired_qty
                campaign_id = (
                    open_production_campaign_id_by_pair.get(out_pair, "")
                    or pending_production_campaign_id_by_pair.get(out_pair, "")
                )
                # Production weeks are aligned to the reported calendar.  A
                # warm-up must not shift J0 into an arbitrary weekly bucket.
                week_index = production_week_index(output_day)
                week_key = (week_index, out_pair)
                started_lots_this_week = int(started_production_lots_by_week_pair.get(week_key, 0))
                requested_lot_starts = 0
                actual_lot_starts = 0
                weekly_lot_limit = max(0, int(math.floor(to_float(lot_policy.get("max_lots_per_week"), 0.0))))
                lot_weekly_limit_blocked = False
                if lot_policy["enabled"]:
                    if campaign_remaining_start_qty <= 1e-9 and desired_qty > 1e-9:
                        campaign_requested_qty = launch_campaign_qty(desired_qty, lot_policy)
                        requested_lot_starts = campaign_lot_count(campaign_requested_qty, lot_policy)
                        if campaign_requested_qty > 1e-9 and not campaign_id:
                            campaign_id = lot_ledger.next_campaign_id(
                                day=output_day,
                                node_id=nid,
                                item_id=out_item,
                            )
                            pending_production_campaign_id_by_pair[out_pair] = campaign_id
                        campaign_started_qty = campaign_requested_qty
                        if weekly_lot_limit > 0:
                            available_lot_starts = max(0, weekly_lot_limit - started_lots_this_week)
                            campaign_started_qty = limit_campaign_qty_by_weekly_lots(
                                campaign_requested_qty,
                                lot_policy,
                                available_lot_starts,
                            )
                            actual_lot_starts = campaign_lot_count(campaign_started_qty, lot_policy)
                            lot_weekly_limit_blocked = actual_lot_starts < requested_lot_starts
                        else:
                            actual_lot_starts = requested_lot_starts
                        campaign_remaining_start_qty = campaign_started_qty
                        open_production_campaign_qty_by_pair[out_pair] = campaign_started_qty
                        if campaign_started_qty > 1e-9:
                            open_production_campaign_id_by_pair[out_pair] = campaign_id
                            production_campaign_started_day_by_pair[out_pair] = output_day
                            production_campaign_requested_qty_by_pair[out_pair] = campaign_requested_qty
                            production_campaign_target_qty_by_pair[out_pair] = campaign_started_qty
                        if actual_lot_starts > 0:
                            started_production_lots_by_week_pair[week_key] = started_lots_this_week + actual_lot_starts
                            started_lots_this_week = int(started_production_lots_by_week_pair[week_key])
                    lot_planned_qty = campaign_remaining_start_qty

                batch_wip: ProductionBatchWip | None = None
                batch_remaining_start_qty = lot_planned_qty
                batch_executed_start_qty = 0.0
                if lot_policy["enabled"] and campaign_remaining_start_qty > 1e-9 and campaign_id:
                    batch_wip = production_batch_wip_by_pair.get(out_pair)
                    if batch_wip is not None and batch_wip.campaign_id != campaign_id:
                        raise RuntimeError(
                            f"Stale production WIP for {out_pair}: {batch_wip.campaign_id} != {campaign_id}"
                        )
                    if batch_wip is None:
                        production_batch_sequence_by_campaign[campaign_id] += 1
                        batch_target_qty = physical_batch_target_qty(campaign_remaining_start_qty, lot_policy)
                        batch_wip = ProductionBatchWip(
                            campaign_id=campaign_id,
                            batch_id=make_batch_id(
                                campaign_id,
                                production_batch_sequence_by_campaign[campaign_id],
                            ),
                            node_id=nid,
                            item_id=out_item,
                            campaign_started_day=production_campaign_started_day_by_pair.get(out_pair, output_day),
                            batch_started_day=output_day,
                            target_qty=batch_target_qty,
                        )
                        production_batch_wip_by_pair[out_pair] = batch_wip
                    batch_remaining_start_qty = batch_wip.remaining_qty
                    batch_executed_start_qty = batch_wip.executed_qty

                execution_plan_qty = batch_remaining_start_qty if batch_wip is not None else lot_planned_qty
                qty = production_wip_execution_quantity(
                    max(0.0, min(cap, max_from_inputs, execution_plan_qty))
                )
                if not lot_policy["enabled"] and qty > 1e-9:
                    campaign_id = lot_ledger.next_campaign_id(
                        day=output_day,
                        node_id=nid,
                        item_id=out_item,
                    )
                    production_campaign_started_day_by_pair[out_pair] = output_day
                binding_cause = "none"
                binding_item = ""
                production_plan_row: dict[str, Any] | None = None
                if desired_qty > 1e-9 or campaign_remaining_start_qty > 1e-9:
                    input_binding_item = ""
                    input_binding_value = float("inf")
                    for inp in (p.get("inputs") or []):
                        in_item = str(inp.get("item_id"))
                        key = (nid, in_item)
                        modeled_input = key in inbound_pairs or key in stock_pairs
                        if not modeled_input:
                            continue
                        ratio = to_float(inp.get("ratio_per_batch"), 0.0)
                        req_per_unit_raw = ratio / batch_size if batch_size > 0 else 0.0
                        input_unit = normalize_unit(inp.get("ratio_unit"))
                        item_unit = normalize_unit(item_unit_map.get(in_item, input_unit))
                        req_per_unit = convert_quantity(req_per_unit_raw, input_unit, item_unit)
                        if req_per_unit <= 0:
                            continue
                        physically_available = available_component_quantity(
                            available_bom_input_qty(nid, in_item, output_day),
                            item_unit,
                        )
                        item_limit = physically_available / req_per_unit
                        if item_limit < input_binding_value:
                            input_binding_value = item_limit
                            input_binding_item = in_item
                    # A campaign may contain several batches. Capacity and
                    # material constraints apply to the current physical batch,
                    # not to all batches in the campaign at once.
                    binding_reference_qty = execution_plan_qty if lot_policy["enabled"] else desired_qty
                    if lot_weekly_limit_blocked and campaign_remaining_start_qty <= 1e-9 and desired_qty > 1e-9:
                        binding_cause = "weekly_lot_limit"
                    elif qty + 1e-9 < binding_reference_qty:
                        if max_from_inputs <= cap + 1e-9 and max_from_inputs <= binding_reference_qty + 1e-9:
                            binding_cause = "input_shortage"
                            binding_item = input_binding_item
                        elif has_capacity_limit and cap <= max_from_inputs + 1e-9 and cap <= binding_reference_qty + 1e-9:
                            binding_cause = "capacity"
                        elif lot_policy["enabled"] and campaign_remaining_start_qty > 1e-9 and qty <= 1e-9:
                            binding_cause = "lot_campaign_blocked"
                        else:
                            binding_cause = "policy_command"
                    elif lot_policy["enabled"] and campaign_remaining_start_qty > 1e-9 and qty <= 1e-9:
                        binding_cause = "lot_campaign_blocked"
                    if (
                        feedback_control_supports_priming
                        and args.controller_prime_during_warmup
                        and not record_day
                        and has_capacity_limit
                        and cap > 1e-9
                    ):
                        feedback_warmup_production_utilization_values.append(
                            max(0.0, qty) / max(1e-9, cap)
                        )
                    if record_day:
                        cap_qty_for_record = cap if has_capacity_limit else 0.0
                        input_qty_for_record = max_from_inputs if math.isfinite(max_from_inputs) else 0.0
                        campaign_remaining_end_qty = round(max(0.0, campaign_remaining_start_qty - qty), 6)
                        production_constraint_rows.append(
                            {
                                "day": output_day,
                                "node_id": nid,
                                "output_item_id": out_item,
                                "desired_qty": round(desired_qty, 6),
                                "planned_qty_after_lot_rule": round(lot_planned_qty, 6),
                                "actual_qty": round(qty, 6),
                                "cap_qty": round(cap_qty_for_record, 6),
                                "capacity_limit_mode": "finite" if has_capacity_limit else "unmodeled",
                                "max_from_inputs_qty": round(input_qty_for_record, 6),
                                "binding_cause": binding_cause,
                                "binding_input_item_id": binding_item,
                                "shortfall_vs_desired_qty": round(max(0.0, desired_qty - qty), 6),
                                "shortfall_vs_lot_plan_qty": round(max(0.0, execution_plan_qty - qty), 6),
                                "lot_policy_mode": (
                                    "fixed"
                                    if lot_policy.get("fixed_lot_qty", 0.0) > 1e-9
                                    else "min_max"
                                    if lot_policy["enabled"]
                                    else "none"
                                ),
                                "lot_fixed_qty": round(to_float(lot_policy.get("fixed_lot_qty"), 0.0), 6),
                                "lot_min_qty": round(to_float(lot_policy.get("min_lot_qty"), 0.0), 6),
                                "lot_max_qty": round(to_float(lot_policy.get("max_lot_qty"), 0.0), 6),
                                "lot_multiple_qty": round(to_float(lot_policy.get("lot_multiple_qty"), 0.0), 6),
                                "max_lots_per_week": weekly_lot_limit,
                                "started_lots_this_week": started_lots_this_week,
                                "requested_lot_starts": requested_lot_starts,
                                "actual_lot_starts": actual_lot_starts,
                                "campaign_requested_qty": round(campaign_requested_qty, 6),
                                "campaign_started_qty": round(campaign_started_qty, 6),
                                "campaign_remaining_start_qty": round(campaign_remaining_start_qty, 6),
                                "campaign_remaining_end_qty": campaign_remaining_end_qty,
                            }
                        )
                        shortfall_vs_desired_qty = max(0.0, desired_qty - qty)
                        shortfall_vs_lot_plan_qty = max(0.0, execution_plan_qty - qty)
                        projected_batch_executed_end_qty = (
                            min(batch_wip.target_qty, batch_executed_start_qty + qty)
                            if batch_wip is not None
                            else qty
                        )
                        projected_batch_complete = (
                            qty > LOT_TRACE_EPS
                            if batch_wip is None
                            else batch_wip.target_qty - projected_batch_executed_end_qty <= LOT_TRACE_EPS
                        )
                        projected_campaign_complete = (
                            projected_batch_complete and campaign_remaining_end_qty <= LOT_TRACE_EPS
                        )
                        if binding_cause == "input_shortage":
                            event_type = "partial_run_input_shortage" if qty > 1e-9 else "delay_input_shortage"
                        elif binding_cause == "capacity":
                            event_type = "partial_run_capacity" if qty > 1e-9 else "delay_capacity"
                        elif binding_cause == "weekly_lot_limit":
                            event_type = "delay_weekly_lot_limit"
                        elif binding_cause == "lot_campaign_blocked":
                            event_type = "delay_lot_campaign_blocked"
                        elif actual_lot_starts > 0:
                            event_type = "start_campaign"
                        elif projected_campaign_complete:
                            event_type = "run_campaign_complete"
                        elif qty > 1e-9 and campaign_remaining_end_qty > 1e-9:
                            event_type = "run_campaign_partial"
                        else:
                            event_type = "plan_no_run"
                        receipt_pair = (nid, binding_item) if binding_item else ("", "")
                        batch_id_for_row = (
                            batch_wip.batch_id
                            if batch_wip is not None
                            else (make_batch_id(campaign_id, 1) if campaign_id and qty > 1e-9 else "")
                        )
                        planned_order_id = lot_ledger.planned_order_id(campaign_id)
                        shortage_causality = {
                            "causal_event_ids": "",
                            "causal_root_ids": "",
                            "causal_status": "nominal",
                        }
                        if binding_cause == "input_shortage" and binding_item:
                            shortage_causality = production_shortage_causal_context(
                                dst_node_id=nid,
                                item_id=binding_item,
                                current_day=day,
                                output_day=output_day,
                                active_risk_events=supplier_risk_events_today,
                            )
                        if campaign_id:
                            previous_causality = production_campaign_causality_by_id.get(
                                campaign_id,
                                {},
                            )
                            campaign_event_ids = join_ids(
                                previous_causality.get("causal_event_ids"),
                                shortage_causality["causal_event_ids"],
                            )
                            campaign_root_ids = join_ids(
                                previous_causality.get("causal_root_ids"),
                                shortage_causality["causal_root_ids"],
                            )
                            production_campaign_causality_by_id[campaign_id] = {
                                "causal_event_ids": campaign_event_ids,
                                "causal_root_ids": campaign_root_ids or campaign_event_ids,
                                "causal_status": causal_status(
                                    campaign_event_ids,
                                    root_ids=campaign_root_ids,
                                ),
                            }
                            shortage_causality = production_campaign_causality_by_id[campaign_id]
                        production_plan_row = {
                                "day": output_day,
                                "campaign_id": campaign_id,
                                "semantics_version": LOT_EXECUTION_SEMANTICS_VERSION,
                                "campaign_started_day": production_campaign_started_day_by_pair.get(
                                    out_pair,
                                    output_day,
                                ),
                                "node_id": nid,
                                "output_item_id": out_item,
                                "batch_id": batch_id_for_row,
                                "batch_started_day": (
                                    batch_wip.batch_started_day if batch_wip is not None else output_day
                                ),
                                "batch_target_qty": round(
                                    batch_wip.target_qty if batch_wip is not None else qty,
                                    6,
                                ),
                                "batch_executed_start_qty": round(batch_executed_start_qty, 6),
                                "batch_executed_today_qty": round(qty, 6),
                                "batch_executed_end_qty": round(projected_batch_executed_end_qty, 6),
                                "process_tau_days": round(process_tau_days_by_pair.get(out_pair, 0.0), 6),
                                "release_gate_mode": "execution_complete_tau_planning_only",
                                "wip_start_qty": round(batch_executed_start_qty, 6),
                                "wip_end_qty": round(
                                    0.0 if projected_batch_complete else projected_batch_executed_end_qty,
                                    6,
                                ),
                                "released_qty": round(
                                    batch_wip.target_qty
                                    if projected_batch_complete and batch_wip is not None
                                    else qty
                                    if batch_wip is None
                                    else 0.0,
                                    6,
                                ),
                                "released_lot_id": "",
                                "is_day_zero_carry_in": int(
                                    output_day == 0
                                    and batch_wip is not None
                                    and batch_wip.batch_started_day < 0
                                ),
                                "event_type": event_type,
                                "reason": binding_cause,
                                "desired_qty": round(desired_qty, 6),
                                "planned_qty_after_lot_rule": round(lot_planned_qty, 6),
                                "actual_qty": round(qty, 6),
                                "shortfall_vs_desired_qty": round(shortfall_vs_desired_qty, 6),
                                "shortfall_vs_lot_plan_qty": round(shortfall_vs_lot_plan_qty, 6),
                                "binding_input_item_id": binding_item,
                                "planned_qty_before": round(campaign_remaining_start_qty, 6),
                                "planned_qty_after": campaign_remaining_end_qty,
                                "lot_policy_mode": (
                                    "fixed"
                                    if lot_policy.get("fixed_lot_qty", 0.0) > 1e-9
                                    else "min_max"
                                    if lot_policy["enabled"]
                                    else "none"
                                ),
                                "lot_fixed_qty": round(to_float(lot_policy.get("fixed_lot_qty"), 0.0), 6),
                                "lot_min_qty": round(to_float(lot_policy.get("min_lot_qty"), 0.0), 6),
                                "lot_max_qty": round(to_float(lot_policy.get("max_lot_qty"), 0.0), 6),
                                "lot_multiple_qty": round(to_float(lot_policy.get("lot_multiple_qty"), 0.0), 6),
                                "max_lots_per_week": weekly_lot_limit,
                                "started_lots_this_week": started_lots_this_week,
                                "requested_lot_starts": requested_lot_starts,
                                "actual_lot_starts": actual_lot_starts,
                                "campaign_requested_qty": round(campaign_requested_qty, 6),
                                "campaign_started_qty": round(campaign_started_qty, 6),
                                "campaign_remaining_start_qty": round(campaign_remaining_start_qty, 6),
                                "campaign_remaining_end_qty": campaign_remaining_end_qty,
                                "next_expected_receipt_day": (
                                    next_receipt_day_for_pair(receipt_pair, day) if binding_item else ""
                                ),
                                "notes": (
                                    "lot_policy_enabled; tau_process_used_for_planning_cover_only"
                                    if lot_policy["enabled"]
                                    else "daily_unlotified_plan; tau_process_used_for_planning_cover_only"
                                ),
                                "scenario_id": lot_ledger.scenario_id,
                                "planned_order_id": planned_order_id,
                                "causal_event_ids": shortage_causality["causal_event_ids"],
                                "causal_root_ids": shortage_causality["causal_root_ids"],
                                "causal_status": shortage_causality["causal_status"],
                                "baseline_reference_id": planned_order_id,
                            }
                        production_plan_event_rows.append(production_plan_row)
                        if args.supplier_state_dependent_risks and binding_cause == "input_shortage" and binding_item:
                            shortage_reference_qty = max(execution_plan_qty, desired_qty, 1.0)
                            shortage_ratio = max(0.0, shortfall_vs_lot_plan_qty) / shortage_reference_qty
                            next_receipt_text = next_receipt_day_for_pair(receipt_pair, day)
                            next_receipt_output_day = (
                                int(to_float(next_receipt_text) or 0)
                                if str(next_receipt_text or "").strip()
                                else None
                            )
                            days_until_receipt = (
                                max(0, next_receipt_output_day - output_day)
                                if next_receipt_output_day is not None
                                else 365
                            )
                            for source_lane in candidate_supply_lanes_for_factory_input(nid, binding_item):
                                source_node_id = str(source_lane.get("src") or "")
                                if not source_node_id:
                                    continue
                                source_edge_id = str(source_lane.get("edge_id") or "")
                                source_lead_days = max(
                                    1.0,
                                    to_float(source_lane.get("lead_days_mean"), source_lane.get("lead_days")) or 1.0,
                                )
                                late_threshold_days = max(7.0, source_lead_days)
                                lane_scope = f"{nid}:{out_item}:{binding_item}"
                                note = (
                                    "Cascade production: report par manque d'intrant. "
                                    f"Site={nid}, produit={out_item}, intrant={binding_item}, "
                                    f"shortfall_ratio={shortage_ratio:.3f}, prochaine_reception={next_receipt_text or 'n/a'}."
                                )
                                update_state_risk_counter_and_register(
                                    trigger_day=output_day,
                                    supplier_id=source_node_id,
                                    item_id=binding_item,
                                    counter_family=f"factory_input_shortage_watch:{lane_scope}",
                                    risk_family="availability",
                                    risk_type="availability",
                                    multiplier=0.92,
                                    trigger_metric="factory_input_shortage_reported",
                                    trigger_value=shortage_ratio,
                                    threshold=0.05,
                                    triggered=shortage_ratio >= 0.05,
                                    required_consecutive_days=2,
                                    effect="Disponibilite lane amont x0.92 pendant 10 jours",
                                    notes=note,
                                    dst_node_id=nid,
                                    edge_id=source_edge_id,
                                    duration_days=10,
                                    cooldown_days=21,
                                )
                                update_state_risk_counter_and_register(
                                    trigger_day=output_day,
                                    supplier_id=source_node_id,
                                    item_id=binding_item,
                                    counter_family=f"factory_input_shortage_late:{lane_scope}",
                                    risk_family="lead",
                                    risk_type="lead_time_extra_days",
                                    multiplier=2.0,
                                    trigger_metric="factory_input_shortage_next_receipt_late",
                                    trigger_value=float(days_until_receipt),
                                    threshold=late_threshold_days,
                                    triggered=shortage_ratio >= 0.10 and float(days_until_receipt) > late_threshold_days,
                                    required_consecutive_days=1,
                                    effect="Delai lane amont +2 jours pendant 14 jours",
                                    notes=note,
                                    dst_node_id=nid,
                                    edge_id=source_edge_id,
                                    duration_days=14,
                                    cooldown_days=21,
                                )
                                update_state_risk_counter_and_register(
                                    trigger_day=output_day,
                                    supplier_id=source_node_id,
                                    item_id=binding_item,
                                    counter_family=f"factory_input_shortage_severe:{lane_scope}",
                                    risk_family="capacity",
                                    risk_type="capacity",
                                    multiplier=0.88,
                                    trigger_metric="factory_input_shortage_severe_or_repeated",
                                    trigger_value=shortage_ratio,
                                    threshold=0.35,
                                    triggered=shortage_ratio >= 0.35,
                                    required_consecutive_days=2,
                                    effect="Capacite lane amont x0.88 pendant 14 jours",
                                    notes=note,
                                    dst_node_id=nid,
                                    edge_id=source_edge_id,
                                    duration_days=14,
                                    cooldown_days=28,
                                )
                if production_control is not None:
                    production_control_actions = [
                        "production_target_multiplier"
                    ]
                    if has_capacity_limit:
                        production_control_actions.append(
                            "capacity_multiplier"
                        )
                    record_control_resolution(
                        production_control,
                        stage="production_execution",
                        action_names=tuple(
                            production_control_actions
                        ),
                        status=(
                            "applied"
                            if qty > 1e-9
                            else (
                                f"blocked:{binding_cause}"
                                if binding_cause != "none"
                                else "no_executable_production"
                            )
                        ),
                        executed_control_volume_qty=qty,
                        extra={
                            "quantity_uom": item_unit_map.get(out_item, ""),
                            "q_target_base_qty": round(base_out_target, 6),
                            "q_target_controlled_qty": round(out_target, 6),
                            "q_command_before_lotification_qty": round(
                                desired_qty,
                                6,
                            ),
                            "q_after_lotification_qty": round(
                                lot_planned_qty,
                                6,
                            ),
                            "q_executable_qty": round(qty, 6),
                            "capacity_base_qty_per_day": round(
                                cap_raw if has_capacity_limit else 0.0,
                                6,
                            ),
                            "capacity_controlled_qty_per_day": round(
                                cap if has_capacity_limit else 0.0,
                                6,
                            ),
                            "binding_reason": binding_cause,
                            "lot_policy_mode": (
                                "fixed"
                                if lot_policy.get("fixed_lot_qty", 0.0) > 1e-9
                                else "min_max"
                                if lot_policy["enabled"]
                                else "none"
                            ),
                        },
                    )
                if qty <= 0:
                    continue

                production_parent_allocations: list[dict[str, Any]] = []
                for inp in (p.get("inputs") or []):
                    in_item = str(inp.get("item_id"))
                    key = (nid, in_item)
                    modeled_input = key in inbound_pairs or key in stock_pairs
                    if not modeled_input:
                        continue
                    ratio = to_float(inp.get("ratio_per_batch"), 0.0)
                    req_per_unit_raw = ratio / batch_size if batch_size > 0 else 0.0
                    input_unit = normalize_unit(inp.get("ratio_unit"))
                    item_unit = normalize_unit(item_unit_map.get(in_item, input_unit))
                    req_per_unit = convert_quantity(req_per_unit_raw, input_unit, item_unit)
                    if req_per_unit > 0:
                        consumed = required_component_quantity(
                            qty,
                            req_per_unit,
                            item_unit,
                        )
                        production_parent_allocations.extend(
                            consume_bom_input_with_reference_transition(
                                output_day=output_day,
                                node_id=nid,
                                item_id=in_item,
                                qty=consumed,
                                event_type="production_consume",
                                source_id=f"{nid}|{out_item}",
                                production_campaign_id=campaign_id,
                                consumed_today_by_pair=consumed_today_by_pair,
                            )
                        )

                campaign_causality = production_campaign_causality_by_id.get(
                    campaign_id,
                    {},
                )
                production_executed_today_by_pair[out_pair] += qty
                released_qty = 0.0
                released_lot_id = ""
                release_parent_allocations = production_parent_allocations
                release_batch_id = make_batch_id(campaign_id, 1)
                if batch_wip is not None:
                    accepted_qty = batch_wip.add_execution(qty, production_parent_allocations)
                    if abs(accepted_qty - qty) > LOT_TRACE_EPS:
                        raise RuntimeError(
                            f"Batch execution mismatch for {batch_wip.batch_id}: accepted={accepted_qty}, planned={qty}"
                        )
                    release_batch_id = batch_wip.batch_id
                    if batch_wip.is_complete:
                        released_qty = batch_wip.target_qty
                        release_parent_allocations = batch_wip.parent_allocations
                        production_batch_wip_by_pair.pop(out_pair, None)
                else:
                    # No lot rule: the daily execution is an immediately
                    # released physical batch, preserving legacy behaviour.
                    released_qty = qty

                if released_qty > LOT_TRACE_EPS:
                    stock[out_pair] += released_qty
                    released_lot_id = lot_ledger.create_child_lot(
                        day=output_day,
                        node_id=nid,
                        item_id=out_item,
                        qty=released_qty,
                        source_type="production_output",
                        source_id=f"{nid}|{out_item}",
                        parent_allocations=release_parent_allocations,
                        link_type="production",
                        uom=item_unit_map.get(out_item, ""),
                        production_campaign_id=campaign_id,
                        planned_order_id=lot_ledger.planned_order_id(campaign_id),
                        baseline_reference_id=lot_ledger.planned_order_id(campaign_id),
                        causal_event_ids=campaign_causality.get("causal_event_ids", ""),
                        causal_root_ids=campaign_causality.get("causal_root_ids", ""),
                        causal_status_value=campaign_causality.get("causal_status", ""),
                        notes=(
                            f"semantics={LOT_EXECUTION_SEMANTICS_VERSION};batch_id={release_batch_id};"
                            "released_only_after_physical_batch_completion"
                        ),
                    )
                    produced_today += released_qty
                    produced_today_by_pair[out_pair] += released_qty

                if production_plan_row is not None:
                    production_plan_row["released_qty"] = round(released_qty, 6)
                    production_plan_row["released_lot_id"] = released_lot_id
                    production_plan_row["wip_end_qty"] = round(
                        production_batch_wip_by_pair[out_pair].executed_qty
                        if out_pair in production_batch_wip_by_pair
                        else 0.0,
                        6,
                    )
                if lot_policy["enabled"]:
                    open_production_campaign_qty_by_pair[out_pair] = max(0.0, campaign_remaining_start_qty - qty)
                    if open_production_campaign_qty_by_pair[out_pair] <= 1e-9:
                        open_production_campaign_id_by_pair.pop(out_pair, None)
                        production_campaign_started_day_by_pair.pop(out_pair, None)
                        production_campaign_requested_qty_by_pair.pop(out_pair, None)
                        production_campaign_target_qty_by_pair.pop(out_pair, None)
                        pending_production_campaign_id_by_pair.pop(out_pair, None)
                else:
                    production_campaign_started_day_by_pair.pop(out_pair, None)

        if record_day:
            total_produced += produced_today
            for node_id, item_id in production_output_pairs:
                q = produced_today_by_pair[(node_id, item_id)]
                executed_q = production_executed_today_by_pair[(node_id, item_id)]
                cum_output_by_pair[(node_id, item_id)] += q
                if executed_q > 1e-9:
                    production_cost_qty_by_day_pair[(output_day, node_id, item_id)] += executed_q
                active_wip = production_batch_wip_by_pair.get((node_id, item_id))
                output_prod_rows.append(
                    {
                        "day": output_day,
                        "node_id": node_id,
                        "item_id": item_id,
                        "produced_qty": round(q, 6),
                        "executed_qty": round(executed_q, 6),
                        "released_qty": round(q, 6),
                        "wip_end_qty": round(active_wip.executed_qty if active_wip is not None else 0.0, 6),
                        "cum_produced_qty": round(cum_output_by_pair[(node_id, item_id)], 6),
                        "stock_end_of_day": round(stock[(node_id, item_id)], 6),
                    }
                )
            for node_id, item_id in production_input_pairs:
                input_consumption_rows.append(
                    {
                        "day": output_day,
                        "node_id": node_id,
                        "item_id": item_id,
                        "consumed_qty": round(consumed_today_by_pair[(node_id, item_id)], 6),
                        "uom": item_unit_map.get(item_id, ""),
                    }
                )

        if record_day and day == warmup_days and not reset_backlog_after_warmup:
            measurement_starting_backlog = sum(max(0.0, val) for val in backlog.values())

        # Demand satisfaction
        demand_today = 0.0
        served_today = 0.0
        for pair in demand_pairs:
            # Only the planning signal is smoothed. Physical customer demand
            # retains the source day, including fractional forecast remainders.
            dval = raw_demand_target_today.get(pair, 0.0)
            required = backlog[pair] + dval
            available = stock[pair]
            served = physical_execution_quantity(min(available, required), item_unit_map.get(pair[1], ""))
            stock[pair] -= served
            lot_ledger.consume(
                day=output_day,
                node_id=pair[0],
                item_id=pair[1],
                qty=served,
                event_type="demand_service",
                source_id="customer_demand",
                uom=item_unit_map.get(pair[1], ""),
            )
            backlog[pair] = required - served
            demand_today += dval
            served_today += served
            if record_day:
                demand_pair_rows.append(
                    {
                        "day": output_day,
                        "node_id": pair[0],
                        "item_id": pair[1],
                        "demand_qty": round(dval, 6),
                        "required_with_backlog_qty": round(required, 6),
                        "served_qty": round(served, 6),
                        "backlog_end_qty": round(backlog[pair], 6),
                        "available_before_service_qty": round(available, 6),
                    }
                )

        if record_day:
            total_demand += demand_today
            total_served += served_today

        # Replenishment and shipments
        shipped_today = 0.0
        transport_cost_today = 0.0
        opening_transport_cost_today = 0.0
        purchase_cost_today = 0.0
        opening_purchase_cost_today = 0.0
        external_procurement_transport_cost_today = 0.0
        external_procurement_purchase_cost_today = 0.0
        external_procured_today = 0.0
        external_procured_rejected_today = 0.0
        external_quality_rejected_today = 0.0
        supplier_capacity_binding_qty_today = 0.0
        shipped_today_to_pair: dict[tuple[str, str], float] = defaultdict(float)
        external_ordered_today_by_src_pair: dict[tuple[str, str], float] = defaultdict(float)
        external_desired_today_by_src_pair: dict[tuple[str, str], float] = defaultdict(float)
        external_rejected_today_by_src_pair: dict[tuple[str, str], float] = defaultdict(float)
        external_cost_ratio_today_by_src_pair: dict[tuple[str, str], float] = defaultdict(float)
        supplier_capacity_used_today_by_src_pair: dict[tuple[str, str], float] = defaultdict(float)
        supplier_shipped_from_stock_today_by_src_pair: dict[tuple[str, str], float] = defaultdict(float)
        supplier_released_today_by_src_pair: dict[tuple[str, str], float] = defaultdict(float)
        supplier_loss_today_by_src_pair: dict[tuple[str, str], float] = defaultdict(float)
        for metric_pair, metric_shipped, metric_transport, metric_purchase, metric_loss, metric_is_opening in scheduled_lane_release_metrics.pop(day, []):
            shipped_today += metric_shipped
            shipped_today_to_pair[metric_pair] += metric_shipped
            transport_cost_today += metric_transport
            purchase_cost_today += metric_purchase
            total_unreliable_loss_qty += metric_loss
            if metric_is_opening:
                opening_transport_cost_today += metric_transport
                opening_purchase_cost_today += metric_purchase

        def external_procurement_leads(
            policy: dict[str, Any],
            risk_mult: dict[str, Any],
        ) -> tuple[int, int, str]:
            mode = str(economic_policy.get("external_procurement_lead_mode") or "supplier_material").strip().lower()
            scale = max(0.01, to_float(economic_policy.get("external_procurement_lead_time_scale"), 1.0))
            lead_basis = "economic_policy.external_procurement_lead_days"
            if mode == "supplier_material":
                policy_lead = to_float(policy.get("external_procurement_lead_days"), math.nan)
                if policy_lead is None or math.isnan(policy_lead) or policy_lead <= 0:
                    policy_lead = to_float(policy.get("planned_material_lead_days"), math.nan)
                    lead_basis = "estimated_source_policy.planned_material_lead_days"
                else:
                    lead_basis = str(
                        policy.get("external_procurement_lead_basis")
                        or "source_material_lead_reference_days"
                    )
                if policy_lead is None or math.isnan(policy_lead) or policy_lead <= 0:
                    policy_lead = to_float(economic_policy.get("external_procurement_lead_days"), 4.0)
                    lead_basis = "economic_policy.external_procurement_lead_days_fallback"
                base_lead_days = max(1, int(math.ceil(policy_lead * scale)))
            else:
                base_lead_days = max(
                    1,
                    int(
                        math.ceil(
                            to_float(economic_policy.get("external_procurement_lead_days"), 4.0) * scale
                        )
                    ),
                )
            effective_lead_days = max(
                1,
                int(
                    math.ceil(
                        float(base_lead_days)
                        * max(0.05, to_float(risk_mult.get("external_lead_time"), 1.0))
                        + max(0.0, to_float(risk_mult.get("external_lead_time_extra_days"), 0.0))
                    )
                ),
            )
            return base_lead_days, effective_lead_days, lead_basis

        def external_procurement_daily_capacity(
            policy: dict[str, Any],
            risk_mult: dict[str, Any],
            demand_signal_qty_per_day: float,
            control_multiplier: float = 1.0,
        ) -> float:
            mode = str(
                economic_policy.get("external_procurement_capacity_mode") or "supplier_nominal"
            ).strip().lower()
            policy_cap = max(
                0.0,
                to_float(policy.get("external_procurement_nominal_capacity_qty_per_day"), 0.0),
            )
            if mode == "supplier_nominal" and policy_cap > 1e-9:
                cap_today = policy_cap * max(
                    0.0,
                    to_float(economic_policy.get("external_procurement_nominal_capacity_scale"), 1.0),
                )
            else:
                cap_today = max(
                    economic_policy["external_procurement_min_daily_cap_qty"],
                    economic_policy["external_procurement_daily_cap_days"]
                    * max(0.0, demand_signal_qty_per_day),
                )
            cap_today *= max(0.0, to_float(risk_mult.get("external_capacity"), 1.0))
            cap_today *= max(0.0, to_float(risk_mult.get("external_availability"), 1.0))
            cap_today *= max(0.0, float(control_multiplier))
            return max(0.0, cap_today)

        dated_plans, dated_requirements, dated_plan_audits = {}, {}, {}
        dated_plan_decisions: dict = {}
        if dated_component_planning:
            # One end-of-day snapshot, after actual production and customer
            # service. Future days are forecasts, not repeated daily MPS orders.
            horizon = min(364, max(0, total_timeline_days - day - 1))
            for delivery_pair, receipt_policy in supplier_receipt_policies.items():
                physical_day = day + max(lead_time_reference_days(lane) for lane in lanes_by_dest_item[delivery_pair])
                network_leads[delivery_pair] = supplier_receipt_available_day(
                    physical_day, receipt_policy["receipt_days"], origin_date=safety_calendar["start_date"],
                ) - day
            forecast_requirements: dict = {pair: [] for pair in demand_pairs}
            for offset in range(1, horizon + 1):
                future_forecast = planning_demand_targets_for_day(output_day, profile_day + offset, window_days=1)
                for forecast_pair, quantity in future_forecast.items():
                    if quantity > LOT_TRACE_EPS:
                        forecast_requirements[forecast_pair].append(Requirement(
                            f"forecast:{forecast_pair[0]}:{forecast_pair[1]}:{day + offset}", day + offset, quantity,
                        ))
            for forecast_pair in demand_pairs:
                if backlog.get(forecast_pair, 0.0) > LOT_TRACE_EPS:
                    forecast_requirements[forecast_pair].append(Requirement(
                        "backlog:" + "|".join(forecast_pair), day + 1, backlog[forecast_pair],
                    ))
            if opening_production_order_bom_issue_mode != "wip":
                for opening_order in opening_open_order_rows:
                    if opening_order.get("order_type") != "opening_production_order":
                        continue
                    issue_day = (int(opening_order["arrival_day"]) if opening_production_order_bom_issue_mode == "receipt"
                                 else max(0, int(opening_order["release_day"])))
                    if issue_day <= day:
                        continue
                    output_pair = (opening_order["node_id"], opening_order["item_id"])
                    for component_pair, ratio in process_input_requirements_by_output_pair.get(output_pair, ()):
                        forecast_requirements.setdefault(component_pair, []).append(Requirement(
                            f"opening_production:{opening_order.get('source_row', '')}:{output_pair}:{component_pair}",
                            issue_day, opening_order["receipt_qty"] * ratio,
                        ))
            firm_snapshot: dict = {}
            for receipt_pair, commitments in planning_commitments_by_pair.items():
                for receipt_id in list(commitments):
                    if commitments[receipt_id][0] <= day:
                        del commitments[receipt_id]
                firm_snapshot[receipt_pair] = [FirmReceipt(
                    receipt_id, arrival, qty,
                    "held" if origin == "held" or (receipt_id in opening_purchase_availability.by_marker
                              and opening_purchase_availability.by_marker[receipt_id]["received"]) else
                    ("confirmed" if origin == "production" else "in_transit"),
                ) for receipt_id, (arrival, qty, origin) in commitments.items()]
            campaigns = {}
            for output_pair, remaining in open_production_campaign_qty_by_pair.items():
                wip = production_batch_wip_by_pair.get(output_pair)
                executed_wip = wip.executed_qty if wip is not None else 0.0
                if remaining + executed_wip <= LOT_TRACE_EPS:
                    continue
                complete_qty = remaining + executed_wip
                if normalize_unit(item_unit_map.get(output_pair[1], "")) == "UN":
                    # Campaign target is physical; partial executed work may be
                    # fractional, but cannot create a fractional finished lot.
                    if abs(complete_qty - round(complete_qty)) <= LOT_TRACE_EPS:
                        complete_qty = float(round(complete_qty))
                    complete_qty = require_physical_integer(complete_qty, "UN")
                work_days = math.ceil(remaining / max(process_capacity_by_output_pair.get(output_pair, 0.0), 1e-9))
                finish_day = day + max(1, work_days, network_leads.get(output_pair, 1))
                campaigns[output_pair] = (
                    open_production_campaign_id_by_pair.get(output_pair) or f"active:{output_pair}",
                    remaining, max(0.0, complete_qty - remaining), finish_day,
                )
            reserve_targets = {}
            for planning_pair in set(network_leads) | set(process_input_requirements_by_output_pair):
                if planning_pair in aggregate_supplier_pairs:
                    continue
                if planning_pair in produced_pairs:
                    reserve_targets[planning_pair] = max(
                        base_stock.get(planning_pair, 0.0),
                        fg_target_days * max(0.0, production_reference_signal_today.get(planning_pair, 0.0)),
                    )
                    continue
                review_days = mrp_review_period_days if planning_pair[0] in process_node_ids else review_period_days
                current_req = max(0.0, propagated_demand_today.get(planning_pair, 0.0))
                if static_requirement_for_pair(planning_pair):
                    current_req = max(0.0, required_daily_input_by_pair.get(planning_pair, 0.0))
                target_req, _floor, _window, cover = mrp_target_requirement_for_pair(planning_pair, current_req, review_days)
                network_covers[planning_pair] = max(1, math.ceil(cover))
                target = 0.0 if initialization_policy["mrp_strict_safety_floor_from_safety_time"] else max(
                    0.0, base_stock.get(planning_pair, 0.0),
                ) * base_stock_floor_factor_for_pair(planning_pair)
                target = max(target, pair_mrp_safety_stock_qty.get(planning_pair, 0.0),
                             target_req * pair_mrp_safety_time_days.get(planning_pair, 0.0) * soft_safety_factor_for_pair(planning_pair),
                             safety_stock_days * target_req)
                if planning_pair in demand_pairs:
                    target = max(target, demand_stock_target_days * target_req)
                if planning_pair not in mrp_snapshot_pairs or dynamic_requirement_for_pair(planning_pair):
                    target = max(target, target_req * cover)
                reserve_targets[planning_pair] = max(0.0, target)
            # 693055 has an explicit aggregate supply policy, not an invented
            # manufacturing process. Its fixed lot and lead are retained.
            for boundary_pair, boundary_policy in source_boundary_policies.items():
                cover = boundary_policy["lead_days"] + boundary_policy["review_period_days"]
                reserve_targets[boundary_pair] = max(0.0, mrp_target_demand_floor_by_pair(
                    mrp_target_profile_day, cover,
                ).get(boundary_pair, 0.0)) * cover
                network_covers[boundary_pair] = cover
            dated_plans, dated_requirements, dated_plan_audits = plan_component_network(
                decision_day=day, requirements_by_pair=forecast_requirements, available_by_pair=stock,
                firm_receipts_by_pair=firm_snapshot, transport_sources_by_pair=network_transport_sources,
                bom_by_pair=process_input_requirements_by_output_pair, lead_days_by_pair=network_leads,
                lot_sizing_by_pair=network_lots, reserve_targets_by_pair=reserve_targets,
                coverage_days_by_pair=network_covers, active_campaigns_by_pair=campaigns,
            )
            for planned_pair, plan in dated_plans.items():
                audit = dated_plan_audits[planned_pair]
                rows = dated_requirements[planned_pair]
                reserve_late = sum(a.qty for a in plan.allocations if a.delay_days > 0 and a.requirement_id.startswith("reserve:"))
                shortage_days = [balance.day for balance in plan.balances if balance.before_proposals_qty < -LOT_TRACE_EPS]
                dated_plan_decisions[planned_pair] = {
                    "dated_action_scope": "component_procurement" if planned_pair in dated_action_pairs else "planning_only_SD_execution_preserved",
                    "dated_requirement_qty": sum(row.qty for row in rows if not row.requirement_id.startswith("reserve:")),
                    "dated_campaign_remaining_qty": audit["campaign_remaining_qty"],
                    "dated_reserve_requirement_qty": audit["reserve_requirement_qty"],
                    "dated_stock_qty": stock.get(planned_pair, 0.0),
                    "dated_firm_held_qty": sum(row.qty for row in audit["firm_receipts"] if row.state == "held"),
                    "dated_firm_transit_qty": sum(row.qty for row in audit["firm_receipts"] if row.state == "in_transit"),
                    "dated_firm_production_qty": sum(row.qty for row in audit["firm_receipts"] if row.state == "confirmed"),
                    "dated_proposed_qty": plan.proposed_qty,
                    "dated_release_today_qty": sum(row.qty for row in plan.proposals if row.release_day <= day),
                    "dated_released_executed_qty": 0.0,
                    "dated_late_qty": plan.late_qty, "dated_late_qty_days": plan.late_qty_days,
                    "dated_reserve_late_qty": reserve_late, "dated_requirement_late_qty": max(0.0, plan.late_qty - reserve_late),
                    "dated_first_shortage_day": min(shortage_days) if shortage_days else "",
                    "dated_min_projected_qty": min((b.before_proposals_qty for b in plan.balances), default=stock.get(planned_pair, 0.0)),
                    "dated_horizon_days": horizon, "dated_lead_days": network_leads.get(planned_pair, 1),
                    "dated_lead_basis": ("process_tau_planning_estimate_not_physical_duration" if planned_pair in produced_pairs
                                         else "source_boundary_receipt_convention" if planned_pair in source_boundary_policies
                                         else "FIA_supplier_delivery_once_then_source_receipt_monday_friday_candidate" if planned_pair in aggregate_delivery_pairs
                                         else "lane_delivery_reference_calendar_convention"),
                }
            if (args.output_profile == "full" and 0 <= output_day < 365
                    and (date.fromisoformat(safety_calendar["start_date"]) + timedelta(days=output_day)).weekday() == 6):
                for planned_pair, plan in dated_plans.items():
                    audit = dated_plan_audits[planned_pair]
                    common = {"decision_day": output_day, "node_id": planned_pair[0], "item_id": planned_pair[1],
                              "uom": item_unit_map.get(planned_pair[1], ""),
                              "action_scope": "component_procurement" if planned_pair in dated_action_pairs else "planning_only_SD_execution_preserved"}
                    dated_plan_weekly_rows.append(dict(common, kind="opening_available", identity="stock", target_day=day,
                                                      release_day="", requested_day="", qty=stock.get(planned_pair, 0.0)))
                    for requirement in dated_requirements[planned_pair]:
                        dated_plan_weekly_rows.append(dict(common,
                            kind="reserve" if requirement.requirement_id.startswith("reserve:") else "requirement",
                            identity=requirement.requirement_id, target_day=requirement.due_day,
                            release_day="", requested_day="", qty=requirement.qty))
                    for receipt in audit["firm_receipts"]:
                        dated_plan_weekly_rows.append(dict(common, kind="firm_" + receipt.state, identity=receipt.receipt_id,
                            target_day=receipt.available_day, release_day="", requested_day="", qty=receipt.qty))
                    for proposal in plan.proposals:
                        dated_plan_weekly_rows.append(dict(common, kind="proposal", identity=proposal.proposal_id,
                            target_day=proposal.available_day, release_day=proposal.release_day,
                            requested_day=proposal.requested_day, qty=proposal.qty))

        for src_pair, boundary in source_boundary_policies.items():
            if output_day % boundary["review_period_days"]:
                continue
            cover_days = boundary["lead_days"] + boundary["review_period_days"]
            daily_forecast = max(0.0, mrp_target_demand_floor_by_pair(
                mrp_target_profile_day, cover_days,
            ).get(src_pair, 0.0))
            boundary_target = daily_forecast * cover_days
            boundary_stock = max(0.0, stock.get(src_pair, 0.0))
            boundary_pending = sum(max(0.0, book.get(src_pair, 0.0)) for book in (
                in_transit, external_in_transit, estimated_source_in_transit,
            ))
            order_qty = source_boundary_order_quantity(
                boundary_target, boundary_stock, boundary_pending, boundary["fixed_lot_qty"],
            )
            if dated_component_planning:
                order_qty = dated_plan_decisions.get(src_pair, {}).get("dated_release_today_qty", 0.0)
            source_boundary_decisions[src_pair] = {
                "source_boundary_target_qty": round(boundary_target, 6),
                "source_boundary_stock_qty_before_order": round(boundary_stock, 6),
                "source_boundary_pending_qty_before_order": round(boundary_pending, 6),
                "source_boundary_order_qty": round(order_qty, 6),
                "source_boundary_fixed_lot_qty": boundary["fixed_lot_qty"],
                "source_boundary_lead_days": boundary["lead_days"],
                "source_boundary_cover_days": cover_days,
                "source_boundary_daily_forecast_qty": round(daily_forecast, 6),
            }
            if order_qty <= LOT_TRACE_EPS:
                continue
            arrival_day = day + boundary["lead_days"]
            order_id = next_mrp_order_identity(
                source_mode="external_procurement_source_boundary", src_node_id="SOURCE_BOUNDARY_SUPPLY",
                dst_node_id=src_pair[0], item_id=src_pair[1],
            )
            source_boundary_order_ids.add(order_id)
            external_pipeline[arrival_day].append((src_pair[0], src_pair[1], order_qty, "", "", order_id))
            external_in_transit[src_pair] += order_qty
            if pending_receipt_calendar is not None:
                pending_receipt_calendar.add(src_pair, arrival_day, order_qty)
            external_ordered_today_by_src_pair[src_pair] += order_qty
            register_mrp_order(
                src_pair, source_mode="external_procurement_source_boundary",
                src_node_id="SOURCE_BOUNDARY_SUPPLY", dst_node_id=src_pair[0], item_id=src_pair[1],
                release_qty=order_qty, receipt_qty=order_qty, arrival_day=arrival_day,
                safety_time_days=0.0, lead_days=boundary["lead_days"],
                edge_id="SOURCE_BOUNDARY_SUPPLY", standard_order_qty=boundary["fixed_lot_qty"],
                mrp_order_id=order_id,
            )
            # Keep the existing external-sourcing valuation convention. This
            # boundary does not supply an industrial manufacturing cost/capacity.
            ref_purchase = max(economic_policy["purchase_cost_floor_per_unit"], max(
                (max(0.0, to_float(lane.get("unit_purchase_cost"), 0.0))
                 for lane in lanes_by_src_item.get(src_pair, [])), default=0.0,
            ))
            unit_purchase = max(economic_policy["external_procurement_unit_cost"],
                                ref_purchase * economic_policy["external_procurement_cost_multiplier"])
            if record_day:
                external_procured_today += order_qty
                external_procurement_purchase_cost_today += order_qty * unit_purchase
                external_procurement_transport_cost_today += order_qty * economic_policy["external_procurement_transport_cost_per_unit"]
                total_external_procurement_cost += order_qty * (unit_purchase + economic_policy["external_procurement_transport_cost_per_unit"])

        if (
            unmodeled_supplier_source_mode == "external_procurement"
            and economic_policy["external_procurement_enabled"]
            and economic_policy["external_procurement_proactive_replenishment"]
        ):
            for src_pair, policy in estimated_source_policies.items():
                if src_pair in source_boundary_policies or src_pair in aggregate_supplier_pairs:
                    continue
                external_control = resolve_daily_control(
                    node_id=src_pair[0],
                    supplier_id=src_pair[0],
                    item_id=src_pair[1],
                    dst_node_id=src_pair[0],
                )
                external_multiplier = (
                    external_control.external_procurement_multiplier
                    if external_control is not None
                    else 1.0
                )
                external_risk = supplier_risk_effects_for_pair(
                    supplier_risk_events_today,
                    src_pair[0],
                    src_pair[1],
                    output_day,
                )
                base_ext_lead_days, effective_ext_lead_days, _external_lead_basis = (
                    external_procurement_leads(policy, external_risk)
                )
                if external_control is not None:
                    expedite_reduction = int(
                        math.floor(
                            external_control.expedite_level
                            * max(0, effective_ext_lead_days - 1)
                        )
                    )
                    effective_ext_lead_days = max(
                        1,
                        effective_ext_lead_days
                        + external_control.lead_time_adjustment_days
                        - expedite_reduction,
                    )
                downstream_requirement = allocate_shared_downstream_pull(
                    src_pair=src_pair,
                    lanes_by_src_item=lanes_by_src_item,
                    externally_sourced_pairs=externally_sourced_pairs,
                    supplier_daily_capacity_by_pair=supplier_daily_capacity_by_pair,
                    downstream_values_by_pair=required_daily_input_by_pair,
                )
                downstream_signal = allocate_shared_downstream_pull(
                    src_pair=src_pair,
                    lanes_by_src_item=lanes_by_src_item,
                    externally_sourced_pairs=externally_sourced_pairs,
                    supplier_daily_capacity_by_pair=supplier_daily_capacity_by_pair,
                    downstream_values_by_pair=propagated_demand_today,
                )
                demand_anchor = (
                    downstream_signal
                    if source_has_dynamic_destination(src_pair)
                    else max(downstream_requirement, downstream_signal)
                )
                if demand_anchor <= 1e-9:
                    continue
                # Supplier upstream supply is a source replenishment buffer, not the
                # full downstream factory MRP target. Keeping it close to the
                # upstream lead time avoids overfilling high-volume suppliers
                # while still preventing reactive "order only at zero" behavior.
                target_cover_days = max(
                    1.0,
                    float(effective_ext_lead_days + int(to_float(policy.get("review_period_days"), 0.0))),
                    to_float(policy.get("external_procurement_target_cover_days"), 0.0),
                )
                target_stock_qty = max(
                    max(0.0, to_float(policy.get("downstream_lot_floor_qty"), 0.0)),
                    demand_anchor * target_cover_days,
                )
                inventory_position = (
                    max(0.0, stock.get(src_pair, 0.0))
                    + max(0.0, external_in_transit.get(src_pair, 0.0))
                    + max(0.0, estimated_source_in_transit.get(src_pair, 0.0))
                )
                if initial_stock_availability is not None:
                    inventory_position += initial_stock_availability.planning_quantity(
                        src_pair, decision_day=output_day,
                        through_day=output_day + max(0, int(math.ceil(target_cover_days)) - 1),
                    )
                desired_order_qty = max(0.0, target_stock_qty - inventory_position)
                if desired_order_qty <= 1e-9:
                    continue
                if record_day:
                    external_desired_today_by_src_pair[src_pair] += desired_order_qty
                if record_day and external_risk.get("event_ids"):
                    supplier_risk_applied_rows.append(
                        supplier_risk_applied_row(
                            day=output_day,
                            supplier_id=src_pair[0],
                            dst_node_id=src_pair[0],
                            item_id=src_pair[1],
                            edge_id=f"{SUPPLIER_UPSTREAM_SUPPLY_EDGE_PREFIX}_PROACTIVE",
                            effects=external_risk,
                        )
                    )
                ext_cap_today = external_procurement_daily_capacity(
                    policy,
                    external_risk,
                    demand_anchor,
                    external_multiplier,
                )
                ext_cap_left = max(0.0, ext_cap_today - external_ordered_today_by_src_pair[src_pair])
                ext_order_qty = physical_execution_quantity(min(desired_order_qty, ext_cap_left), item_unit_map.get(src_pair[1], ""))
                if ext_order_qty <= 1e-9:
                    if record_day:
                        external_procured_rejected_today += desired_order_qty
                        external_rejected_today_by_src_pair[src_pair] += desired_order_qty
                    if external_control is not None:
                        record_control_resolution(
                            external_control,
                            stage="external_procurement_proactive",
                            action_names=(
                                "external_procurement_multiplier",
                                "expedite_level",
                                "lead_time_adjustment_days",
                            ),
                            status="applied_no_executable_flow",
                            executed_control_volume_qty=0.0,
                            extra={
                                "quantity_uom": item_unit_map.get(
                                    src_pair[1],
                                    "",
                                ),
                                "q_mrp_base_qty": round(
                                    desired_order_qty,
                                    6,
                                ),
                                "q_after_control_qty": round(
                                    desired_order_qty,
                                    6,
                                ),
                                "q_after_constraints_qty": 0.0,
                                "q_executable_qty": 0.0,
                                "capacity_controlled_qty_per_day": (
                                    round(ext_cap_today, 6)
                                ),
                                "lead_reference_days": int(
                                    base_ext_lead_days
                                ),
                                "lead_effective_days": int(
                                    effective_ext_lead_days
                                ),
                                "binding_reason": (
                                    "external_capacity_or_control_zero"
                                ),
                            },
                        )
                    continue
                ext_receipt_qty = ext_order_qty * max(
                    0.01,
                    to_float(external_risk.get("external_quality_yield"), 1.0),
                )
                ext_receipt_qty = physical_execution_quantity(ext_receipt_qty, item_unit_map.get(src_pair[1], ""))
                ext_arrival_day = day + effective_ext_lead_days
                ext_planned_order_id = next_mrp_order_identity(
                    source_mode="external_procurement_proactive",
                    src_node_id=SUPPLIER_UPSTREAM_SUPPLY_NODE_ID,
                    dst_node_id=src_pair[0],
                    item_id=src_pair[1],
                )
                external_pipeline[ext_arrival_day].append(
                    (
                        src_pair[0],
                        src_pair[1],
                        ext_receipt_qty,
                        join_ids(external_risk.get("event_ids")),
                        join_ids(external_risk.get("causal_root_ids")),
                        ext_planned_order_id,
                    )
                )
                external_in_transit[src_pair] += ext_receipt_qty
                if pending_receipt_calendar is not None:
                    pending_receipt_calendar.add(src_pair, ext_arrival_day, ext_receipt_qty)
                external_ordered_today_by_src_pair[src_pair] += ext_order_qty
                register_mrp_order(
                    src_pair,
                    source_mode="external_procurement_proactive",
                    src_node_id=SUPPLIER_UPSTREAM_SUPPLY_NODE_ID,
                    dst_node_id=src_pair[0],
                    item_id=src_pair[1],
                    release_qty=ext_order_qty,
                    receipt_qty=ext_receipt_qty,
                    arrival_day=ext_arrival_day,
                    safety_time_days=pair_mrp_safety_time_days.get(src_pair, 0.0),
                    lead_days=effective_ext_lead_days,
                    lead_cover_days=effective_ext_lead_days,
                    lead_reference_days=base_ext_lead_days,
                    edge_id=f"{SUPPLIER_UPSTREAM_SUPPLY_EDGE_PREFIX}_PROACTIVE",
                    reliability=max(0.01, to_float(external_risk.get("external_quality_yield"), 1.0)),
                    mrp_order_id=ext_planned_order_id,
                    causal_event_ids=external_risk.get("event_ids"),
                    causal_root_ids=external_risk.get("causal_root_ids"),
                )
                ref_lane_purchase = max(
                    [max(0.0, to_float(lane.get("unit_purchase_cost"), 0.0)) for lane in lanes_by_src_item.get(src_pair, [])]
                    or [0.0]
                )
                ref_purchase = max(economic_policy["purchase_cost_floor_per_unit"], ref_lane_purchase)
                ext_unit_purchase = max(
                    economic_policy["external_procurement_unit_cost"],
                    ref_purchase * economic_policy["external_procurement_cost_multiplier"],
                )
                ext_unit_purchase *= max(0.0, to_float(external_risk.get("external_cost"), 1.0))
                ext_unit_transport = (
                    economic_policy["external_procurement_transport_cost_per_unit"]
                    * max(0.0, to_float(external_risk.get("external_cost"), 1.0))
                )
                if external_control is not None:
                    ext_unit_transport *= (
                        1.0 + 1.5 * external_control.expedite_level
                    )
                ext_purchase_cost = ext_order_qty * ext_unit_purchase
                ext_transport_cost = ext_order_qty * ext_unit_transport
                if record_day:
                    external_procured_today += ext_order_qty
                    external_procurement_purchase_cost_today += ext_purchase_cost
                    external_procurement_transport_cost_today += ext_transport_cost
                    total_external_procurement_cost += ext_order_qty * (ext_unit_purchase + ext_unit_transport)
                    ext_cap_rejected = max(0.0, desired_order_qty - ext_order_qty)
                    ext_quality_rejected = max(0.0, ext_order_qty - ext_receipt_qty)
                    external_procured_rejected_today += ext_cap_rejected
                    external_quality_rejected_today += ext_quality_rejected
                    external_rejected_today_by_src_pair[src_pair] += ext_cap_rejected
                    external_quality_loss_by_pair[src_pair] += ext_quality_rejected
                    if ref_purchase > 1e-9:
                        external_cost_ratio_today_by_src_pair[src_pair] = max(
                            external_cost_ratio_today_by_src_pair[src_pair],
                            (ext_unit_purchase + ext_unit_transport) / ref_purchase,
                        )
                if external_control is not None:
                    record_control_resolution(
                        external_control,
                        stage="external_procurement_proactive",
                        action_names=(
                            "external_procurement_multiplier",
                            "expedite_level",
                            "lead_time_adjustment_days",
                        ),
                        executed_control_volume_qty=ext_order_qty,
                        extra={
                            "quantity_uom": item_unit_map.get(src_pair[1], ""),
                            "q_mrp_base_qty": round(desired_order_qty, 6),
                            "q_after_control_qty": round(
                                desired_order_qty,
                                6,
                            ),
                            "q_after_constraints_qty": round(
                                ext_order_qty,
                                6,
                            ),
                            "q_executable_qty": round(
                                ext_receipt_qty,
                                6,
                            ),
                            "capacity_controlled_qty_per_day": round(
                                ext_cap_today,
                                6,
                            ),
                            "lead_reference_days": int(base_ext_lead_days),
                            "lead_effective_days": int(
                                effective_ext_lead_days
                            ),
                            "binding_reason": (
                                "external_capacity"
                                if ext_order_qty + 1e-9
                                < desired_order_qty
                                else "none"
                            ),
                        },
                    )
        for pair, lane_list in lanes_by_dest_item.items():
            dst, item_id = pair
            pair_control = resolve_daily_control(
                node_id=dst,
                item_id=item_id,
                dst_node_id=dst,
            )
            safety_stock_multiplier = (
                pair_control.safety_stock_multiplier
                if pair_control is not None
                else 1.0
            )
            order_multiplier = (
                pair_control.order_multiplier
                if pair_control is not None
                else 1.0
            )
            pair_is_upstream_factory_mrp = dst in process_node_ids and pair not in demand_pairs
            pair_review_period_days = mrp_review_period_days if pair_is_upstream_factory_mrp else review_period_days
            strict_safety_floor = initialization_policy["mrp_strict_safety_floor_from_safety_time"]
            target = (
                0.0
                if strict_safety_floor
                else max(base_stock.get(pair, 0.0), 0.0) * base_stock_floor_factor_for_pair(pair)
            )
            # Keep a control-free MRP target in parallel so the ledger's
            # q_MRP value is genuinely the historical reference, even when a
            # safety-stock multiplier is active.
            neutral_target = target
            static_daily_req = max(0.0, required_daily_input_by_pair.get(pair, 0.0))
            dynamic_daily_req = max(0.0, propagated_demand_today.get(pair, 0.0))
            if static_requirement_for_pair(pair):
                item_daily_req = static_daily_req
            elif dynamic_daily_req > 1e-9:
                # Use the propagated downstream demand signal for day-to-day supplier
                # replenishment targets. The static engineering requirement remains a
                # fallback for items that currently have no propagated demand, but it
                # should not force long-lead suppliers into a flat, capped shipment
                # profile when downstream demand and production actually vary.
                item_daily_req = dynamic_daily_req
            elif (
                initialization_policy["use_bom_demand_signal_for_mrp"]
                and not initialization_policy["mrp_static_fallback_for_propagated_pairs"]
                and pair in propagated_mrp_signal_pairs
            ):
                item_daily_req = 0.0
            else:
                item_daily_req = static_daily_req
            target_daily_req, _target_floor_req, _target_window_days, effective_cover_days = mrp_target_requirement_for_pair(
                pair,
                item_daily_req,
                pair_review_period_days,
            )
            explicit_safety_stock_base_qty = max(
                0.0,
                pair_mrp_safety_stock_qty.get(pair, 0.0),
            )
            explicit_safety_stock_qty = (
                explicit_safety_stock_base_qty * safety_stock_multiplier
            )
            soft_safety_target_qty = explicit_safety_stock_qty if strict_safety_floor else max(target, explicit_safety_stock_qty)
            neutral_soft_safety_target_qty = (
                explicit_safety_stock_base_qty
                if strict_safety_floor
                else max(neutral_target, explicit_safety_stock_base_qty)
            )
            target = max(target, explicit_safety_stock_qty)
            neutral_target = max(
                neutral_target,
                explicit_safety_stock_base_qty,
            )
            if target_daily_req > 0:
                safety_time_target_qty = (
                    target_daily_req
                    * max(0.0, pair_mrp_safety_time_days.get(pair, 0.0))
                    * soft_safety_factor_for_pair(pair)
                    * safety_stock_multiplier
                )
                neutral_safety_time_target_qty = (
                    target_daily_req
                    * max(
                        0.0,
                        pair_mrp_safety_time_days.get(pair, 0.0),
                    )
                    * soft_safety_factor_for_pair(pair)
                )
                safety_target_qty = max(explicit_safety_stock_qty, safety_time_target_qty)
                neutral_safety_target_qty = max(
                    explicit_safety_stock_base_qty,
                    neutral_safety_time_target_qty,
                )
                if strict_safety_floor:
                    soft_safety_target_qty = safety_target_qty
                    neutral_soft_safety_target_qty = (
                        neutral_safety_target_qty
                    )
                else:
                    soft_safety_target_qty = max(target, safety_target_qty)
                    neutral_soft_safety_target_qty = max(
                        neutral_target,
                        neutral_safety_target_qty,
                    )
                target = max(target, soft_safety_target_qty)
                neutral_target = max(
                    neutral_target,
                    neutral_soft_safety_target_qty,
                )
                target = max(
                    target,
                    safety_stock_days
                    * target_daily_req
                    * safety_stock_multiplier,
                )
                neutral_target = max(
                    neutral_target,
                    safety_stock_days * target_daily_req,
                )
                if pair in demand_pairs and demand_stock_target_days > 0.0:
                    target = max(target, demand_stock_target_days * target_daily_req)
                    neutral_target = max(
                        neutral_target,
                        demand_stock_target_days * target_daily_req,
                    )
                if pair not in mrp_snapshot_pairs or dynamic_requirement_for_pair(pair):
                    target = max(
                        target,
                        target_daily_req * effective_cover_days,
                    )
                    neutral_target = max(
                        neutral_target,
                        target_daily_req * effective_cover_days,
                    )
            else:
                target = max(target, 0.0)
                neutral_target = max(neutral_target, 0.0)
            target += backlog[pair]
            neutral_target += backlog[pair]

            if day % pair_review_period_days != 0:
                continue

            receipt_cover_qty = in_transit[pair]
            if pending_receipt_calendar is not None:
                receipt_cover_end_day = mrp_receipt_cover_end_day(day, _target_window_days)
                receipt_cover_qty = pending_receipt_calendar.quantity(
                    pair, decision_day=day, through_day=receipt_cover_end_day,
                )
            neutral_needed = neutral_target - stock[pair] - receipt_cover_qty
            needed = target - stock[pair] - receipt_cover_qty
            held_release_cover_qty = 0.0
            if initial_stock_availability is not None:
                held_release_cover_qty = initial_stock_availability.planning_quantity(
                    pair, decision_day=output_day,
                    through_day=output_day + max(0, int(_target_window_days) - 1),
                )
                neutral_needed -= held_release_cover_qty
                needed -= held_release_cover_qty
            if initialization_policy["mrp_enforce_physical_safety_floor"]:
                if explicit_safety_stock_qty > 0.0 and pair_mrp_safety_time_days.get(pair, 0.0) <= 0.0:
                    # For explicit stock-only targets, avoid stacking duplicate
                    # long-lead lots when already-released orders cover the target.
                    needed = max(needed, soft_safety_target_qty - stock[pair] - receipt_cover_qty - held_release_cover_qty)
                else:
                    # A physical floor should trigger when the local stock is too
                    # low, but it must still respect firm in-transit receipts.
                    # Ignoring in-transit here stacks duplicate long-lead lots on
                    # every review day until the receipts physically arrive.
                    needed = max(needed, soft_safety_target_qty - stock[pair] - receipt_cover_qty - held_release_cover_qty)
                neutral_needed = max(
                    neutral_needed,
                    neutral_soft_safety_target_qty
                    - stock[pair]
                    - receipt_cover_qty
                    - held_release_cover_qty,
                )
            if dated_component_planning and pair in dated_action_pairs:
                needed = dated_plan_decisions.get(pair, {}).get("dated_release_today_qty", 0.0)
                neutral_needed = needed
            q_mrp_base_qty = max(0.0, neutral_needed)
            q_after_safety_stock_control_qty = max(0.0, needed)
            needed *= order_multiplier
            q_after_control_qty = max(0.0, needed)
            if pending_receipt_calendar is not None:
                pending_qty = pending_receipt_calendar.total(pair)
                dated_receipt_decisions[pair] = {
                    "decision_receipt_cover_end_day": receipt_cover_end_day - warmup_days,
                    "decision_recv_prev_future_qty": round(pending_qty, 6),
                    "decision_recv_prev_within_cover_qty": round(receipt_cover_qty, 6),
                    "decision_recv_prev_after_cover_qty": round(max(0.0, pending_qty - receipt_cover_qty), 6),
                    "decision_stock_proj_qty": round(stock[pair], 6),
                    "decision_target_with_backlog_qty": round(target, 6),
                    "decision_held_release_within_cover_qty": round(held_release_cover_qty, 6),
                    "decision_bn_qty": round(q_after_safety_stock_control_qty, 6),
                    "decision_controlled_bn_qty": round(q_after_control_qty, 6),
                }
            has_regular_need = needed > 1e-9
            active_lanes: list[
                tuple[
                    dict[str, Any],
                    float,
                    dict[str, Any],
                    ResolvedControl | None,
                ]
            ] = []
            annual_min_lot_lanes: list[
                tuple[
                    dict[str, Any],
                    float,
                    dict[str, Any],
                    ResolvedControl | None,
                ]
            ] = []

            for lane in lane_list:
                lane_review_days = int(round(max(1.0, to_float(lane.get("order_frequency_days"), 1.0))))
                if day % lane_review_days != 0:
                    continue
                risk_mult = supplier_risk_multipliers_for_lane(supplier_risk_events_today, lane, output_day)
                lane_control = resolve_daily_control(
                    node_id=dst,
                    supplier_id=str(lane.get("src") or ""),
                    item_id=item_id,
                    dst_node_id=dst,
                )
                availability_mult = lane_availability_multiplier(lane, day) * to_float(
                    risk_mult.get("availability"),
                    1.0,
                )
                if has_regular_need and record_day and risk_mult.get("event_ids"):
                    supplier_risk_applied_rows.append(
                        supplier_risk_applied_row(
                            day=output_day,
                            supplier_id=str(lane.get("src") or ""),
                            dst_node_id=str(lane.get("dst") or ""),
                            item_id=str(lane.get("item_id") or ""),
                            edge_id=str(lane.get("edge_id") or ""),
                            effects=risk_mult,
                        )
                    )
                if availability_mult <= 1e-9:
                    continue
                active_lanes.append(
                    (lane, availability_mult, risk_mult, lane_control)
                )

            if (
                mrp_multisource_min_annual_lot_enabled
                and record_day
                and pair_is_upstream_factory_mrp
                and len(lane_list) > 1
                and not (dated_component_planning and pair in dated_action_pairs)
            ):
                output_day_nonnegative = max(0, int(output_day))
                year_idx = output_day_nonnegative // 365
                day_in_year = output_day_nonnegative % 365
                if day_in_year >= 365 - mrp_multisource_min_annual_lot_window_days:
                    for lane in lane_list:
                        edge_id = str(lane.get("edge_id") or "")
                        if not edge_id or (year_idx, edge_id) in mrp_multisource_annual_lane_orders:
                            continue
                        standard_order_qty = max(0.0, to_float(lane.get("standard_order_qty"), 0.0))
                        if standard_order_qty <= 1e-9:
                            continue
                        risk_mult = supplier_risk_multipliers_for_lane(supplier_risk_events_today, lane, output_day)
                        lane_control = resolve_daily_control(
                            node_id=dst,
                            supplier_id=str(lane.get("src") or ""),
                            item_id=item_id,
                            dst_node_id=dst,
                        )
                        availability_mult = lane_availability_multiplier(lane, day) * to_float(
                            risk_mult.get("availability"),
                            1.0,
                        )
                        if availability_mult <= 1e-9:
                            continue
                        if record_day and risk_mult.get("event_ids"):
                            supplier_risk_applied_rows.append(
                                supplier_risk_applied_row(
                                    day=output_day,
                                    supplier_id=str(lane.get("src") or ""),
                                    dst_node_id=str(lane.get("dst") or ""),
                                    item_id=str(lane.get("item_id") or ""),
                                    edge_id=str(lane.get("edge_id") or ""),
                                    effects=risk_mult,
                                )
                            )
                        annual_min_lot_lanes.append(
                            (lane, availability_mult, risk_mult, lane_control)
                        )

            # Supplier-targeted order multipliers act once on the lane's base
            # MRP share. Their weighted mean adjusts the total pair need, so a
            # multiplier above one can increase a mono-source order instead of
            # being clipped back to the original remaining need.
            base_lane_weights = {
                id(lane): max(
                    0.0,
                    to_float(lane.get("mrp_share"), 0.0),
                )
                for lane, _, _, _ in active_lanes
            }
            if (
                active_lanes
                and sum(base_lane_weights.values()) <= 1e-9
            ):
                base_lane_weights = {
                    id(lane): 1.0
                    for lane, _, _, _ in active_lanes
                }
            base_lane_weight_total = sum(base_lane_weights.values())
            supplier_order_multipliers: dict[int, float] = {}
            priority_weights: dict[int, float] = {}
            for lane, _, _, lane_control in active_lanes:
                targeted_order_multiplier = 1.0
                priority_weight = 1.0
                if lane_control is not None:
                    order_action = lane_control.action("order_multiplier")
                    if (
                        order_action.applied
                        and bool(order_action.supplier_id)
                    ):
                        targeted_order_multiplier = max(
                            0.0,
                            lane_control.order_multiplier,
                        )
                    priority_action = lane_control.action(
                        "priority_weight"
                    )
                    if priority_action.applied:
                        priority_weight = max(
                            0.0,
                            lane_control.priority_weight,
                        )
                supplier_order_multipliers[id(lane)] = (
                    targeted_order_multiplier
                )
                priority_weights[id(lane)] = priority_weight

            q_after_supplier_control_qty = _supplier_controlled_need_qty(
                q_after_control_qty,
                base_lane_weights,
                supplier_order_multipliers,
            )
            needed = q_after_supplier_control_qty

            allocation_weights = {
                id(lane): (
                    base_lane_weights[id(lane)]
                    * supplier_order_multipliers[id(lane)]
                    * priority_weights[id(lane)]
                )
                for lane, _, _, _ in active_lanes
            }
            active_share_total = sum(allocation_weights.values())
            eligible_active_lanes = [
                entry
                for entry in active_lanes
                if allocation_weights[id(entry[0])] > 1e-9
            ]
            has_regular_need = (
                needed > 1e-9 and bool(eligible_active_lanes)
            )

            if base_lane_weight_total > 1e-9:
                order_only_weight_total = sum(
                    base_lane_weights[id(lane)]
                    * supplier_order_multipliers[id(lane)]
                    for lane, _, _, _ in active_lanes
                )
                for lane, _, _, lane_control in active_lanes:
                    if lane_control is None:
                        continue
                    lane_key = id(lane)
                    base_lane_target = (
                        q_after_control_qty
                        * base_lane_weights[lane_key]
                        / base_lane_weight_total
                    )
                    supplier_controlled_lane_target = (
                        base_lane_target
                        * supplier_order_multipliers[lane_key]
                    )
                    order_action = lane_control.action(
                        "order_multiplier"
                    )
                    if (
                        order_action.applied
                        and bool(order_action.supplier_id)
                    ):
                        record_control_resolution(
                            lane_control,
                            stage=(
                                "supplier_order_control_before_constraints"
                            ),
                            action_names=("order_multiplier",),
                            status=(
                                "applied"
                                if supplier_controlled_lane_target > 1e-9
                                else "applied_zero_target"
                            ),
                            extra={
                                "edge_id": str(
                                    lane.get("edge_id") or ""
                                ),
                                "quantity_uom": item_unit_map.get(
                                    item_id,
                                    "",
                                ),
                                "q_supplier_base_share_qty": round(
                                    base_lane_target,
                                    6,
                                ),
                                "q_after_supplier_control_qty": round(
                                    supplier_controlled_lane_target,
                                    6,
                                ),
                                "q_pair_after_supplier_control_qty": (
                                    round(
                                        q_after_supplier_control_qty,
                                        6,
                                    )
                                ),
                                "binding_reason": (
                                    "supplier_order_multiplier_zero"
                                    if supplier_controlled_lane_target
                                    <= 1e-9
                                    else "none"
                                ),
                            },
                        )

                    priority_action = lane_control.action(
                        "priority_weight"
                    )
                    if (
                        priority_action.applied
                        and len(active_lanes) > 1
                    ):
                        before_priority_target = (
                            q_after_supplier_control_qty
                            * (
                                base_lane_weights[lane_key]
                                * supplier_order_multipliers[lane_key]
                            )
                            / max(order_only_weight_total, 1e-9)
                        )
                        after_priority_target = (
                            q_after_supplier_control_qty
                            * allocation_weights[lane_key]
                            / max(active_share_total, 1e-9)
                            if active_share_total > 1e-9
                            else 0.0
                        )
                        priority_changed = (
                            abs(
                                after_priority_target
                                - before_priority_target
                            )
                            > 1e-9
                        )
                        record_control_resolution(
                            lane_control,
                            stage="supplier_allocation_priority",
                            action_names=("priority_weight",),
                            status=(
                                "applied"
                                if priority_changed
                                else "applied_no_relative_effect"
                            ),
                            extra={
                                "edge_id": str(
                                    lane.get("edge_id") or ""
                                ),
                                "quantity_uom": item_unit_map.get(
                                    item_id,
                                    "",
                                ),
                                "q_before_priority_allocation_qty": (
                                    round(
                                        before_priority_target,
                                        6,
                                    )
                                ),
                                "q_after_priority_allocation_qty": (
                                    round(
                                        after_priority_target,
                                        6,
                                    )
                                ),
                                "binding_reason": (
                                    "all_priority_weights_zero"
                                    if active_share_total <= 1e-9
                                    else (
                                        "global_or_common_weight_cancels"
                                        if not priority_changed
                                        else "none"
                                    )
                                ),
                            },
                        )

            pair_constrained_before_lot_qty = 0.0

            def try_ship_lane(
                lane: dict[str, Any],
                availability_mult: float,
                risk_mult: dict[str, Any],
                lane_control: ResolvedControl | None,
                desired_delivered_qty: float,
                remaining_need_qty: float,
                source_mode: str = "lane_release",
            ) -> float:
                nonlocal shipped_today
                nonlocal transport_cost_today
                nonlocal opening_transport_cost_today
                nonlocal purchase_cost_today
                nonlocal opening_purchase_cost_today
                nonlocal external_procurement_transport_cost_today
                nonlocal external_procurement_purchase_cost_today
                nonlocal external_procured_today
                nonlocal external_procured_rejected_today, external_quality_rejected_today
                nonlocal supplier_capacity_binding_qty_today
                nonlocal total_external_procurement_cost
                nonlocal total_unreliable_loss_qty
                nonlocal pair_constrained_before_lot_qty
                nonlocal supplier_shipment_sequence

                if desired_delivered_qty <= 1e-9 or remaining_need_qty <= 1e-9:
                    return 0.0
                src_pair = (lane["src"], item_id)
                if dated_component_planning and pair in aggregate_delivery_pairs:
                    # FIA describes one supplier delivery promise. No unobserved
                    # supplier replenishment followed by a second FIA transit,
                    # and no invented departure/truck/source inventory movement.
                    rel = min(1.0, max(0.01, to_float(lane.get("reliability"), 1.0)
                                      * to_float(risk_mult.get("reliability"), 1.0)
                                      * to_float(risk_mult.get("quality_yield"), 1.0)))
                    planning_rel = supplier_planning_reliability(
                        max(0.01, min(1.0, to_float(lane.get("reliability"), 1.0))), rel,
                        gross_up_temporary_risk_loss=economic_policy["supplier_risk_loss_gross_up"],
                    )
                    requested = desired_delivered_qty / planning_rel
                    cap = supplier_daily_capacity_by_pair.get(src_pair, requested)
                    cap *= availability_mult * max(0.0, to_float(risk_mult.get("capacity"), 1.0))
                    if lane_control is not None:
                        cap *= lane_control.capacity_multiplier
                    capacity_left = max(0.0, cap - supplier_capacity_used_today_by_src_pair[src_pair])
                    standard = max(0.0, to_float(lane.get("standard_order_qty"), 0.0))
                    binding = policy_pair_key(*pair) not in nonbinding_standard_order_pair_keys
                    uom = normalize_unit(item_unit_map.get(item_id, ""))
                    ordered = mrp_purchase_order_quantity(requested, capacity_left, standard, binding=binding, uom=uom)
                    physical_multiple = max(0.0, to_float(lane.get("physical_dispatch_multiple"), 0.0))
                    if physical_multiple > 0:
                        ordered = min(math.ceil(ordered / physical_multiple) * physical_multiple,
                                      math.floor(capacity_left / physical_multiple) * physical_multiple)
                    received = physical_execution_quantity(ordered * rel, uom)
                    if ordered <= LOT_TRACE_EPS or received <= LOT_TRACE_EPS:
                        return 0.0
                    delivery_lead = sample_lead_days(
                        lane, paired_lane_rng(measured_day=output_day, lane=lane, source_mode=source_mode),
                        args.stochastic_lead_times, lead_time_distribution_mode,
                    )
                    delivery_lead = compose_controlled_lane_lead_days(
                        transport_lead_days_before_quality=float(delivery_lead) * max(0.05, to_float(risk_mult.get("lead_time"), 1.0))
                        + max(0.0, to_float(risk_mult.get("lead_time_extra_days"), 0.0)),
                        quality_delay_days=0.0,
                        expedite_level=lane_control.expedite_level if lane_control is not None else 0.0,
                        lead_time_adjustment_days=lane_control.lead_time_adjustment_days if lane_control is not None else 0,
                        delay_control_active=bool(lane_control is not None and
                                                  (lane_control.expedite_level > 1e-12 or lane_control.lead_time_adjustment_days != 0)),
                    )
                    physical_day = day + max(1, int(delivery_lead))
                    receipt_policy = supplier_receipt_policies[pair]
                    available_day = supplier_receipt_available_day(
                        physical_day, receipt_policy["receipt_days"], origin_date=safety_calendar["start_date"],
                    )
                    order_id = next_mrp_order_identity(
                        source_mode="external_procurement_supplier_delivery", src_node_id=src_pair[0],
                        dst_node_id=dst, item_id=item_id,
                    )
                    supplier_delivery_orders[order_id] = dict(receipt_policy, supplier_id=src_pair[0], edge_id=lane["edge_id"])
                    opening_purchase_availability.add_order({
                        "order_type": "external_procurement_supplier_delivery", "mrp_order_id": order_id,
                        "node_id": dst, "item_id": item_id, "src_node_id": src_pair[0], "edge_id": lane["edge_id"],
                        "receipt_qty": received, "physical_delivery_day": physical_day, "arrival_day": available_day,
                        "source_file": receipt_policy["source_file"], "source_row": json.dumps(receipt_policy["source_cells"], ensure_ascii=False),
                    })
                    external_pipeline[available_day].append((dst, item_id, received, "", "", order_id))
                    external_in_transit[pair] += received
                    register_mrp_order(
                        pair, source_mode="external_procurement_supplier_delivery", src_node_id=src_pair[0],
                        dst_node_id=dst, item_id=item_id, release_qty=ordered, receipt_qty=received,
                        arrival_day=available_day, safety_time_days=pair_mrp_safety_time_days.get(pair, 0.0),
                        lead_days=available_day - day, lead_reference_days=network_leads[pair],
                        edge_id=lane["edge_id"], reliability=rel, standard_order_qty=standard,
                        mrp_share=to_float(lane.get("mrp_share"), 0.0), mrp_order_id=order_id,
                        source_inventory_reserved=False,
                    )
                    if record_day:
                        mrp_order_rows[-1].update({
                            "physical_delivery_day": physical_day, "available_day": available_day,
                            "actual_physical_receipt_day": physical_day if physical_day < total_timeline_days else "",
                            "actual_available_day": available_day if available_day < total_timeline_days else "",
                            "source_file": receipt_policy["source_file"],
                            "source_row": json.dumps(receipt_policy["source_cells"], ensure_ascii=False),
                            "planning_status": "supplier_promise_confirmed", "release_status": "order_placed_departure_unknown",
                            "delivery_reference_days": lead_time_reference_days(lane),
                            "delivery_sampled_days": physical_day - day,
                            "receipt_source_days": receipt_policy["receipt_days"], "receipt_calendar": "monday_friday_candidate",
                        })
                    supplier_capacity_used_today_by_src_pair[src_pair] += ordered
                    pair_constrained_before_lot_qty += min(requested, capacity_left)
                    supplier_capacity_binding_qty_today += max(0.0, requested - capacity_left)
                    external_ordered_today_by_src_pair[src_pair] += ordered
                    external_procured_today += ordered
                    external_quality_rejected_today += max(0.0, ordered - received)
                    transport_cost, _, _ = lane_transport_cost_for_chunk(lane, item_id, ordered, received)
                    transport_cost *= max(0.0, to_float(risk_mult.get("transport_cost"), 1.0))
                    purchase_cost = received * lane["unit_purchase_cost"] * max(0.0, to_float(risk_mult.get("purchase_cost"), 1.0))
                    external_procurement_purchase_cost_today += purchase_cost
                    external_procurement_transport_cost_today += transport_cost
                    total_external_procurement_cost += purchase_cost + transport_cost
                    return received
                stock_access_mult = max(0.0, to_float(risk_mult.get("stock"), 1.0))
                available = stock[src_pair] * availability_mult * stock_access_mult
                annual_external_backorder = (
                    source_mode == "lane_release_min_annual_lot"
                    and src_pair in externally_sourced_pairs_set
                )
                if (
                    src_pair in externally_sourced_pairs_set
                    and src_pair not in source_boundary_policies
                    and available < remaining_need_qty
                    and not annual_external_backorder
                ):
                    if (
                        unmodeled_supplier_source_mode == "external_procurement"
                        and economic_policy["external_procurement_enabled"]
                    ):
                        ext_gap = remaining_need_qty - available
                        ext_daily_signal = max(
                            propagated_demand_today.get(src_pair, 0.0),
                            item_daily_req,
                        )
                        ext_policy = estimated_source_policies.get(src_pair, {})
                        ext_cap_today = external_procurement_daily_capacity(
                            ext_policy,
                            risk_mult,
                            ext_daily_signal,
                            (
                                lane_control.external_procurement_multiplier
                                if lane_control is not None
                                else 1.0
                            ),
                        )
                        if record_day:
                            external_desired_today_by_src_pair[src_pair] += ext_gap
                        ext_cap_left = max(0.0, ext_cap_today - external_ordered_today_by_src_pair[src_pair])
                        ext_order_qty = physical_execution_quantity(min(ext_gap, ext_cap_left), item_unit_map.get(src_pair[1], ""))
                        if ext_order_qty > 1e-9:
                            base_ext_lead_days, ext_lead_days, _external_lead_basis = (
                                external_procurement_leads(
                                    ext_policy,
                                    risk_mult,
                                )
                            )
                            if lane_control is not None:
                                ext_expedite_reduction = int(
                                    math.floor(
                                        lane_control.expedite_level
                                        * max(0, ext_lead_days - 1)
                                    )
                                )
                                ext_lead_days = max(
                                    1,
                                    ext_lead_days
                                    + lane_control.lead_time_adjustment_days
                                    - ext_expedite_reduction,
                                )
                            ext_receipt_qty = ext_order_qty * max(
                                0.01,
                                to_float(risk_mult.get("external_quality_yield"), 1.0),
                            )
                            ext_receipt_qty = physical_execution_quantity(ext_receipt_qty, item_unit_map.get(src_pair[1], ""))
                            ext_arrival_day = day + ext_lead_days
                            ext_planned_order_id = next_mrp_order_identity(
                                source_mode="external_procurement",
                                src_node_id=SUPPLIER_UPSTREAM_SUPPLY_NODE_ID,
                                dst_node_id=src_pair[0],
                                item_id=src_pair[1],
                            )
                            external_pipeline[ext_arrival_day].append(
                                (
                                    src_pair[0],
                                    src_pair[1],
                                    ext_receipt_qty,
                                    join_ids(risk_mult.get("event_ids")),
                                    join_ids(risk_mult.get("causal_root_ids")),
                                    ext_planned_order_id,
                                )
                            )
                            external_in_transit[src_pair] += ext_receipt_qty
                            if pending_receipt_calendar is not None:
                                pending_receipt_calendar.add(src_pair, ext_arrival_day, ext_receipt_qty)
                            register_mrp_order(
                                src_pair,
                                source_mode="external_procurement",
                                src_node_id=SUPPLIER_UPSTREAM_SUPPLY_NODE_ID,
                                dst_node_id=src_pair[0],
                                item_id=src_pair[1],
                                release_qty=ext_order_qty,
                                receipt_qty=ext_receipt_qty,
                                arrival_day=ext_arrival_day,
                                safety_time_days=pair_mrp_safety_time_days.get(src_pair, 0.0),
                                lead_days=ext_lead_days,
                                lead_cover_days=ext_lead_days,
                                lead_reference_days=base_ext_lead_days,
                                edge_id=f"{SUPPLIER_UPSTREAM_SUPPLY_EDGE_PREFIX}_REACTIVE",
                                reliability=max(0.01, to_float(risk_mult.get("external_quality_yield"), 1.0)),
                                mrp_order_id=ext_planned_order_id,
                                causal_event_ids=risk_mult.get("event_ids"),
                                causal_root_ids=risk_mult.get("causal_root_ids"),
                            )
                            if record_day:
                                external_procured_today += ext_order_qty
                            external_ordered_today_by_src_pair[src_pair] += ext_order_qty
                            ref_purchase = max(
                                economic_policy["purchase_cost_floor_per_unit"],
                                to_float(lane.get("unit_purchase_cost"), 0.0),
                            )
                            ext_unit_purchase = max(
                                economic_policy["external_procurement_unit_cost"],
                                ref_purchase * economic_policy["external_procurement_cost_multiplier"],
                            )
                            ext_unit_purchase *= max(0.0, to_float(risk_mult.get("external_cost"), 1.0))
                            ext_unit_transport = (
                                economic_policy["external_procurement_transport_cost_per_unit"]
                                * max(0.0, to_float(risk_mult.get("external_cost"), 1.0))
                            )
                            if lane_control is not None:
                                ext_unit_transport *= (
                                    1.0
                                    + 1.5
                                    * lane_control.expedite_level
                                )
                            ext_order_cost = ext_order_qty * (ext_unit_purchase + ext_unit_transport)
                            if record_day:
                                ext_purchase_cost = ext_order_qty * ext_unit_purchase
                                ext_transport_cost = ext_order_qty * ext_unit_transport
                                external_procurement_purchase_cost_today += ext_purchase_cost
                                external_procurement_transport_cost_today += ext_transport_cost
                                total_external_procurement_cost += ext_order_cost
                            if lane_control is not None:
                                record_control_resolution(
                                    lane_control,
                                    stage="external_procurement_reactive",
                                    action_names=(
                                        "external_procurement_multiplier",
                                        "expedite_level",
                                        "lead_time_adjustment_days",
                                    ),
                                    executed_control_volume_qty=ext_order_qty,
                                    extra={
                                        "edge_id": str(
                                            lane.get("edge_id") or ""
                                        ),
                                        "quantity_uom": item_unit_map.get(
                                            item_id,
                                            "",
                                        ),
                                        "q_mrp_base_qty": round(
                                            ext_gap,
                                            6,
                                        ),
                                        "q_after_constraints_qty": round(
                                            ext_order_qty,
                                            6,
                                        ),
                                        "q_executable_qty": round(
                                            ext_receipt_qty,
                                            6,
                                        ),
                                        "capacity_controlled_qty_per_day": round(
                                            ext_cap_today,
                                            6,
                                        ),
                                        "lead_reference_days": int(
                                            base_ext_lead_days
                                        ),
                                        "lead_effective_days": int(
                                            ext_lead_days
                                        ),
                                        "binding_reason": (
                                            "external_capacity"
                                            if ext_order_qty + 1e-9 < ext_gap
                                            else "none"
                                        ),
                                    },
                                )
                        else:
                            (
                                base_ext_lead_days,
                                ext_lead_days,
                                _external_lead_basis,
                            ) = external_procurement_leads(
                                ext_policy,
                                risk_mult,
                            )
                            if lane_control is not None:
                                ext_expedite_reduction = int(
                                    math.floor(
                                        lane_control.expedite_level
                                        * max(0, ext_lead_days - 1)
                                    )
                                )
                                ext_lead_days = max(
                                    1,
                                    ext_lead_days
                                    + lane_control.lead_time_adjustment_days
                                    - ext_expedite_reduction,
                                )
                                record_control_resolution(
                                    lane_control,
                                    stage="external_procurement_reactive",
                                    action_names=(
                                        "external_procurement_multiplier",
                                        "expedite_level",
                                        "lead_time_adjustment_days",
                                    ),
                                    status=(
                                        "applied_no_executable_flow"
                                    ),
                                    executed_control_volume_qty=0.0,
                                    extra={
                                        "edge_id": str(
                                            lane.get("edge_id") or ""
                                        ),
                                        "quantity_uom": item_unit_map.get(
                                            item_id,
                                            "",
                                        ),
                                        "q_mrp_base_qty": round(
                                            ext_gap,
                                            6,
                                        ),
                                        "q_after_constraints_qty": 0.0,
                                        "q_executable_qty": 0.0,
                                        "capacity_controlled_qty_per_day": (
                                            round(ext_cap_today, 6)
                                        ),
                                        "lead_reference_days": int(
                                            base_ext_lead_days
                                        ),
                                        "lead_effective_days": int(
                                            ext_lead_days
                                        ),
                                        "binding_reason": (
                                            "external_capacity_or_control_zero"
                                        ),
                                    },
                                )
                        ext_rejected = max(0.0, ext_gap - ext_order_qty)
                        if record_day:
                            external_procured_rejected_today += ext_rejected
                            external_rejected_today_by_src_pair[src_pair] += ext_rejected
                            if ext_order_qty > 1e-9:
                                ext_quality_rejected = max(0.0, ext_order_qty - ext_receipt_qty)
                                external_quality_rejected_today += ext_quality_rejected
                                external_quality_loss_by_pair[src_pair] += ext_quality_rejected
                                if ref_purchase > 1e-9:
                                    external_cost_ratio_today_by_src_pair[src_pair] = max(
                                        external_cost_ratio_today_by_src_pair[src_pair],
                                        (ext_unit_purchase + ext_unit_transport) / ref_purchase,
                                    )
                    available = stock[src_pair] * availability_mult * stock_access_mult
                if available <= 1e-9 and not annual_external_backorder:
                    return 0.0
                rel = max(
                    0.01,
                    min(
                        1.0,
                        to_float(lane.get("reliability"), 1.0)
                        * max(0.01, to_float(risk_mult.get("reliability"), 1.0)),
                        to_float(lane.get("reliability"), 1.0)
                        * max(0.01, to_float(risk_mult.get("reliability"), 1.0))
                        * max(0.01, to_float(risk_mult.get("quality_yield"), 1.0)),
                    ),
                )
                # Nominal lane reliability is known when the plan is built and
                # can legitimately be grossed up.  A temporary risk event may
                # instead represent a surprise short shipment or rejection.  In
                # that mode, do not let the MRP know and perfectly compensate the
                # incident on the same day.
                nominal_rel = max(
                    0.01,
                    min(1.0, to_float(lane.get("reliability"), 1.0)),
                )
                planning_rel = supplier_planning_reliability(
                    nominal_rel,
                    rel,
                    gross_up_temporary_risk_loss=economic_policy[
                        "supplier_risk_loss_gross_up"
                    ],
                )
                unconstrained_pull_qty = desired_delivered_qty / planning_rel
                standard_order_qty = max(0.0, to_float(lane.get("standard_order_qty"), 0.0))
                standard_order_binding = policy_pair_key(dst, item_id) not in nonbinding_standard_order_pair_keys
                physical_dispatch_multiple = max(
                    0.0,
                    to_float(lane.get("physical_dispatch_multiple"), 0.0),
                )
                max_feasible_qty = available
                shipment_uom = normalize_unit(item_unit_map.get(str(item_id), ""))
                if shipment_uom == "UN":
                    standard_order_qty = normalize_physical_quantity(
                        standard_order_qty,
                        shipment_uom,
                        rounding="nearest",
                    )
                    physical_dispatch_multiple = normalize_physical_quantity(
                        physical_dispatch_multiple,
                        shipment_uom,
                        rounding="nearest",
                    )
                    max_feasible_qty = normalize_physical_quantity(
                        max_feasible_qty,
                        shipment_uom,
                        rounding="down",
                    )
                supplier_backorder_extra_lead_days = 0
                if annual_external_backorder and available + 1e-9 < unconstrained_pull_qty:
                    ext_policy = estimated_source_policies.get(src_pair, {})
                    _base_ext_lead_days, ext_lead_days, _external_lead_basis = external_procurement_leads(
                        ext_policy,
                        risk_mult,
                    )
                    supplier_backorder_extra_lead_days = max(0, int(ext_lead_days))
                    max_feasible_qty = max(max_feasible_qty, unconstrained_pull_qty)
                supplier_capacity_left = supplier_daily_capacity_by_pair.get(src_pair)
                if supplier_capacity_left is not None:
                    control_capacity_multiplier = (
                        lane_control.capacity_multiplier
                        if lane_control is not None
                        else 1.0
                    )
                    supplier_capacity_left = max(
                        0.0,
                        supplier_capacity_left
                        * availability_mult
                        * max(0.0, to_float(risk_mult.get("capacity"), 1.0))
                        * control_capacity_multiplier
                        - supplier_capacity_used_today_by_src_pair[src_pair],
                    )
                    if supplier_backorder_extra_lead_days <= 0:
                        max_feasible_qty = min(max_feasible_qty, supplier_capacity_left)
                    if supplier_backorder_extra_lead_days <= 0 and supplier_capacity_left + 1e-9 < unconstrained_pull_qty:
                        supplier_capacity_binding_qty_today += unconstrained_pull_qty - max(0.0, supplier_capacity_left)
                constrained_pull_qty = min(
                    unconstrained_pull_qty,
                    max_feasible_qty,
                )
                pair_constrained_before_lot_qty += constrained_pull_qty
                if (
                    physical_dispatch_multiple > 1e-9
                    and max_feasible_qty + 1e-9 >= physical_dispatch_multiple
                    and source_mode == "lane_release"
                ):
                    # Consolidate an internal road movement only after MRP has
                    # created a real need. This rounds the physical release to a
                    # production-batch multiple without changing the MRP target,
                    # opening pipeline, or order-generation logic.
                    target_dispatches = max(
                        1,
                        int(
                            math.ceil(
                                (unconstrained_pull_qty / physical_dispatch_multiple)
                                - 1e-9
                            )
                        ),
                    )
                    feasible_dispatches = max(
                        1,
                        int(
                            math.floor(
                                (max_feasible_qty / physical_dispatch_multiple)
                                + 1e-9
                            )
                        ),
                    )
                    pull_qty = (
                        min(target_dispatches, feasible_dispatches)
                        * physical_dispatch_multiple
                    )
                else:
                    pull_qty = mrp_purchase_order_quantity(
                        unconstrained_pull_qty, max_feasible_qty, standard_order_qty,
                        binding=standard_order_binding, uom=shipment_uom,
                    )
                if shipment_uom == "UN":
                    pull_qty = normalize_physical_quantity(
                        pull_qty,
                        shipment_uom,
                        rounding="down",
                    )
                delivered_qty = pull_qty * rel
                if shipment_uom == "UN":
                    delivered_qty = min(
                        pull_qty,
                        normalize_physical_quantity(
                            delivered_qty,
                            shipment_uom,
                            rounding="nearest",
                        ),
                    )
                if pull_qty <= 1e-9 or delivered_qty <= 1e-9:
                    if lane_control is not None:
                        zero_flow_actions: list[str] = []
                        capacity_action = lane_control.action(
                            "capacity_multiplier"
                        )
                        if (
                            supplier_capacity_left is not None
                            and capacity_action.applied
                        ):
                            zero_flow_actions.append(
                                "capacity_multiplier"
                            )
                        if zero_flow_actions:
                            record_control_resolution(
                                lane_control,
                                stage="supplier_lane_execution",
                                action_names=tuple(zero_flow_actions),
                                status="applied_no_executable_flow",
                                executed_control_volume_qty=0.0,
                                extra={
                                    "edge_id": str(
                                        lane.get("edge_id") or ""
                                    ),
                                    "quantity_uom": item_unit_map.get(
                                        item_id,
                                        "",
                                    ),
                                    "q_lane_requested_qty": round(
                                        desired_delivered_qty,
                                        6,
                                    ),
                                    "q_before_constraints_qty": round(
                                        unconstrained_pull_qty,
                                        6,
                                    ),
                                    "q_after_constraints_qty": round(
                                        constrained_pull_qty,
                                        6,
                                    ),
                                    "q_after_lotification_qty": 0.0,
                                    "q_executable_qty": 0.0,
                                    "standard_order_qty": round(
                                        standard_order_qty,
                                        6,
                                    ),
                                    "capacity_controlled_remaining_qty": (
                                        round(
                                            supplier_capacity_left,
                                            6,
                                        )
                                        if supplier_capacity_left
                                        is not None
                                        else ""
                                    ),
                                    "binding_reason": (
                                        "lotification_or_capacity_zero"
                                    ),
                                },
                            )
                    return 0.0

                if supplier_backorder_extra_lead_days <= 0:
                    stock[src_pair] -= pull_qty
                    supplier_capacity_used_today_by_src_pair[src_pair] += pull_qty
                    supplier_shipped_from_stock_today_by_src_pair[src_pair] += delivered_qty
                lead_rng = paired_lane_rng(
                    measured_day=output_day,
                    lane=lane,
                    source_mode=source_mode,
                )
                transport_lead_days = sample_lead_days(
                    lane,
                    lead_rng,
                    args.stochastic_lead_times,
                    lead_time_distribution_mode,
                )
                transport_lead_days_before_quality = (
                    float(transport_lead_days)
                    * max(
                        0.05,
                        to_float(risk_mult.get("lead_time"), 1.0),
                    )
                    + max(
                        0.0,
                        to_float(
                            risk_mult.get("lead_time_extra_days"),
                            0.0,
                        ),
                    )
                )
                quality_delay_days = max(
                    0.0,
                    to_float(risk_mult.get("quality_delay"), 0.0),
                )
                delay_control_active = bool(
                    lane_control is not None
                    and (
                        lane_control.expedite_level > 1e-12
                        or lane_control.lead_time_adjustment_days != 0
                    )
                )
                transport_lead_days = compose_controlled_lane_lead_days(
                    transport_lead_days_before_quality=(
                        transport_lead_days_before_quality
                    ),
                    quality_delay_days=quality_delay_days,
                    expedite_level=(
                        lane_control.expedite_level
                        if lane_control is not None
                        else 0.0
                    ),
                    lead_time_adjustment_days=(
                        lane_control.lead_time_adjustment_days
                        if lane_control is not None
                        else 0
                    ),
                    delay_control_active=delay_control_active,
                )
                lead_days = int(transport_lead_days + supplier_backorder_extra_lead_days)
                lead_cover = (
                    lead_time_cover_days(lane, args.stochastic_lead_times, lead_time_distribution_mode)
                    + supplier_backorder_extra_lead_days
                )
                if lane_control is not None:
                    lead_cover = max(
                        1,
                        lead_cover
                        + lane_control.lead_time_adjustment_days
                        - int(
                            math.floor(
                                lane_control.expedite_level
                                * max(0, lead_cover - 1)
                            )
                        ),
                    )
                lead_reference = lead_time_reference_days(lane) + supplier_backorder_extra_lead_days
                order_frequency_days = max(1, int(round(max(1.0, to_float(lane.get("order_frequency_days"), 1.0)))))
                delivery_schedule: list[tuple[int, float, float]] = []
                if standard_order_binding and standard_order_qty > 1e-9 and pull_qty > standard_order_qty + 1e-9:
                    total_units = max(1, int(round(pull_qty / standard_order_qty)))
                    max_delivery_count = max(1, int(math.ceil(float(lead_cover) / float(order_frequency_days))))
                    delivery_count = min(total_units, max_delivery_count)
                    base_units = max(1, total_units // delivery_count)
                    remainder_units = total_units % delivery_count
                    latest_offset = max(0, int(lead_cover) - 1)
                    for idx in range(delivery_count):
                        units = base_units + (1 if idx < remainder_units else 0)
                        chunk_pull_qty = units * standard_order_qty
                        chunk_delivered_qty = chunk_pull_qty * rel
                        if shipment_uom == "UN":
                            chunk_delivered_qty = min(
                                chunk_pull_qty,
                                normalize_physical_quantity(
                                    chunk_delivered_qty,
                                    shipment_uom,
                                    rounding="nearest",
                                ),
                            )
                        if delivery_count > 1:
                            even_offset = int(round(idx * latest_offset / float(delivery_count - 1)))
                            cadence_offset = idx * order_frequency_days
                            delivery_offset = min(latest_offset, max(cadence_offset, even_offset))
                        else:
                            delivery_offset = 0
                        arrival_day = day + lead_days + delivery_offset
                        delivery_schedule.append((arrival_day, chunk_pull_qty, chunk_delivered_qty))
                else:
                    delivery_schedule.append((day + lead_days, pull_qty, delivered_qty))

                traced_delivery_schedule, supplier_shipment_sequence = _attach_shipment_trace_ids(
                    delivery_schedule,
                    start_sequence=supplier_shipment_sequence,
                    risk_event_ids=tuple(risk_mult.get("event_ids") or []),
                )
                for (
                    arrival_day,
                    chunk_pull_qty,
                    chunk_delivered_qty,
                    shipment_id,
                    risk_event_ids,
                ) in traced_delivery_schedule:
                    physical_release_day = int(arrival_day - transport_lead_days)
                    if args.supplier_state_dependent_risks and src_pair[0] in supplier_node_ids:
                        receipt_lead_observations.schedule(
                            arrival_day=arrival_day, departure_day=physical_release_day,
                            supplier_pair=src_pair, reference_days=lead_time_reference_days(lane),
                            quantity=chunk_delivered_qty,
                        )
                    departure_day_for_trace = int(physical_release_day - warmup_days)
                    arrival_day_for_trace = int(arrival_day - warmup_days)
                    mrp_order_id = next_mrp_order_identity(
                        source_mode=source_mode,
                        src_node_id=str(lane["src"]),
                        dst_node_id=str(dst),
                        item_id=str(item_id),
                    )
                    # Keep the transaction identity assigned to this delivery
                    # chunk. Route/date grouping can contain different items or
                    # risk decisions and is not the supplier-ledger join key.
                    handling_unit_id = ""
                    shipment_trace_status = (
                        "modeled_backorder_origin"
                        if supplier_backorder_extra_lead_days > 0
                        else "traced"
                    )
                    shipment_trace_reason = (
                        "supplier_source_batch_not_available_in_model"
                        if supplier_backorder_extra_lead_days > 0
                        else "supplier_delivery_chunk_not_confirmed_vehicle"
                    )
                    internal_truck_route = (
                        (
                            is_upstream_internal_site(str(lane["src"]))
                            or str(lane["src"]).startswith("M-")
                        )
                        and (
                            str(dst).startswith("M-")
                            or str(dst).startswith("DC-")
                        )
                    )
                    if internal_truck_route:
                        truck_estimate = estimate_internal_truck_handling(
                            item_id=str(item_id),
                            quantity=chunk_pull_qty,
                            uom=shipment_uom,
                            logistics_assumptions=LOT_TRACE_DEFAULT_LOGISTICS_ASSUMPTIONS,
                        )
                        if truck_estimate.handling_unit_kind:
                            handling_unit_id = (
                                f"{truck_estimate.handling_unit_kind}-{shipment_id}"
                                f"-N{truck_estimate.truck_count}"
                            )
                        shipment_trace_reason = truck_estimate.trace_note()
                    pipeline[arrival_day].append((dst, item_id, chunk_delivered_qty, lane["edge_id"]))
                    if pending_receipt_calendar is not None:
                        pending_receipt_calendar.add(pair, arrival_day, chunk_delivered_qty)
                    chunk_parent_allocations: list[dict[str, Any]] = []
                    if supplier_backorder_extra_lead_days <= 0:
                        reservation_precedes_departure = physical_release_day > day
                        chunk_parent_allocations = lot_ledger.consume(
                            day=output_day,
                            node_id=str(lane["src"]),
                            item_id=str(item_id),
                            qty=chunk_pull_qty,
                            event_type=(
                                "shipment_reserve"
                                if reservation_precedes_departure
                                else "lane_ship"
                            ),
                            source_id=str(lane["edge_id"]),
                            shipment_id=shipment_id,
                            risk_decision_day=output_day,
                            risk_event_ids=risk_event_ids,
                            uom=item_unit_map.get(str(item_id), ""),
                            departure_day=departure_day_for_trace,
                            arrival_day=arrival_day_for_trace,
                            handling_unit_id=handling_unit_id,
                            trace_status=shipment_trace_status,
                            trace_reason=shipment_trace_reason,
                            causal_event_ids=risk_mult.get("event_ids"),
                            causal_root_ids=risk_mult.get("causal_root_ids"),
                            planned_order_id=mrp_order_id,
                            baseline_reference_id=mrp_order_id,
                        )
                        if reservation_precedes_departure:
                            lot_departure_pipeline[physical_release_day].append(
                                {
                                    "src_node_id": str(lane["src"]),
                                    "item_id": str(item_id),
                                    "qty": chunk_pull_qty,
                                    "uom": item_unit_map.get(str(item_id), ""),
                                    "source_id": str(lane["edge_id"]),
                                    "parent_allocations": chunk_parent_allocations,
                                    "shipment_id": shipment_id,
                                    "risk_decision_day": output_day,
                                    "risk_event_ids": risk_event_ids,
                                    "arrival_day": arrival_day_for_trace,
                                    "handling_unit_id": handling_unit_id,
                                    "trace_status": shipment_trace_status,
                                    "trace_reason": shipment_trace_reason,
                                    "causal_event_ids": risk_mult.get("event_ids"),
                                    "causal_root_ids": risk_mult.get(
                                        "causal_root_ids"
                                    ),
                                    "planned_order_id": mrp_order_id,
                                    "baseline_reference_id": mrp_order_id,
                                    "materialize_backorder_origin": False,
                                }
                            )
                    else:
                        lot_departure_pipeline[physical_release_day].append(
                            {
                                "src_node_id": str(lane["src"]),
                                "item_id": str(item_id),
                                "qty": chunk_pull_qty,
                                "uom": item_unit_map.get(str(item_id), ""),
                                "source_id": str(lane["edge_id"]),
                                "parent_allocations": chunk_parent_allocations,
                                "shipment_id": shipment_id,
                                "risk_decision_day": output_day,
                                "risk_event_ids": risk_event_ids,
                                "arrival_day": arrival_day_for_trace,
                                "handling_unit_id": handling_unit_id,
                                "trace_status": shipment_trace_status,
                                "trace_reason": shipment_trace_reason,
                                "causal_event_ids": risk_mult.get("event_ids"),
                                "causal_root_ids": risk_mult.get(
                                    "causal_root_ids"
                                ),
                                "planned_order_id": mrp_order_id,
                                "baseline_reference_id": mrp_order_id,
                                "materialize_backorder_origin": True,
                            }
                        )
                    schedule_lot_arrival(
                        arrival_day=arrival_day,
                        departure_day=departure_day_for_trace,
                        dst_node_id=str(dst),
                        item_id=str(item_id),
                        qty=chunk_delivered_qty,
                        lane_id=str(lane["edge_id"]),
                        source_type="lane_receipt",
                        source_id=str(lane["edge_id"]),
                        shipment_id=shipment_id,
                        risk_decision_day=output_day,
                        risk_event_ids=risk_event_ids,
                        parent_allocations=chunk_parent_allocations,
                        link_type="transport",
                        notes=shipment_trace_reason,
                        handling_unit_id=handling_unit_id,
                        trace_status=shipment_trace_status,
                        trace_reason=shipment_trace_reason,
                        causal_event_ids=risk_mult.get("event_ids"),
                        causal_root_ids=risk_mult.get("causal_root_ids"),
                        planned_order_id=mrp_order_id,
                        baseline_reference_id=mrp_order_id,
                    )
                    register_mrp_order(
                        pair,
                        source_mode=source_mode,
                        src_node_id=str(lane["src"]),
                        dst_node_id=str(dst),
                        item_id=str(item_id),
                        release_qty=chunk_pull_qty,
                        receipt_qty=chunk_delivered_qty,
                        arrival_day=arrival_day,
                        safety_time_days=pair_mrp_safety_time_days.get(pair, 0.0),
                        lead_days=lead_days,
                        lead_cover_days=lead_cover,
                        lead_reference_days=lead_reference,
                        edge_id=str(lane["edge_id"]),
                        reliability=rel,
                        standard_order_qty=standard_order_qty,
                        mrp_share=to_float(lane.get("mrp_share"), 0.0),
                        physical_release_day=physical_release_day,
                        source_inventory_reserved=supplier_backorder_extra_lead_days <= 0,
                        mrp_order_id=mrp_order_id,
                        shipment_id=shipment_id,
                        causal_event_ids=risk_mult.get("event_ids"),
                        causal_root_ids=risk_mult.get("causal_root_ids"),
                    )
                in_transit[pair] += delivered_qty
                if record_day:
                    for (
                        arrival_day,
                        chunk_pull_qty,
                        chunk_delivered_qty,
                        shipment_id,
                        risk_event_ids,
                    ) in traced_delivery_schedule:
                        physical_release_day = int(arrival_day - transport_lead_days)
                        is_opening_open_order_cost = source_mode.startswith("opening_")
                        chunk_transport_cost, transport_cost_basis, transport_cost_units = lane_transport_cost_for_chunk(
                            lane,
                            str(item_id),
                            chunk_pull_qty,
                            chunk_delivered_qty,
                        )
                        chunk_transport_cost *= max(0.0, to_float(risk_mult.get("transport_cost"), 1.0))
                        if lane_control is not None:
                            chunk_transport_cost *= (
                                1.0
                                + 1.5
                                * lane_control.expedite_level
                            )
                        chunk_purchase_cost = (
                            chunk_delivered_qty
                            * lane["unit_purchase_cost"]
                            * max(0.0, to_float(risk_mult.get("purchase_cost"), 1.0))
                        )
                        chunk_loss = max(0.0, chunk_pull_qty - chunk_delivered_qty)
                        supplier_released_today_by_src_pair[src_pair] += chunk_pull_qty
                        supplier_loss_today_by_src_pair[src_pair] += chunk_loss
                        if physical_release_day <= day:
                            shipped_today += chunk_delivered_qty
                            shipped_today_to_pair[(dst, item_id)] += chunk_delivered_qty
                            transport_cost_today += chunk_transport_cost
                            purchase_cost_today += chunk_purchase_cost
                            total_unreliable_loss_qty += chunk_loss
                            if is_opening_open_order_cost:
                                opening_transport_cost_today += chunk_transport_cost
                                opening_purchase_cost_today += chunk_purchase_cost
                        else:
                            scheduled_lane_release_metrics[physical_release_day].append(
                                (
                                    (dst, item_id),
                                    chunk_delivered_qty,
                                    chunk_transport_cost,
                                    chunk_purchase_cost,
                                    chunk_loss,
                                    is_opening_open_order_cost,
                                )
                            )
                        supplier_shipment_rows.append(
                            {
                                "day": int(physical_release_day - warmup_days),
                                "shipment_id": shipment_id,
                                "risk_decision_day": int(output_day),
                                "risk_event_ids": risk_event_ids,
                                "src_node_id": str(lane["src"]),
                                "dst_node_id": str(dst),
                                "item_id": str(item_id),
                                "edge_id": str(lane["edge_id"]),
                                "shipped_qty": round(chunk_delivered_qty, 6),
                                "pulled_qty": round(chunk_pull_qty, 6),
                                "lead_days": int(transport_lead_days),
                                "arrival_day": int(arrival_day - warmup_days),
                                "reliability": round(rel, 6),
                                "uom": item_unit_map.get(item_id, ""),
                                "transport_cost_basis": transport_cost_basis,
                                "source_inventory_reserved": int(supplier_backorder_extra_lead_days <= 0),
                                "transport_cost_units": round(transport_cost_units, 6),
                                "transport_cost": round(chunk_transport_cost, 6),
                                "purchase_cost": round(chunk_purchase_cost, 6),
                            }
                        )
                if lane_control is not None:
                    executed_lane_actions: list[str] = []
                    capacity_action = lane_control.action(
                        "capacity_multiplier"
                    )
                    if (
                        supplier_capacity_left is not None
                        and capacity_action.applied
                    ):
                        executed_lane_actions.append(
                            "capacity_multiplier"
                        )
                    for action_name in (
                        "expedite_level",
                        "lead_time_adjustment_days",
                    ):
                        if lane_control.action(action_name).applied:
                            executed_lane_actions.append(action_name)
                    record_control_resolution(
                        lane_control,
                        stage="supplier_lane_execution",
                        action_names=tuple(executed_lane_actions),
                        executed_control_volume_qty=delivered_qty,
                        extra={
                            "edge_id": str(lane.get("edge_id") or ""),
                            "quantity_uom": item_unit_map.get(item_id, ""),
                            "q_lane_requested_qty": round(
                                desired_delivered_qty,
                                6,
                            ),
                            "q_before_constraints_qty": round(
                                unconstrained_pull_qty,
                                6,
                            ),
                            "q_after_constraints_qty": round(
                                constrained_pull_qty,
                                6,
                            ),
                            "q_after_lotification_qty": round(
                                pull_qty,
                                6,
                            ),
                            "q_executable_qty": round(
                                delivered_qty,
                                6,
                            ),
                            "standard_order_qty": round(
                                standard_order_qty,
                                6,
                            ),
                            "capacity_controlled_remaining_qty": (
                                round(supplier_capacity_left, 6)
                                if supplier_capacity_left is not None
                                else ""
                            ),
                            "lead_reference_days": int(lead_reference),
                            "lead_effective_days": int(lead_days),
                            "binding_reason": (
                                "supplier_stock_or_capacity"
                                if pull_qty + 1e-9
                                < unconstrained_pull_qty
                                else "none"
                            ),
                        },
                    )
                return delivered_qty

            remaining = max(0.0, needed)
            if (
                has_regular_need
                and active_share_total > 1e-9
                and len(eligible_active_lanes) > 1
            ):
                for (
                    lane,
                    availability_mult,
                    risk_mult,
                    lane_control,
                ) in eligible_active_lanes:
                    if remaining <= 1e-9:
                        break
                    lane_share = allocation_weights[id(lane)]
                    lane_target_qty = needed * lane_share / active_share_total
                    remaining -= try_ship_lane(
                        lane,
                        availability_mult,
                        risk_mult,
                        lane_control,
                        desired_delivered_qty=min(remaining, lane_target_qty),
                        remaining_need_qty=remaining,
                    )

            if has_regular_need:
                for (
                    lane,
                    availability_mult,
                    risk_mult,
                    lane_control,
                ) in eligible_active_lanes:
                    if remaining <= 1e-9:
                        break
                    remaining -= try_ship_lane(
                        lane,
                        availability_mult,
                        risk_mult,
                        lane_control,
                        desired_delivered_qty=remaining,
                        remaining_need_qty=remaining,
                    )

            for lane, availability_mult, risk_mult, lane_control in annual_min_lot_lanes:
                edge_id = str(lane.get("edge_id") or "")
                output_day_nonnegative = max(0, int(output_day))
                year_idx = output_day_nonnegative // 365
                if not edge_id or (year_idx, edge_id) in mrp_multisource_annual_lane_orders:
                    continue
                standard_order_qty = max(0.0, to_float(lane.get("standard_order_qty"), 0.0))
                if standard_order_qty <= 1e-9:
                    continue
                try_ship_lane(
                    lane,
                    availability_mult,
                    risk_mult,
                    lane_control,
                    desired_delivered_qty=standard_order_qty,
                    remaining_need_qty=standard_order_qty,
                    source_mode="lane_release_min_annual_lot",
                )
            if pair_control is not None:
                pair_release_qty = max(
                    0.0,
                    planned_release_today_by_pair.get(pair, 0.0),
                )
                pair_receipt_qty = max(
                    0.0,
                    planned_receipt_today_by_pair.get(pair, 0.0),
                )
                record_control_resolution(
                    pair_control,
                    # The audit row is emitted after executable quantities are
                    # known, but the control itself was applied to ``needed``
                    # before lane constraints and lotification.
                    stage="mrp_order_control_before_constraints",
                    action_names=(
                        "order_multiplier",
                        "safety_stock_multiplier",
                    ),
                    status=(
                        "applied"
                        if pair_receipt_qty > 1e-9
                        else "no_executable_order"
                    ),
                    executed_control_volume_qty=pair_receipt_qty,
                    extra={
                        "quantity_uom": item_unit_map.get(item_id, ""),
                        "q_mrp_base_qty": round(q_mrp_base_qty, 6),
                        "q_after_safety_stock_control_qty": round(
                            q_after_safety_stock_control_qty,
                            6,
                        ),
                        "q_after_control_qty": round(
                            q_after_control_qty,
                            6,
                        ),
                        "q_after_supplier_control_qty": round(
                            q_after_supplier_control_qty,
                            6,
                        ),
                        "q_after_constraints_qty": round(
                            pair_constrained_before_lot_qty,
                            6,
                        ),
                        "q_after_lotification_qty": round(
                            pair_release_qty,
                            6,
                        ),
                        "q_executable_qty": round(
                            pair_receipt_qty,
                            6,
                        ),
                        "target_stock_controlled_qty": round(
                            target,
                            6,
                        ),
                        "explicit_safety_stock_base_qty": round(
                            explicit_safety_stock_base_qty,
                            6,
                        ),
                        "explicit_safety_stock_controlled_qty": round(
                            explicit_safety_stock_qty,
                            6,
                        ),
                        "binding_reason": (
                            "stock_capacity_or_lot"
                            if remaining > 1e-9
                            else "none"
                        ),
                    },
                )

        if record_day:
            total_shipped += shipped_today
            total_transport_cost += transport_cost_today
            total_purchase_cost += purchase_cost_today
            total_external_procured += external_procured_today
            total_external_procured_rejected += external_procured_rejected_today
            total_external_quality_rejected += external_quality_rejected_today
            total_supplier_capacity_binding_qty += supplier_capacity_binding_qty_today
            for node_id, item_id in production_input_pairs:
                input_shipment_rows.append(
                    {
                        "day": output_day,
                        "node_id": node_id,
                        "item_id": item_id,
                        "shipped_to_node_qty": round(shipped_today_to_pair[(node_id, item_id)], 6),
                        "uom": item_unit_map.get(item_id, ""),
                    }
                )
            for src_pair, nominal_cap in supplier_daily_capacity_by_pair.items():
                src, item_id = src_pair
                supplier_control = resolve_daily_control(
                    node_id=src,
                    supplier_id=src,
                    item_id=item_id,
                )
                supplier_control_capacity = (
                    supplier_control.capacity_multiplier
                    if supplier_control is not None
                    else 1.0
                )
                used_qty = supplier_capacity_used_today_by_src_pair.get(src_pair, 0.0)
                capacity_multipliers_today: list[float] = []
                for cap_lane in lanes_by_src_item.get(src_pair, []):
                    cap_risk = supplier_risk_multipliers_for_lane(supplier_risk_events_today, cap_lane, output_day)
                    if cap_risk.get("event_ids"):
                        capacity_multipliers_today.append(
                            max(0.0, to_float(cap_risk.get("capacity"), 1.0))
                            * max(0.0, to_float(cap_risk.get("availability"), 1.0))
                        )
                effective_cap_today = (
                    nominal_cap
                    * min(capacity_multipliers_today or [1.0])
                    * supplier_control_capacity
                )
                supplier_capacity_daily_rows.append(
                    {
                        "day": output_day,
                        "node_id": src,
                        "item_id": item_id,
                        "capacity_qty_per_day": round(effective_cap_today, 6),
                        "used_qty": round(used_qty, 6),
                        "remaining_capacity_qty": round(max(0.0, effective_cap_today - used_qty), 6),
                        "utilization": round(used_qty / effective_cap_today, 6) if effective_cap_today > 1e-9 else 0.0,
                    }
                )
                if supplier_control is not None:
                    record_control_resolution(
                        supplier_control,
                        stage="supplier_capacity",
                        action_names=("capacity_multiplier",),
                        executed_control_volume_qty=used_qty,
                        extra={
                            "quantity_uom": item_unit_map.get(item_id, ""),
                            "capacity_base_qty_per_day": round(
                                nominal_cap,
                                6,
                            ),
                            "capacity_controlled_qty_per_day": round(
                                effective_cap_today,
                                6,
                            ),
                            "capacity_used_qty": round(used_qty, 6),
                            "binding_reason": (
                                "supplier_capacity"
                                if effective_cap_today > 1e-9
                                and used_qty + 1e-9
                                >= effective_cap_today
                                else "none"
                            ),
                        },
                    )
                if args.supplier_state_dependent_risks:
                    utilization = used_qty / effective_cap_today if effective_cap_today > 1e-9 else 0.0
                    update_state_risk_counter_and_register(
                        trigger_day=output_day,
                        supplier_id=src,
                        item_id=item_id,
                        counter_family="capacity_watch",
                        risk_family="capacity",
                        risk_type="capacity",
                        multiplier=0.97,
                        trigger_metric="capacity_utilization_above_75pct",
                        trigger_value=utilization,
                        threshold=0.75,
                        triggered=utilization > 0.75,
                        required_consecutive_days=5,
                        effect="Capacite fournisseur x0.97 pendant 7 jours",
                        notes=(
                            "Alerte capacite: declenche quand l'utilisation capacite fournisseur "
                            "depasse 75% pendant 5 jours consecutifs."
                        ),
                        duration_days=7,
                        cooldown_days=21,
                    )
                    update_state_risk_counter_and_register(
                        trigger_day=output_day,
                        supplier_id=src,
                        item_id=item_id,
                        counter_family="capacity_full_day",
                        risk_family="capacity",
                        risk_type="capacity",
                        multiplier=0.92,
                        trigger_metric="capacity_utilization_full_day",
                        trigger_value=utilization,
                        threshold=0.995,
                        triggered=utilization >= 0.995,
                        required_consecutive_days=1,
                        effect="Capacite fournisseur x0.92 pendant 7 jours",
                        notes=(
                            "Alerte capacite ponctuelle: declenche quand la capacite disponible "
                            "est consommee a 100% sur une journee observee."
                        ),
                        duration_days=7,
                        cooldown_days=21,
                    )
                    update_state_risk_counter_and_register(
                        trigger_day=output_day,
                        supplier_id=src,
                        item_id=item_id,
                        counter_family="capacity_tension",
                        risk_family="capacity",
                        risk_type="capacity",
                        multiplier=0.90,
                        trigger_metric="capacity_utilization_above_85pct",
                        trigger_value=utilization,
                        threshold=0.85,
                        triggered=utilization > 0.85,
                        required_consecutive_days=3,
                        effect="Capacite fournisseur x0.90 pendant 14 jours",
                        notes=(
                            "Tension capacite: declenche quand l'utilisation capacite fournisseur "
                            "depasse 85% pendant 3 jours consecutifs."
                        ),
                    )
                    update_state_risk_counter_and_register(
                        trigger_day=output_day,
                        supplier_id=src,
                        item_id=item_id,
                        counter_family="capacity_saturation",
                        risk_family="capacity",
                        risk_type="capacity",
                        multiplier=0.85,
                        trigger_metric="capacity_utilization_above_90pct",
                        trigger_value=utilization,
                        threshold=0.90,
                        triggered=utilization > 0.90,
                        required_consecutive_days=3,
                        effect="Capacite fournisseur x0.85 pendant 14 jours",
                        notes=(
                            "Risque capacite actif: declenche quand l'utilisation capacite fournisseur "
                            "depasse 90% pendant 3 jours consecutifs."
                        ),
                    )

            if args.supplier_state_dependent_risks:
                for src_pair, observations in supplier_state_lead_observations_today_by_pair.items():
                    if not observations:
                        continue
                    max_ratio = max(
                        lead_days / max(1.0, reference_days)
                        for lead_days, reference_days in observations
                    )
                    update_state_risk_counter_and_register(
                        trigger_day=output_day,
                        supplier_id=src_pair[0],
                        item_id=src_pair[1],
                        counter_family="lead_watch",
                        risk_family="lead",
                        risk_type="lead_time",
                        multiplier=1.10,
                        trigger_metric="observed_lead_ratio_above_110pct",
                        trigger_value=max_ratio,
                        threshold=1.10,
                        triggered=max_ratio > 1.10,
                        required_consecutive_days=3,
                        effect="Delai fournisseur x1.10 pendant 7 jours",
                        notes=(
                            "Alerte delai: declenche quand le delai observe depasse 110% "
                            "du delai prevu pendant 3 jours observes."
                        ),
                        duration_days=7,
                        cooldown_days=21,
                    )
                    update_state_risk_counter_and_register(
                        trigger_day=output_day,
                        supplier_id=src_pair[0],
                        item_id=src_pair[1],
                        counter_family="lead_tension",
                        risk_family="lead",
                        risk_type="lead_time_extra_days",
                        multiplier=3.0,
                        trigger_metric="observed_lead_ratio_above_125pct",
                        trigger_value=max_ratio,
                        threshold=1.25,
                        triggered=max_ratio > 1.25,
                        required_consecutive_days=2,
                        effect="Delai fournisseur +3 jours pendant 14 jours",
                        notes=(
                            "Tension delai: declenche quand le delai observe depasse 125% "
                            "du delai prevu pendant 2 jours observes."
                        ),
                    )
                    update_state_risk_counter_and_register(
                        trigger_day=output_day,
                        supplier_id=src_pair[0],
                        item_id=src_pair[1],
                        counter_family="lead_late",
                        risk_family="lead",
                        risk_type="lead_time_extra_days",
                        multiplier=5.0,
                        trigger_metric="observed_lead_ratio_above_135pct",
                        trigger_value=max_ratio,
                        threshold=1.35,
                        triggered=max_ratio > 1.35,
                        required_consecutive_days=2,
                        effect="Delai fournisseur +5 jours pendant 14 jours",
                        notes=(
                            "Risque delai actif: declenche quand le delai observe depasse 135% "
                            "du delai prevu pendant 2 jours observes."
                        ),
                    )

            if args.supplier_state_dependent_risks:
                for src_pair in supplier_stock_pairs:
                    desired_upstream = max(0.0, external_desired_today_by_src_pair.get(src_pair, 0.0))
                    rejected_upstream = max(0.0, external_rejected_today_by_src_pair.get(src_pair, 0.0))
                    upstream_rejection_ratio_daily = rejected_upstream / desired_upstream if desired_upstream > 1e-9 else 0.0
                    upstream_rejection_avg_7d = update_state_risk_metric_window(
                        ("upstream_rejection_7d", src_pair[0], src_pair[1]),
                        upstream_rejection_ratio_daily,
                        7,
                    )
                    upstream_rejection_avg_14d = update_state_risk_metric_window(
                        ("upstream_rejection_14d", src_pair[0], src_pair[1]),
                        upstream_rejection_ratio_daily,
                        14,
                    )
                    stock_cover_for_gate = supplier_state_stock_cover_today_by_pair.get(src_pair, math.inf)
                    stock_no_long_cover = stock_cover_for_gate < 7.0
                    stock_critical = stock_cover_for_gate < 3.0
                    update_state_risk_counter_and_register(
                        trigger_day=output_day,
                        supplier_id=src_pair[0],
                        item_id=src_pair[1],
                        counter_family="upstream_rejection_watch",
                        risk_family="upstream",
                        risk_type="external_availability",
                        multiplier=0.97,
                        trigger_metric="upstream_rejection_avg_7d_above_10pct_with_stock_cover_below_7d",
                        trigger_value=upstream_rejection_avg_7d,
                        threshold=0.10,
                        triggered=upstream_rejection_avg_7d > 0.10 and stock_no_long_cover,
                        required_consecutive_days=2,
                        effect="Appro amont fournisseur disponibilite x0.97 pendant 7 jours",
                        notes=(
                            "Alerte appro amont persistante: declenche quand le rejet amont moyen "
                            "7 jours depasse 10% et que le stock fournisseur couvre moins de 7 jours."
                        ),
                        duration_days=7,
                        cooldown_days=21,
                    )
                    update_state_risk_counter_and_register(
                        trigger_day=output_day,
                        supplier_id=src_pair[0],
                        item_id=src_pair[1],
                        counter_family="upstream_rejection_blocked",
                        risk_family="upstream",
                        risk_type="external_capacity",
                        multiplier=0.90,
                        trigger_metric="upstream_rejection_avg_14d_above_50pct_with_stock_cover_below_3d",
                        trigger_value=upstream_rejection_avg_14d,
                        threshold=0.50,
                        triggered=upstream_rejection_avg_14d > 0.50 and stock_critical,
                        required_consecutive_days=1,
                        effect="Appro amont fournisseur capacite x0.90 pendant 14 jours",
                        notes=(
                            "Risque appro amont severise: declenche quand le rejet amont moyen "
                            "14 jours depasse 50% et que le stock fournisseur couvre moins de 3 jours."
                        ),
                    )
                    upstream_cost_ratio = max(0.0, external_cost_ratio_today_by_src_pair.get(src_pair, 0.0))
                    update_state_risk_counter_and_register(
                        trigger_day=output_day,
                        supplier_id=src_pair[0],
                        item_id=src_pair[1],
                        counter_family="upstream_cost",
                        risk_family="cost",
                        risk_type="external_cost",
                        multiplier=1.10,
                        trigger_metric="upstream_recourse_cost_ratio_above_250pct",
                        trigger_value=upstream_cost_ratio,
                        threshold=2.50,
                        triggered=upstream_cost_ratio > 2.50 and desired_upstream > 1e-9,
                        required_consecutive_days=3,
                        effect="Cout de recours amont x1.10 pendant 14 jours",
                        notes=(
                            "Cout de recours amont: declenche quand le cout unitaire amont observe "
                            "depasse 250% du prix fournisseur de reference pendant 3 jours. "
                            "C'est un cout de secours, pas un risque physique fournisseur."
                        ),
                    )

                    released_qty = max(0.0, supplier_released_today_by_src_pair.get(src_pair, 0.0))
                    lost_qty = max(0.0, supplier_loss_today_by_src_pair.get(src_pair, 0.0))
                    loss_rate = lost_qty / released_qty if released_qty > 1e-9 else 0.0
                    update_state_risk_counter_and_register(
                        trigger_day=output_day,
                        supplier_id=src_pair[0],
                        item_id=src_pair[1],
                        counter_family="reliability_loss",
                        risk_family="reliability",
                        risk_type="reliability",
                        multiplier=0.95,
                        trigger_metric="delivery_loss_rate_above_3pct",
                        trigger_value=loss_rate,
                        threshold=0.03,
                        triggered=loss_rate > 0.03,
                        required_consecutive_days=2,
                        effect="Fiabilite de livraison x0.95 pendant 14 jours",
                        notes=(
                            "Alerte fiabilite: declenche quand plus de 3% de la quantite "
                            "appelee n'est pas livree pendant 2 jours observes."
                        ),
                    )
                    update_state_risk_counter_and_register(
                        trigger_day=output_day,
                        supplier_id=src_pair[0],
                        item_id=src_pair[1],
                        counter_family="quality_loss",
                        risk_family="quality",
                        risk_type="quality_yield",
                        multiplier=0.90,
                        trigger_metric="delivery_loss_rate_above_8pct",
                        trigger_value=loss_rate,
                        threshold=0.08,
                        triggered=loss_rate > 0.08,
                        required_consecutive_days=1,
                        effect="Rendement qualite reception x0.90 pendant 14 jours",
                        notes=(
                            "Risque qualite: declenche quand plus de 8% de la quantite appelee "
                            "est perdue a la livraison sur une journee observee."
                        ),
                    )

            if dated_component_planning:
                for planned_pair, decision in dated_plan_decisions.items():
                    decision["dated_released_executed_qty"] = planned_receipt_today_by_pair.get(planned_pair, 0.0) if planned_pair in dated_action_pairs else 0.0
                    dated_plan_daily_rows.append({"day": output_day, "node_id": planned_pair[0], "item_id": planned_pair[1],
                        "uom": item_unit_map.get(planned_pair[1], ""),
                        "action_scope": "component_procurement" if planned_pair in dated_action_pairs else "planning_only_SD_execution_preserved",
                        **{key: round(value, 6) if isinstance(value, float) else value for key, value in decision.items()}})
            for pair in mrp_trace_pairs:
                trace_control = resolve_daily_control(
                    node_id=pair[0],
                    item_id=pair[1],
                    dst_node_id=pair[0],
                )
                trace_safety_multiplier = (
                    trace_control.safety_stock_multiplier
                    if trace_control is not None
                    else 1.0
                )
                trace_order_multiplier = (
                    trace_control.order_multiplier
                    if trace_control is not None
                    else 1.0
                )
                pair_is_upstream_factory_mrp = pair[0] in process_node_ids and pair not in demand_pairs
                pair_review_period_days = mrp_review_period_days if pair_is_upstream_factory_mrp else review_period_days
                item_daily_req_static = max(0.0, required_daily_input_by_pair.get(pair, 0.0))
                item_daily_req_dynamic = max(0.0, propagated_demand_today.get(pair, 0.0))
                item_daily_req_raw_dynamic = max(0.0, raw_propagated_demand_today.get(pair, 0.0))
                if static_requirement_for_pair(pair):
                    item_daily_req = item_daily_req_static
                    gross_requirement_basis = "static_requirement_override" if item_daily_req_static > 1e-9 else "none"
                elif item_daily_req_dynamic > 1e-9:
                    item_daily_req = item_daily_req_dynamic
                    if mrp_demand_signal_source == "mps_lotified":
                        gross_requirement_basis = (
                            f"mps_lotified_{mrp_signal_smoothing_days}d_avg"
                            if mrp_signal_smoothing_days > 1
                            else "mps_lotified"
                        )
                    else:
                        gross_requirement_basis = (
                            f"propagated_demand_{mrp_signal_smoothing_days}d_avg"
                            if mrp_signal_smoothing_days > 1
                            else "propagated_demand"
                        )
                elif (
                    initialization_policy["use_bom_demand_signal_for_mrp"]
                    and not initialization_policy["mrp_static_fallback_for_propagated_pairs"]
                    and pair in propagated_mrp_signal_pairs
                ):
                    item_daily_req = 0.0
                    gross_requirement_basis = "propagated_demand_zero"
                else:
                    item_daily_req = item_daily_req_static
                    gross_requirement_basis = "static_requirement" if item_daily_req_static > 1e-9 else "none"
                target_daily_req, target_floor_req, target_window_days, effective_cover_days = mrp_target_requirement_for_pair(
                    pair,
                    item_daily_req,
                    pair_review_period_days,
                )
                strict_safety_floor = initialization_policy["mrp_strict_safety_floor_from_safety_time"]
                operational_base_floor_qty = (
                    0.0
                    if strict_safety_floor
                    else max(base_stock.get(pair, 0.0), 0.0) * base_stock_floor_factor_for_pair(pair)
                )
                explicit_safety_stock_qty = (
                    max(
                        0.0,
                        pair_mrp_safety_stock_qty.get(pair, 0.0),
                    )
                    * trace_safety_multiplier
                )
                safety_floor_qty = explicit_safety_stock_qty
                soft_safety_target_qty = explicit_safety_stock_qty
                coverage_target_qty = 0.0
                if target_daily_req > 0.0:
                    safety_time_floor_qty = target_daily_req * max(
                        0.0,
                        pair_mrp_safety_time_days.get(pair, 0.0),
                    ) * trace_safety_multiplier
                    safety_floor_qty = max(explicit_safety_stock_qty, safety_time_floor_qty)
                    soft_safety_target_qty = max(
                        explicit_safety_stock_qty,
                        safety_time_floor_qty * soft_safety_factor_for_pair(pair),
                    )
                    coverage_target_qty = max(
                        coverage_target_qty,
                        safety_stock_days
                        * target_daily_req
                        * trace_safety_multiplier,
                    )
                    if pair in demand_pairs and demand_stock_target_days > 0.0:
                        coverage_target_qty = max(coverage_target_qty, demand_stock_target_days * target_daily_req)
                    if pair not in mrp_snapshot_pairs or dynamic_requirement_for_pair(pair):
                        coverage_target_qty = max(
                            coverage_target_qty,
                            target_daily_req * effective_cover_days,
                        )
                target_stock_qty = max(
                    operational_base_floor_qty,
                    soft_safety_target_qty,
                    coverage_target_qty,
                )
                target_display_floor_req = target_floor_req
                target_display_daily_req = target_daily_req
                target_display_stock_qty = target_stock_qty
                if mrp_target_cutover_context_days > 0:
                    target_display_floor_req = max(
                        0.0,
                        mrp_target_demand_floor_by_pair(
                            mrp_target_profile_day,
                            target_window_days,
                            include_cutover_context=True,
                        ).get(pair, 0.0),
                    )
                    target_display_daily_req = max(max(0.0, item_daily_req), target_display_floor_req)
                    display_soft_safety_target_qty = explicit_safety_stock_qty
                    display_coverage_target_qty = 0.0
                    if target_display_daily_req > 0.0:
                        display_safety_time_floor_qty = target_display_daily_req * max(
                            0.0,
                            pair_mrp_safety_time_days.get(pair, 0.0),
                        ) * trace_safety_multiplier
                        display_soft_safety_target_qty = max(
                            explicit_safety_stock_qty,
                            display_safety_time_floor_qty * soft_safety_factor_for_pair(pair),
                        )
                        display_coverage_target_qty = max(
                            display_coverage_target_qty,
                            safety_stock_days
                            * target_display_daily_req
                            * trace_safety_multiplier,
                        )
                        if pair in demand_pairs and demand_stock_target_days > 0.0:
                            display_coverage_target_qty = max(
                                display_coverage_target_qty,
                                demand_stock_target_days * target_display_daily_req,
                            )
                        if pair not in mrp_snapshot_pairs or dynamic_requirement_for_pair(pair):
                            display_coverage_target_qty = max(
                                display_coverage_target_qty,
                                target_display_daily_req * effective_cover_days,
                            )
                    target_display_stock_qty = max(
                        operational_base_floor_qty,
                        display_soft_safety_target_qty,
                        display_coverage_target_qty,
                    )
                backlog_target_qty = max(0.0, backlog.get(pair, 0.0))
                target_with_backlog_qty = target_stock_qty + backlog_target_qty
                recv_prev_today_qty = (
                    arrivals_today_by_pair.get(pair, 0.0)
                    + external_arrivals_today_by_pair.get(pair, 0.0)
                    + estimated_source_arrivals_today_by_pair.get(pair, 0.0)
                )
                recv_prev_future_qty = (
                    max(0.0, in_transit.get(pair, 0.0))
                    + max(0.0, external_in_transit.get(pair, 0.0))
                    + max(0.0, estimated_source_in_transit.get(pair, 0.0))
                )
                stock_proj_qty = max(0.0, stock.get(pair, 0.0))
                inventory_position_qty = stock_proj_qty + recv_prev_future_qty
                pair_uses_dated_receipts = pending_receipt_calendar is not None and pair in lanes_by_dest_item
                dated_receipt_trace: dict[str, Any] = {}
                if pending_receipt_calendar is not None:
                    # The new scope is transport replenishment only. Supplier
                    # source buffers keep their historical separate controllers.
                    receipt_cover_end_day = mrp_receipt_cover_end_day(day, target_window_days)
                    retained_receipts = (
                        pending_receipt_calendar.quantity(pair, decision_day=day, through_day=receipt_cover_end_day)
                        if pair_uses_dated_receipts else recv_prev_future_qty
                    )
                    if pair_uses_dated_receipts:
                        inventory_position_qty = stock_proj_qty + retained_receipts
                    dated_receipt_trace = {
                        "mrp_receipt_netting_mode": "within_cover" if pair_uses_dated_receipts else "all_future",
                        "mrp_receipt_netting_scope": "transport_replenishment" if pair_uses_dated_receipts else "outside_transport_replenishment",
                        "receipt_cover_end_day": receipt_cover_end_day - warmup_days if pair_uses_dated_receipts else "",
                        "recv_prev_within_cover_qty": round(retained_receipts, 6),
                        "recv_prev_after_cover_qty": round(max(0.0, recv_prev_future_qty - retained_receipts), 6),
                        **{field: "" for field in MRP_DATED_RECEIPT_FIELDS if field.startswith("decision_")},
                        **dated_receipt_decisions.get(pair, {}),
                    }
                held_release_cover_qty = 0.0
                if initial_stock_availability is not None:
                    held_release_cover_qty = initial_stock_availability.planning_quantity(
                        pair, decision_day=output_day,
                        through_day=output_day + max(0, int(target_window_days) - 1),
                    )
                    inventory_position_qty += held_release_cover_qty
                bb_backlog_qty = backlog_start_of_day_by_pair.get(pair, 0.0)
                bb_qty = item_daily_req + bb_backlog_qty
                bn_qty = max(0.0, target_with_backlog_qty - inventory_position_qty)
                if initialization_policy["mrp_enforce_physical_safety_floor"]:
                    if pair_uses_dated_receipts or (explicit_safety_stock_qty > 0.0 and pair_mrp_safety_time_days.get(pair, 0.0) <= 0.0):
                        bn_qty = max(0.0, bn_qty, soft_safety_target_qty - inventory_position_qty)
                    else:
                        bn_qty = max(0.0, bn_qty, soft_safety_target_qty - stock_proj_qty)
                controlled_bn_qty = max(
                    0.0,
                    bn_qty * trace_order_multiplier,
                )
                arrival_min_day = planned_receipt_min_day_by_pair.get(pair)
                arrival_max_day = planned_receipt_max_day_by_pair.get(pair)
                forecast_trace: dict[str, Any] = {}
                if mrp_source_forecasts is not None:
                    selected_vintage = mrp_source_forecasts.selection(output_day)
                    forecast_trace = {field: "" for field in MRP_SOURCE_FORECAST_FIELDS}
                    forecast_trace["mrp_forecast_source"] = "source"
                    if selected_vintage is not None:
                        vintage, cycle = selected_vintage
                        forecast_trace["mrp_forecast_vintage_day"] = vintage + cycle * mrp_source_forecasts.repeat_period_days
                        forecast_trace["mrp_forecast_cycle_index"] = cycle
                    # A PF forecast is not a directly observed component need.
                    # Coverage counts apply only to that finished-good item;
                    # component rows retain their propagated/MPS signal above.
                    forecast_pair = forecast_demand_pair_by_item.get(pair[1])
                    if forecast_pair is not None:
                        forecast_window_days = max(target_window_days, mrp_signal_smoothing_days)
                        forecast_qty, forecast_audit = planning_forecast_window(
                            forecast_pair, decision_day=output_day, target_day=mrp_target_profile_day,
                            window_days=forecast_window_days,
                        )
                        forecast_trace.update({
                            "mrp_forecast_window_days": forecast_window_days,
                            "mrp_forecast_source_days": forecast_audit["source_days"],
                            "mrp_forecast_fallback_days": forecast_audit["fallback_days"],
                            "mrp_forecast_daily_qty": round(forecast_qty, 6),
                            "mrp_forecast_source_rows": forecast_audit["source_rows"],
                        })
                mrp_trace_rows.append(
                    {
                        "day": output_day,
                        "node_id": pair[0],
                        "item_id": pair[1],
                        "bb_qty": round(bb_qty, 6),
                        "bb_demand_signal_qty": round(item_daily_req, 6),
                        "bb_demand_signal_raw_qty": round(item_daily_req_raw_dynamic, 6),
                        "target_demand_signal_qty": round(target_daily_req, 6),
                        "target_demand_signal_floor_qty": round(target_floor_req, 6),
                        "target_demand_signal_window_days": int(target_window_days),
                        "target_cutover_context_days": int(mrp_target_cutover_context_days),
                        "target_demand_signal_display_qty": round(target_display_daily_req, 6),
                        "target_demand_signal_display_floor_qty": round(target_display_floor_req, 6),
                        "bb_backlog_qty": round(bb_backlog_qty, 6),
                        "gross_requirement_basis": gross_requirement_basis,
                        "mrp_demand_signal_source": mrp_demand_signal_source,
                        "mrp_demand_signal_smoothing_days": int(mrp_signal_smoothing_days),
                        "safety_floor_qty": round(safety_floor_qty, 6),
                        "soft_safety_target_qty": round(soft_safety_target_qty, 6),
                        "coverage_target_qty": round(coverage_target_qty, 6),
                        "target_stock_qty": round(target_stock_qty, 6),
                        "target_stock_display_qty": round(target_display_stock_qty, 6),
                        "backlog_target_qty": round(backlog_target_qty, 6),
                        "target_with_backlog_qty": round(target_with_backlog_qty, 6),
                        "stock_proj_qty": round(stock_proj_qty, 6),
                        "recv_prev_today_qty": round(recv_prev_today_qty, 6),
                        "recv_prev_future_qty": round(recv_prev_future_qty, 6),
                        "inventory_position_qty": round(inventory_position_qty, 6),
                        **({
                            "mrp_execution_mode": args.mrp_execution_mode,
                            "recv_prev_undelivered_qty": round(max(0.0, recv_prev_future_qty - opening_purchase_availability.held_by_pair.get(pair, 0.0)), 6),
                            "held_pending_availability_qty": round(opening_purchase_availability.held_by_pair.get(pair, 0.0), 6),
                            "available_release_today_qty": round(opening_usable_releases_today.get(pair, 0.0), 6),
                        } if opening_purchase_availability is not None else {}),
                        **({key: (round(dated_plan_decisions[pair][key], 6) if isinstance(dated_plan_decisions[pair][key], float)
                                  else dated_plan_decisions[pair][key]) if pair in dated_plan_decisions else ""
                            for key in MRP_NETWORK_PLAN_FIELDS} if dated_component_planning else {}),
                        **dated_receipt_trace,
                        **forecast_trace,
                        **({**{field: "" for field in SOURCE_BOUNDARY_TRACE_FIELDS},
                            **source_boundary_decisions.get(pair, {})}
                           if source_boundary_policies else {}),
                        **({"mrp_standard_order_binding": int(policy_pair_key(*pair) not in nonbinding_standard_order_pair_keys)}
                           if nonbinding_standard_order_pair_keys else {}),
                        **({**{field: "" for field in PRODUCTION_MRP_SAFETY_FIELDS},
                            **production_safety_decisions.get(pair, {})}
                           if record_production_planning else {}),
                        **({"held_release_within_cover_qty": round(held_release_cover_qty, 6)}
                           if initial_stock_availability is not None else {}),
                        "bn_qty": round(bn_qty, 6),
                        "controlled_bn_qty": round(
                            controlled_bn_qty,
                            6,
                        ),
                        "control_order_multiplier": round(
                            trace_order_multiplier,
                            6,
                        ),
                        "control_safety_stock_multiplier": round(
                            trace_safety_multiplier,
                            6,
                        ),
                        "planned_release_qty": round(planned_release_today_by_pair.get(pair, 0.0), 6),
                        "planned_receipt_qty": round(planned_receipt_today_by_pair.get(pair, 0.0), 6),
                        "planned_order_count": int(planned_order_count_by_pair.get(pair, 0)),
                        "planned_receipt_min_day": (
                            int(arrival_min_day - warmup_days) if arrival_min_day is not None else ""
                        ),
                        "planned_receipt_max_day": (
                            int(arrival_max_day - warmup_days) if arrival_max_day is not None else ""
                        ),
                        "review_period_days": int(pair_review_period_days),
                        "safety_time_days": round(pair_mrp_safety_time_days.get(pair, 0.0), 6),
                        "safety_stock_qty": round(pair_mrp_safety_stock_qty.get(pair, 0.0), 6),
                        "has_mrp_snapshot_policy": int(pair in mrp_snapshot_pairs),
                    }
                )

        # End-of-day holding costs
        inv_total_today = 0.0
        raw_holding_cost_today = 0.0
        holding_stock_items = stock.items() if opening_purchase_availability is None else (
            (key, stock.get(key, 0.0))
            for key in sorted(set(stock) | set(opening_purchase_availability.held_by_pair))
        )
        for key, qty in holding_stock_items:
            if initial_stock_availability is not None:
                qty += initial_stock_availability.held_by_pair.get(key, 0.0)
            if opening_purchase_availability is not None:
                qty += opening_purchase_availability.held_by_pair.get(key, 0.0)
            if qty <= 0:
                continue
            inv_total_today += qty
            raw_holding_cost_today += qty * holding_cost.get(key, 0.0)
            if key not in holding_cost:
                holding_cost_unknown_reasons.setdefault(key, "inventory_pair_without_configured_holding_rate")
            if record_day and key in holding_cost_unknown_reasons:
                unknown_inventory_quantity_days[key] += qty
        holding_cost_today = (
            raw_holding_cost_today * economic_policy["inventory_capital_cost_share_of_raw_holding"]
        )
        warehouse_operating_cost_today = (
            raw_holding_cost_today * economic_policy["warehouse_operating_cost_share_of_raw_holding"]
        )
        inventory_risk_cost_today = (
            raw_holding_cost_today * economic_policy["inventory_risk_cost_share_of_raw_holding"]
        )
        if record_day:
            total_holding_cost += holding_cost_today
            total_warehouse_operating_cost += warehouse_operating_cost_today
            total_inventory_risk_cost += inventory_risk_cost_today
            total_legacy_raw_holding_cost += raw_holding_cost_today

        for node_id, item_id in production_input_pairs:
            row = day_input_rows_by_pair.get((node_id, item_id))
            if row is not None:
                row["stock_end_of_day"] = round(stock[(node_id, item_id)], 6)

        for row in output_prod_rows[output_prod_day_start:]:
            row["stock_end_of_day"] = round(stock[(row["node_id"], row["item_id"])], 6)

        feedback_order_nervousness_today = 0.0
        feedback_active_order_pair_count = 0
        if feedback_control is not None:
            feedback_demand_history.append(max(0.0, demand_today))
            current_order_by_pair = {
                pair: max(0.0, to_float(qty, 0.0))
                for pair, qty in planned_release_today_by_pair.items()
                if max(0.0, to_float(qty, 0.0)) > 1e-9
            }
            feedback_active_order_pair_count = len(current_order_by_pair)
            if feedback_previous_order_by_pair is not None:
                relative_changes = [
                    abs(
                        current_order_by_pair.get(pair, 0.0)
                        - feedback_previous_order_by_pair.get(pair, 0.0)
                    )
                    / max(
                        current_order_by_pair.get(pair, 0.0),
                        feedback_previous_order_by_pair.get(pair, 0.0),
                    )
                    for pair in (
                        set(current_order_by_pair)
                        | set(feedback_previous_order_by_pair)
                    )
                    if max(
                        current_order_by_pair.get(pair, 0.0),
                        feedback_previous_order_by_pair.get(pair, 0.0),
                    )
                    > 1e-9
                ]
                feedback_order_nervousness_today = (
                    _finite_median(relative_changes) or 0.0
                )
            feedback_previous_order_by_pair = current_order_by_pair

        def build_feedback_observation(
            *,
            production_utilization_values: list[float],
            supplier_utilization_values: list[float],
        ) -> CanonicalObservation:
            backlog_end_qty = sum(max(0.0, qty) for qty in backlog.values())
            required_today_qty = demand_today + sum(
                max(0.0, backlog_start_of_day_by_pair.get(pair, 0.0))
                for pair in demand_pairs
            )
            service_level_today = (
                min(1.0, max(0.0, served_today / required_today_qty))
                if required_today_qty > 1e-9
                else 1.0
            )
            recent_demand_qty = (
                sum(feedback_demand_history) / len(feedback_demand_history)
                if feedback_demand_history
                else 0.0
            )
            backlog_days_today = (
                backlog_end_qty / recent_demand_qty
                if recent_demand_qty > 1e-9
                else (365.0 if backlog_end_qty > 1e-9 else 0.0)
            )

            finished_cover_values = [
                max(0.0, stock.get(pair, 0.0)) / demand_rate
                for pair in demand_pairs
                for demand_rate in [
                    max(0.0, raw_demand_target_today.get(pair, 0.0))
                ]
                if demand_rate > 1e-9
            ]
            material_cover_values = [
                max(0.0, stock.get(pair, 0.0)) / requirement
                for pair in production_input_pairs
                for requirement in [
                    max(
                        0.0,
                        consumed_today_by_pair.get(pair, 0.0),
                        raw_propagated_demand_today.get(pair, 0.0),
                    )
                ]
                if requirement > 1e-9
            ]
            finished_inventory_cover_days = _finite_median(
                finished_cover_values
            )
            material_cover_days = (
                min(material_cover_values)
                if material_cover_values
                else None
            )
            disruption_score, active_event_count = (
                _canonical_supplier_disruption_proxy(
                    supplier_risk_events_today,
                    output_day,
                )
            )
            return CanonicalObservation(
                day=int(output_day),
                demand_qty=max(0.0, demand_today),
                served_qty=max(0.0, served_today),
                service_level=service_level_today,
                backlog_qty=backlog_end_qty,
                backlog_days=max(0.0, backlog_days_today),
                inventory_qty=max(0.0, inv_total_today),
                finished_inventory_cover_days=(
                    max(0.0, finished_inventory_cover_days)
                    if finished_inventory_cover_days is not None
                    else None
                ),
                material_cover_days=(
                    max(0.0, material_cover_days)
                    if material_cover_days is not None
                    else None
                ),
                production_utilization=max(
                    production_utilization_values,
                    default=0.0,
                ),
                supplier_utilization=max(
                    supplier_utilization_values,
                    default=0.0,
                ),
                order_nervousness=max(
                    0.0,
                    feedback_order_nervousness_today,
                ),
                active_order_pair_count=feedback_active_order_pair_count,
                supplier_disruption_score=disruption_score,
                active_supplier_event_count=active_event_count,
            )

        if (
            feedback_control is not None
            and feedback_control_supports_priming
            and args.controller_prime_during_warmup
            and not record_day
        ):
            feedback_warmup_supplier_utilization_values: list[float] = []
            for src_pair, nominal_cap in supplier_daily_capacity_by_pair.items():
                capacity_multipliers_today: list[float] = []
                for cap_lane in lanes_by_src_item.get(src_pair, []):
                    cap_risk = supplier_risk_multipliers_for_lane(
                        supplier_risk_events_today,
                        cap_lane,
                        output_day,
                    )
                    if cap_risk.get("event_ids"):
                        capacity_multipliers_today.append(
                            max(0.0, to_float(cap_risk.get("capacity"), 1.0))
                            * max(
                                0.0,
                                to_float(cap_risk.get("availability"), 1.0),
                            )
                        )
                effective_cap_today = (
                    nominal_cap * min(capacity_multipliers_today or [1.0])
                )
                used_qty = supplier_capacity_used_today_by_src_pair.get(
                    src_pair,
                    0.0,
                )
                feedback_warmup_supplier_utilization_values.append(
                    used_qty / effective_cap_today
                    if effective_cap_today > 1e-9
                    else 0.0
                )
            prime_observation = getattr(feedback_control, "prime", None)
            if not callable(prime_observation):
                provider_version = "V3" if feedback_control_is_v3 else "V2"
                raise SystemExit(
                    f"The selected {provider_version} control provider does not "
                    "support warm-up priming."
                )
            try:
                prime_observation(
                    build_feedback_observation(
                        production_utilization_values=(
                            feedback_warmup_production_utilization_values
                        ),
                        supplier_utilization_values=(
                            feedback_warmup_supplier_utilization_values
                        ),
                    )
                )
            except ControlProviderError as exc:
                provider_version = "V3" if feedback_control_is_v3 else "V2"
                raise SystemExit(
                    f"State-feedback {provider_version} priming failed on warm-up day "
                    f"{output_day}: {exc}"
                ) from exc

        if record_day:
            if initial_stock_availability is not None or opening_purchase_availability is not None:
                reserved_by_pair: dict[tuple[str, str], float] = defaultdict(float)
                for departure_day, payloads in lot_departure_pipeline.items():
                    if departure_day <= day:
                        continue
                    for payload in payloads:
                        if not payload.get("materialize_backorder_origin"):
                            reserved_by_pair[(str(payload["src_node_id"]), str(payload["item_id"]))] += float(payload["qty"])
                availability_pairs = set(stock) | set(reserved_by_pair)
                if opening_purchase_availability is not None:
                    availability_pairs.update(opening_purchase_availability.held_by_pair)
                for pair in sorted(availability_pairs):
                    available_qty = max(0.0, stock.get(pair, 0.0))
                    held_qty = initial_stock_availability.held_by_pair.get(pair, 0.0) if initial_stock_availability is not None else 0.0
                    if opening_purchase_availability is not None:
                        held_qty += opening_purchase_availability.held_by_pair.get(pair, 0.0)
                    reserved_qty = reserved_by_pair.get(pair, 0.0)
                    stock_availability_daily_rows.append({
                        "day": output_day, "node_id": pair[0], "item_id": pair[1],
                        "uom": item_unit_map.get(pair[1], ""),
                        "available_qty": round(available_qty, 6), "held_qty": round(held_qty, 6),
                        "reserved_qty": round(reserved_qty, 6),
                        "physical_qty": round(available_qty + held_qty + reserved_qty, 6),
                        "released_qty": round(availability_released_today.get(pair, 0.0) + opening_usable_releases_today.get(pair, 0.0), 6),
                    })
            for node_id, item_id in supplier_stock_pairs:
                pair = (node_id, item_id)
                incoming_upstream = max(0.0, arrivals_today_by_pair.get(pair, 0.0))
                incoming_external = max(0.0, external_arrivals_today_by_pair.get(pair, 0.0))
                incoming_estimated = max(0.0, estimated_source_arrivals_today_by_pair.get(pair, 0.0)) + max(
                    0.0,
                    estimated_capacity_replenished_today_by_pair.get(pair, 0.0),
                )
                incoming_qty = incoming_upstream + incoming_external + incoming_estimated
                stock_writeoff = max(0.0, supplier_stock_writeoff_today_by_pair.get(pair, 0.0))
                outgoing_pulled = max(0.0, supplier_capacity_used_today_by_src_pair.get(pair, 0.0))
                outgoing_shipped = max(0.0, supplier_shipped_from_stock_today_by_src_pair.get(pair, 0.0))
                stock_start = max(0.0, supplier_stock_start_by_pair.get(pair, 0.0))
                stock_end = max(0.0, stock.get(pair, 0.0))
                expected_stock_end = stock_start + incoming_qty - stock_writeoff - outgoing_pulled
                supplier_stock_flow_rows.append(
                    {
                        "day": output_day,
                        "node_id": node_id,
                        "item_id": item_id,
                        "uom": item_unit_map.get(item_id, ""),
                        "stock_start_of_day": round(stock_start, 6),
                        "incoming_qty": round(incoming_qty, 6),
                        "incoming_upstream_pipeline_qty": round(incoming_upstream, 6),
                        "incoming_external_market_qty": round(incoming_external, 6),
                        "incoming_estimated_source_qty": round(incoming_estimated, 6),
                        "stock_writeoff_qty": round(stock_writeoff, 6),
                        "outgoing_pulled_qty": round(outgoing_pulled, 6),
                        "outgoing_shipped_qty": round(outgoing_shipped, 6),
                        "outgoing_unreliable_loss_qty": round(max(0.0, outgoing_pulled - outgoing_shipped), 6),
                        "stock_end_of_day": round(stock_end, 6),
                        "balance_delta_qty": round(stock_end - stock_start, 6),
                        "balance_check_gap_qty": round(stock_end - expected_stock_end, 6),
                    }
                )
                supplier_stock_rows.append(
                    {
                        "day": output_day,
                        "node_id": node_id,
                        "item_id": item_id,
                        "stock_end_of_day": round(stock[(node_id, item_id)], 6),
                    }
                )
            for node_id, item_id in dc_stock_pairs:
                dc_stock_rows.append(
                    {
                        "day": output_day,
                        "node_id": node_id,
                        "item_id": item_id,
                        "stock_end_of_day": round(stock[(node_id, item_id)], 6),
                    }
                )

            daily_rows.append(
                {
                    "day": output_day,
                    "demand": round(demand_today, 4),
                    "served": round(served_today, 4),
                    "backlog_end": round(sum(backlog.values()), 4),
                    "arrivals_qty": round(arrivals_qty, 4),
                    "produced_qty": round(produced_today, 4),
                    "shipped_qty": round(shipped_today, 4),
                    "inventory_total": round(inv_total_today, 4),
                    "holding_cost_day": round(holding_cost_today, 4),
                    "warehouse_operating_cost_day": round(warehouse_operating_cost_today, 4),
                    "inventory_risk_cost_day": round(inventory_risk_cost_today, 4),
                    "legacy_raw_holding_cost_day": round(raw_holding_cost_today, 4),
                    "transport_cost_day": round(transport_cost_today, 4),
                    "opening_open_order_transport_cost_day": round(opening_transport_cost_today, 4),
                    "external_procurement_transport_cost_day": round(external_procurement_transport_cost_today, 4),
                    "operational_transport_cost_day": round(max(0.0, transport_cost_today - opening_transport_cost_today), 4),
                    "purchase_cost_day": round(purchase_cost_today, 4),
                    "opening_open_order_purchase_cost_day": round(opening_purchase_cost_today, 4),
                    "external_procurement_purchase_cost_day": round(external_procurement_purchase_cost_today, 4),
                    "operational_purchase_cost_day": round(max(0.0, purchase_cost_today - opening_purchase_cost_today), 4),
                    "external_procured_ordered_qty": round(external_procured_today, 4),
                    "external_procured_arrived_qty": round(external_arrivals_qty, 4),
                    "external_procured_rejected_qty": round(external_procured_rejected_today, 4),
                    "external_quality_rejected_qty": round(external_quality_rejected_today, 4),
                    "estimated_source_ordered_qty": round(estimated_source_ordered_today, 4),
                    "estimated_source_arrived_qty": round(estimated_source_arrivals_qty, 4),
                    "estimated_source_rejected_qty": round(estimated_source_rejected_today, 4),
                    "supplier_capacity_binding_qty": round(supplier_capacity_binding_qty_today, 4),
                }
            )

            if feedback_control is not None:
                production_utilization_values = [
                    max(0.0, to_float(row.get("actual_qty"), 0.0))
                    / max(1e-9, to_float(row.get("cap_qty"), 0.0))
                    for row in production_constraint_rows[
                        production_constraint_day_start:
                    ]
                    if str(row.get("capacity_limit_mode") or "") == "finite"
                    and to_float(row.get("cap_qty"), 0.0) > 1e-9
                ]
                supplier_utilization_values = [
                    max(0.0, to_float(row.get("utilization"), 0.0))
                    for row in supplier_capacity_daily_rows[
                        supplier_capacity_day_start:
                    ]
                ]
                observation = build_feedback_observation(
                    production_utilization_values=production_utilization_values,
                    supplier_utilization_values=supplier_utilization_values,
                )
                try:
                    feedback_control.observe(
                        observation,
                        last_effective_day=sim_days - 1,
                    )
                except ControlProviderError as exc:
                    raise SystemExit(
                        f"State-feedback control failed on day {output_day}: {exc}"
                    ) from exc

    for shipment_row in supplier_shipment_rows:
        departure_day = int(shipment_row["day"])
        arrival_day = int(shipment_row["arrival_day"])
        departed = departure_day < sim_days
        received = arrival_day < sim_days
        shipment_row.update({
            "observation_day": sim_days - 1,
            "execution_status": shipment_execution_state(
                departure_day, arrival_day, sim_days - 1,
                reserved=bool(shipment_row.get("source_inventory_reserved", False)),
            ),
            "departure_executed": int(departed), "arrival_executed": int(received),
            "executed_shipped_qty": shipment_row["shipped_qty"] if departed else 0.0,
            "realized_departure_day": departure_day if departed else "",
            "realized_arrival_day": arrival_day if received else "",
            "planned_departure_day": departure_day,
            "planned_arrival_day": arrival_day,
            "realized_transport_lead_days": arrival_day - departure_day if received else "",
            "lead_time_information_status": "realized_at_receipt" if received else "planned_not_yet_observed",
        })

    for order_row in mrp_order_rows:
        pair = (str(order_row["node_id"]), str(order_row["item_id"]))
        order_row["safety_time_source_days"] = pair_mrp_safety_source_days.get(pair, 0.0)
        order_row["safety_time_calendar"] = args.safety_time_calendar
        if order_row.get("order_type") == "external_procurement_supplier_delivery":
            available = int(order_row["available_day"]) < sim_days
            received = int(order_row["physical_delivery_day"]) < sim_days
            order_row["order_status_end_of_run"] = "available" if available else "held_pending_availability" if received else "awaiting_physical_delivery"
        # Opening firm orders also distinguish a future release from transit.
        if str(order_row.get("order_type") or "").startswith("opening_"):
            order_row["order_status_end_of_run"] = shipment_execution_state(
                int(order_row["release_day"]), int(order_row["arrival_day"]), sim_days - 1,
                reserved=False,
            )
            if int(order_row["release_day"]) >= sim_days:
                order_row["release_status"] = "planned_pending_departure"

    for trace_row in mrp_trace_rows:
        pair = (str(trace_row["node_id"]), str(trace_row["item_id"]))
        trace_row["safety_time_source_days"] = pair_mrp_safety_source_days.get(pair, 0.0)
        trace_row["safety_time_calendar"] = args.safety_time_calendar

    supplier_nominal_parameter_rows = build_supplier_nominal_parameter_rows(
        nodes=nodes,
        supplier_node_ids=supplier_node_ids,
        lanes=lanes,
        supplier_capacity_metadata_rows=supplier_capacity_metadata_rows,
        estimated_source_policies=estimated_source_policies,
        item_unit_map=item_unit_map,
        opening_stock_source_snapshot=opening_stock_source_snapshot,
        stock=simulated_opening_stock_snapshot,
        base_stock=base_stock,
        supplier_shipment_rows=supplier_shipment_rows,
        supplier_stock_rows=supplier_stock_rows,
        supplier_capacity_daily_rows=supplier_capacity_daily_rows,
        stochastic_lead_times=args.stochastic_lead_times,
        lead_time_distribution_mode=lead_time_distribution_mode,
    )
    factory_nominal_capacity_rows = build_factory_nominal_capacity_rows(
        nodes=nodes,
        production_constraint_rows=production_constraint_rows,
        item_unit_map=item_unit_map,
    )
    production_campaign_rows = build_production_campaign_rows(
        production_plan_event_rows,
        lot_ledger.event_rows,
    )
    lot_causal_link_rows = build_lot_causal_link_rows(
        lot_event_rows=lot_ledger.event_rows,
        genealogy_rows=lot_ledger.genealogy_rows,
        production_plan_rows=production_plan_event_rows,
        production_campaign_rows=production_campaign_rows,
        mrp_order_rows=mrp_order_rows,
    )
    factory_nervousness_rows = build_factory_nervousness_rows(
        production_constraint_rows,
        production_campaign_rows,
        horizon_days=len(daily_rows),
    )

    ending_inventory = sum(v for v in stock.values() if v > 0)
    ending_backlog = sum(v for v in backlog.values() if v > 0)
    measured_required_total = total_demand + measurement_starting_backlog
    fill_rate = (total_served / measured_required_total) if measured_required_total > 0 else 1.0
    avg_inventory = sum(r["inventory_total"] for r in daily_rows) / len(daily_rows) if daily_rows else 0.0

    production_qty_by_pair: dict[tuple[str, str], float] = defaultdict(float)
    production_qty_by_pair_day: dict[tuple[str, str], dict[int, float]] = defaultdict(lambda: defaultdict(float))
    for (day_idx, node_id, item_id), qty in production_cost_qty_by_day_pair.items():
        if qty <= 1e-9:
            continue
        pair = (node_id, item_id)
        production_qty_by_pair[pair] += qty
        production_qty_by_pair_day[pair][int(day_idx)] += qty

    production_cost_by_day: dict[int, float] = defaultdict(float)
    production_cost_line_rows: list[dict[str, Any]] = []
    cost_without_production = (
        total_transport_cost
        + total_holding_cost
        + total_warehouse_operating_cost
        + total_inventory_risk_cost
        + total_purchase_cost
    )
    if (
        economic_policy["production_cost_enabled"]
        and economic_policy["production_cost_mode"] == "fixed_unit_rate"
        and production_qty_by_pair
    ):
        active_pairs = sorted(production_qty_by_pair)
        allocated_cost_total = 0.0
        for pair in active_pairs:
            pair_key = policy_pair_key(pair[0], pair[1])
            pair_qty_total = production_qty_by_pair.get(pair, 0.0)
            unit_rate = max(
                0.0,
                to_float(economic_policy["production_cost_unit_rates"].get(pair_key), 0.0),
            )
            pair_cost = pair_qty_total * unit_rate
            allocated_cost_total += pair_cost
            if pair_cost > 1e-9:
                for day_idx, qty in production_qty_by_pair_day[pair].items():
                    production_cost_by_day[int(day_idx)] += qty * unit_rate
            profile = str(
                economic_policy["production_cost_line_profiles"].get(pair_key)
                or "production"
            )
            production_cost_line_rows.append(
                {
                    "node_id": pair[0],
                    "item_id": pair[1],
                    "profile": profile,
                    "produced_qty": round(pair_qty_total, 6),
                    "unit_conversion_cost": round(unit_rate, 12),
                    "cost_share_of_production": 0.0,
                    "production_cost": round(pair_cost, 4),
                    "allocation_basis": economic_policy["production_cost_basis"],
                }
            )
        if allocated_cost_total > 1e-9:
            for row in production_cost_line_rows:
                row["cost_share_of_production"] = round(
                    max(0.0, to_float(row.get("production_cost"), 0.0))
                    / allocated_cost_total,
                    6,
                )
    elif (
        economic_policy["production_cost_enabled"]
        and economic_policy["production_cost_target_share_of_total"] > 1e-9
        and cost_without_production > 1e-9
        and production_qty_by_pair
    ):
        target_share = economic_policy["production_cost_target_share_of_total"]
        target_production_cost = cost_without_production * target_share / max(1e-12, 1.0 - target_share)
        active_pairs = sorted(production_qty_by_pair)
        raw_line_shares = {
            pair: max(0.0, to_float(economic_policy["production_cost_line_shares"].get(policy_pair_key(pair[0], pair[1])), 0.0))
            for pair in active_pairs
        }
        configured_share_total = sum(raw_line_shares.values())
        unconfigured_pairs = [pair for pair in active_pairs if raw_line_shares.get(pair, 0.0) <= 1e-9]
        line_share_by_pair: dict[tuple[str, str], float] = {}
        if configured_share_total > 1e-9:
            if unconfigured_pairs and configured_share_total < 1.0:
                remaining_share = max(0.0, 1.0 - configured_share_total)

                def production_volume_weight(pair: tuple[str, str]) -> float:
                    qty = production_qty_by_pair.get(pair, 0.0)
                    uom = normalize_unit(item_unit_map.get(pair[1], ""))
                    return qty / 1000.0 if uom == "G" else qty

                unconfigured_weight_total = sum(production_volume_weight(pair) for pair in unconfigured_pairs)
                for pair in active_pairs:
                    if raw_line_shares.get(pair, 0.0) > 1e-9:
                        line_share_by_pair[pair] = raw_line_shares[pair]
                    elif unconfigured_weight_total > 1e-9:
                        line_share_by_pair[pair] = remaining_share * production_volume_weight(pair) / unconfigured_weight_total
                    else:
                        line_share_by_pair[pair] = remaining_share / float(len(unconfigured_pairs))
            else:
                line_share_by_pair = {
                    pair: raw_line_shares[pair] / configured_share_total
                    for pair in active_pairs
                    if raw_line_shares[pair] > 1e-9
                }
        else:
            weighted_qty_by_pair: dict[tuple[str, str], float] = {}
            for pair in active_pairs:
                qty = production_qty_by_pair.get(pair, 0.0)
                uom = normalize_unit(item_unit_map.get(pair[1], ""))
                weighted_qty_by_pair[pair] = qty / 1000.0 if uom == "G" else qty
            weighted_total = sum(weighted_qty_by_pair.values())
            line_share_by_pair = {
                pair: (weighted_qty_by_pair[pair] / weighted_total if weighted_total > 1e-9 else 1.0 / float(len(active_pairs)))
                for pair in active_pairs
            }

        normalized_share_total = sum(line_share_by_pair.values())
        if normalized_share_total > 1e-9:
            line_share_by_pair = {pair: share / normalized_share_total for pair, share in line_share_by_pair.items()}

        for pair in active_pairs:
            pair_qty_total = production_qty_by_pair.get(pair, 0.0)
            pair_share = max(0.0, line_share_by_pair.get(pair, 0.0))
            pair_cost = target_production_cost * pair_share
            if pair_qty_total > 1e-9 and pair_cost > 1e-9:
                for day_idx, qty in production_qty_by_pair_day[pair].items():
                    production_cost_by_day[int(day_idx)] += pair_cost * qty / pair_qty_total
            profile = str(
                economic_policy["production_cost_line_profiles"].get(policy_pair_key(pair[0], pair[1]))
                or "production"
            )
            production_cost_line_rows.append(
                {
                    "node_id": pair[0],
                    "item_id": pair[1],
                    "profile": profile,
                    "produced_qty": round(pair_qty_total, 6),
                    "unit_conversion_cost": round(
                        pair_cost / pair_qty_total if pair_qty_total > 1e-9 else 0.0,
                        12,
                    ),
                    "cost_share_of_production": round(pair_share, 6),
                    "production_cost": round(pair_cost, 4),
                    "allocation_basis": economic_policy["production_cost_basis"],
                }
            )

    total_production_cost = sum(production_cost_by_day.values())
    for row in daily_rows:
        day_idx = int(to_float(row.get("day"), 0.0))
        production_cost_day = max(0.0, production_cost_by_day.get(day_idx, 0.0))
        operational_purchase = max(0.0, to_float(row.get("operational_purchase_cost_day"), row.get("purchase_cost_day", 0.0)))
        operational_transport = max(0.0, to_float(row.get("operational_transport_cost_day"), row.get("transport_cost_day", 0.0)))
        inventory_cost_day = (
            max(0.0, to_float(row.get("holding_cost_day"), 0.0))
            + max(0.0, to_float(row.get("warehouse_operating_cost_day"), 0.0))
            + max(0.0, to_float(row.get("inventory_risk_cost_day"), 0.0))
        )
        row["production_cost_day"] = round(production_cost_day, 4)
        row["total_supply_cost_day"] = round(
            operational_purchase + operational_transport + inventory_cost_day + production_cost_day,
            4,
        )
        exceptional_supply_cost_day = (
            max(0.0, to_float(row.get("external_procurement_purchase_cost_day"), 0.0))
            + max(0.0, to_float(row.get("external_procurement_transport_cost_day"), 0.0))
        )
        row["exceptional_supply_cost_day"] = round(exceptional_supply_cost_day, 4)
        row["total_economic_exposure_day"] = round(
            to_float(row.get("total_supply_cost_day"), 0.0) + exceptional_supply_cost_day,
            4,
        )

    top_backlog = sorted(
        [
            {"node_id": pair[0], "item_id": pair[1], "backlog": round(val, 4)}
            for pair, val in backlog.items()
            if val > 0
        ],
        key=lambda x: -x["backlog"],
    )[:10]
    total_logistics_cost = (
        total_transport_cost
        + total_holding_cost
        + total_warehouse_operating_cost
        + total_inventory_risk_cost
    )
    total_cost = total_logistics_cost + total_purchase_cost + total_production_cost
    holding_share = total_holding_cost / max(1e-12, total_cost)
    warehouse_share = total_warehouse_operating_cost / max(1e-12, total_cost)
    inventory_risk_share = total_inventory_risk_cost / max(1e-12, total_cost)
    transport_share = total_transport_cost / max(1e-12, total_cost)
    purchase_share = total_purchase_cost / max(1e-12, total_cost)
    production_share = total_production_cost / max(1e-12, total_cost)
    economic_warnings: list[str] = []
    if holding_share > 0.60:
        economic_warnings.append("capital_holding_cost_share_above_60pct")
    if transport_share < 0.02:
        economic_warnings.append("transport_cost_share_below_2pct")
    if warehouse_share < 0.10:
        economic_warnings.append("warehouse_operating_cost_share_below_10pct")
    if inventory_risk_share < 0.05:
        economic_warnings.append("inventory_risk_cost_share_below_5pct")
    if total_external_procured > 0 and total_external_procured_arrived <= 1e-9:
        economic_warnings.append("external_procurement_ordered_but_not_arrived_in_horizon")
    customer_delay_qty_day = sum(max(0.0, to_float(row.get("backlog_end"), 0.0)) for row in daily_rows)
    unmet_customer_demand_qty = ending_backlog
    non_quality_loss_qty = (
        max(0.0, total_unreliable_loss_qty)
        + max(0.0, total_external_quality_rejected)
        + sum(max(0.0, float(row.get("stock_writeoff_qty", 0))) for row in supplier_stock_flow_rows)
    )
    exceptional_supply_cost = max(0.0, total_external_procurement_cost)
    total_economic_exposure = total_cost + exceptional_supply_cost
    operational_risk_cost = (
        max(0.0, total_inventory_risk_cost)
        + max(0.0, exceptional_supply_cost)
    )

    actual_input_consumption_avg_by_pair: dict[tuple[str, str], float] = defaultdict(float)
    for row in input_consumption_rows:
        actual_input_consumption_avg_by_pair[(str(row["node_id"]), str(row["item_id"]))] += max(
            0.0,
            to_float(row.get("consumed_qty"), 0.0),
        )
    actual_output_production_avg_by_pair: dict[tuple[str, str], float] = defaultdict(float)
    for row in output_prod_rows:
        actual_output_production_avg_by_pair[(str(row["node_id"]), str(row["item_id"]))] += max(
            0.0,
            to_float(row.get("produced_qty"), 0.0),
        )
    actual_demand_avg_by_pair: dict[tuple[str, str], float] = defaultdict(float)
    served_avg_by_pair: dict[tuple[str, str], float] = defaultdict(float)
    for row in demand_pair_rows:
        pair = (str(row["node_id"]), str(row["item_id"]))
        actual_demand_avg_by_pair[pair] += max(0.0, to_float(row.get("demand_qty"), 0.0))
        served_avg_by_pair[pair] += max(0.0, to_float(row.get("served_qty"), 0.0))
    avg_divisor = max(1.0, float(sim_days))
    for bucket in (
        actual_input_consumption_avg_by_pair,
        actual_output_production_avg_by_pair,
        actual_demand_avg_by_pair,
        served_avg_by_pair,
    ):
        for pair in list(bucket.keys()):
            bucket[pair] = bucket[pair] / avg_divisor

    mrp_trace_stats_by_pair: dict[tuple[str, str], dict[str, float]] = defaultdict(lambda: defaultdict(float))
    for row in mrp_trace_rows:
        pair = (str(row.get("node_id") or ""), str(row.get("item_id") or ""))
        if not pair[0] or not pair[1]:
            continue
        rec = mrp_trace_stats_by_pair[pair]
        rec["count"] += 1.0
        demand_signal_qty = max(0.0, to_float(row.get("bb_demand_signal_qty"), 0.0))
        safety_floor_qty = max(0.0, to_float(row.get("safety_floor_qty"), 0.0))
        soft_target_qty = max(0.0, to_float(row.get("soft_safety_target_qty"), 0.0))
        rec["demand_signal_sum"] += demand_signal_qty
        rec["safety_floor_sum"] += safety_floor_qty
        rec["soft_target_sum"] += soft_target_qty
        rec["demand_signal_max"] = max(rec.get("demand_signal_max", 0.0), demand_signal_qty)
        rec["safety_floor_max"] = max(rec.get("safety_floor_max", 0.0), safety_floor_qty)
        rec["soft_target_max"] = max(rec.get("soft_target_max", 0.0), soft_target_qty)

    safety_reference_pairs = sorted(
        set(production_input_pairs)
        | set(production_output_pairs)
        | set(demand_pairs)
        | set(propagated_demand_daily)
        | set(pair_mrp_safety_time_days)
        | set(pair_mrp_safety_stock_qty)
    )
    safety_reference_rows: list[dict[str, Any]] = []
    soft_safety_factor = initialization_policy["soft_safety_time_stock_target_factor"]
    for pair in safety_reference_pairs:
        node_id, item_id = pair
        if item_id == "item:__process_time__":
            continue
        pair_soft_safety_factor = soft_safety_factor_for_pair(pair)
        safety_days = max(0.0, pair_mrp_safety_time_days.get(pair, 0.0))
        explicit_safety_stock_qty = max(0.0, pair_mrp_safety_stock_qty.get(pair, 0.0))
        trace_stats = mrp_trace_stats_by_pair.get(pair)
        if trace_stats and trace_stats.get("count", 0.0) > 0:
            trace_count = max(1.0, trace_stats["count"])
            planned_avg_daily_demand_qty = trace_stats["demand_signal_sum"] / trace_count
            stock_equiv_safety_time_qty = planned_avg_daily_demand_qty * safety_days
            effective_reference_stock_qty = max(
                explicit_safety_stock_qty,
                trace_stats["safety_floor_sum"] / trace_count,
            )
            soft_simulated_target_qty = max(
                explicit_safety_stock_qty,
                trace_stats["soft_target_sum"] / trace_count,
            )
            max_mrp_demand_signal_qty = trace_stats.get("demand_signal_max", 0.0)
            max_mrp_safety_floor_qty = trace_stats.get("safety_floor_max", 0.0)
            max_soft_simulated_target_qty = trace_stats.get("soft_target_max", 0.0)
            safety_reference_basis = "mrp_trace_demand_signal"
        else:
            planned_avg_daily_demand_qty = max(
                0.0,
                demand_target_daily.get(pair, 0.0),
                propagated_demand_daily.get(pair, 0.0),
                required_daily_input_by_pair.get(pair, 0.0),
            )
            stock_equiv_safety_time_qty = planned_avg_daily_demand_qty * safety_days
            effective_reference_stock_qty = max(explicit_safety_stock_qty, stock_equiv_safety_time_qty)
            soft_simulated_target_qty = max(
                explicit_safety_stock_qty,
                stock_equiv_safety_time_qty * pair_soft_safety_factor,
            )
            max_mrp_demand_signal_qty = planned_avg_daily_demand_qty
            max_mrp_safety_floor_qty = effective_reference_stock_qty
            max_soft_simulated_target_qty = soft_simulated_target_qty
            safety_reference_basis = "static_or_propagated_daily_requirement"
        observed_avg_daily_flow_qty = max(
            0.0,
            actual_input_consumption_avg_by_pair.get(pair, 0.0),
            actual_output_production_avg_by_pair.get(pair, 0.0),
            actual_demand_avg_by_pair.get(pair, 0.0),
        )
        node_type = node_type_by_id.get(node_id, "")
        if pair in demand_pairs or node_type in {"distribution_center", "customer"}:
            scope = "finished_good"
        elif pair in production_output_pairs:
            scope = "semi_finished_or_output"
        elif pair in production_input_pairs:
            scope = "input_material"
        else:
            scope = "supply_pair"
        safety_reference_rows.append(
            {
                "scope": scope,
                "node_id": node_id,
                "item_id": item_id,
                "uom": item_unit_map.get(item_id, ""),
                "safety_time_days": round(safety_days, 6),
                "safety_time_calendar_days": round(safety_days, 6),
                "safety_time_source_days": round(pair_mrp_safety_source_days.get(pair, 0.0), 6),
                "safety_time_calendar": args.safety_time_calendar,
                "safety_time_effective_at_day": sim_days - 1,
                "planned_avg_daily_demand_qty": round(planned_avg_daily_demand_qty, 6),
                "observed_avg_daily_flow_qty": round(observed_avg_daily_flow_qty, 6),
                "stock_equiv_safety_time_qty": round(stock_equiv_safety_time_qty, 6),
                "explicit_safety_stock_qty": round(explicit_safety_stock_qty, 6),
                "effective_reference_stock_qty": round(effective_reference_stock_qty, 6),
                "soft_simulated_target_qty": round(soft_simulated_target_qty, 6),
                "max_mrp_demand_signal_qty": round(max_mrp_demand_signal_qty, 6),
                "max_mrp_safety_floor_qty": round(max_mrp_safety_floor_qty, 6),
                "max_soft_simulated_target_qty": round(max_soft_simulated_target_qty, 6),
                "safety_reference_basis": safety_reference_basis,
                "soft_safety_factor": round(pair_soft_safety_factor, 6),
                "served_avg_daily_qty": round(served_avg_by_pair.get(pair, 0.0), 6),
            }
        )

    control_rows_for_audit = (
        feedback_control.rows
        if feedback_control is not None
        else control_schedule.rows
    )
    for schedule_row in control_rows_for_audit:
        for action_name in schedule_row.effective:
            if (schedule_row.source_line, action_name) in control_applied_actions:
                continue
            feedback_audit = feedback_audit_metadata_for_day(
                schedule_row.day
            )
            control_action_ledger_rows.append(
                {
                    "day": schedule_row.day,
                    "resolved_node_id": "",
                    "resolved_supplier_id": "",
                    "resolved_item_id": "",
                    "resolved_dst_node_id": "",
                    "policy": schedule_row.policy,
                    "action": action_name,
                    "requested": schedule_row.requested[action_name],
                    "effective": schedule_row.effective[action_name],
                    "bound": schedule_row.bound[action_name],
                    "status": "scheduled_not_resolved",
                    "source_line": schedule_row.source_line,
                    "scope_type": (
                        "global"
                        if schedule_row.specificity == 0
                        else "targeted"
                    ),
                    "scope_specificity": schedule_row.specificity,
                    "source_node_id": schedule_row.node_id,
                    "source_supplier_id": schedule_row.supplier_id,
                    "source_item_id": schedule_row.item_id,
                    "source_dst_node_id": schedule_row.dst_node_id,
                    "matched_source_lines": "",
                    "action_stage": "schedule_audit",
                    "executed_control_volume_qty": "",
                    "binding_reason": (
                        "day_or_operational_scope_not_reached_or_no_physical_execution"
                    ),
                    **feedback_audit,
                }
            )
    control_action_ledger_rows.sort(
        key=lambda row: (
            int(to_float(row.get("day"), -1)),
            str(row.get("action_stage") or ""),
            str(row.get("resolved_node_id") or ""),
            str(row.get("resolved_supplier_id") or ""),
            str(row.get("resolved_item_id") or ""),
            int(to_float(row.get("source_line"), -1)),
            str(row.get("action") or ""),
        )
    )
    matched_control_schedule_rows = len(
        {
            row.source_line
            for row in control_schedule.rows
            if row.source_line in control_applied_source_lines
        }
    )
    scheduled_control_actions = sum(
        len(row.effective)
        for row in control_schedule.rows
    )
    resolved_control_actions = len(
        {
            action
            for action in control_applied_actions
            if action[0] in {row.source_line for row in control_schedule.rows}
        }
    )
    control_probe_rows = (
        control_probe.rows if control_probe is not None else ()
    )
    control_probe_scheduled_actions = sum(
        len(row.effective) for row in control_probe_rows
    )
    resolved_probe_actions = {
        (int(row["probe_source_line"]), str(row["action"]))
        for row in control_probe_composition_rows.values()
        if str(row.get("probe_source_line") or "").strip()
    }
    matched_control_probe_rows = len(
        {
            row.source_line
            for row in control_probe_rows
            if any(
                source_line == row.source_line
                for source_line, _ in resolved_probe_actions
            )
        }
    )
    control_probe_clipped_rows = [
        row
        for row in control_probe_composition_rows.values()
        if int(to_float(row.get("composition_clipped"), 0)) == 1
    ]
    feedback_source_lines = {
        row.source_line
        for row in (feedback_control.rows if feedback_control is not None else ())
    }
    matched_feedback_rows = len(
        feedback_source_lines & control_applied_source_lines
    )
    scheduled_feedback_actions = sum(
        len(row.effective)
        for row in (feedback_control.rows if feedback_control is not None else ())
    )
    resolved_feedback_actions = len(
        {
            action
            for action in control_applied_actions
            if action[0] in feedback_source_lines
        }
    )
    physically_applied_feedback_actions = {
        (
            int(to_float(row.get("source_line"), -1)),
            str(row.get("action") or ""),
        )
        for row in control_action_ledger_rows
        if int(to_float(row.get("source_line"), -1)) in feedback_source_lines
        and str(row.get("status") or "") == "applied"
        and to_float(row.get("executed_control_volume_qty"), 0.0) > 1e-9
    }
    feedback_provider_metadata = (
        feedback_control.summary_metadata()
        if feedback_control is not None
        else {}
    )
    feedback_priming_rows = (
        [dict(row) for row in getattr(feedback_control, "priming_rows", ())]
        if feedback_control is not None
        else []
    )
    controller_dynamic_warmup_days = int(
        feedback_provider_metadata.get(
            "controller_dynamic_warmup_days",
            feedback_provider_metadata.get(
                "priming_observation_count",
                len(feedback_priming_rows),
            ),
        )
        or 0
    )
    warmup_feedback_command_count = int(
        feedback_provider_metadata.get(
            "warmup_control_action_count",
            feedback_provider_metadata.get("warmup_action_count", 0),
        )
        or 0
    )
    controller_warmup_matches_physical_warmup = bool(
        controller_dynamic_warmup_days == int(warmup_days)
        and warmup_feedback_command_count == 0
    )
    controller_observation_forecast_lookahead_days = max(
        0,
        int(mrp_signal_smoothing_days) - 1,
    )
    future_information_contract_satisfied = (
        controller_observation_forecast_lookahead_days == 0
    )
    feedback_provider_causal_contract_satisfied = bool(
        feedback_provider_metadata.get("causal_contract_satisfied", False)
    )
    feedback_observation_decision_count_match = bool(
        feedback_provider_metadata.get("observation_count", 0)
        == feedback_provider_metadata.get("decision_count", -1)
        and feedback_provider_metadata.get("observation_count", 0) > 0
    )
    feedback_closed_loop_claim_checks = {
        "provider_causal_contract_satisfied": (
            feedback_provider_causal_contract_satisfied
        ),
        "observation_causal_contract_satisfied": bool(
            future_information_contract_satisfied
        ),
        "observation_decision_count_match": (
            feedback_observation_decision_count_match
        ),
        "controller_warmup_matches_physical_warmup": bool(
            controller_warmup_matches_physical_warmup
        ),
        "physical_feedback_action_applied": bool(
            physically_applied_feedback_actions
        ),
    }
    feedback_closed_loop_claimed = bool(
        feedback_control is not None
        and all(feedback_closed_loop_claim_checks.values())
    )
    feedback_closed_loop_claim_reasons = [
        name
        for name, satisfied in feedback_closed_loop_claim_checks.items()
        if not satisfied
    ]
    feedback_engine_warnings = list(
        feedback_provider_metadata.get("warnings", [])
    )
    if feedback_control is not None and not future_information_contract_satisfied:
        feedback_engine_warnings.append(
            "The realized demand signal exposed to the controller uses a "
            f"forward {int(mrp_signal_smoothing_days)}-day profile window; "
            "closed_loop_claimed is therefore disabled. Use "
            "--mrp-demand-signal-smoothing-days 1 for a causal observation."
        )
    if (
        feedback_control is not None
        and warmup_days > 0
        and not controller_warmup_matches_physical_warmup
    ):
        feedback_engine_warnings.append(
            "The physical engine was warmed up, but the controller dynamic "
            "memory starts at measured day 0 and was not primed during warm-up."
        )

    demand_perturbation_manifest = {
        "enabled": True,
        "source_csv": str(demand_perturbation_path),
        "sha256": demand_perturbation_sha256,
        "row_count": len(demand_perturbation.rows),
        "applied_count": len(demand_perturbation_applied_keys),
        "audit_csv": "data/canonical_demand_perturbations.csv",
        "measured_day_basis": "zero_based_after_warmup",
        "warmup_application_count": 0,
        "scope": "exact_node_id_item_id_demand_pairs",
        "multiplier_bounds": [
            DEMAND_MULTIPLIER_MIN,
            DEMAND_MULTIPLIER_MAX,
        ],
        "application_stage": "daily_demand_before_service_and_mrp_propagation",
    }

    physical_losses = defaultdict(lambda: {"supplier_flow_loss_qty": 0.0, "stock_writeoff_qty": 0.0, "external_quality_loss_qty": 0.0})
    for row in supplier_stock_flow_rows:
        key = (row["node_id"], row["item_id"], row["uom"])
        physical_losses[key]["supplier_flow_loss_qty"] += float(row["outgoing_unreliable_loss_qty"])
        physical_losses[key]["stock_writeoff_qty"] += float(row["stock_writeoff_qty"])
    for (node, item), qty in external_quality_loss_by_pair.items():
        physical_losses[(node, item, item_unit_map.get(item, ""))]["external_quality_loss_qty"] += qty
    unknown_inventory_pairs = [
        {"node_id": pair[0], "item_id": pair[1], "uom": item_unit_map.get(pair[1], ""),
         "quantity_days": round(quantity_days, 6), "reason": holding_cost_unknown_reasons[pair]}
        for pair, quantity_days in sorted(unknown_inventory_quantity_days.items()) if quantity_days > 0
    ]
    economic_valuation = {
        "schema_version": "etudecas.economic-valuation.v1",
        "status": "incomplete" if unknown_inventory_pairs else "complete",
        "complete": not unknown_inventory_pairs,
        "metric_basis": "known_subtotal_incomplete" if unknown_inventory_pairs else "configured_model_cost",
        "unknown_inventory_pairs": unknown_inventory_pairs,
        "warnings": ["unvalued_inventory_excluded_from_legacy_cost_subtotals"] if unknown_inventory_pairs else [],
        "legacy_numeric_keys": "total_cost and total_economic_exposure remain numeric known subtotals for compatibility; not complete totals when complete=false",
        "industrial_calibration_validated": False,
    }
    if unknown_inventory_pairs:
        economic_warnings.append("incomplete_inventory_valuation_no_economic_ranking")
    summary = {
        **({"initial_stock_availability": initial_stock_availability.audit()}
           if initial_stock_availability is not None else {}),
        "economic_valuation": economic_valuation,
        "demand_execution_contract": {
            "version": "source_demand_separate_from_planning_v1",
            "physical_demand_basis": "unsmoothed_source_daily_profile_with_explicit_perturbations",
            "mrp_signal_smoothing_days": mrp_signal_smoothing_days,
            "mrp_window": "forward_planning_only",
        },
        "model_qualifications": {
            "safety_calendar": safety_calendar,
            "static_mrp_requirement_pairs": initialization_policy["mrp_static_requirement_pairs"],
            "static_mrp_basis": "nominal_process_capacity_times_bom_not_observed_demand",
            "process_tau_semantics": "planning_cover_only_physical_duration_pending_business_confirmation",
            "reserved_inventory_holding": "excluded_from_available_stock_holding_pending_ownership_rule",
        },
        "physical_losses_by_item_uom": [{"node_id": key[0], "item_id": key[1], "uom": key[2], **values}
                                        for key, values in sorted(physical_losses.items())],
        "quantity_metric_contract": {
            "external_procured_rejected_qty": "Unexecuted capacity-limited requests; may recur on successive days, not physical destruction.",
            "external_quality_rejected_qty": "Ordered physical quantity not received because of modeled quality yield.",
            "aggregate_loss_totals": "Legacy arithmetic totals across heterogeneous units; use physical_losses_by_item_uom for interpretation.",
        },
        "input_file": str(input_path),
        "input_sha256": input_sha256,
        "scenario_id": str(scenario.get("id")),
        "sim_days": sim_days,
        "warmup_days": warmup_days,
        "timeline_days": sim_days,
        "total_simulated_timeline_days": total_timeline_days,
        "policy": {
            **({"mrp_execution_mode": args.mrp_execution_mode, "opening_purchase_availability": {
                "source": "explicit_opening_order_G_and_I_dates",
                "scope": "opening_purchase_orders_only_not_initial_stock_J_or_new_supplier_orders",
                "physical_receipt_date": "physical_delivery_day_G",
                "availability_date": "available_day_I",
                "source_dates_are": "planned_dates_executed_by_simulation_not_observed_actual_deliveries",
                "netting": "in_transit_and_recv_prev_future_qty_are_promised_availability_until_I_including_held_once",
                "physical_decomposition": "recv_prev_undelivered_qty_plus_held_pending_availability_qty_equals_recv_prev_future_qty",
                "order_arrival_day_and_actual_receipt_day_semantics": "availability_I_legacy_names_use_actual_physical_receipt_day_for_G",
                "costs": "opening_purchase_transport_zero_existing_convention_holding_includes_received_held_stock",
                "daily_csv": "data/production_stock_availability_daily.csv",
                "row_count": sum(row["order_type"] == "opening_purchase_order" for row in opening_purchase_availability.rows),
                "aggregate_purchase_count": len(supplier_delivery_orders),
                "unsupported": "warmup_initial_state_scaling_and_supplier_risk_overlays",
            }} if opening_purchase_availability is not None else {}),
            **({"dated_component_planning": {
                "scope": "component_procurement_with_downstream_netting_SD_manufacturing_preserved",
                "decision": "end_of_day_after_physical_production_and_customer_service",
                "horizon": "up_to_364_days_remaining_in_scenario_no_demand_past_simulation_end",
                "firm_policy": "credit_all_unique_firm_quantities_keep_lateness_no_automatic_duplicate_purchase",
                "production": "remaining_campaign_components_once_output_remaining_plus_unreleased_WIP_estimated_completion_not_physical_receipt",
                "completion_date": "max_one_day_tau_planning_cover_and_remaining_work_over_nominal_capacity_not_capacity_guarantee",
                "safety": "existing_max_targets_preserved_complement_after_dated_gross_requirements_within_coverage_not_reconstructed_ERP_rule",
                "reserve": "technical_requirement_separate_from_physical_consumption_restore_reserve_when_reconstructing_projected_stock",
                "daily_csv": "data/mrp_dated_plan_daily.csv", "weekly_csv": "data/mrp_dated_plan_weekly.csv" if args.output_profile == "full" else "",
                "supplier_boundary": "FIA_order_to_physical_delivery_once_no_departure_or_supplier_stock_claim_receipt_G_to_I_same_lot",
                "supplier_receipt_calendar": "monday_friday_candidate_without_holidays_not_user_confirmed_receipt_calendar",
                "supplier_receipt_policy": list(supplier_receipt_policies.values()),
                "supplier_capacity_and_cost": "existing_declared_lane_capacity_reliability_and_procurement_cost_assumptions_not_industrial_measurements",
                "inactive_supplier_stock": "historical_initial_supplier_stock_retained_but_not_used_to_net_aggregate_delivery_promises",
                "annual_portfolio_minimum": "no_extra_orders_outside_dated_requirements_for_component_scope",
            }} if dated_component_planning else {}),
            **({"source_boundary_supplies": {
                "schema_version": 1, "rows": list(source_boundary_policies.values()),
                "scope": "aggregate_unmodeled_factory_supply_boundary_not_detailed_manufacturing",
                "activation": "production_signal_source_forecast_and_explicit_graph_metadata",
                "target": "downstream_forecast_over_receipt_lead_plus_review_days",
                "netting": "available_stock_plus_all_committed_receipt_origins_before_order",
                "lot": "source_fixed_lot_rounded_once_with_each_received_batch_kept_separate",
                "capacity": "unknown_not_modeled_no_manufacturing_capacity_inferred",
                "valuation": "existing_external_procurement_convention_not_industrial_manufacturing_cost",
                "lead": "source_receipt_time_in_calendar_days_assumption_not_downstream_transport_lead",
            }} if source_boundary_policies else {}),
            **({"production_signal_source": "forecast",
                "production_signal_contract": "multilevel_forecast_seeds_each_output_once_capacity_remains_a_constraint",
                "mrp_opening_order_cover_mode": "quantity_netting_only_no_opening_bridge_deduction",
                "mrp_opening_order_cover_scope": "transport_replenishment_lead_review_and_source_safety_unchanged"}
               if forecast_production_signal else {}),
            **({"mrp_nonbinding_standard_order_pairs": sorted(nonbinding_standard_order_pair_keys),
                "mrp_nonbinding_standard_order_contract": "standard_reference_retained_no_mandatory_rounding_or_staggered_standard_chunks_physical_dispatch_multiple_unchanged"}
               if nonbinding_standard_order_pair_keys else {}),
            **({"mrp_forecast_source": "source", "mrp_forecasts": {
                "schema_version": 1, "origin": mrp_source_forecasts.origin_date,
                "row_count": mrp_source_forecasts.row_count,
                "repeat_period_days": mrp_source_forecasts.repeat_period_days,
                "calendar": "sunday_start_unconfirmed_industrial_convention",
                "vintage_selection": "latest_known_at_decision_no_future_vintage_no_cross_vintage_gap_filling",
                "missing_period": "explicit_nominal_forecast_fallback_zero_source_values_preserved",
                "current_bucket_policy": mrp_source_forecasts.current_bucket_policy,
                "physical_demand_unchanged": True,
                "source_scope": "finished_good_outflow_forecast_at_DC_mapped_to_modeled_customer_pair",
                "trace_coverage_scope": "finished_good_items_only_components_are_propagated_forecasts",
                "years_after_first": "explicit_repeated_annual_planning_scenario_not_industrial_observations",
                "source_plan_receipts_H_and_balances_K_used_as_orders": False,
            }} if mrp_source_forecasts is not None else {}),
            **({"production_mrp_safety_targets": True,
                "production_mrp_safety_scope": "manufactured_outputs_with_source_mrp_policy",
                "production_mrp_safety_contract": {
                    "target": "max_historical_target_source_quantity_output_signal_times_calendar_safety_days",
                    "stages": ["mps", "physical_production_controller"],
                    "diagnostic_mrp_target_is_distinct": True,
                    "capacity_signal_floor_lots_gains_tau_and_source_safety_unchanged": not forecast_production_signal,
                    "industrial_calibration_validated": False,
                }} if args.production_mrp_safety_targets else {}),
            **({"mrp_receipt_netting_mode": "within_cover",
                "mrp_receipt_netting_scope": "transport_replenishment",
                "mrp_receipt_netting_contract": {
                    "window": "decision_day_through_day_plus_target_window_days_minus_one_inclusive",
                    "receipt_date": "scheduled_availability_day",
                    "origins": ["standard_pipeline", "external_pipeline", "estimated_source_pipeline"],
                    "decision_snapshot": "before_transport_orders_on_review_days",
                    "trace_snapshot": "end_of_day_after_new_orders",
                    "source_buffer_controllers": "unchanged",
                    "limitation": "window_filter_only_not_full_time_phased_netting_no_intra_window_shortage_check",
                }} if dated_receipt_netting else {}),
            **({"initial_stock_availability_enabled": True}
               if initial_stock_availability is not None else {}),
            "safety_stock_days": safety_stock_days,
            "review_period_days": review_period_days,
            "mrp_review_period_days": mrp_review_period_days,
            "mrp_target_bucket_days": mrp_target_bucket_days,
            "mrp_target_cutover_context_days": mrp_target_cutover_context_days,
            "mrp_multisource_policy": args.mrp_multisource_policy,
            "mrp_multisource_min_annual_lot_window_days": mrp_multisource_min_annual_lot_window_days,
            "fg_target_days": fg_target_days,
            "demand_stock_target_days": demand_stock_target_days,
            "production_gap_gain": production_gap_gain,
            "production_smoothing": production_smoothing,
            "warmup_days": warmup_days,
            "warmup_profile_mode": args.warmup_profile_mode,
            "demand_profile_cycle_days": demand_profile_cycle_days,
            "reset_backlog_after_warmup": reset_backlog_after_warmup,
            "output_profile": args.output_profile,
            "lot_trace_enabled": bool(args.lot_trace),
            "opening_stock_bootstrap_scale": opening_stock_bootstrap_scale,
            **(
                {
                    "opening_observed_stock_scale": (
                        opening_observed_stock_scale_audit
                    )
                }
                if opening_observed_stock_scale_requested
                else {}
            ),
            **(
                {
                    "measurement_start_stock_scale": (
                        measurement_start_stock_scale_audit
                    )
                }
                if measurement_start_stock_scale_csv_path
                else {}
            ),
            **(
                {
                    "measurement_start_in_transit_scale": (
                        measurement_start_in_transit_scale_audit
                    )
                }
                if measurement_start_in_transit_scale_csv_path
                else {}
            ),
            "unmodeled_supplier_source_mode": unmodeled_supplier_source_mode,
            "stochastic_lead_times": bool(args.stochastic_lead_times),
            "lead_time_distribution_mode": lead_time_distribution_mode,
            "seed": int(args.seed),
            "common_random_numbers": bool(args.common_random_numbers),
            **(
                {"demand_perturbation": demand_perturbation_manifest}
                if demand_perturbation.enabled
                else {}
            ),
            **(
                {"warmup_boundary_audit": warmup_boundary_state_audit}
                if args.warmup_boundary_audit
                else {}
            ),
            "control_schedule": {
                "enabled": bool(control_schedule.enabled),
                "source_csv": str(control_schedule_path or ""),
                "sha256": control_schedule_sha256,
                "schedule_rows": len(control_schedule.rows),
                "matched_schedule_rows": matched_control_schedule_rows,
                "unmatched_schedule_rows": (
                    len(control_schedule.rows) - matched_control_schedule_rows
                ),
                "action_ledger_rows": (
                    len(control_action_ledger_rows)
                    if control_schedule.enabled
                    else 0
                ),
                "scheduled_actions": scheduled_control_actions,
                "resolved_actions": resolved_control_actions,
                "unresolved_actions": max(
                    0,
                    scheduled_control_actions - resolved_control_actions,
                ),
                "measured_day_basis": "zero_based_after_warmup",
                "neutral_without_schedule": True,
                "warnings": list(control_schedule.warnings),
            },
            **(
                {
                    "control_probe": {
                        "enabled": True,
                        "source_csv": str(control_probe_schedule_path),
                        "sha256": control_probe_schedule_sha256,
                        "schedule_rows": len(control_probe_rows),
                        "matched_schedule_rows": matched_control_probe_rows,
                        "unmatched_schedule_rows": max(
                            0,
                            len(control_probe_rows)
                            - matched_control_probe_rows,
                        ),
                        "scheduled_actions": control_probe_scheduled_actions,
                        "resolved_actions": len(resolved_probe_actions),
                        "unresolved_actions": max(
                            0,
                            control_probe_scheduled_actions
                            - len(resolved_probe_actions),
                        ),
                        "composition_rows": len(
                            control_probe_composition_rows
                        ),
                        "composition_mode": CONTROL_PROBE_MODE,
                        "composition_formula": (
                            "clip(feedback_effective + "
                            "(probe_effective - neutral_value))"
                        ),
                        "allowed_actions": list(CONTROL_PROBE_ACTIONS),
                        "clipped_action_count": len(
                            control_probe_clipped_rows
                        ),
                        "clipped_day_count": len(
                            {
                                int(row["day"])
                                for row in control_probe_clipped_rows
                            }
                        ),
                        "measured_day_basis": "zero_based_after_warmup",
                        "warmup_application_count": 0,
                        "audit_csv": (
                            "data/canonical_control_probe_composition.csv"
                        ),
                        "feedback_command_export_modified": False,
                        "incremental_physical_effect_claimed": False,
                        "warnings": list(control_probe.warnings),
                    }
                }
                if control_probe is not None
                else {}
            ),
            "control_provider": (
                {
                    **feedback_provider_metadata,
                    "provider_causal_contract_satisfied": bool(
                        feedback_provider_causal_contract_satisfied
                    ),
                    "closed_loop_claimed": feedback_closed_loop_claimed,
                    "closed_loop_claim_checks": (
                        feedback_closed_loop_claim_checks
                    ),
                    "closed_loop_claim_reasons": (
                        feedback_closed_loop_claim_reasons
                    ),
                    "direct_future_realization_access": False,
                    "mrp_demand_signal_smoothing_days_effective": int(
                        mrp_signal_smoothing_days
                    ),
                    "demand_realization_window_days_effective": int(
                        mrp_signal_smoothing_days
                    ),
                    "demand_window_direction": "forward_inclusive",
                    "future_profile_semantics": "realized_demand_path",
                    "controller_observation_max_future_day_offset": int(
                        controller_observation_forecast_lookahead_days
                    ),
                    "controller_observation_forecast_lookahead_days": int(
                        controller_observation_forecast_lookahead_days
                    ),
                    "future_realization_access": bool(
                        controller_observation_forecast_lookahead_days
                    ),
                    "future_information_contract_satisfied": bool(
                        future_information_contract_satisfied
                    ),
                    "observation_causal_contract_satisfied": bool(
                        future_information_contract_satisfied
                    ),
                    "physical_warmup_days": int(warmup_days),
                    "controller_dynamic_warmup_days": int(
                        controller_dynamic_warmup_days
                    ),
                    **(
                        {
                            "warmup_control_action_count": int(
                                warmup_feedback_command_count
                            )
                        }
                        if feedback_control_supports_priming
                        else {}
                    ),
                    "controller_warmup_matches_physical_warmup": bool(
                        controller_warmup_matches_physical_warmup
                    ),
                    "physical_action_applied": bool(
                        physically_applied_feedback_actions
                    ),
                    "physically_applied_action_count": len(
                        physically_applied_feedback_actions
                    ),
                    "matched_active_command_rows": matched_feedback_rows,
                    "unmatched_active_command_rows": max(
                        0,
                        len(feedback_control.rows) - matched_feedback_rows,
                    ),
                    "scheduled_active_actions": scheduled_feedback_actions,
                    "resolved_active_actions": resolved_feedback_actions,
                    "unresolved_active_actions": max(
                        0,
                        scheduled_feedback_actions - resolved_feedback_actions,
                    ),
                    "action_ledger_rows": len(control_action_ledger_rows),
                    "measured_day_basis": "zero_based_after_warmup",
                    "warnings": feedback_engine_warnings,
                    "artifacts": {
                        "observations": "data/canonical_closed_loop_observations.csv",
                        "decisions": "data/canonical_closed_loop_decisions.csv",
                        "commands": "data/canonical_closed_loop_commands.csv",
                        "action_ledger": "data/canonical_action_ledger.csv",
                        **(
                            {
                                "priming": (
                                    "data/canonical_controller_priming.csv"
                                )
                            }
                            if feedback_priming_rows
                            else {}
                        ),
                    },
                }
                if feedback_control is not None
                else {
                    "enabled": bool(control_schedule.enabled),
                    "mode": (
                        "daily_open_loop_schedule"
                        if control_schedule.enabled
                        else "historical_no_external_control"
                    ),
                    "integration_mode": (
                        "daily_open_loop_schedule"
                        if control_schedule.enabled
                        else "historical_no_external_control"
                    ),
                    "closed_loop_claimed": False,
                    "causal_lag_days": None,
                    "future_realization_access": False,
                }
            ),
            "supplier_risk": {
                "enabled": bool(supplier_risk_events),
                "events_csv": str(args.supplier_risk_events_csv or ""),
                "events_csv_sha256": supplier_risk_events_sha256,
                "event_count": len(supplier_risk_events),
                "warnings": supplier_risk_warnings,
                "neutral_without_events": True,
                **(
                    {
                        "opening_purchase_order_replay": {
                            "enabled": True,
                            "source_semantics": (
                                "observed_planned_opening_orders_not_observed_actual_otif"
                            ),
                            "risk_decision_date": "planned_physical_delivery_day",
                            "audit_rows": len(
                                opening_purchase_order_risk_audit_rows
                            ),
                            "affected_rows": sum(
                                1
                                for row in opening_purchase_order_risk_audit_rows
                                if str(row.get("risk_event_ids") or "")
                            ),
                            "warnings": opening_purchase_order_risk_warnings,
                            "audit_csv": (
                                "data/opening_purchase_order_supplier_risk_audit.csv"
                            ),
                            "capacity_semantics": (
                                "not_operationalized_without_dated_supplier_capacity_calendar"
                            ),
                        }
                    }
                    if args.supplier_risk_events_apply_to_opening_purchase_orders
                    else {}
                ),
            },
            "supplier_state_dependent_risk": {
                "lead_observation_basis": "realized_transport_duration_observed_at_receipt",
                "future_sampled_delays_are_observations": False,
                "enabled": bool(args.supplier_state_dependent_risks),
                "generated_event_count": len(supplier_state_risk_events),
                "observation_warmup_days": max(0, int(args.supplier_state_risk_observation_warmup_days or 0)),
                "stock_rules": [
                    "stock cover < 5 days for 5 consecutive days -> availability x0.95 for 7 days",
                    "stock cover < 3 days for 2 consecutive days -> availability x0.85 for 14 days",
                    "stock cover <= 0.25 day -> availability x0.70 for 21 days",
                ],
                "capacity_rules": [
                    "capacity utilization > 75% for 5 consecutive days -> capacity x0.97 for 7 days",
                    "capacity utilization >= 99.5% for 1 day -> capacity x0.92 for 7 days",
                    "capacity utilization > 85% for 3 consecutive days -> capacity x0.90 for 14 days",
                    "capacity utilization > 90% for 3 consecutive days -> capacity x0.85 for 14 days",
                ],
                "lead_rules": [
                    "observed lead ratio > 110% for 3 observed days -> lead time x1.10 for 7 days",
                    "observed lead ratio > 125% for 2 observed days -> lead time +3 days for 14 days",
                    "observed lead ratio > 135% for 2 observed days -> lead time +5 days for 14 days",
                ],
                "upstream_rules": [
                    "upstream rejection avg 7d > 10% for 2 days and stock cover < 7 days -> upstream availability x0.97 for 7 days",
                    "upstream rejection avg 14d > 50% and stock cover < 3 days -> upstream capacity x0.90 for 14 days",
                ],
                "reliability_quality_rules": [
                    "delivery loss rate > 3% for 2 days -> supplier reliability x0.95 for 14 days",
                    "delivery loss rate > 8% -> quality yield x0.90 for 14 days",
                ],
                "cost_rule": "upstream recourse cost ratio > 250% for 3 days -> upstream recourse cost x1.10 for 14 days",
                "state_effect_caps": (
                    "state-dependent effects are capped: availability/capacity >=70%, "
                    "reliability/quality >=75%, lead multiplier <=1.5, extra lead <=10 days, cost <=1.5"
                ),
            },
            "supplier_neutral_floor_test": {
                "enabled": bool(args.supplier_neutral_floors_csv),
                "floors_csv": str(args.supplier_neutral_floors_csv or ""),
                "capacity_override_pairs": len(supplier_capacity_floor_overrides),
                "stock_override_pairs": len(supplier_stock_floor_overrides),
                "warnings": supplier_floor_warnings,
            },
            "factory_nominal_capacity_test": {
                "enabled": bool(args.factory_nominal_capacities_csv),
                "capacities_csv": str(args.factory_nominal_capacities_csv or ""),
                "override_pairs": len(factory_capacity_overrides),
                "applied_processes": factory_capacity_override_applied,
                "warnings": factory_capacity_override_warnings,
            },
            "initialization_policy": {
                "mode": initialization_policy["mode"],
                "state_scale": initialization_policy["state_scale"],
                "factory_input_on_hand_days": initialization_policy["factory_input_on_hand_days"],
                "supplier_output_on_hand_days": initialization_policy["supplier_output_on_hand_days"],
                "distribution_center_on_hand_days": initialization_policy["distribution_center_on_hand_days"],
                "customer_on_hand_days": initialization_policy["customer_on_hand_days"],
                "seed_safety_time_on_hand": initialization_policy["seed_safety_time_on_hand"],
                "seed_estimated_source_on_hand": initialization_policy["seed_estimated_source_on_hand"],
                "seed_in_transit": initialization_policy["seed_in_transit"],
                "in_transit_fill_ratio": initialization_policy["in_transit_fill_ratio"],
                "seed_estimated_source_pipeline": initialization_policy["seed_estimated_source_pipeline"],
                "opening_production_order_bom_issue_mode": initialization_policy[
                    "opening_production_order_bom_issue_mode"
                ],
                "restore_opening_stock_after_warmup": initialization_policy["restore_opening_stock_after_warmup"],
                "seed_open_orders_from_january_snapshot": initialization_policy["seed_open_orders_from_january_snapshot"],
                "opening_open_order_source": opening_open_order_source,
                "opening_open_orders_horizon_days": initialization_policy["opening_open_orders_horizon_days"],
                "opening_open_orders_demand_multiplier": initialization_policy[
                    "opening_open_orders_demand_multiplier"
                ],
                "use_bom_demand_signal_for_mrp": initialization_policy["use_bom_demand_signal_for_mrp"],
                "mrp_demand_signal_source": initialization_policy["mrp_demand_signal_source"],
                "mrp_demand_signal_smoothing_days": initialization_policy[
                    "mrp_demand_signal_smoothing_days"
                ],
                "mrp_static_fallback_for_propagated_pairs": initialization_policy[
                    "mrp_static_fallback_for_propagated_pairs"
                ],
                "mrp_static_requirement_pairs": initialization_policy[
                    "mrp_static_requirement_pairs"
                ],
                "mrp_dynamic_requirement_pairs": initialization_policy[
                    "mrp_dynamic_requirement_pairs"
                ],
                "mrp_smoothed_cover_requirement_pairs": initialization_policy[
                    "mrp_smoothed_cover_requirement_pairs"
                ],
                "mrp_enforce_physical_safety_floor": initialization_policy[
                    "mrp_enforce_physical_safety_floor"
                ],
                "mrp_strict_safety_floor_from_safety_time": initialization_policy[
                    "mrp_strict_safety_floor_from_safety_time"
                ],
                "soft_safety_time_stock_target_factor": initialization_policy[
                    "soft_safety_time_stock_target_factor"
                ],
                "soft_safety_time_stock_target_factor_by_pair": initialization_policy[
                    "soft_safety_time_stock_target_factor_by_pair"
                ],
                "mrp_base_stock_floor_factor": initialization_policy["mrp_base_stock_floor_factor"],
                "mrp_base_stock_floor_factor_by_pair": initialization_policy[
                    "mrp_base_stock_floor_factor_by_pair"
                ],
            },
            "economic_policy": {
                "transport_cost_floor_per_unit": economic_policy["transport_cost_floor_per_unit"],
                "transport_cost_per_km_per_unit": economic_policy["transport_cost_per_km_per_unit"],
                "purchase_cost_floor_per_unit": economic_policy["purchase_cost_floor_per_unit"],
                "holding_cost_scale": economic_policy["holding_cost_scale"],
                "inventory_capital_cost_share_of_raw_holding": round(
                    economic_policy["inventory_capital_cost_share_of_raw_holding"],
                    6,
                ),
                "warehouse_operating_cost_share_of_raw_holding": round(
                    economic_policy["warehouse_operating_cost_share_of_raw_holding"],
                    6,
                ),
                "inventory_risk_cost_share_of_raw_holding": round(
                    economic_policy["inventory_risk_cost_share_of_raw_holding"],
                    6,
                ),
                "transport_cost_realism_multiplier": economic_policy["transport_cost_realism_multiplier"],
                "purchase_cost_realism_multiplier": economic_policy["purchase_cost_realism_multiplier"],
                "production_cost_enabled": economic_policy["production_cost_enabled"],
                "production_cost_mode": economic_policy["production_cost_mode"],
                "production_cost_target_share_of_total": round(
                    economic_policy["production_cost_target_share_of_total"],
                    6,
                ),
                "production_cost_basis": economic_policy["production_cost_basis"],
                "production_cost_line_shares": {
                    key: round(max(0.0, to_float(value, 0.0)), 6)
                    for key, value in sorted(economic_policy["production_cost_line_shares"].items())
                },
                "production_cost_line_profiles": dict(
                    sorted(economic_policy["production_cost_line_profiles"].items())
                ),
                "production_cost_unit_rates": {
                    key: round(max(0.0, to_float(value, 0.0)), 12)
                    for key, value in sorted(economic_policy["production_cost_unit_rates"].items())
                },
                "external_procurement_enabled": economic_policy["external_procurement_enabled"],
                "external_procurement_proactive_replenishment": economic_policy[
                    "external_procurement_proactive_replenishment"
                ],
                "supplier_risk_loss_gross_up": economic_policy[
                    "supplier_risk_loss_gross_up"
                ],
                "external_procurement_lead_days": economic_policy["external_procurement_lead_days"],
                "external_procurement_lead_mode": economic_policy["external_procurement_lead_mode"],
                "external_procurement_lead_time_scale": economic_policy["external_procurement_lead_time_scale"],
                "external_procurement_capacity_mode": economic_policy["external_procurement_capacity_mode"],
                "external_procurement_nominal_capacity_scale": economic_policy[
                    "external_procurement_nominal_capacity_scale"
                ],
                "external_procurement_seed_upstream_pipeline": economic_policy[
                    "external_procurement_seed_upstream_pipeline"
                ],
                "external_procurement_upstream_pipeline_fill_ratio": economic_policy[
                    "external_procurement_upstream_pipeline_fill_ratio"
                ],
                "external_procurement_daily_cap_days": economic_policy["external_procurement_daily_cap_days"],
                "external_procurement_min_daily_cap_qty": economic_policy["external_procurement_min_daily_cap_qty"],
                "external_procurement_unit_cost": economic_policy["external_procurement_unit_cost"],
                "external_procurement_cost_multiplier": economic_policy["external_procurement_cost_multiplier"],
                "external_procurement_transport_cost_per_unit": economic_policy["external_procurement_transport_cost_per_unit"],
            },
        },
        "counts": {
            "nodes": len(nodes),
            "edges": len(edges),
            "lanes": len(lanes),
            "demand_rows": len(demand_rows),
        },
        "production_tracking": {
            "input_material_pairs": [
                {"node_id": n, "item_id": i}
                for n, i in production_input_pairs
            ],
            "output_product_pairs": [
                {"node_id": n, "item_id": i}
                for n, i in production_output_pairs
            ],
            "unconstrained_process_inputs_not_in_relations": [
                {"node_id": n, "item_id": i}
                for n, i in unconstrained_input_pairs
            ],
            "item_unit_map": dict(sorted(item_unit_map.items())),
            "input_unit_conversions_applied": [
                {"node_id": n, "item_id": i, "from_unit": fu, "to_unit": tu}
                for n, i, fu, tu in sorted(input_unit_conversions_applied)
            ],
            "input_unit_mismatch_not_converted": [
                {"node_id": n, "item_id": i, "from_unit": fu, "to_unit": tu}
                for n, i, fu, tu in sorted(input_unit_mismatch_not_converted)
            ],
            "reference_transition_stocks": reference_transition_stock_rows,
            "customer_demand_daily_signal": [
                {"node_id": n, "item_id": i, "demand_per_day": round(v, 6)}
                for (n, i), v in sorted(demand_target_daily.items())
            ],
            "propagated_demand_daily_signal": [
                {"node_id": n, "item_id": i, "demand_per_day": round(v, 6)}
                for (n, i), v in sorted(propagated_demand_daily.items())
                if v > 0
            ],
            "assumed_supplier_nodes": assumed_supplier_nodes,
            "assumed_supply_edges": assumed_supply_edges,
            "observed_opening_stock_rows": observed_opening_stock_rows,
            "externally_sourced_unmodeled_pairs": [
                {"node_id": n, "item_id": i}
                for n, i in externally_sourced_pairs
            ],
            "opening_stock_bootstrap_pairs": opening_stock_bootstrap_rows,
            "explicit_initialization_stock_rows": initialization_state_rows,
            "explicit_initialization_pipeline_rows": initialization_pipeline_rows,
            "opening_open_order_rows": opening_open_order_rows,
            "pair_mrp_safety_policies": [
                {
                    "node_id": n,
                    "item_id": i,
                    "safety_time_days": round(pair_mrp_safety_time_days.get((n, i), 0.0), 6),
                    "safety_stock_qty": round(pair_mrp_safety_stock_qty.get((n, i), 0.0), 6),
                }
                for (n, i) in sorted(
                    {
                        pair
                        for pair in set(pair_mrp_safety_time_days) | set(pair_mrp_safety_stock_qty)
                        if pair_mrp_safety_time_days.get(pair, 0.0) > 0.0
                        or pair_mrp_safety_stock_qty.get(pair, 0.0) > 0.0
                    }
                )
            ],
            "safety_stock_reference": safety_reference_rows,
            "process_lot_execution_policies": [
                {
                    "node_id": str(node.get("id")),
                    "item_id": str(((proc.get("outputs") or [{}])[0] or {}).get("item_id") or ""),
                    "max_lots_per_week": round(
                        max(0.0, to_float(((proc.get("lot_execution") or {}).get("max_lots_per_week")), 0.0)),
                        6,
                    ),
                    "lot_multiple_qty": round(
                        max(0.0, to_float(((proc.get("lot_sizing") or {}).get("lot_multiple_qty")), 0.0)),
                        6,
                    ),
                    "source": str(((proc.get("lot_execution") or {}).get("source")) or ""),
                }
                for node in (nodes or [])
                for proc in (node.get("processes") or [])
                if (proc.get("outputs") or []) and max(
                    0.0,
                    to_float(((proc.get("lot_execution") or {}).get("max_lots_per_week")), 0.0),
                ) > 0.0
            ],
            "supplier_daily_capacity_pairs": supplier_capacity_metadata_rows,
            "supplier_nominal_parameter_rows": len(supplier_nominal_parameter_rows),
            "factory_nominal_capacity_rows": len(factory_nominal_capacity_rows),
            "supplier_stock_flow_rows": len(supplier_stock_flow_rows),
            "supplier_risk_events": supplier_risk_events,
            "supplier_risk_event_application_rows": len(supplier_risk_applied_rows),
            "unmodeled_supplier_source_policies": estimated_source_policy_rows,
            "lot_trace": {
                "enabled": bool(args.lot_trace),
                "lot_trace_contract_version": LOT_TRACE_CONTRACT_VERSION,
                "lot_count": len(lot_ledger.lots),
                "event_rows": len(lot_ledger.event_rows),
                "genealogy_rows": len(lot_ledger.genealogy_rows),
                "causal_link_rows": len(lot_causal_link_rows),
                "outputs": [
                    "production_lot_events.csv",
                    "production_lot_genealogy.csv",
                    "lot_causal_links.csv",
                ],
            },
            "production_plan_events": {
                "event_rows": len(production_plan_event_rows),
                "outputs": [
                    "production_plan_events.csv",
                ],
            },
            "production_campaigns": {
                "campaign_rows": len(production_campaign_rows),
                "delayed_campaign_rows": sum(
                    1
                    for row in production_campaign_rows
                    if str(row.get("status") or "") in {"completed_after_delay", "still_blocked", "not_started_blocked"}
                ),
                "outputs": [
                    "production_campaigns.csv",
                ],
            },
            "factory_nervousness": {
                "rows": len(factory_nervousness_rows),
                "high_rows": sum(1 for row in factory_nervousness_rows if str(row.get("nervousness_level") or "") == "high"),
                "medium_rows": sum(1 for row in factory_nervousness_rows if str(row.get("nervousness_level") or "") == "medium"),
                "outputs": [
                    "production_factory_nervousness.csv",
                ],
            },
            "mrp_trace": {
                "enabled": True,
                "tracked_pairs": len(mrp_trace_pairs),
                "trace_rows": len(mrp_trace_rows),
                "order_rows": len(mrp_order_rows),
                "trace_outputs": [
                    "mrp_trace_daily.csv",
                    "mrp_orders_daily.csv",
                ],
            },
            "lane_purchase_cost_stats": {
                "lanes_with_positive_purchase_cost": sum(1 for l in lanes if to_float(l.get("unit_purchase_cost"), 0.0) > 0),
                "lanes_with_zero_purchase_cost": sum(1 for l in lanes if to_float(l.get("unit_purchase_cost"), 0.0) <= 0),
                "lanes_with_explicit_transport_cost": lanes_with_explicit_transport_cost,
                "lanes_with_fallback_transport_cost": lanes_with_fallback_transport_cost,
            },
            "production_cost_allocation": production_cost_line_rows,
        },
        "kpis": {
            "total_demand": round(total_demand, 4),
            "measurement_starting_backlog": round(measurement_starting_backlog, 4),
            "warmup_backlog_cleared_qty": round(warmup_backlog_cleared_qty, 4),
            "measured_required_total": round(measured_required_total, 4),
            "total_served": round(total_served, 4),
            "ending_backlog": round(ending_backlog, 4),
            "fill_rate": round(fill_rate, 6),
            "total_shipped": round(total_shipped, 4),
            "total_arrived": round(total_arrived, 4),
            "total_produced": round(total_produced, 4),
            "avg_inventory": round(avg_inventory, 4),
            "ending_inventory": round(ending_inventory, 4),
            "total_transport_cost": round(total_transport_cost, 4),
            "total_holding_cost": round(total_holding_cost, 4),
            "total_warehouse_operating_cost": round(total_warehouse_operating_cost, 4),
            "total_inventory_risk_cost": round(total_inventory_risk_cost, 4),
            "total_inventory_cost_legacy_raw_holding": round(total_legacy_raw_holding_cost, 4),
            "total_purchase_cost": round(total_purchase_cost, 4),
            "total_production_cost": round(total_production_cost, 4),
            "total_logistics_cost": round(total_logistics_cost, 4),
            "total_cost": round(total_cost, 4),
            "known_cost_subtotal": round(total_cost, 4),
            "known_economic_exposure_subtotal": round(total_economic_exposure, 4),
            "total_supply_cost_accounting": round(total_cost, 4),
            "total_economic_exposure": round(total_economic_exposure, 4),
            "unmet_customer_demand_qty": round(unmet_customer_demand_qty, 4),
            "customer_delay_qty_day": round(customer_delay_qty_day, 4),
            "non_quality_loss_qty": round(non_quality_loss_qty, 4),
            "exceptional_supply_cost": round(exceptional_supply_cost, 4),
            "operational_risk_cost": round(operational_risk_cost, 4),
            "sales_at_risk_qty_proxy": round(unmet_customer_demand_qty, 4),
            "backlog_penalty_qty_day_proxy": round(customer_delay_qty_day, 4),
            "quality_loss_qty_proxy": round(non_quality_loss_qty, 4),
            "emergency_procurement_cost_proxy": round(exceptional_supply_cost, 4),
            "risk_economic_cost_proxy_total": round(operational_risk_cost, 4),
            "total_external_procured_ordered_qty": round(total_external_procured, 4),
            "total_external_procured_arrived_qty": round(total_external_procured_arrived, 4),
            "total_external_procured_rejected_qty": round(total_external_procured_rejected, 4),
            "total_external_quality_rejected_qty": round(total_external_quality_rejected, 4),
            "total_external_procured_qty": round(total_external_procured, 4),
            "total_external_procurement_cost": round(total_external_procurement_cost, 4),
            "total_estimated_source_ordered_qty": round(total_estimated_source_ordered, 4),
            "total_estimated_source_replenished_qty": round(total_estimated_source_replenished, 4),
            "total_estimated_source_rejected_qty": round(total_estimated_source_rejected, 4),
            "total_opening_stock_bootstrap_qty": round(total_opening_stock_bootstrap, 4),
            "total_explicit_initialization_stock_qty": round(total_initialization_stock_added, 4),
            "total_explicit_initialization_pipeline_qty": round(total_initialization_pipeline_seeded, 4),
            "total_opening_open_order_qty": round(total_opening_open_order_qty, 4),
            "total_unreliable_loss_qty": round(total_unreliable_loss_qty, 4),
            "total_supplier_capacity_binding_qty": round(total_supplier_capacity_binding_qty, 4),
            "cost_share_holding": round(holding_share, 6),
            "cost_share_warehouse_operating": round(warehouse_share, 6),
            "cost_share_inventory_risk": round(inventory_risk_share, 6),
            "cost_share_transport": round(transport_share, 6),
            "cost_share_purchase": round(purchase_share, 6),
            "cost_share_production": round(production_share, 6),
        },
        "economic_risk_kpi_basis": {
            "unmet_customer_demand_qty": "Demande client encore non servie en fin d'horizon. Le modele met la demande en retard; il ne l'annule pas automatiquement en vente perdue.",
            "customer_delay_qty_day": "Retard client cumule: somme des quantites en backlog en fin de jour. Unite: quantite-jour.",
            "non_quality_loss_qty": "Somme arithmetique de pertes physiques (unites heterogenes, ne pas classer avec ce total). Exclut les demandes non executees faute de capacite.",
            "exceptional_supply_cost": "Cout d'approvisionnement exceptionnel: cout des achats de secours / approvisionnement amont alternatif simule.",
            "operational_risk_cost": "Cout operationnel lie aux risques: cout de risque stock + cout d'approvisionnement exceptionnel. Ce n'est pas un compte de resultat comptable.",
        },
        "economic_consistency": {
            "status": "warn" if economic_warnings else "ok",
            "warnings": economic_warnings,
            "transport_cost_share_target_min": 0.02,
            "capital_holding_cost_share_target_max": 0.60,
            "warehouse_operating_cost_share_target_min": 0.10,
            "inventory_risk_cost_share_target_min": 0.05,
        },
        "top_backlog_pairs": top_backlog,
    }
    if args.supplier_state_risk_families != SUPPLIER_STATE_RISK_FAMILIES:
        state_policy = summary["policy"]["supplier_state_dependent_risk"]
        state_policy.update({
            "available_families": list(SUPPLIER_STATE_RISK_FAMILIES),
            "enabled_families": list(args.supplier_state_risk_families),
            "excluded_families": [f for f in SUPPLIER_STATE_RISK_FAMILIES if f not in args.supplier_state_risk_families],
            "family_filter_mode": "allowlist",
        })
        for family in ("stock", "capacity", "lead", "upstream"):
            if family not in args.supplier_state_risk_families:
                state_policy[family + "_rules"] = []
        state_policy["reliability_quality_rules"] = [
            rule for family, rule in zip(("reliability", "quality"), state_policy["reliability_quality_rules"])
            if family in args.supplier_state_risk_families
        ]
        if "cost" not in args.supplier_state_risk_families:
            state_policy["cost_rule"] = ""


    for node_id in assumed_supplier_nodes:
        assumptions_ledger_rows.append(
            {
                "category": "assumed_supplier_node",
                "node_id": str(node_id),
                "item_id": "",
                "edge_id": "",
                "source": "simulation_prep_assumption",
                "payload_json": json.dumps({"node_id": node_id}, ensure_ascii=False, sort_keys=True),
            }
        )
    for edge_id in assumed_supply_edges:
        assumptions_ledger_rows.append(
            {
                "category": "assumed_supply_edge",
                "node_id": "",
                "item_id": "",
                "edge_id": str(edge_id),
                "source": "simulation_prep_assumption",
                "payload_json": json.dumps({"edge_id": edge_id}, ensure_ascii=False, sort_keys=True),
            }
        )
    for row in supplier_capacity_metadata_rows:
        assumptions_ledger_rows.append(
            {
                "category": "supplier_capacity_basis",
                "node_id": str(row.get("node_id") or ""),
                "item_id": str(row.get("item_id") or ""),
                "edge_id": "",
                "source": str(row.get("capacity_basis") or row.get("basis") or "derived"),
                "payload_json": json.dumps(row, ensure_ascii=False, sort_keys=True),
            }
        )
    for row in estimated_source_policy_rows:
        assumptions_ledger_rows.append(
            {
                "category": "unmodeled_supplier_source_policy",
                "node_id": str(row.get("node_id") or ""),
                "item_id": str(row.get("item_id") or ""),
                "edge_id": "",
                "source": str(row.get("mode") or "estimated_replenishment"),
                "payload_json": json.dumps(row, ensure_ascii=False, sort_keys=True),
            }
        )
    for event in supplier_risk_events:
        assumptions_ledger_rows.append(
            {
                "category": "supplier_risk_event",
                "node_id": str(event.get("supplier_id") or ""),
                "item_id": str(event.get("item_id") or ""),
                "edge_id": str(event.get("edge_id") or ""),
                "source": str(event.get("source") or "supplier_risk_events"),
                "payload_json": json.dumps(event, ensure_ascii=False, sort_keys=True),
            }
        )
    for event in supplier_state_risk_events:
        assumptions_ledger_rows.append(
            {
                "category": "supplier_risk_event",
                "node_id": str(event.get("supplier_id") or ""),
                "item_id": str(event.get("item_id") or ""),
                "edge_id": str(event.get("edge_id") or ""),
                "source": str(event.get("source") or "state_dependent_supplier_risk"),
                "payload_json": json.dumps(event, ensure_ascii=False, sort_keys=True),
            }
        )
    for pair in sorted(set(pair_mrp_safety_time_days) | set(pair_mrp_safety_stock_qty)):
        assumptions_ledger_rows.append(
            {
                "category": "mrp_safety_policy",
                "node_id": str(pair[0]),
                "item_id": str(pair[1]),
                "edge_id": "",
                "source": "stocks_mrp_or_override",
                "payload_json": json.dumps(
                    {
                        "node_id": pair[0],
                        "item_id": pair[1],
                        "safety_time_days": round(pair_mrp_safety_time_days.get(pair, 0.0), 6),
                        "safety_stock_qty": round(pair_mrp_safety_stock_qty.get(pair, 0.0), 6),
                    },
                    ensure_ascii=False,
                    sort_keys=True,
                ),
            }
        )
    for node in (nodes or []):
        for proc in (node.get("processes") or []):
            outputs = proc.get("outputs") or []
            if not outputs:
                continue
            item_id = str((outputs[0] or {}).get("item_id") or "")
            payload = {
                "node_id": str(node.get("id") or ""),
                "item_id": item_id,
                "lot_sizing": proc.get("lot_sizing") or {},
                "lot_execution": proc.get("lot_execution") or {},
                "capacity": proc.get("capacity") or {},
            }
            assumptions_ledger_rows.append(
                {
                    "category": "process_execution_policy",
                    "node_id": str(node.get("id") or ""),
                    "item_id": item_id,
                    "edge_id": "",
                    "source": str(
                        ((proc.get("lot_execution") or {}).get("source"))
                        or ((proc.get("lot_sizing") or {}).get("source"))
                        or ((proc.get("capacity") or {}).get("source"))
                        or "process_policy"
                    ),
                    "payload_json": json.dumps(payload, ensure_ascii=False, sort_keys=True),
                }
            )
    for node_id, item_id in unconstrained_input_pairs:
        assumptions_ledger_rows.append(
            {
                "category": "unconstrained_process_input",
                "node_id": str(node_id),
                "item_id": str(item_id),
                "edge_id": "",
                "source": "missing_relations_acteurs_lane",
                "payload_json": json.dumps(
                    {"node_id": node_id, "item_id": item_id},
                    ensure_ascii=False,
                    sort_keys=True,
                ),
            }
        )
    assumptions_ledger_rows.sort(key=lambda r: (r["category"], r["node_id"], r["item_id"], r["edge_id"]))

    if initial_stock_availability is not None or opening_purchase_availability is not None:
        availability_path = data_path(output_dir, "production_stock_availability_daily.csv")
        with availability_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=InitialStockAvailability.DAILY_FIELDS)
            writer.writeheader()
            writer.writerows(stock_availability_daily_rows)

    summary_output_path = summary_path(output_dir, "first_simulation_summary.json")
    daily_path = data_path(output_dir, "first_simulation_daily.csv")
    report_output_path = report_path(output_dir, "first_simulation_report.md")
    safety_reference_path = report_path(output_dir, "mrp_safety_stock_reference.csv")
    input_stock_path = data_path(output_dir, "production_input_stocks_daily.csv")
    input_consumption_path = data_path(output_dir, "production_input_consumption_daily.csv")
    opening_production_consumption_path = data_path(output_dir, "opening_production_order_component_consumption.csv")
    input_arrival_path = data_path(output_dir, "production_input_replenishment_arrivals_daily.csv")
    input_shipment_path = data_path(output_dir, "production_input_replenishment_shipments_daily.csv")
    output_prod_path = data_path(output_dir, "production_output_products_daily.csv")
    supplier_shipment_path = data_path(output_dir, "production_supplier_shipments_daily.csv")
    supplier_stock_path = data_path(output_dir, "production_supplier_stocks_daily.csv")
    supplier_stock_flow_path = data_path(output_dir, "production_supplier_stock_flows_daily.csv")
    supplier_capacity_path = data_path(output_dir, "production_supplier_capacity_daily.csv")
    supplier_nominal_path = data_path(output_dir, "supplier_nominal_parameters.csv")
    factory_nominal_capacity_path = data_path(output_dir, "production_capacity_nominal_parameters.csv")
    supplier_risk_applied_path = data_path(output_dir, "supplier_risk_events_applied_daily.csv")
    opening_purchase_order_risk_audit_path = data_path(
        output_dir,
        "opening_purchase_order_supplier_risk_audit.csv",
    )
    supplier_state_risk_events_path = data_path(output_dir, "supplier_state_dependent_risk_events.csv")
    supplier_nominal_audit_path = report_path(output_dir, "supplier_nominal_audit.md")
    dc_stock_path = data_path(output_dir, "production_dc_stocks_daily.csv")
    demand_pair_path = data_path(output_dir, "production_demand_service_daily.csv")
    production_constraint_path = data_path(output_dir, "production_constraint_daily.csv")
    production_plan_event_path = data_path(output_dir, "production_plan_events.csv")
    production_campaign_path = data_path(output_dir, "production_campaigns.csv")
    factory_nervousness_path = data_path(output_dir, "production_factory_nervousness.csv")
    mrp_trace_path = data_path(output_dir, "mrp_trace_daily.csv")
    mrp_orders_path = data_path(output_dir, "mrp_orders_daily.csv")
    demand_perturbation_audit_path = data_path(
        output_dir,
        "canonical_demand_perturbations.csv",
    )
    control_action_ledger_path = data_path(output_dir, "canonical_action_ledger.csv")
    control_probe_composition_path = data_path(
        output_dir,
        "canonical_control_probe_composition.csv",
    )
    feedback_observations_path = data_path(
        output_dir,
        "canonical_closed_loop_observations.csv",
    )
    feedback_decisions_path = data_path(
        output_dir,
        "canonical_closed_loop_decisions.csv",
    )
    feedback_commands_path = data_path(
        output_dir,
        "canonical_closed_loop_commands.csv",
    )
    feedback_priming_path = data_path(
        output_dir,
        "canonical_controller_priming.csv",
    )
    lot_event_path = data_path(output_dir, "production_lot_events.csv")
    lot_genealogy_path = data_path(output_dir, "production_lot_genealogy.csv")
    lot_causal_link_path = data_path(output_dir, "lot_causal_links.csv")
    lot_path_audit_report_path = report_path(output_dir, "lot_path_audit.md")
    lot_path_audit_issues_path = data_path(output_dir, "lot_path_audit_issues.csv")
    assumptions_ledger_path = data_path(output_dir, "assumptions_ledger.csv")
    observed_opening_stock_path = data_path(output_dir, "initialization_observed_stock.csv")
    measurement_start_stock_adjustment_path = data_path(
        output_dir,
        "measurement_start_stock_adjustments.csv",
    )
    measurement_start_in_transit_adjustment_path = data_path(
        output_dir,
        "measurement_start_in_transit_adjustments.csv",
    )
    initialization_state_path = data_path(output_dir, "initialization_state.csv")
    initialization_pipeline_path = data_path(output_dir, "initialization_pipeline.csv")
    input_pivot_path = data_path(output_dir, "production_input_stocks_pivot.csv")
    compact_output = args.output_profile == "compact"

    summary_output_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    if demand_perturbation.enabled:
        with demand_perturbation_audit_path.open(
            "w",
            encoding="utf-8",
            newline="",
        ) as f:
            writer = csv.DictWriter(
                f,
                fieldnames=list(DEMAND_PERTURBATION_AUDIT_COLUMNS),
            )
            writer.writeheader()
            writer.writerows(demand_perturbation_audit_rows)
    with safety_reference_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "scope",
                "node_id",
                "item_id",
                "uom",
                "safety_time_days",
                "safety_time_source_days",
                "safety_time_calendar",
                "safety_time_effective_at_day",
                "safety_time_calendar_days",
                "planned_avg_daily_demand_qty",
                "observed_avg_daily_flow_qty",
                "stock_equiv_safety_time_qty",
                "explicit_safety_stock_qty",
                "effective_reference_stock_qty",
                "soft_simulated_target_qty",
                "max_mrp_demand_signal_qty",
                "max_mrp_safety_floor_qty",
                "max_soft_simulated_target_qty",
                "safety_reference_basis",
                "soft_safety_factor",
                "served_avg_daily_qty",
            ],
        )
        writer.writeheader()
        writer.writerows(safety_reference_rows)
    # This file is small and is the canonical daily KPI/cost source consumed by maps.
    # Keep it even in compact mode; compact only skips bulky diagnostic extracts.
    with daily_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(daily_rows[0].keys()) if daily_rows else [])
        if daily_rows:
            writer.writeheader()
            writer.writerows(daily_rows)

    if control_probe is not None:
        probe_rows = [
            control_probe_composition_rows[key]
            for key in sorted(control_probe_composition_rows)
        ]
        probe_extra_columns = sorted(
            {
                str(column)
                for row in probe_rows
                for column in row
                if column not in CONTROL_PROBE_COMPOSITION_COLUMNS
            }
        )
        with control_probe_composition_path.open(
            "w",
            encoding="utf-8",
            newline="",
        ) as f:
            writer = csv.DictWriter(
                f,
                fieldnames=[
                    *CONTROL_PROBE_COMPOSITION_COLUMNS,
                    *probe_extra_columns,
                ],
            )
            writer.writeheader()
            writer.writerows(probe_rows)

    control_action_ledger_extra_columns = sorted(
        {
            str(column)
            for row in control_action_ledger_rows
            for column in row
            if column not in CONTROL_LEDGER_COLUMNS
        }
    )
    with control_action_ledger_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                *CONTROL_LEDGER_COLUMNS,
                *control_action_ledger_extra_columns,
            ],
        )
        writer.writeheader()
        writer.writerows(control_action_ledger_rows)

    if feedback_control is not None:
        def write_feedback_rows(
            path: Path,
            rows: list[dict[str, Any]],
            base_fields: list[str],
        ) -> None:
            extra_fields = sorted(
                {
                    str(field)
                    for row in rows
                    for field in row
                    if field not in base_fields
                }
            )
            with path.open("w", encoding="utf-8", newline="") as feedback_file:
                writer = csv.DictWriter(
                    feedback_file,
                    fieldnames=[*base_fields, *extra_fields],
                )
                writer.writeheader()
                writer.writerows(rows)

        observation_rows = [dict(row) for row in feedback_control.observation_rows]
        decision_rows = [dict(row) for row in feedback_control.decision_rows]
        command_rows = [
            {
                "decision_day": command.decision_day,
                "effective_day": command.effective_day,
                "causal_lag_days": command.effective_day - command.decision_day,
                "policy": command.policy,
                "node_id": command.node_id,
                "supplier_id": command.supplier_id,
                "item_id": command.item_id,
                "dst_node_id": command.dst_node_id,
                "scope_type": (
                    "targeted" if any(command.scope_key) else "global"
                ),
                "active": int(command.active),
                "requested_json": json.dumps(
                    dict(command.requested or {}),
                    ensure_ascii=False,
                    sort_keys=True,
                ),
                "effective_json": json.dumps(
                    dict(command.effective or {}),
                    ensure_ascii=False,
                    sort_keys=True,
                ),
                "slew_limited_actions": ";".join(
                    command.slew_limited_actions
                ),
                "source_line": (
                    command.source_line
                    if command.source_line is not None
                    else ""
                ),
                **(
                    feedback_audit_metadata_for_day(command.effective_day)
                    if feedback_control_supports_priming
                    else {}
                ),
            }
            for command in feedback_control.commands
        ]
        write_feedback_rows(
            feedback_observations_path,
            observation_rows,
            ["day", "observation_hash", "observation_valid", "invalid_reason"],
        )
        write_feedback_rows(
            feedback_decisions_path,
            decision_rows,
            [
                "decision_day",
                "effective_day",
                "causal_lag_days",
                "observation_hash",
                "selected_policy",
                "confirmed_regime",
            ],
        )
        write_feedback_rows(
            feedback_commands_path,
            command_rows,
            [
                "decision_day",
                "effective_day",
                "causal_lag_days",
                "policy",
                "node_id",
                "supplier_id",
                "item_id",
                "dst_node_id",
                "scope_type",
                "active",
                "requested_json",
                "effective_json",
                "slew_limited_actions",
                "source_line",
            ],
        )
        if feedback_priming_rows:
            write_feedback_rows(
                feedback_priming_path,
                feedback_priming_rows,
                [
                    "day",
                    "observation_hash",
                    "observation_valid",
                    "invalid_reason",
                    "priming_observation",
                    "generated_command_count",
                    "active_command_row_count",
                ],
            )

    initialization_state_fields = [
        "node_id",
        "item_id",
        "category",
        "daily_signal",
        "cover_days",
        "added_opening_qty",
        "target_opening_stock",
    ]
    with initialization_state_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=initialization_state_fields)
        writer.writeheader()
        for row in initialization_state_rows:
            writer.writerow({field: row.get(field, "") for field in initialization_state_fields})

    observed_opening_stock_fields = [
        "node_id",
        "node_type",
        "item_id",
        "opening_stock_qty",
        "uom",
        "source",
    ]
    if opening_observed_stock_scale_requested:
        observed_opening_stock_fields.extend(
            [
                "input_opening_stock_qty",
                "opening_observed_stock_scale",
                "effective_opening_stock_qty",
                "base_stock_qty_after_scale",
                "mrp_snapshot_state_only",
            ]
        )
    with observed_opening_stock_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=observed_opening_stock_fields)
        writer.writeheader()
        for row in observed_opening_stock_rows:
            writer.writerow({field: row.get(field, "") for field in observed_opening_stock_fields})

    if measurement_start_stock_scale_csv_path:
        measurement_start_stock_adjustment_fields = [
            "measured_day",
            "node_id",
            "item_id",
            "uom",
            "scale",
            "stock_before_qty",
            "stock_after_qty",
            "stock_removed_qty",
            "stock_added_qty",
            "lot_trace_enabled",
            "lot_balance_before_qty",
            "lot_balance_after_qty",
            "lot_removed_qty",
            "lot_added_qty",
            "lot_balance_matches_stock_after",
            "source_csv",
            "source_csv_sha256",
        ]
        with measurement_start_stock_adjustment_path.open(
            "w",
            encoding="utf-8",
            newline="",
        ) as f:
            writer = csv.DictWriter(
                f,
                fieldnames=measurement_start_stock_adjustment_fields,
            )
            writer.writeheader()
            writer.writerows(measurement_start_stock_adjustment_rows)

    if measurement_start_in_transit_scale_csv_path:
        measurement_start_in_transit_adjustment_fields = [
            "measured_day",
            "node_id",
            "item_id",
            "uom",
            "scale",
            "in_transit_before_qty",
            "in_transit_after_qty",
            "in_transit_removed_qty",
            "standard_pipeline_before_qty",
            "standard_pipeline_after_qty",
            "standard_pipeline_removed_qty",
            "standard_pipeline_row_count",
            "lot_trace_enabled",
            "lot_pipeline_before_qty",
            "lot_pipeline_after_qty",
            "lot_pipeline_removed_qty",
            "lot_payload_count",
            "arrival_day_count",
            "arrival_days_json",
            "pipeline_matches_in_transit_before",
            "pipeline_matches_in_transit_after",
            "external_in_transit_unchanged_qty",
            "estimated_source_in_transit_unchanged_qty",
            "source_csv",
            "source_csv_sha256",
        ]
        with measurement_start_in_transit_adjustment_path.open(
            "w",
            encoding="utf-8",
            newline="",
        ) as f:
            writer = csv.DictWriter(
                f,
                fieldnames=measurement_start_in_transit_adjustment_fields,
            )
            writer.writeheader()
            writer.writerows(measurement_start_in_transit_adjustment_rows)

    initialization_pipeline_fields = [
        "node_id",
        "item_id",
        "category",
        "seeded_pipeline_qty",
        "lead_days",
        "lane_src",
        "source_file",
        "planning_element",
        "physical_delivery_day",
        "usable_day",
        "receipt_release_days",
    ]
    if args.supplier_risk_events_apply_to_opening_purchase_orders:
        initialization_pipeline_fields.extend(
            [
                "source_row",
                "supplier_id",
                "shipment_id",
                "risk_decision_day",
                "risk_event_ids",
                "planned_qty_before_risk",
                "physical_delivery_day_before_risk",
                "usable_day_before_risk",
                "receipt_release_days_before_risk",
            ]
        )
    with initialization_pipeline_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=initialization_pipeline_fields)
        writer.writeheader()
        for row in initialization_pipeline_rows:
            writer.writerow({field: row.get(field, "") for field in initialization_pipeline_fields})

    with input_stock_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["day", "node_id", "item_id", "stock_before_production", "stock_end_of_day"],
        )
        writer.writeheader()
        writer.writerows(input_stock_rows)

    if not compact_output:
        with input_consumption_path.open("w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["day", "node_id", "item_id", "consumed_qty", "uom"])
            writer.writeheader()
            writer.writerows(input_consumption_rows)

    with opening_production_consumption_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "day",
                "issue_day",
                "receipt_day",
                "node_id",
                "output_item_id",
                "component_node_id",
                "component_item_id",
                "bom_issue_mode",
                "opening_production_qty",
                "required_component_qty",
                "consumed_from_stock_qty",
                "assumed_initial_wip_qty",
                "shortage_assumed_wip_or_source_gap_qty",
                "source_id",
            ],
        )
        writer.writeheader()
        writer.writerows(opening_production_consumption_rows)

    with input_arrival_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["day", "node_id", "item_id", "arrived_qty", "uom"])
        writer.writeheader()
        writer.writerows(input_arrival_rows)

    if not compact_output:
        with input_shipment_path.open("w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["day", "node_id", "item_id", "shipped_to_node_qty", "uom"])
            writer.writeheader()
            writer.writerows(input_shipment_rows)

    with output_prod_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "day",
                "node_id",
                "item_id",
                "produced_qty",
                "executed_qty",
                "released_qty",
                "wip_end_qty",
                "cum_produced_qty",
                "stock_end_of_day",
            ],
        )
        writer.writeheader()
        writer.writerows(output_prod_rows)

    with demand_pair_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "day",
                "node_id",
                "item_id",
                "demand_qty",
                "required_with_backlog_qty",
                "served_qty",
                "backlog_end_qty",
                "available_before_service_qty",
            ],
        )
        writer.writeheader()
        writer.writerows(demand_pair_rows)

    with production_constraint_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "day",
                "node_id",
                "output_item_id",
                "desired_qty",
                "planned_qty_after_lot_rule",
                "actual_qty",
                "cap_qty",
                "capacity_limit_mode",
                "max_from_inputs_qty",
                "binding_cause",
                "binding_input_item_id",
                "shortfall_vs_desired_qty",
                "shortfall_vs_lot_plan_qty",
                "lot_policy_mode",
                "lot_fixed_qty",
                "lot_min_qty",
                "lot_max_qty",
                "lot_multiple_qty",
                "max_lots_per_week",
                "started_lots_this_week",
                "requested_lot_starts",
                "actual_lot_starts",
                "campaign_requested_qty",
                "campaign_started_qty",
                "campaign_remaining_start_qty",
                "campaign_remaining_end_qty",
            ],
        )
        writer.writeheader()
        writer.writerows(production_constraint_rows)

    with production_plan_event_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=PRODUCTION_PLAN_EVENT_FIELDS)
        writer.writeheader()
        writer.writerows(production_plan_event_rows)

    with production_campaign_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=PRODUCTION_CAMPAIGN_FIELDS)
        writer.writeheader()
        writer.writerows(production_campaign_rows)

    with factory_nervousness_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FACTORY_NERVOUSNESS_FIELDS)
        writer.writeheader()
        writer.writerows(factory_nervousness_rows)

    lot_csv_fields = lot_trace_csv_fields(
        dated_availability=dated_mrp_execution,
        opening_purchase_risks=args.supplier_risk_events_apply_to_opening_purchase_orders,
    )
    with lot_event_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=lot_csv_fields["events"])
        writer.writeheader()
        writer.writerows(lot_ledger.event_rows)

    with lot_genealogy_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=lot_csv_fields["genealogy"])
        writer.writeheader()
        writer.writerows(lot_ledger.genealogy_rows)

    from etudecas.simulation.run_format.exporter import CsvHashingWriter

    with lot_causal_link_path.open("w", encoding="utf-8", newline="") as f:
        lot_causal_link_hashing_writer = CsvHashingWriter(f)
        writer = csv.DictWriter(lot_causal_link_hashing_writer, fieldnames=LOT_CAUSAL_LINK_FIELDS)
        writer.writeheader()
        writer.writerows(lot_causal_link_rows)
    try:
        lot_causal_link_written_stat = lot_causal_link_path.stat()
    except OSError:
        lot_causal_link_written_stat = None

    generated_lot_audit_report_path: str | None = None
    if lot_ledger.enabled and not args.skip_lot_audit:
        lot_audit_script_path = Path(__file__).resolve().parents[1] / "analysis" / "audit_lot_paths.py"
        if lot_audit_script_path.exists():
            lot_audit_cmd = [
                sys.executable,
                str(lot_audit_script_path),
                "--output-root",
                str(output_dir),
                "--input",
                str(input_path),
                "--report",
                str(lot_path_audit_report_path),
                "--issues-csv",
                str(lot_path_audit_issues_path),
            ]
            try:
                subprocess.run(lot_audit_cmd, check=True, capture_output=True, text=True)
                generated_lot_audit_report_path = str(lot_path_audit_report_path)
            except subprocess.CalledProcessError as exc:
                print(f"[WARN] Lot path audit failed: {exc}", file=sys.stderr)
                if exc.stdout:
                    print(exc.stdout.strip(), file=sys.stderr)
                if exc.stderr:
                    print(exc.stderr.strip(), file=sys.stderr)
        else:
            print(f"[WARN] Lot path audit script not found: {lot_audit_script_path}", file=sys.stderr)

    with mrp_trace_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "day",
                "node_id",
                "item_id",
                "bb_qty",
                "bb_demand_signal_qty",
                "bb_demand_signal_raw_qty",
                "target_demand_signal_qty",
                "target_demand_signal_floor_qty",
                "target_demand_signal_window_days",
                "target_cutover_context_days",
                "target_demand_signal_display_qty",
                "target_demand_signal_display_floor_qty",
                "bb_backlog_qty",
                "gross_requirement_basis",
                "mrp_demand_signal_source",
                "mrp_demand_signal_smoothing_days",
                "safety_floor_qty",
                "soft_safety_target_qty",
                "coverage_target_qty",
                "target_stock_qty",
                "target_stock_display_qty",
                "backlog_target_qty",
                "target_with_backlog_qty",
                "stock_proj_qty",
                "recv_prev_today_qty",
                "recv_prev_future_qty",
                "inventory_position_qty",
                "bn_qty",
                "controlled_bn_qty",
                "control_order_multiplier",
                "control_safety_stock_multiplier",
                "planned_release_qty",
                "planned_receipt_qty",
                "planned_order_count",
                "planned_receipt_min_day",
                "planned_receipt_max_day",
                "review_period_days",
                "safety_time_days",
                "safety_time_source_days",
                "safety_time_calendar",
                "safety_stock_qty",
                "has_mrp_snapshot_policy",
            ] + (["held_release_within_cover_qty"] if initial_stock_availability is not None else [])
              + (MRP_DATED_RECEIPT_FIELDS if dated_receipt_netting else [])
              + (PRODUCTION_MRP_SAFETY_FIELDS if record_production_planning else [])
              + (MRP_SOURCE_FORECAST_FIELDS if mrp_source_forecasts is not None else [])
              + (SOURCE_BOUNDARY_TRACE_FIELDS if source_boundary_policies else [])
              + (["mrp_execution_mode", "recv_prev_undelivered_qty", "held_pending_availability_qty", "available_release_today_qty"] if dated_mrp_execution else [])
              + (MRP_NETWORK_PLAN_FIELDS if dated_component_planning else [])
              + (["mrp_standard_order_binding"] if nonbinding_standard_order_pair_keys else []),
        )
        writer.writeheader()
        writer.writerows(mrp_trace_rows)

    with mrp_orders_path.open("w", encoding="utf-8", newline="") as f:
        mrp_order_fields = [
                "day",
                "node_id",
                "item_id",
                "order_type",
                "src_node_id",
                "dst_node_id",
                "edge_id",
                "planning_status",
                "release_status",
                "receipt_status",
                "order_status_end_of_run",
                "release_qty",
                "planned_receipt_qty",
                "release_day",
                "order_date_imt",
                "arrival_day",
                "actual_receipt_day",
                "implied_cover_need_day",
                "lead_days",
                "lead_reference_days",
                "lead_cover_days",
                "safety_time_days",
                "safety_time_source_days",
                "safety_time_calendar",
                "reliability",
                "standard_order_qty",
                "mrp_share",
                "mrp_order_id",
                "shipment_id",
                "scenario_id",
                "causal_event_ids",
                "causal_root_ids",
                "causal_status",
                "baseline_reference_id",
            ]
        if args.supplier_risk_events_apply_to_opening_purchase_orders:
            mrp_order_fields.extend(
                [
                    "source_row",
                    "source_file",
                    "shipment_id",
                    "risk_decision_day",
                    "risk_event_ids",
                    "planned_physical_delivery_day_before_risk",
                    "planned_usable_day_before_risk",
                    "planned_receipt_qty_before_risk",
                ]
            )
        if dated_mrp_execution:
            mrp_order_fields.extend([
                "physical_delivery_day", "available_day", "actual_physical_receipt_day",
                "actual_available_day", "source_row", "source_file",
            ])
        if dated_component_planning:
            mrp_order_fields.extend(SUPPLIER_DELIVERY_ORDER_FIELDS)
        writer = csv.DictWriter(f, fieldnames=mrp_order_fields)
        writer.writeheader()
        writer.writerows(mrp_order_rows)

    if dated_component_planning:
        with data_path(output_dir, "mrp_dated_plan_daily.csv").open("w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["day", "node_id", "item_id", "uom", "action_scope"] + MRP_NETWORK_PLAN_FIELDS)
            writer.writeheader()
            writer.writerows(dated_plan_daily_rows)
        if args.output_profile == "full":
            with data_path(output_dir, "mrp_dated_plan_weekly.csv").open("w", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=["decision_day", "node_id", "item_id", "uom", "action_scope",
                                                      "kind", "identity", "target_day", "release_day", "requested_day", "qty"])
                writer.writeheader()
                writer.writerows(dated_plan_weekly_rows)

    with assumptions_ledger_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "category",
                "node_id",
                "item_id",
                "edge_id",
                "source",
                "payload_json",
            ],
        )
        writer.writeheader()
        writer.writerows(assumptions_ledger_rows)

    with supplier_shipment_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "day",
                "shipment_id",
                "risk_decision_day",
                "risk_event_ids",
                "src_node_id",
                "dst_node_id",
                "item_id",
                "edge_id",
                "shipped_qty",
                "pulled_qty",
                "lead_days",
                "arrival_day",
                "reliability",
                "uom",
                "transport_cost_basis",
                "source_inventory_reserved",
                "transport_cost_units",
                "transport_cost",
                "purchase_cost",
                "observation_day",
                "execution_status",
                "departure_executed",
                "arrival_executed",
                "executed_shipped_qty",
                "realized_departure_day",
                "realized_arrival_day",
                "planned_departure_day",
                "planned_arrival_day",
                "realized_transport_lead_days",
                "lead_time_information_status",
            ],
        )
        writer.writeheader()
        writer.writerows(supplier_shipment_rows)

    with supplier_stock_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["day", "node_id", "item_id", "stock_end_of_day"])
        writer.writeheader()
        writer.writerows(supplier_stock_rows)

    with supplier_stock_flow_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=SUPPLIER_STOCK_FLOW_FIELDS)
        writer.writeheader()
        writer.writerows(supplier_stock_flow_rows)

    with supplier_capacity_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "day",
                "node_id",
                "item_id",
                "capacity_qty_per_day",
                "used_qty",
                "remaining_capacity_qty",
                "utilization",
            ],
        )
        writer.writeheader()
        writer.writerows(supplier_capacity_daily_rows)

    with supplier_nominal_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=SUPPLIER_NOMINAL_PARAMETER_FIELDS)
        writer.writeheader()
        writer.writerows(supplier_nominal_parameter_rows)

    with factory_nominal_capacity_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FACTORY_NOMINAL_CAPACITY_FIELDS)
        writer.writeheader()
        writer.writerows(factory_nominal_capacity_rows)

    with supplier_risk_applied_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=SUPPLIER_RISK_APPLIED_FIELDS)
        writer.writeheader()
        writer.writerows(supplier_risk_applied_rows)

    if args.supplier_risk_events_apply_to_opening_purchase_orders:
        with opening_purchase_order_risk_audit_path.open(
            "w",
            encoding="utf-8",
            newline="",
        ) as f:
            writer = csv.DictWriter(
                f,
                fieldnames=OPENING_PURCHASE_ORDER_RISK_AUDIT_FIELDS,
            )
            writer.writeheader()
            writer.writerows(opening_purchase_order_risk_audit_rows)

    with supplier_state_risk_events_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=SUPPLIER_STATE_RISK_EVENT_FIELDS)
        writer.writeheader()
        writer.writerows(supplier_state_risk_event_rows)

    supplier_nominal_audit_path.write_text(
        build_supplier_nominal_audit_report(
            rows=supplier_nominal_parameter_rows,
            supplier_risk_events=supplier_risk_events,
            supplier_risk_warnings=supplier_risk_warnings,
        ),
        encoding="utf-8",
    )

    with dc_stock_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["day", "node_id", "item_id", "stock_end_of_day"])
        writer.writeheader()
        writer.writerows(dc_stock_rows)

    if not compact_output:
        # Pivot file for easier read: one column per (factory,item) input stock.
        input_pairs = sorted({(str(r["node_id"]), str(r["item_id"])) for r in input_stock_rows})
        per_day_values: dict[int, dict[tuple[str, str], float]] = defaultdict(dict)
        for r in input_stock_rows:
            day = int(r["day"])
            key = (str(r["node_id"]), str(r["item_id"]))
            per_day_values[day][key] = to_float(r.get("stock_end_of_day", r.get("stock_before_production")), 0.0)
        with input_pivot_path.open("w", encoding="utf-8", newline="") as f:
            fieldnames = ["day"] + [pair_label(n, i) for n, i in input_pairs]
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for day in sorted(per_day_values.keys()):
                row = {"day": day}
                for n, i in input_pairs:
                    row[pair_label(n, i)] = round(per_day_values[day].get((n, i), 0.0), 6)
                writer.writerow(row)

    generated_plots: dict[str, str] = {}
    if not args.skip_plots:
        generated_plots = try_generate_plots(
            input_stock_rows=input_stock_rows,
            output_prod_rows=output_prod_rows,
            supplier_shipment_rows=supplier_shipment_rows,
            supplier_factory_items=supplier_factory_items,
            dc_factory_items=dc_factory_items,
            dc_node_ids=dc_node_ids,
            output_dir=output_dir,
            item_unit_map=item_unit_map,
        )
        legacy_agg_input_plot = output_dir / "production_input_stocks.png"
        if legacy_agg_input_plot.exists():
            legacy_agg_input_plot.unlink()
    plot_root = plots_path(output_dir)
    if args.map_output:
        map_output_path = Path(args.map_output)
    else:
        default_map_name = f"supply_graph_{output_dir.name}.html"
        map_output_path = map_path(output_dir, default_map_name)
    generated_map_path: str | None = None
    if not args.skip_map:
        map_script_path = Path(args.map_script)
        if map_script_path.exists():
            map_output_path.parent.mkdir(parents=True, exist_ok=True)
            map_cmd = [
                sys.executable,
                str(map_script_path),
                "--input",
                str(input_path),
                "--output",
                str(map_output_path),
                "--sim-input-stocks-csv",
                str(input_stock_path),
                "--sim-output-products-csv",
                str(output_prod_path),
                "--demand-service-csv",
                str(demand_pair_path),
                "--sim-input-stocks-png-dir",
                str(plot_root),
                "--sim-output-products-png-dir",
                str(plot_root),
                "--supplier-shipments-csv",
                str(supplier_shipment_path),
                "--supplier-stocks-csv",
                str(supplier_stock_path),
                "--supplier-stock-flows-csv",
                str(supplier_stock_flow_path),
                "--supplier-capacity-csv",
                str(supplier_capacity_path),
                "--supplier-nominal-parameters-csv",
                str(supplier_nominal_path),
                "--factory-nominal-capacities-csv",
                str(factory_nominal_capacity_path),
                "--input-arrivals-csv",
                str(input_arrival_path),
                "--dc-stocks-csv",
                str(dc_stock_path),
                "--production-constraint-csv",
                str(production_constraint_path),
                "--safety-reference-csv",
                str(safety_reference_path),
                "--daily-kpi-csv",
                str(daily_path),
                "--supplier-local-criticality-csv",
                str(data_path(output_dir, "supplier_local_criticality_ranking.csv")),
                "--supplier-local-criticality-json",
                str(summary_path(output_dir, "supplier_local_criticality_summary.json")),
            ]
            if args.map_payload_mode == "chunked":
                map_cmd.append("--chunked-embedded-payload")
            elif args.map_payload_mode == "compressed":
                map_cmd.append("--compress-embedded-payload")
            elif args.map_payload_mode == "external":
                map_cmd.append("--externalize-payload")
            try:
                subprocess.run(map_cmd, check=True, capture_output=True, text=True)
                generated_map_path = str(map_output_path)
            except subprocess.CalledProcessError as exc:
                print(f"[WARN] Map generation failed: {exc}", file=sys.stderr)
                if exc.stdout:
                    print(exc.stdout.strip(), file=sys.stderr)
                if exc.stderr:
                    print(exc.stderr.strip(), file=sys.stderr)
        else:
            print(f"[WARN] Map script not found: {map_script_path}", file=sys.stderr)

    detailed_input_plot_paths = [
        path
        for key, path in sorted(generated_plots.items())
        if key.startswith("production_input_stocks_by_material_")
    ]
    detailed_output_plot_paths = [
        path
        for key, path in sorted(generated_plots.items())
        if key.startswith("production_output_products_by_factory_")
    ]
    detailed_supplier_plot_paths = [
        path
        for key, path in sorted(generated_plots.items())
        if key.startswith("production_supplier_input_stocks_by_material_")
    ]
    detailed_dc_plot_paths = [
        path
        for key, path in sorted(generated_plots.items())
        if key.startswith("production_dc_factory_outputs_by_material_")
    ]

    output_pairs_txt = ", ".join(pair_label(n, i) for n, i in production_output_pairs) or "n/a"
    unconstrained_txt = ", ".join(pair_label(n, i) for n, i in unconstrained_input_pairs) or "none"
    conversion_count = len(input_unit_conversions_applied)
    mismatch_count = len(input_unit_mismatch_not_converted)
    assumed_nodes_txt = ", ".join(assumed_supplier_nodes) if assumed_supplier_nodes else "none"
    assumed_edges_txt = ", ".join(assumed_supply_edges) if assumed_supply_edges else "none"
    safety_reference_preview_rows = [
        row
        for row in safety_reference_rows
        if row["safety_time_days"] > 0.0 or row["explicit_safety_stock_qty"] > 0.0
    ][:40]
    if safety_reference_preview_rows:
        safety_reference_preview_md = "\n".join(
            [
                "| Scope | Noeud | Item | Delai secu j | Demande MRP moy/j | Stock equiv delai moy | Cible physique moy | Max cible physique | Base | Unite |",
                "|---|---:|---:|---:|---:|---:|---:|---:|---|---|",
            ]
            + [
                "| {scope} | {node_id} | {item_id} | {safety_time_days} | {planned_avg_daily_demand_qty} | {stock_equiv_safety_time_qty} | {soft_simulated_target_qty} | {max_soft_simulated_target_qty} | {safety_reference_basis} | {uom} |".format(
                    **row
                )
                for row in safety_reference_preview_rows
            ]
        )
    else:
        safety_reference_preview_md = "Aucune politique de delai/stock de securite detectee."

    mrp_validation_by_pair: dict[tuple[str, str], dict[str, Any]] = {}
    release_by_pair_day: dict[tuple[str, str], dict[int, float]] = defaultdict(lambda: defaultdict(float))
    old_release_by_pair_day: dict[tuple[str, str], dict[int, float]] = defaultdict(lambda: defaultdict(float))
    for row in mrp_order_rows:
        if str(row.get("order_type") or "") != "lane_release":
            continue
        node_id = str(row.get("dst_node_id") or row.get("node_id") or "")
        item_id = str(row.get("item_id") or "")
        if not node_id or not item_id or not (
            node_id.startswith("M-") or node_id.startswith("DC-") or is_upstream_internal_site(node_id)
        ):
            continue
        pair = (node_id, item_id)
        qty = max(0.0, to_float(row.get("release_qty"), 0.0))
        imt_day = int(to_float(row.get("order_date_imt"), 0.0))
        sim_day = int(to_float(row.get("day"), 0.0))
        release_by_pair_day[pair][imt_day] += qty
        old_release_by_pair_day[pair][sim_day] += qty
        rec = mrp_validation_by_pair.setdefault(
            pair,
            {
                "node_id": node_id,
                "item_id": item_id,
                "standard_order_qty": 0.0,
                "total_release_qty": 0.0,
                "pre_jan_release_qty": 0.0,
            },
        )
        rec["standard_order_qty"] = max(
            rec["standard_order_qty"],
            max(0.0, to_float(row.get("standard_order_qty"), 0.0)),
        )
        rec["total_release_qty"] += qty
        if imt_day < 0:
            rec["pre_jan_release_qty"] += qty

    industrial_validation_rows: list[dict[str, Any]] = []
    for pair, rec in mrp_validation_by_pair.items():
        imt_series = release_by_pair_day.get(pair, {})
        old_series = old_release_by_pair_day.get(pair, {})
        if not imt_series:
            continue
        peak_imt_day, peak_imt_qty = max(imt_series.items(), key=lambda it: it[1])
        old_peak_day, old_peak_qty = max(old_series.items(), key=lambda it: it[1]) if old_series else (0, 0.0)
        old_day0_qty = old_series.get(0, 0.0)
        std_qty = max(0.0, to_float(rec.get("standard_order_qty"), 0.0))
        lots_at_peak = peak_imt_qty / std_qty if std_qty > 1e-9 else 0.0
        remark = ""
        if std_qty >= 1_000_000.0:
            remark = "Lot FIA tres eleve a valider avec l'industriel."
        elif 0.0 < std_qty <= 1.0 and rec["total_release_qty"] >= 100_000.0:
            remark = "Quantite standard=1 non interpretable comme lot industriel; lot/campagne interne a renseigner."
        elif std_qty > 1.0 and lots_at_peak > 10.0:
            remark = "Concentration MRP a valider; plusieurs lots commandes le meme jour IMT."
        elif old_day0_qty > 0.0 and old_day0_qty > max(peak_imt_qty * 2.0, std_qty * 2.0):
            remark = "Pic initial redate avant le 1er janvier via order_date_IMT; affichage MRP corrige."
        if remark:
            industrial_validation_rows.append(
                {
                    "node_id": rec["node_id"],
                    "item_id": rec["item_id"].replace("item:", ""),
                    "standard_order_qty": round(std_qty, 6),
                    "old_day0_qty": round(old_day0_qty, 6),
                    "old_peak_qty": round(old_peak_qty, 6),
                    "old_peak_day": old_peak_day,
                    "imt_peak_qty": round(peak_imt_qty, 6),
                    "imt_peak_day": peak_imt_day,
                    "pre_jan_release_qty": round(max(0.0, rec["pre_jan_release_qty"]), 6),
                    "lots_at_peak": round(lots_at_peak, 3) if std_qty > 1e-9 else "",
                    "remark": remark,
                }
            )
    industrial_validation_rows = sorted(
        industrial_validation_rows,
        key=lambda r: (
            0 if "Concentration" in str(r["remark"]) else 1,
            -max(0.0, to_float(r.get("imt_peak_qty"), 0.0)),
        ),
    )
    if industrial_validation_rows:
        industrial_validation_md = "\n".join(
            [
                "| Noeud | Item | Lot std | Ancien pic J0 | Pic IMT | Jour IMT | Avant J0 | Lots au pic | Remarque |",
                "|---|---:|---:|---:|---:|---:|---:|---:|---|",
            ]
            + [
                "| {node_id} | {item_id} | {standard_order_qty} | {old_day0_qty} | {imt_peak_qty} | {imt_peak_day} | {pre_jan_release_qty} | {lots_at_peak} | {remark} |".format(
                    **row
                )
                for row in industrial_validation_rows[:30]
            ]
        )
    else:
        industrial_validation_md = "Aucune concentration MRP ou lot atypique detecte."
    unmodeled_process_capacity_rows: list[tuple[str, str, str]] = []
    for node in nodes:
        node_id = str(node.get("id") or "")
        for proc in node.get("processes") or []:
            if not (proc.get("inputs") or []):
                continue
            cap = to_float(((proc.get("capacity") or {}).get("max_rate")), 0.0)
            if cap > 0.0:
                continue
            output_ids = [
                str((out or {}).get("item_id") or "").replace("item:", "")
                for out in (proc.get("outputs") or [])
                if str((out or {}).get("item_id") or "")
            ]
            unmodeled_process_capacity_rows.append(
                (node_id, str(proc.get("id") or "n/a"), ", ".join(output_ids) or "n/a")
            )
    if unmodeled_process_capacity_rows:
        capacity_note_lines = [
            "",
            "Process internes sans capacite source: la simulation ne les bloque pas par capacite, mais conserve les contraintes de lots, d'intrants et de besoin.",
            "| Noeud | Process | Sortie |",
            "|---|---|---:|",
        ]
        capacity_note_lines.extend(
            f"| {node_id} | {proc_id} | {outputs} |"
            for node_id, proc_id, outputs in unmodeled_process_capacity_rows[:10]
        )
        industrial_validation_md = f"{industrial_validation_md}\n" + "\n".join(capacity_note_lines)
    generated_generic_run_path: str | None = None
    try:
        from etudecas.simulation.run_format import export_run_package
        from etudecas.simulation.run_format.exporter import profile_written_csv

        generic_run_metadata: dict[str, Any] = {
            "producer": "simulation_engine",
        }
        if demand_perturbation.enabled:
            generic_run_metadata["demand_perturbation"] = (
                demand_perturbation_manifest
            )
        generic_run_path = export_run_package(
            output_dir=output_dir,
            input_graph=input_path,
            map_html=Path(generated_map_path) if generated_map_path else None,
            extra_metadata=generic_run_metadata,
            lot_causal_link_profile=profile_written_csv(
                lot_causal_link_path, LOT_CAUSAL_LINK_FIELDS,
                lot_causal_link_rows, lot_causal_link_written_stat,
                written_sha256=lot_causal_link_hashing_writer.hexdigest(),
            ),
        )
        generated_generic_run_path = str(generic_run_path)
    except Exception as exc:
        print(f"[WARN] Generic run package export failed: {exc}", file=sys.stderr)

    report = f"""# First simulation report

## Run setup
- Input: {summary['input_file']}
- Scenario: {summary['scenario_id']}
- Measured horizon (days): {summary['sim_days']}
- Warm-up (days): {summary['warmup_days']}
- Warm-up demand profile mode / cycle: {summary['policy']['warmup_profile_mode']} / {summary['policy']['demand_profile_cycle_days']} days
- Total simulated timeline (days): {summary['timeline_days']}
- Output profile: {summary['policy']['output_profile']}
- Lot trace enabled: {summary['policy']['lot_trace_enabled']}
- Safety stock policy (days): {summary['policy']['safety_stock_days']}
- Replenishment review period (customer/DC, days): {summary['policy']['review_period_days']}
- Upstream factory MRP review period (days): {summary['policy']['mrp_review_period_days']}
- MRP target bucket (days): {summary['policy']['mrp_target_bucket_days']}
- MRP target cutover context (days): {summary['policy']['mrp_target_cutover_context_days']}
- MRP multi-source policy / min annual lot window: {summary['policy']['mrp_multisource_policy']} / {summary['policy']['mrp_multisource_min_annual_lot_window_days']} days
- Finished-goods target cover (days): {summary['policy']['fg_target_days']}
- Production stock-gap gain: {summary['policy']['production_gap_gain']}
- Production smoothing factor: {summary['policy']['production_smoothing']}
- Opening stock bootstrap scale: {summary['policy']['opening_stock_bootstrap_scale']}
- Initialization mode: {summary['policy']['initialization_policy']['mode']}
- Initialization stock days factory / supplier FG / DC / customer: {summary['policy']['initialization_policy']['factory_input_on_hand_days']} / {summary['policy']['initialization_policy']['supplier_output_on_hand_days']} / {summary['policy']['initialization_policy']['distribution_center_on_hand_days']} / {summary['policy']['initialization_policy']['customer_on_hand_days']}
- Initialization synthetic safety/source buffers: safety-time on hand={summary['policy']['initialization_policy'].get('seed_safety_time_on_hand', True)} / estimated-source on hand={summary['policy']['initialization_policy'].get('seed_estimated_source_on_hand', True)}
- Initialization seed in-transit / fill ratio / estimated-source pipeline: {summary['policy']['initialization_policy']['seed_in_transit']} / {summary['policy']['initialization_policy']['in_transit_fill_ratio']} / {summary['policy']['initialization_policy']['seed_estimated_source_pipeline']}
- Opening open-orders reconstruction enabled / horizon days: {summary['policy']['initialization_policy']['seed_open_orders_from_january_snapshot']} / {summary['policy']['initialization_policy']['opening_open_orders_horizon_days']}
- Opening open-orders source: {summary['policy']['initialization_policy'].get('opening_open_order_source', 'none')}
- Opening production-order BOM issue mode: {summary['policy']['initialization_policy'].get('opening_production_order_bom_issue_mode', 'receipt')}
- Opening open-orders demand multiplier / BOM signal for MRP: {summary['policy']['initialization_policy']['opening_open_orders_demand_multiplier']} / {summary['policy']['initialization_policy']['use_bom_demand_signal_for_mrp']}
- MRP demand signal source: {summary['policy']['initialization_policy']['mrp_demand_signal_source']}
- MRP demand signal smoothing / static fallback on propagated pairs: {summary['policy']['initialization_policy']['mrp_demand_signal_smoothing_days']} j / {summary['policy']['initialization_policy']['mrp_static_fallback_for_propagated_pairs']}
- Forced static MRP requirement pairs: {summary['policy']['initialization_policy'].get('mrp_static_requirement_pairs', [])}
- Forced dynamic MRP requirement pairs: {summary['policy']['initialization_policy'].get('mrp_dynamic_requirement_pairs', [])}
- Smoothed lead-cover requirement pairs: {summary['policy']['initialization_policy'].get('mrp_smoothed_cover_requirement_pairs', [])}
- MRP physical safety floor enforced: {summary['policy']['initialization_policy']['mrp_enforce_physical_safety_floor']}
- MRP strict safety floor from safety time only: {summary['policy']['initialization_policy']['mrp_strict_safety_floor_from_safety_time']}
- Soft safety-time physical stock target factor: {summary['policy']['initialization_policy']['soft_safety_time_stock_target_factor']}
- Soft safety-time pair factors: {summary['policy']['initialization_policy']['soft_safety_time_stock_target_factor_by_pair']}
- Base stock floor factor: {summary['policy']['initialization_policy']['mrp_base_stock_floor_factor']}
- Base stock floor pair factors: {summary['policy']['initialization_policy']['mrp_base_stock_floor_factor_by_pair']}
- Unmodeled supplier source mode: {summary['policy']['unmodeled_supplier_source_mode']}
- Stochastic lead times: {summary['policy']['stochastic_lead_times']}
- Lead-time distribution mode: {summary['policy']['lead_time_distribution_mode']}
- Random seed: {summary['policy']['seed']}
- Common random numbers: {summary['policy']['common_random_numbers']}
- Daily control schedule enabled / rows / matched: {summary['policy']['control_schedule']['enabled']} / {summary['policy']['control_schedule']['schedule_rows']} / {summary['policy']['control_schedule']['matched_schedule_rows']}
- Daily control schedule source / SHA-256: {summary['policy']['control_schedule']['source_csv'] or 'none'} / {summary['policy']['control_schedule']['sha256'] or 'n/a'}
- Control provider mode / closed-loop claimed / causal lag: {summary['policy']['control_provider']['mode']} / {summary['policy']['control_provider']['closed_loop_claimed']} / {summary['policy']['control_provider']['causal_lag_days']}
- Supplier risk events enabled / count: {summary['policy']['supplier_risk']['enabled']} / {summary['policy']['supplier_risk']['event_count']}
- Supplier risk warnings: {summary['policy']['supplier_risk']['warnings']}
- Supplier neutral floor test enabled / capacity pairs / stock pairs: {summary['policy']['supplier_neutral_floor_test']['enabled']} / {summary['policy']['supplier_neutral_floor_test']['capacity_override_pairs']} / {summary['policy']['supplier_neutral_floor_test']['stock_override_pairs']}
- Factory nominal capacity test enabled / applied processes: {summary['policy']['factory_nominal_capacity_test']['enabled']} / {summary['policy']['factory_nominal_capacity_test']['applied_processes']}
- Economic policy transport floor /km: {summary['policy']['economic_policy']['transport_cost_floor_per_unit']} / {summary['policy']['economic_policy']['transport_cost_per_km_per_unit']}
- Economic policy purchase floor: {summary['policy']['economic_policy']['purchase_cost_floor_per_unit']}
- Holding cost scale: {summary['policy']['economic_policy']['holding_cost_scale']}
- Inventory cost split capital / warehouse / risk: {summary['policy']['economic_policy']['inventory_capital_cost_share_of_raw_holding']} / {summary['policy']['economic_policy']['warehouse_operating_cost_share_of_raw_holding']} / {summary['policy']['economic_policy']['inventory_risk_cost_share_of_raw_holding']}
- Transport / purchase realism multipliers: {summary['policy']['economic_policy']['transport_cost_realism_multiplier']} / {summary['policy']['economic_policy']['purchase_cost_realism_multiplier']}
- Production cost enabled / target share: {summary['policy']['economic_policy']['production_cost_enabled']} / {summary['policy']['economic_policy']['production_cost_target_share_of_total']}
- Production cost basis: {summary['policy']['economic_policy']['production_cost_basis']}
- Production cost line shares: {summary['policy']['economic_policy']['production_cost_line_shares']}
- Supplier upstream supply enabled: {summary['policy']['economic_policy']['external_procurement_enabled']}
- Supplier upstream proactive replenishment: {summary['policy']['economic_policy']['external_procurement_proactive_replenishment']}
- Temporary supplier-risk losses grossed up immediately by MRP: {summary['policy']['economic_policy'].get('supplier_risk_loss_gross_up', True)}
- Supplier upstream lead days: {summary['policy']['economic_policy']['external_procurement_lead_days']}
- Supplier upstream lead mode / scale: {summary['policy']['economic_policy'].get('external_procurement_lead_mode', 'policy_fixed')} / {summary['policy']['economic_policy'].get('external_procurement_lead_time_scale', 1.0)}
- Supplier upstream capacity mode / nominal scale: {summary['policy']['economic_policy'].get('external_procurement_capacity_mode', 'policy_cap')} / {summary['policy']['economic_policy'].get('external_procurement_nominal_capacity_scale', 1.0)}
- Supplier upstream pipeline seed / fill ratio: {summary['policy']['economic_policy'].get('external_procurement_seed_upstream_pipeline', False)} / {summary['policy']['economic_policy'].get('external_procurement_upstream_pipeline_fill_ratio', 0.0)}
- Supplier upstream daily cap days: {summary['policy']['economic_policy']['external_procurement_daily_cap_days']}
- Supplier upstream min daily cap qty: {summary['policy']['economic_policy']['external_procurement_min_daily_cap_qty']}
- Supplier upstream unit cost / multiplier / transport unit: {summary['policy']['economic_policy']['external_procurement_unit_cost']} / {summary['policy']['economic_policy']['external_procurement_cost_multiplier']} / {summary['policy']['economic_policy']['external_procurement_transport_cost_per_unit']}
- Nodes: {summary['counts']['nodes']}
- Edges: {summary['counts']['edges']}
- Flux transport (edge x item): {summary['counts']['lanes']}
- Demand rows: {summary['counts']['demand_rows']}
- Input material pairs tracked: {len(production_input_pairs)}
- Output product pairs tracked: {len(production_output_pairs)} ({output_pairs_txt})
- Inputs non modelises par Relations_acteurs (non bloquants): {len(unconstrained_input_pairs)} ({unconstrained_txt})
- Conversions d'unites BOM appliquees: {conversion_count}
- Mismatch d'unites non convertis: {mismatch_count}
- Assumed supplier nodes (explicitly tagged, includes '?'): {len(assumed_supplier_nodes)} ({assumed_nodes_txt})
- Assumed supply edges (explicitly tagged, includes '?'): {len(assumed_supply_edges)} ({assumed_edges_txt})
- Supplier upstream sourcing for unmodeled source pairs: {len(externally_sourced_pairs)}
- Opening stock bootstrap pairs (lead-time coverage at max capacity): {len(opening_stock_bootstrap_rows)}
- Opening open-order rows seeded: {len(opening_open_order_rows)}
- MRP trace tracked pairs / rows / orders: {summary['production_tracking']['mrp_trace']['tracked_pairs']} / {summary['production_tracking']['mrp_trace']['trace_rows']} / {summary['production_tracking']['mrp_trace']['order_rows']}
- Lot trace lots / events / genealogy rows: {summary['production_tracking']['lot_trace']['lot_count']} / {summary['production_tracking']['lot_trace']['event_rows']} / {summary['production_tracking']['lot_trace']['genealogy_rows']}
- Production plan event rows: {summary['production_tracking']['production_plan_events']['event_rows']}
- Production campaigns / delayed campaigns: {summary['production_tracking']['production_campaigns']['campaign_rows']} / {summary['production_tracking']['production_campaigns']['delayed_campaign_rows']}
- Factory nervousness rows high / medium: {summary['production_tracking']['factory_nervousness']['high_rows']} / {summary['production_tracking']['factory_nervousness']['medium_rows']}

## KPIs
- Total demand: {summary['kpis']['total_demand']}
- Total served: {summary['kpis']['total_served']}
- Fill rate: {summary['kpis']['fill_rate']}
- Ending backlog: {summary['kpis']['ending_backlog']}
- Total produced: {summary['kpis']['total_produced']}
- Total shipped: {summary['kpis']['total_shipped']}
- Avg inventory: {summary['kpis']['avg_inventory']}
- Ending inventory: {summary['kpis']['ending_inventory']}
- Transport cost: {summary['kpis']['total_transport_cost']}
- Holding cost (capital tied-up): {summary['kpis']['total_holding_cost']}
- Warehouse operating cost: {summary['kpis']['total_warehouse_operating_cost']}
- Stock risk cost (obsolescence / compliance / depreciation): {summary['kpis']['total_inventory_risk_cost']}
- Legacy raw holding cost before split: {summary['kpis']['total_inventory_cost_legacy_raw_holding']}
- Purchase cost (from order_terms sell_price): {summary['kpis']['total_purchase_cost']}
- Allocated production cost: {summary['kpis']['total_production_cost']}
- Logistics cost (transport + inventory capital + warehouse + inventory risk): {summary['kpis']['total_logistics_cost']}
- Total cost: {summary['kpis']['total_cost']}
- Total supplier upstream ordered qty: {summary['kpis']['total_external_procured_ordered_qty']}
- Total supplier upstream arrived qty: {summary['kpis']['total_external_procured_arrived_qty']}
- Supplier upstream arrived includes opening upstream pipeline receipts when the upstream pipeline seed is enabled.
- Total supplier upstream rejected qty (cap-limited): {summary['kpis']['total_external_procured_rejected_qty']}
- Exceptional upstream procurement cost: {summary['kpis']['total_external_procurement_cost']}
- Unserved customer demand at horizon end: {summary['kpis']['unmet_customer_demand_qty']}
- Customer delay cumulated quantity-days: {summary['kpis']['customer_delay_qty_day']}
- Rejected or lost quantity: {summary['kpis']['non_quality_loss_qty']}
- Operational risk cost: {summary['kpis']['operational_risk_cost']}
- Total estimated source ordered qty: {summary['kpis']['total_estimated_source_ordered_qty']}
- Total estimated source replenished qty: {summary['kpis']['total_estimated_source_replenished_qty']}
- Total estimated source rejected qty: {summary['kpis']['total_estimated_source_rejected_qty']}
- Cost share capital holding / warehouse / inventory risk / transport / purchase / production: {summary['kpis']['cost_share_holding']} / {summary['kpis']['cost_share_warehouse_operating']} / {summary['kpis']['cost_share_inventory_risk']} / {summary['kpis']['cost_share_transport']} / {summary['kpis']['cost_share_purchase']} / {summary['kpis']['cost_share_production']}
- Total opening stock bootstrap qty: {summary['kpis']['total_opening_stock_bootstrap_qty']}
- Total explicit initialization stock qty: {summary['kpis']['total_explicit_initialization_stock_qty']}
- Total explicit initialization pipeline qty: {summary['kpis']['total_explicit_initialization_pipeline_qty']}
- Total opening open-order qty: {summary['kpis']['total_opening_open_order_qty']}
- Total unreliable supplier loss qty: {summary['kpis']['total_unreliable_loss_qty']}
- Total supplier capacity binding qty: {summary['kpis']['total_supplier_capacity_binding_qty']}
- Economic consistency status: {summary['economic_consistency']['status']}
- Economic consistency warnings: {summary['economic_consistency']['warnings']}

## Top backlog pairs
{json.dumps(summary['top_backlog_pairs'], indent=2, ensure_ascii=False)}

## Safety stock reference
Calcul: `stock equiv delai = demande moyenne journaliere MRP x delai de securite`. Quand une trace MRP existe, la demande moyenne vient du signal reel utilise par le MRP (`bb_demand_signal_qty`), pas d'une capacite ou d'un besoin statique gonfle. Si le mode strict est actif, le plancher physique MRP vient uniquement de cette couverture de delai de securite. La cible physique simulee applique le facteur global `{summary['policy']['initialization_policy']['soft_safety_time_stock_target_factor']}` ou un facteur specifique par couple si renseigne.

{safety_reference_preview_md}

## Remarques validation industrielle
Le graphe `Reappro amont` utilise maintenant `order_date_IMT` pour dater les ordres MRP. Les commandes du carnet initial peuvent donc apparaitre avant J0 au lieu d'etre empilees artificiellement au 1er janvier.

{industrial_validation_md}

## Files
- summaries/first_simulation_summary.json
- run/run_manifest.json ({generated_generic_run_path or 'not generated'})
- reports/mrp_safety_stock_reference.csv
- data/first_simulation_daily.csv
- data/production_input_stocks_daily.csv
- data/opening_production_order_component_consumption.csv
- data/production_output_products_daily.csv
- data/production_demand_service_daily.csv
- data/production_constraint_daily.csv
- data/production_plan_events.csv
- data/production_campaigns.csv
- data/production_factory_nervousness.csv
- data/production_lot_events.csv
- data/production_lot_genealogy.csv
- data/lot_causal_links.csv
- reports/lot_path_audit.md ({generated_lot_audit_report_path or 'not generated'})
- data/lot_path_audit_issues.csv ({lot_path_audit_issues_path if generated_lot_audit_report_path else 'not generated'})
- data/mrp_trace_daily.csv
- data/mrp_orders_daily.csv
- data/canonical_action_ledger.csv
- data/canonical_closed_loop_observations.csv (feedback mode only)
- data/canonical_closed_loop_decisions.csv (feedback mode only)
- data/canonical_closed_loop_commands.csv (feedback mode only)
- data/assumptions_ledger.csv
- data/initialization_observed_stock.csv
- data/initialization_state.csv
- data/initialization_pipeline.csv
- data/production_supplier_shipments_daily.csv
- data/production_supplier_stocks_daily.csv
- data/production_supplier_stock_flows_daily.csv
- data/production_supplier_capacity_daily.csv
- data/supplier_nominal_parameters.csv
- data/production_capacity_nominal_parameters.csv
- data/supplier_risk_events_applied_daily.csv
- data/supplier_state_dependent_risk_events.csv
- reports/supplier_nominal_audit.md
- Additional detailed CSVs: {'generated' if summary['policy']['output_profile'] == 'full' else 'skipped in compact mode'}
- production_input_stocks_by_material_*.png ({', '.join(detailed_input_plot_paths) if detailed_input_plot_paths else 'not generated'})
- production_output_products.png ({generated_plots.get('production_output_products_png', 'not generated')})
- production_output_products_by_factory_*.png ({', '.join(detailed_output_plot_paths) if detailed_output_plot_paths else 'not generated'})
- production_supplier_input_stocks_by_material_*.png ({', '.join(detailed_supplier_plot_paths) if detailed_supplier_plot_paths else 'not generated'})
- production_dc_factory_outputs_by_material_*.png ({', '.join(detailed_dc_plot_paths) if detailed_dc_plot_paths else 'not generated'})
- maps/supply_graph_poc_geocoded_map_with_factory_hover.html ({generated_map_path or 'not generated'})
"""
    report_output_path.write_text(report, encoding="utf-8")

    print(f"[OK] Simulation summary: {summary_output_path.resolve()}")
    print(f"[OK] Simulation report: {report_output_path.resolve()}")
    print(f"[OK] MRP safety stock reference CSV: {safety_reference_path.resolve()}")
    print(f"[OK] Simulation daily CSV: {daily_path.resolve()}")
    if demand_perturbation.enabled:
        print(
            "[OK] Canonical demand perturbation CSV: "
            f"{demand_perturbation_audit_path.resolve()}"
        )
    print(f"[OK] Production input stocks CSV: {input_stock_path.resolve()}")
    print(f"[OK] Production output products CSV: {output_prod_path.resolve()}")
    print(f"[OK] Production demand service CSV: {demand_pair_path.resolve()}")
    print(f"[OK] Production constraint CSV: {production_constraint_path.resolve()}")
    print(f"[OK] Production plan events CSV: {production_plan_event_path.resolve()}")
    print(f"[OK] Production campaigns CSV: {production_campaign_path.resolve()}")
    print(f"[OK] Factory nervousness CSV: {factory_nervousness_path.resolve()}")
    print(f"[OK] Production lot events CSV: {lot_event_path.resolve()}")
    print(f"[OK] Production lot genealogy CSV: {lot_genealogy_path.resolve()}")
    print(f"[OK] Lot causal links CSV: {lot_causal_link_path.resolve()}")
    if generated_generic_run_path:
        print(f"[OK] Generic run package: {Path(generated_generic_run_path).resolve()}")
    if generated_lot_audit_report_path:
        print(f"[OK] Lot path audit report: {lot_path_audit_report_path.resolve()}")
        print(f"[OK] Lot path audit issues CSV: {lot_path_audit_issues_path.resolve()}")
    elif args.skip_lot_audit:
        print("[INFO] Lot path audit skipped (--skip-lot-audit).")
    print(f"[OK] MRP trace CSV: {mrp_trace_path.resolve()}")
    print(f"[OK] MRP orders CSV: {mrp_orders_path.resolve()}")
    print(f"[OK] Canonical action ledger CSV: {control_action_ledger_path.resolve()}")
    if control_probe is not None:
        print(
            "[OK] Closed-loop control probe composition CSV: "
            f"{control_probe_composition_path.resolve()}"
        )
    if feedback_control is not None:
        print(f"[OK] Closed-loop observations CSV: {feedback_observations_path.resolve()}")
        print(f"[OK] Closed-loop decisions CSV: {feedback_decisions_path.resolve()}")
        print(f"[OK] Closed-loop commands CSV: {feedback_commands_path.resolve()}")
        if feedback_priming_rows:
            print(f"[OK] Controller priming CSV: {feedback_priming_path.resolve()}")
    print(f"[OK] Assumptions ledger CSV: {assumptions_ledger_path.resolve()}")
    print(f"[OK] Initialization observed stock CSV: {observed_opening_stock_path.resolve()}")
    if measurement_start_stock_scale_csv_path:
        print(
            "[OK] Measurement-start stock adjustment CSV: "
            f"{measurement_start_stock_adjustment_path.resolve()}"
        )
    if measurement_start_in_transit_scale_csv_path:
        print(
            "[OK] Measurement-start in-transit adjustment CSV: "
            f"{measurement_start_in_transit_adjustment_path.resolve()}"
        )
    print(f"[OK] Initialization synthetic stock CSV: {initialization_state_path.resolve()}")
    print(f"[OK] Initialization pipeline CSV: {initialization_pipeline_path.resolve()}")
    print(f"[OK] Production supplier shipments CSV: {supplier_shipment_path.resolve()}")
    print(f"[OK] Production supplier stocks CSV: {supplier_stock_path.resolve()}")
    print(f"[OK] Production supplier stock flows CSV: {supplier_stock_flow_path.resolve()}")
    print(f"[OK] Production supplier capacity CSV: {supplier_capacity_path.resolve()}")
    print(f"[OK] Supplier nominal parameters CSV: {supplier_nominal_path.resolve()}")
    print(f"[OK] Production nominal capacity CSV: {factory_nominal_capacity_path.resolve()}")
    print(f"[OK] Supplier risk applied CSV: {supplier_risk_applied_path.resolve()}")
    print(f"[OK] Supplier state-dependent risk events CSV: {supplier_state_risk_events_path.resolve()}")
    print(f"[OK] Supplier nominal audit report: {supplier_nominal_audit_path.resolve()}")
    if compact_output:
        print("[INFO] Compact output profile: bulky detailed input/DC CSVs skipped; first_simulation_daily.csv is kept.")
    else:
        print(f"[OK] Production input consumption CSV: {input_consumption_path.resolve()}")
        print(f"[OK] Production input replenishment arrivals CSV: {input_arrival_path.resolve()}")
        print(f"[OK] Production input replenishment shipments CSV: {input_shipment_path.resolve()}")
        print(f"[OK] Production input stocks pivot CSV: {input_pivot_path.resolve()}")
        print(f"[OK] Production distribution center stocks CSV: {dc_stock_path.resolve()}")
    if generated_plots:
        for _, path in sorted(generated_plots.items()):
            print(f"[OK] Plot generated: {Path(path).resolve()}")
    else:
        reason = "--skip-plots" if args.skip_plots else "matplotlib unavailable"
        print(f"[INFO] Plot generation skipped ({reason}).")
    if generated_map_path:
        print(f"[OK] Hover map generated: {Path(generated_map_path).resolve()}")
    elif args.skip_map:
        print("[INFO] Map generation skipped (--skip-map).")


if __name__ == "__main__":
    main()
