"""Pure dated material planning, independent of the daily physical simulation.

Existing commitments are netted before proposing additional purchases, even
when late. This explicit no-duplicate-purchase convention is not claimed to be
the unidentified industrial ERP policy. Dates of firm receipts never change.
The signed balances are projections, not negative physical inventories.
"""
from __future__ import annotations

from dataclasses import dataclass
from bisect import bisect_left, bisect_right
from collections import defaultdict
from datetime import date
from decimal import Decimal
from math import ceil, floor, fsum, isfinite, nextafter
from typing import Iterable, Mapping


@dataclass(frozen=True)
class Requirement:
    requirement_id: str
    due_day: int
    qty: float


@dataclass(frozen=True)
class ExternalComponentService:
    """Physical allocations to uses outside the modeled finished products."""

    allocations: tuple[Requirement, ...]
    remaining: tuple[Requirement, ...]
    demand_qty: float
    backlog_start_qty: float
    consumed_qty: float
    available_end_qty: float


def _component_quantity(value, *, uom: str, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float, Decimal)):
        raise ValueError(f"{field} must be a numeric component quantity")
    quantity = _number(value, field)
    if uom == "UN" and quantity != floor(quantity):
        raise ValueError(f"{field} must be integer for physical UN")
    return quantity


class ExternalComponentDemandCalendar:
    """One selected incremental scenario, never a sum of rolling MRP vintages.

    Weekly quantities are already net of the modeled product scope in the
    scenario estimator. This class neither derives them from stock nor subtracts
    a BOM again. Unprovided periods remain outside the declared scenario; they
    are not industrial observations of zero demand. Repeated years are synthetic.
    """

    def __init__(self, payload, *, pair_uoms: Mapping, origin_date: str, horizon_days: int):
        if not isinstance(payload, dict) or type(payload.get("schema_version")) is not int or payload["schema_version"] != 1:
            raise ValueError("External component demands require schema_version 1")
        if payload.get("origin") != origin_date:
            raise ValueError("External component demand origin must match the simulation")
        date.fromisoformat(origin_date)
        if type(horizon_days) is not int or horizon_days <= 0:
            raise ValueError("External component horizon must be a positive integer")
        self.scenario_id = payload.get("scenario_id")
        if not isinstance(self.scenario_id, str) or not self.scenario_id.strip():
            raise ValueError("External component scenario_id is required")
        if payload.get("semantics") != "incremental_non_modelled_component_use":
            raise ValueError("External component rows must describe incremental non-modeled uses")
        repeat = payload.get("repeat_period_days")
        if repeat is not None and (type(repeat) is not int or repeat != 365):
            raise ValueError("External component repetition must explicitly be 365 days or null")
        self.repeat_period_days = repeat
        self.horizon_days = horizon_days
        rows = payload.get("rows")
        if not isinstance(rows, list) or not rows:
            raise ValueError("External component rows must be nonempty")
        self.row_count = len(rows)
        self._daily: dict = defaultdict(list)
        self._provenance: dict = {}
        intervals: dict = defaultdict(list)
        seen: set[str] = set()
        all_pairs = set()
        for row in rows:
            if not isinstance(row, dict):
                raise ValueError("External component row must be an object")
            identity = row.get("demand_id")
            _identity(identity, seen, "external demand_id")
            pair = (row.get("node_id"), row.get("item_id"))
            uom = row.get("uom")
            if (any(not isinstance(part, str) or not part.strip() for part in pair)
                    or pair not in pair_uoms or not isinstance(uom, str) or not uom or pair_uoms[pair] != uom):
                raise ValueError("External demand must identify a modeled component with its exact unit")
            known, start, length = (row.get(k) for k in ("known_day", "period_start_day", "period_days"))
            if (any(type(day) is not int for day in (known, start, length))
                    or not 0 <= known <= start < 365 or not 1 <= length <= 7 or start + length > 365):
                raise ValueError("External component periods must lie in year one and be known by their start")
            if any(start < previous_end and previous_start < start + length
                   for previous_start, previous_end in intervals[pair]):
                raise ValueError("External component periods overlap; select one source plan rather than add vintages")
            intervals[pair].append((start, start + length))
            qty = _component_quantity(row.get("qty"), uom=uom, field="external component qty")
            for field in ("source_file", "source_cells", "estimation_basis"):
                if not isinstance(row.get(field), str) or not row[field].strip():
                    raise ValueError(f"External component {field} is required")
            all_pairs.add(pair)
            cycles = range((horizon_days - 1) // repeat + 1) if repeat else range(1)
            total = Decimal(str(qty))
            # Difference of cumulative floors conserves each weekly UN total.
            cumulative = [Decimal(floor(total * i / length)) if uom == "UN" else total * i / length
                          for i in range(length + 1)]
            for cycle in cycles:
                shift = cycle * (repeat or 0)
                for offset in range(length):
                    due_day = start + shift + offset
                    if due_day >= horizon_days:
                        continue
                    amount = float(cumulative[offset + 1] - cumulative[offset])
                    if amount <= 0:
                        continue
                    requirement_id = f"external:{self.scenario_id}:{identity}:C{cycle}:D{due_day}"
                    requirement = Requirement(requirement_id, due_day, amount)
                    self._daily[pair].append((due_day, known + shift, requirement))
                    self._provenance[requirement_id] = {
                        "demand_id": identity, "scenario_id": self.scenario_id, "cycle_index": cycle,
                        "known_day": known + shift, "source_file": row["source_file"],
                        "source_cells": row["source_cells"], "estimation_basis": row["estimation_basis"],
                    }
        self.pairs = tuple(sorted(all_pairs))
        self._days = {}
        for pair, events in self._daily.items():
            events.sort(key=lambda event: (event[0], event[2].requirement_id))
            self._days[pair] = [event[0] for event in events]

    def requirements(self, *, decision_day: int, first_day: int, through_day: int) -> dict:
        for value in (decision_day, first_day, through_day):
            _day(value, "external component query day")
        if decision_day < 0 or first_day < 0 or through_day < first_day:
            raise ValueError("Invalid external component query interval")
        result = {}
        for pair, events in self._daily.items():
            days = self._days[pair]
            selected = tuple(event[2] for event in events[bisect_left(days, first_day):bisect_right(days, through_day)]
                             if event[1] <= decision_day)
            if selected:
                result[pair] = selected
        return result

    def due(self, day: int) -> dict:
        return self.requirements(decision_day=day, first_day=day, through_day=day)

    def provenance(self, requirement_id: str) -> dict:
        return dict(self._provenance[requirement_id])


def serve_external_component_requirements(
    *, decision_day: int, available_qty: float, backlog: Iterable[Requirement],
    due: Iterable[Requirement], uom: str,
) -> ExternalComponentService:
    """Allocate only available stock, FIFO, without adding a finished product.

    Caller supplies stock after modeled production, excluding held/reserved
    quantities. The returned remainders retain their original identities/dates
    for tomorrow's execution and today's dated purchasing snapshot.
    """
    _day(decision_day, "external service day")
    if decision_day < 0 or not isinstance(uom, str) or not uom:
        raise ValueError("External service requires a nonnegative day and an explicit unit")
    available = Decimal(str(_component_quantity(available_qty, uom=uom, field="available stock")))
    pending, incoming = tuple(backlog), tuple(due)
    seen: set[str] = set()
    for row in pending + incoming:
        _identity(row.requirement_id, seen, "external remaining requirement")
        if not 0 <= _day(row.due_day, "external due day") <= decision_day:
            raise ValueError("Only current or overdue component demand can be physically consumed")
        _component_quantity(row.qty, uom=uom, field="remaining external demand")
    allocations, remaining = [], []
    for row in sorted(pending + incoming, key=lambda row: (row.due_day, row.requirement_id)):
        quantity = Decimal(str(row.qty))
        take = min(available, quantity)
        if take > 0:
            allocations.append(Requirement(row.requirement_id, row.due_day, float(take)))
        if quantity > take:
            remaining.append(Requirement(row.requirement_id, row.due_day, float(quantity - take)))
        available -= take
    return ExternalComponentService(
        tuple(allocations), tuple(remaining), fsum(row.qty for row in incoming),
        fsum(row.qty for row in pending), fsum(row.qty for row in allocations), float(available),
    )


@dataclass(frozen=True)
class FirmReceipt:
    receipt_id: str
    available_day: int
    qty: float
    state: str = "in_transit"


@dataclass(frozen=True)
class LotSizing:
    minimum: float = 0.0
    multiple: float = 0.0
    maximum: float | None = None
    integer: bool = False


@dataclass(frozen=True)
class Allocation:
    requirement_id: str
    supply_id: str
    supply_kind: str
    qty: float
    due_day: int
    available_day: int
    delay_days: int


@dataclass(frozen=True)
class OrderProposal:
    proposal_id: str
    release_day: int
    available_day: int
    requested_day: int
    qty: float


@dataclass(frozen=True)
class ProjectedBalance:
    day: int
    requirement_qty: float
    firm_receipt_qty: float
    proposed_receipt_qty: float
    before_proposals_qty: float
    after_proposals_qty: float


@dataclass(frozen=True)
class DatedPlan:
    decision_day: int
    opening_available_qty: float
    commitment_allocations: tuple[Allocation, ...]
    allocations: tuple[Allocation, ...]
    proposals: tuple[OrderProposal, ...]
    balances: tuple[ProjectedBalance, ...]
    late_qty: float
    late_qty_days: float
    firm_late_qty: float
    proposed_qty: float
    unallocated_firm_qty: float
    closing_projected_qty: float


def _number(value: float, field: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{field} must be a finite nonnegative quantity")
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field} must be a finite nonnegative quantity") from exc
    if not isfinite(number) or number < 0:
        raise ValueError(f"{field} must be a finite nonnegative quantity")
    return number


def _day(value: int, field: str) -> int:
    if type(value) is not int:
        raise ValueError(f"{field} must be an integer day")
    return value


def _identity(value: str, seen: set[str], field: str) -> None:
    if not isinstance(value, str) or not value.strip() or value in seen:
        raise ValueError(f"{field} must be nonempty and unique")
    seen.add(value)


def _lot_bounds(policy: LotSizing) -> tuple[float, float, float | None]:
    if type(policy.integer) is not bool:
        raise ValueError("integer must be a boolean")
    minimum = _number(policy.minimum, "minimum")
    multiple = _number(policy.multiple, "multiple")
    maximum = None if policy.maximum is None else _number(policy.maximum, "maximum")
    if maximum is not None and (maximum == 0 or minimum > maximum):
        raise ValueError("maximum must be positive and at least minimum")
    if policy.integer:
        # Bounds and purchase multiples are physical; forecasts may be fractional.
        for value in (minimum, multiple, maximum):
            if value is not None and value != floor(value):
                raise ValueError("Physical UN lot bounds must be integers")
    if multiple:
        step = Decimal(str(multiple))
        minimum = _number(float(ceil(Decimal(str(minimum)) / step) * step), "rounded minimum")
        if maximum is not None:
            maximum = float(floor(Decimal(str(maximum)) / step) * step)
            if maximum == 0 or minimum > maximum:
                raise ValueError("No purchase lot satisfies the bounds and multiple")
    return minimum, multiple, maximum


def _allocate(requirements, supplies):
    """FIFO needs and earliest availability; inputs contain only local copies."""
    # Decimal conversion of the declared quantities avoids a ghost UN purchase
    # after subtracting thirty 0.1 forecasts from three physical units.
    pools = [[identity, day, Decimal(str(qty)), kind] for identity, day, qty, kind in supplies]
    pools.sort(key=lambda row: (row[1], row[0]))
    allocations, missing = [], []
    cursor = 0
    for requirement in requirements:
        remaining = Decimal(str(requirement.qty))
        while remaining > 0 and cursor < len(pools):
            supply = pools[cursor]
            if supply[2] <= 0:
                cursor += 1
                continue
            qty = min(remaining, supply[2])
            allocations.append(Allocation(
                requirement.requirement_id, supply[0], supply[3], float(qty),
                requirement.due_day, supply[1], max(0, supply[1] - requirement.due_day),
            ))
            remaining -= qty
            supply[2] -= qty
        if remaining > 0:
            # Keep the exact remainder until lot sizing. A float here can round
            # down (e.g. 2 - 0.9999999999999999) and leave a need uncovered.
            missing.append((requirement, remaining))
    return tuple(allocations), tuple(missing), pools


def plan_dated_requirements(
    *, decision_day: int, available_qty: float,
    requirements: Iterable[Requirement], firm_receipts: Iterable[FirmReceipt],
    lead_days: int, lot_sizing: LotSizing | None = None,
) -> DatedPlan:
    """Propose quantities not covered by stock/commitments and expose lateness.

    Requirements describe remaining needs, not repeated daily MPS signals.
    Firm receipts include each held or undelivered quantity exactly once, at its
    availability date. Receipts already available belong in available_qty.
    New proposals remain revocable until their release is physically executed.
    Lot maxima limit one order, not total daily manufacturing capacity.
    """
    decision_day = _day(decision_day, "decision_day")
    lead_days = _day(lead_days, "lead_days")
    if lead_days < 0:
        raise ValueError("lead_days must be nonnegative")
    available = _number(available_qty, "available_qty")
    policy = lot_sizing or LotSizing()
    minimum, multiple, maximum = _lot_bounds(policy)
    if policy.integer and available != floor(available):
        raise ValueError("Physical UN available stock must be integer")
    needs, receipts = tuple(requirements), tuple(firm_receipts)
    seen = set()
    for row in needs:
        _identity(row.requirement_id, seen, "requirement_id")
        _day(row.due_day, "due_day")
        _number(row.qty, "requirement qty")
    needs = tuple(sorted(needs, key=lambda row: (row.due_day, row.requirement_id)))
    seen = {"opening_stock"}
    supplies = [("opening_stock", decision_day, available, "available")]
    for row in receipts:
        _identity(row.receipt_id, seen, "receipt_id")
        _day(row.available_day, "available_day")
        if row.available_day < decision_day:
            raise ValueError("Past receipts must be reconciled with available stock")
        qty = _number(row.qty, "firm receipt qty")
        if policy.integer and qty != floor(qty):
            raise ValueError("Physical UN firm receipts must be integer")
        if row.state not in ("held", "in_transit", "confirmed"):
            raise ValueError("Firm receipt state must be held, in_transit or confirmed")
        supplies.append((row.receipt_id, row.available_day, qty, row.state))

    committed_allocations, missing, _ = _allocate(needs, supplies)
    proposals = []
    surplus = Decimal(0)
    for requirement, remainder in missing:
        need = max(Decimal(0), remainder - surplus)
        surplus = max(Decimal(0), surplus - remainder)
        while need > 0:
            qty = max(need, Decimal(str(minimum)))
            if multiple:
                qty = ceil(qty / Decimal(str(multiple))) * Decimal(str(multiple))
            if policy.integer:
                qty = Decimal(ceil(qty))
            if maximum is not None:
                qty = min(qty, Decimal(str(maximum)))
            published_qty = _number(qty, "proposal qty")
            if Decimal(str(published_qty)) < qty:
                # The public engine interface uses floats. Represent a proposal
                # outward by at most one ULP, then use that SAME quantity for
                # netting and balances. Never erase a shortage with a tolerance
                # or turn floating-point dust into an extra physical UN lot.
                published_qty = _number(nextafter(published_qty, float("inf")), "proposal qty")
            qty = Decimal(str(published_qty))
            if qty <= 0:
                raise ValueError("Lot policy produced a zero purchase for a positive need")
            release = max(decision_day, requirement.due_day - lead_days)
            arrival = release + lead_days
            proposal_id = f"proposal:{len(proposals) + 1}"
            if proposal_id in seen:
                raise ValueError("Receipt id collides with a generated proposal id")
            proposals.append(OrderProposal(proposal_id, release, arrival, requirement.due_day, published_qty))
            surplus += max(Decimal(0), qty - need)
            need = max(Decimal(0), need - qty)

    # Minimum/multiple rounding may provide earlier surplus. Reallocate by actual
    # availability so lateness is not overstated when that surplus covers a need.
    all_supplies = supplies + [(p.proposal_id, p.available_day, p.qty, "proposal") for p in proposals]
    allocations, uncovered, leftovers = _allocate(needs, all_supplies)
    if uncovered:
        raise ArithmeticError("Proposed plan does not cover every remaining quantity")
    events: dict[int, list[list[float]]] = {decision_day: [[], [], []]}
    for row in needs:
        events.setdefault(max(decision_day, row.due_day), [[], [], []])[0].append(float(row.qty))
    for row in receipts:
        events.setdefault(row.available_day, [[], [], []])[1].append(float(row.qty))
    for row in proposals:
        events.setdefault(row.available_day, [[], [], []])[2].append(row.qty)
    balances = []
    before = after = Decimal(str(available))
    for day, amounts in sorted(events.items()):
        needed, firm, proposed = (sum((Decimal(str(value)) for value in group), Decimal(0)) for group in amounts)
        before += firm - needed
        after += firm + proposed - needed
        if not isfinite(before) or not isfinite(after):
            raise ValueError("Projected balance overflow")
        balances.append(ProjectedBalance(day, float(needed), float(firm), float(proposed), float(before), float(after)))
    return DatedPlan(
        decision_day, available, committed_allocations, allocations, tuple(proposals), tuple(balances),
        fsum(a.qty for a in allocations if a.delay_days),
        fsum(a.qty * a.delay_days for a in allocations),
        fsum(a.qty for a in allocations if a.delay_days and a.supply_kind in ("held", "in_transit", "confirmed")),
        fsum(p.qty for p in proposals),
        fsum(p[2] for p in leftovers if p[3] in ("held", "in_transit", "confirmed")),
        float(after),
    )
