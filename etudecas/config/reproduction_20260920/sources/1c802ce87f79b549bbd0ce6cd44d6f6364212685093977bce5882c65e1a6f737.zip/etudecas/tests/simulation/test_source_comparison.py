"""Manual weekly-calendar oracles, entirely in memory; no file fixtures."""
import pytest

from etudecas.visualization.maps.source_comparison import (
    COLUMNS, FLOW_TYPES, _event_unit_evidence, _external_component_rows,
    _trace_values, _weekly_rows, _weekly_windows,
)


@pytest.mark.parametrize("convention,first,last", [
    ("sunday_start", (4, 4, 10), (354, 354, 360)),
    ("monday_after", (4, 5, 11), (354, 355, 361)),
    ("sunday_end", (11, 5, 11), (361, 355, 361)),
])
def test_calendar_keeps_only_complete_nonoverlapping_first_year_weeks(convention, first, last):
    windows = list(_weekly_windows(convention))
    assert len(windows) == 51
    assert windows[0] == first
    assert windows[-1] == last
    days = [d for _, start, end in windows for d in range(start, end + 1)]
    assert len(days) == len(set(days)) == 357
    assert min(days) >= 0 and max(days) < 365


def test_january_seventh_receipt_uses_preceding_or_following_sunday_explicitly():
    # Jan 7 is J6. The source plan labels the 140 t delivery as Jan 5 (J4).
    events = {6: [140_000, 0, 0]}
    start = _weekly_rows(events, {}, {}, True, "sunday_start")
    following = _weekly_rows(events, {}, {}, True, "monday_after")
    historical = _weekly_rows(events, {}, {}, True, "sunday_end")
    assert start[0] == [4, 140_000, 0, 0, None, None, None, 4, 10]
    assert following[0] == [4, 140_000, 0, 0, None, None, None, 5, 11]
    assert historical[0] == [11, 140_000, 0, 0, None, None, None, 5, 11]
    assert sum(row[1] for row in start) == sum(row[1] for row in historical) == 140_000


def test_sunday_boundary_changes_quantity_not_only_display_label():
    # 5 Jan, 7 Jan and 12 Jan: distinguish the two plausible forward windows.
    events = {4: [20, 0, 0], 6: [140, 0, 0], 11: [30, 0, 0]}
    start = _weekly_rows(events, {}, {}, True, "sunday_start")
    following = _weekly_rows(events, {}, {}, True, "monday_after")
    assert start[0][1] == 160
    assert following[0][1] == 170
    assert start[1][1] == 30
    assert following[1][1] == 0


def test_missing_forecast_or_production_day_is_not_a_zero_observation():
    production = {d: 10 for d in (4, 5, 6, 7, 8, 9)}  # missing Jan 11
    trace = {d: [100, 10] for d in (4, 5, 6, 7, 8, 9, 10)}
    first = _weekly_rows({}, production, trace, True, "sunday_start")[0]
    assert first[1:7] == [0, 0, 0, None, 700, 70]
    del trace[7]  # In-memory missing observation, never filesystem alteration.
    assert _weekly_rows({}, production, trace, True, "sunday_start")[0][5:7] == [None, None]


def test_unmodelled_pair_does_not_become_zero_physical_flows():
    first = _weekly_rows({}, {}, {}, False, "sunday_start")[0]
    assert first[1:7] == [None, None, None, None, None, None]


def test_manual_daily_production_and_forecast_totals_keep_distinct_units_of_time():
    production = {d: d for d in (4, 5, 6, 7, 8, 9, 10, 11)}
    trace = {d: [100, d] for d in production}
    start = _weekly_rows({}, production, trace, True, "sunday_start")[0]
    following = _weekly_rows({}, production, trace, True, "monday_after")[0]
    assert start[4:7] == [49, 700, 49]
    assert following[4:7] == [56, 700, 56]


def test_dynamic_pair_unit_comes_from_explicit_lot_event_and_keeps_source_line():
    pair = ('M-1430', 'item:001848')
    rows = [
        {'node_id': 'M-1810', 'item_id': pair[1], 'uom': 'G'},
        {'node_id': pair[0], 'item_id': pair[1], 'uom': 'KG', 'qty': '7000'},
        {'node_id': pair[0], 'item_id': pair[1], 'uom': 'KG', 'qty': '7000'},
    ]
    result = _event_unit_evidence(rows, {pair})
    assert result == {pair: {'uom': 'KG', 'evidence_file': 'production_lot_events.csv', 'csv_line': 3}}
    assert rows[1]['qty'] == '7000'
    # The helper supplies a dimension, never an opening-stock observation.
    assert not {'opening_qty', 'opening_stock', 'initial_quantity'} & set(result[pair])


def test_missing_event_unit_is_not_inferred_from_quantity_or_article_identity():
    pair = ('M-1430', 'item:001848')
    rows = [{'node_id': pair[0], 'item_id': pair[1], 'uom': '', 'qty': '7000'}]
    assert _event_unit_evidence(rows, {pair}) == {}


@pytest.mark.parametrize('contradictory_unit', ['G', 'UN'])
def test_dynamic_pair_conflicting_quantity_unit_or_conversion_factor_is_rejected(contradictory_unit):
    pair = ('M-1430', 'item:001848')
    rows = [{'node_id': pair[0], 'item_id': pair[1], 'uom': unit} for unit in ('KG', contradictory_unit)]
    with pytest.raises(ValueError, match='Conflicting ledger units'):
        _event_unit_evidence(rows, {pair})


def _external_row(**changes):
    row = dict(day='0', node_id='M-1810', item_id='item:002612', uom='G',
               demand_qty='2000', backlog_start_qty='500', required_qty='2500',
               consumed_qty='1250', backlog_end_qty='1250', available_before_qty='10000',
               available_after_qty='8750', core_consumed_qty='3000', total_component_consumed_qty='4250')
    return dict(row, **changes)


def test_external_usage_grams_convert_all_nine_quantities_without_mixing_core_and_extra():
    pair = ('M-1810', 'item:002612')
    result = _external_component_rows([_external_row()], {pair: 'KG'})
    assert result == {pair: [[0, 2, .5, 2.5, 1.25, 1.25, 10, 8.75, 3, 4.25]]}
    assert 'external_component_consume' not in FLOW_TYPES


@pytest.mark.parametrize('field', ['required_qty', 'backlog_end_qty', 'available_after_qty',
                                 'total_component_consumed_qty'])
def test_external_usage_rejects_broken_material_or_requirement_balance(field):
    pair = ('M-1810', 'item:002612')
    with pytest.raises(ValueError, match='balance mismatch'):
        _external_component_rows([_external_row(**{field: '9999'})], {pair: 'KG'})


def test_external_usage_distinguishes_missing_days_from_exported_zero():
    pair = ('M-1810', 'item:002612')
    rows = [_external_row(day='4'), _external_row(day='6')]
    assert [row[0] for row in _external_component_rows(rows, {pair: 'KG'})[pair]] == [4, 6]
    assert _external_component_rows([], {pair: 'KG'}) == {}


def test_external_usage_rejects_duplicate_day_and_backlog_reset():
    pair = ('M-1810', 'item:002612')
    with pytest.raises(ValueError, match='Duplicate'):
        _external_component_rows([_external_row(), _external_row()], {pair: 'KG'})
    with pytest.raises(ValueError, match='backlog discontinuity'):
        _external_component_rows([_external_row(), _external_row(day='1')], {pair: 'KG'})


def test_external_usage_preserves_integer_physical_units_and_rejects_other_dimension():
    pair = ('M-1810', 'item:002612')
    with pytest.raises(ValueError, match='unit mismatch'):
        _external_component_rows([_external_row()], {pair: 'UN'})
    with pytest.raises(ValueError, match='Fractional physical units'):
        _external_component_rows([_external_row(uom='UN', consumed_qty='1.5')], {pair: 'UN'})


def test_external_trace_extension_keeps_legacy_positions_and_absence():
    row = dict(bb_demand_signal_qty='1000', bb_demand_signal_raw_qty='2000',
               target_stock_qty='3000', safety_floor_qty='4000', bn_qty='5000',
               recv_prev_future_qty='6000', coverage_target_qty='7000', receipt_cover_end_day='42')
    legacy = _trace_values(row, .001)
    assert len(COLUMNS['trace']) == 59 and len(legacy) == 58
    assert legacy[:7] == [1, 2, 3, 4, 5, 6, 7]
    assert legacy[9] == 42  # Inclusive horizon date retains its original position.
    assert legacy[54:] == [None, None, None, None]
    row.update(external_demand_qty='2500', external_consumed_qty='1250',
               external_backlog_qty='1250', dated_external_requirement_qty='9000')
    current = _trace_values(row, .001)
    assert current[:54] == legacy[:54]
    assert current[54:] == [2.5, 1.25, 1.25, 9]
