"""Manual weekly-calendar oracles, entirely in memory; no file fixtures."""
import pytest

from etudecas.visualization.maps.source_comparison import _event_unit_evidence, _weekly_rows, _weekly_windows


@pytest.mark.parametrize("convention,first,last", [
    ("sunday_start", (4, 4, 10), (354, 354, 360)),
    ("monday_after", (4, 5, 11), (354, 355, 361)),
    ("sunday_end", (11, 5, 11), (361, 355, 361)),
])
def test_calendar_keeps_only_complete_nonoverlapping_first_year_weeks(convention, first, last):
    windows = list(_weekly_windows(convention))
    assert len(windows) == 51
    assert windows[0] == first
    assert windows[-1] == last
    days = [d for _, start, end in windows for d in range(start, end + 1)]
    assert len(days) == len(set(days)) == 357
    assert min(days) >= 0 and max(days) < 365


def test_january_seventh_receipt_uses_preceding_or_following_sunday_explicitly():
    # Jan 7 is J6. The source plan labels the 140 t delivery as Jan 5 (J4).
    events = {6: [140_000, 0, 0]}
    start = _weekly_rows(events, {}, {}, True, "sunday_start")
    following = _weekly_rows(events, {}, {}, True, "monday_after")
    historical = _weekly_rows(events, {}, {}, True, "sunday_end")
    assert start[0] == [4, 140_000, 0, 0, None, None, None, 4, 10]
    assert following[0] == [4, 140_000, 0, 0, None, None, None, 5, 11]
    assert historical[0] == [11, 140_000, 0, 0, None, None, None, 5, 11]
    assert sum(row[1] for row in start) == sum(row[1] for row in historical) == 140_000


def test_sunday_boundary_changes_quantity_not_only_display_label():
    # 5 Jan, 7 Jan and 12 Jan: distinguish the two plausible forward windows.
    events = {4: [20, 0, 0], 6: [140, 0, 0], 11: [30, 0, 0]}
    start = _weekly_rows(events, {}, {}, True, "sunday_start")
    following = _weekly_rows(events, {}, {}, True, "monday_after")
    assert start[0][1] == 160
    assert following[0][1] == 170
    assert start[1][1] == 30
    assert following[1][1] == 0


def test_missing_forecast_or_production_day_is_not_a_zero_observation():
    production = {d: 10 for d in (4, 5, 6, 7, 8, 9)}  # missing Jan 11
    trace = {d: [100, 10] for d in (4, 5, 6, 7, 8, 9, 10)}
    first = _weekly_rows({}, production, trace, True, "sunday_start")[0]
    assert first[1:7] == [0, 0, 0, None, 700, 70]
    del trace[7]  # In-memory missing observation, never filesystem alteration.
    assert _weekly_rows({}, production, trace, True, "sunday_start")[0][5:7] == [None, None]


def test_unmodelled_pair_does_not_become_zero_physical_flows():
    first = _weekly_rows({}, {}, {}, False, "sunday_start")[0]
    assert first[1:7] == [None, None, None, None, None, None]


def test_manual_daily_production_and_forecast_totals_keep_distinct_units_of_time():
    production = {d: d for d in (4, 5, 6, 7, 8, 9, 10, 11)}
    trace = {d: [100, d] for d in production}
    start = _weekly_rows({}, production, trace, True, "sunday_start")[0]
    following = _weekly_rows({}, production, trace, True, "monday_after")[0]
    assert start[4:7] == [49, 700, 49]
    assert following[4:7] == [56, 700, 56]


def test_dynamic_pair_unit_comes_from_explicit_lot_event_and_keeps_source_line():
    pair = ('M-1430', 'item:001848')
    rows = [
        {'node_id': 'M-1810', 'item_id': pair[1], 'uom': 'G'},
        {'node_id': pair[0], 'item_id': pair[1], 'uom': 'KG', 'qty': '7000'},
        {'node_id': pair[0], 'item_id': pair[1], 'uom': 'KG', 'qty': '7000'},
    ]
    result = _event_unit_evidence(rows, {pair})
    assert result == {pair: {'uom': 'KG', 'evidence_file': 'production_lot_events.csv', 'csv_line': 3}}
    assert rows[1]['qty'] == '7000'
    # The helper supplies a dimension, never an opening-stock observation.
    assert not {'opening_qty', 'opening_stock', 'initial_quantity'} & set(result[pair])


def test_missing_event_unit_is_not_inferred_from_quantity_or_article_identity():
    pair = ('M-1430', 'item:001848')
    rows = [{'node_id': pair[0], 'item_id': pair[1], 'uom': '', 'qty': '7000'}]
    assert _event_unit_evidence(rows, {pair}) == {}


@pytest.mark.parametrize('contradictory_unit', ['G', 'UN'])
def test_dynamic_pair_conflicting_quantity_unit_or_conversion_factor_is_rejected(contradictory_unit):
    pair = ('M-1430', 'item:001848')
    rows = [{'node_id': pair[0], 'item_id': pair[1], 'uom': unit} for unit in ('KG', contradictory_unit)]
    with pytest.raises(ValueError, match='Conflicting ledger units'):
        _event_unit_evidence(rows, {pair})
