"""Independent CSV arithmetic; no engine imports and no simulation execution."""
import argparse,collections,csv,datetime,hashlib,json,math
from pathlib import Path
import openpyxl

p=argparse.ArgumentParser();p.add_argument('--baseline-only',action='store_true');p.add_argument('--total-only',action='store_true');args=p.parse_args()
root=Path('etudecas/artifacts/testing/mrp_need_dates_20261001')
globalroot=Path('etudecas/artifacts/testing/mrp_global_rules_20261001')
base=Path('etudecas/artifacts/testing/mrp_offer_alignment_20261001/shared_007923')
paths={'baseline':base/'run_shared','safety_total_all':globalroot/'experiment/run_safety_total_all','need_dates':root/'experiment/run_need_dates_2'}
execs={'baseline':base/'shared_execution.json','safety_total_all':globalroot/'experiment/safety_total_all_execution.json','need_dates':root/'experiment/need_dates_execution_2.json'}
variants=['baseline'] if args.baseline_only else (['baseline','safety_total_all'] if args.total_only else list(paths))
hashes={}
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def reg(p): hashes[str(p)]=sha(p);return p
def rows(v,name):
    with reg(paths[v]/'data'/name).open(encoding='utf-8-sig') as f:yield from csv.DictReader(f)
for v in variants:
    ex=json.loads(reg(execs[v]).read_text());assert ex['returncode']==0,(v,'Execution has not succeeded')
    assert ex['code_unchanged'] and ex['inputs_unchanged'],(v,'Run inputs changed')
    assert ex['code_before']==ex['code_after'] and ex['input_before']==ex['input_after']
    assert ex['command'][ex['command'].index('--days')+1]=='1825'
contract=json.loads(reg(globalroot/'oracle/source_contract.json').read_text());contracts={r['pair']:r for r in contract['pairs']}
# 021081 offers belong to the intermediate-product workbook, not either PF workbook.
wb=openpyxl.load_workbook(reg(Path('etudecas/data/source/773474.xlsx')),read_only=True,data_only=True)
supplement=[]
for n,r in enumerate(wb['FIA'].iter_rows(min_row=2,values_only=True),2):
    if str(r[0]).zfill(6)!='021081':continue
    supplement.append({'file':'773474.xlsx','row':n,'supplier':'SDC-'+str(r[1]),'price':r[2],'price_base':r[3],'currency':r[4],'delivery_days':r[5],'standard_qty':r[6],'uom':r[7]})
wb.close();assert len(supplement)==4
contracts['SDC-1450/item:021081']['offers']=supplement
g=json.loads(reg(base/'shared_graph.json').read_text());states={(n['id'],s['item_id']):s for n in g['nodes'] for s in n.get('inventory',{}).get('states',[])}
receipt_policy=g['meta']['supplier_delivery_receipt_policy'];assert receipt_policy['calendar']=='monday_friday'
assert not any('nonworking' in k for k in receipt_policy)
assert not any(any('nonworking' in k for k in row) for row in receipt_policy['rows'])
receipt_days={(r['node_id'],r['item_id']):int(r['receipt_days']) for r in receipt_policy['rows']}
def available_after_receipt(physical_day,workdays):
    date=origin+datetime.timedelta(days=physical_day)
    while workdays:
        date+=datetime.timedelta(days=1)
        if date.weekday()<5:workdays-=1
    return (date-origin).days
origin=datetime.date(2025,1,1);sites={'1430':'M-1430','1450':'SDC-1450','1810':'M-1810','1920':'DC-1920'}
photo=collections.defaultdict(list)
wb=openpyxl.load_workbook(reg(Path('etudecas/data/source/Flow_Data_Inventory_and_Replenishment_rules.xlsx')),read_only=True,data_only=True)
for n,r in enumerate(wb['Stocks'].iter_rows(min_row=2,values_only=True),2):
    if str(r[2]) not in sites:continue
    dt=datetime.datetime.fromisoformat(r[7]) if isinstance(r[7],str) else r[7];day=(dt.date()-origin).days
    if 0<day<=365:photo[sites[str(r[2])],'item:'+str(r[0]).zfill(6)].append((day,float(r[4])*(.001 if r[6]=='G' else 1),n))
wb.close()
stocks={};service={};physical={};integrity={};sourcing={};external={};technical_errors=[];date_audit={};sourcing_cost={};delivery_timing={}
for v in variants:
    stocks[v]=collections.defaultdict(dict);unbad=[];partition=[]
    for r in rows(v,'production_stock_availability_daily.csv'):
        pair=r['node_id'],r['item_id'];day=int(r['day']);factor=.001 if r['uom']=='G' else 1
        q=[float(r[k])*factor for k in ['physical_qty','available_qty','held_qty','reserved_qty']]
        stocks[v][pair][day]=q
        residual=q[0]-sum(q[1:])
        if abs(residual)>3e-6:partition.append((pair,day,residual))
        if r['uom']=='UN' and any(abs(x-round(x))>1e-7 for x in q):unbad.append((pair,day,q))
    assert max(d for series in stocks[v].values() for d in series)==1824
    external[v]={};external_consumed=collections.defaultdict(float)
    for r in rows(v,'external_component_demand_daily.csv'):
        pair=r['node_id'],r['item_id'];d=int(r['day']);factor=.001 if r['uom']=='G' else 1
        external[v][(*pair,d)]=tuple(r[k] for k in ['demand_qty','forecast_vintage_id','forecast_known_day','forecast_source_cells'])
        external_consumed[pair,d]+=float(r['consumed_qty'])*factor
    core=collections.defaultdict(float)
    for r in rows(v,'production_input_consumption_daily.csv'):
        core[(r['node_id'],r['item_id']),int(r['day'])]+=float(r['consumed_qty'])*(.001 if r['uom']=='G' else 1)
    receipts=collections.defaultdict(float);buy=collections.defaultdict(list);offer_errors=[];un_orders=[];timing_errors=[];timing_counts=collections.Counter()
    for r in rows(v,'mrp_orders_daily.csv'):
        pair=r['node_id'],r['item_id'];key='/'.join(pair)
        if key not in contracts:continue
        if r['actual_physical_receipt_day']:
            receipts[pair,int(float(r['actual_physical_receipt_day']))]+=float(r['planned_receipt_qty'])
        if r['order_type']!='external_procurement_supplier_delivery':continue
        buy[pair].append(r);offers=contracts[key]['offers'];match=[o for o in offers if o['supplier']==r['src_node_id']]
        if not match:offer_errors.append((key,r['day'],'unknown supplier'));continue
        o=match[0]
        for column,field in [('delivery_reference_days','delivery_days'),('standard_order_qty','standard_qty')]:
            if abs(float(r[column])-float(o[field]))>1e-6:offer_errors.append((key,r['day'],column,r[column],o[field]))
        L=int(float(o['delivery_days']));R=receipt_days[pair];release=int(float(r['release_day']))
        expected_physical=release+L;expected_available=available_after_receipt(expected_physical,R)
        timing_counts['new_orders']+=1
        for field,expected in [('physical_delivery_day',expected_physical),('available_day',expected_available),('receipt_source_days',R)]:
            if not r[field] or float(r[field])!=expected:timing_errors.append((key,r['mrp_order_id'],field,r[field],expected))
        for field,expected in [('actual_physical_receipt_day',expected_physical),('actual_available_day',expected_available)]:
            if r[field]:
                timing_counts[field]+=1
                if float(r[field])!=expected:timing_errors.append((key,r['mrp_order_id'],field,r[field],expected))
        if contracts[key]['uom']=='UN' and abs(float(r['release_qty'])-round(float(r['release_qty'])))>1e-7:un_orders.append((key,r['day']))
    physical[v]={};balance_errors=[]
    for key,c in contracts.items():
        pair=tuple(key.split('/'));initial=float(states[pair]['initial']);byperiod={}
        for name,start,end in [('year2025',0,364),('Q4',273,364),('five_years',0,1824)]:
            opening=initial if start==0 else stocks[v][pair][start-1][0]
            received=sum(receipts[pair,d] for d in range(start,end+1));own=sum(core[pair,d] for d in range(start,end+1));other=sum(external_consumed[pair,d] for d in range(start,end+1));closing=stocks[v][pair][end][0]
            residual=opening+received-own-other-closing
            byperiod[name]={'opening':opening,'receipts':received,'own_consumed':own,'other_consumed':other,'closing':closing,'balance_residual':residual,'orders':sum(start<=int(r['day'])<=end for r in buy[pair]),'ordered_qty':sum(float(r['release_qty']) for r in buy[pair] if start<=int(r['day'])<=end),'available_zero_days':sum(stocks[v][pair][d][1]<=1e-6 for d in range(start,end+1))}
            # Six-decimal CSV accumulation may introduce up to about 0.002 over five years.
            if abs(residual)>0.004:balance_errors.append((key,name,residual))
        byperiod['orders_2025']=[{k:r[k] for k in ['day','release_qty','src_node_id','actual_physical_receipt_day','actual_available_day','delivery_reference_days','receipt_source_days','standard_order_qty','sourcing_role','sourcing_purchase_unit_cost','sourcing_purchase_cost','sourcing_currency']} for r in buy[pair] if 0<=int(r['day'])<365]
        physical[v][key]=byperiod
    sourcing[v]={key:dict(collections.Counter(r['src_node_id'] for r in buy[tuple(key.split('/'))])) for key in contracts}
    role_cost=collections.defaultdict(lambda:{'orders':0,'qty':0.,'purchase_cost_EUR':0.});unknown_cost=[]
    for r in buy['M-1810','item:001848']:
        if not 0<=int(r['day'])<365:continue
        if not r['sourcing_purchase_cost'] or r['sourcing_currency']!='EUR':unknown_cost.append(r['mrp_order_id']);continue
        role=r['sourcing_role'];q=float(r['release_qty']);cost=float(r['sourcing_purchase_cost'])
        assert abs(cost-q*float(r['sourcing_purchase_unit_cost']))<1e-5
        role_cost[role]['orders']+=1;role_cost[role]['qty']+=q;role_cost[role]['purchase_cost_EUR']+=cost
    sourcing_cost[v]={'pair':'M-1810/item:001848','new_orders_released_in_2025':dict(role_cost),'missing_or_nonEUR_cost_orders':unknown_cost,'sum_new_purchase_cost_EUR':sum(x['purchase_cost_EUR'] for x in role_cost.values()),'basis':'Sum recorded sourcing_purchase_cost on new external procurement orders only; opening commitments and operational/transport cost excluded; not observed industrial payment cash flow.'}
    service[v]={(r['node_id'],r['item_id'],int(r['day'])):r for r in rows(v,'production_demand_service_daily.csv')}
    if v=='need_dates':
        counts=collections.Counter();date_errors=[]
        for r in rows(v,'mrp_dated_plan_daily.csv'):
            key=r['node_id']+'/'+r['item_id']
            if key not in contracts:
                if r.get('purchase_need_date_policy'):date_errors.append((key,r['day'],'unexpected active pair'))
                continue
            c=contracts[key];counts[key]+=1
            checks={'purchase_need_date_policy':r.get('purchase_need_date_policy')=='source_safety_backwards_v1',
                'source_safety_days_unscaled':float(r['anticipated_safety_working_days'])==c['source_safety']['days'],
                'fixed_source_floor':abs(float(r['anticipated_fixed_floor_qty'])-c['graph_safety']['safety_stock_qty'])<1e-7,
                'no_extra_time_floor_flag':r['anticipated_no_extra_time_floor']=='1',
                'no_legacy_reserve_quantity':float(r['dated_reserve_requirement_qty'])==0,
                'calendar_index_is_integer':not r['anticipated_first_shortage_day'] or float(r['anticipated_first_shortage_day']).is_integer(),
                'legacy_protection_not_applied':r.get('dated_protection_target_qty','')==''}
            for name,ok in checks.items():
                if not ok:date_errors.append((key,r['day'],name))
        assert set(counts)==set(contracts) and all(n==1825 for n in counts.values())
        date_audit[v]={'rows_checked':sum(counts.values()),'pair_counts':dict(counts),'errors':date_errors,'semantics':'Safety days, mode flag and day indices checked as raw scalars; no unit conversion.'}
        if date_errors:technical_errors.append(v+':date_trace_errors')
        # Independent cumulative envelope from sampled weekly physical needs.
        # This run exports weekly detail only for the52 source-year snapshots.
        sampled_days={4,88,179,270,361};weekly=collections.defaultdict(lambda:collections.defaultdict(list));weekly_errors=[]
        for r in rows(v,'mrp_dated_plan_weekly.csv'):
            d=int(r['decision_day']);key=r['node_id']+'/'+r['item_id']
            if d not in sampled_days or key not in contracts:continue
            if r['kind'] in ['stock_protection','reserve']:weekly_errors.append((d,key,'obsolete protection or reserve exported'))
            if r['kind'] in ['requirement','anticipated_planning_requirement']:
                weekly[d,key][r['kind']].append((int(r['target_day']),float(r['qty'])))
        sampled=[]
        for (d,key),w in sorted(weekly.items()):
            c=contracts[key];events=collections.defaultdict(lambda:[[],[]]);events[d];N=int(c['source_safety']['days'])
            for due,q in w['requirement']:
                date=origin+datetime.timedelta(days=due);remaining=N
                while remaining:
                    date-=datetime.timedelta(days=1)
                    if date.weekday()<5:remaining-=1
                events[max(d,(date-origin).days)][0].append(q);events[max(d,due)][1].append(q)
            actual=collections.defaultdict(list)
            for due,q in w['anticipated_planning_requirement']:actual[due].append(q)
            early=physical_qty=previous=0.;expected={}
            for day,(shifted,physical_values) in sorted(events.items()):
                early+=math.fsum(shifted);physical_qty+=math.fsum(physical_values)
                envelope=max(early,physical_qty+c['graph_safety']['safety_stock_qty'])
                expected[day]=envelope-previous;previous=envelope
            difference=max((abs(expected.get(day,0)-math.fsum(actual.get(day,()))) for day in set(expected)|set(actual)),default=0)
            tolerance=max(2e-6,(len(w['requirement'])+len(w['anticipated_planning_requirement']))*1e-6)
            if difference>tolerance:weekly_errors.append((d,key,'envelope mismatch',difference,tolerance))
            sampled.append({'decision_day':d,'pair':key,'physical_rows':len(w['requirement']),'planning_rows':len(w['anticipated_planning_requirement']),'max_increment_difference':difference,'CSV_rounding_tolerance':tolerance})
        assert set(d for d,k in weekly)==sampled_days
        date_audit[v]['weekly_envelope_samples']=sampled;date_audit[v]['weekly_envelope_errors']=weekly_errors
        date_audit[v]['weekly_scope']='Five sampled snapshots within2025; weekly detail is exported for52 first-year snapshots only. Daily scalars/service/physical checks cover1825days.'
        if weekly_errors:technical_errors.append(v+':weekly_envelope_errors')
    integrity[v]={'UN_stock_errors':len(unbad),'partition_errors':len(partition),'UN_order_errors':len(un_orders),'source_offer_errors':offer_errors,'physical_balance_errors':balance_errors,'external_calendar_equals_baseline':external[v]==external['baseline']}
    delivery_timing[v]={'counts':dict(timing_counts),'errors':timing_errors,'rule':'physical=release+FIA calendar-day L; available=forward R Monday-Friday workdays from physical receipt, excluding the receipt date itself; no inferred holidays; actual fields checked only when populated.'}
    if timing_errors:technical_errors.append(v+':delivery_timing_errors')
    if unbad or partition or un_orders or offer_errors or balance_errors or external[v]!=external['baseline']:technical_errors.append(v)

metrics={}
for pair,obs in photo.items():
    obs=[x for x in obs if x[0]-1 in stocks['baseline'].get(pair,{})]
    if not obs:continue
    out={'n':len(obs),'last_photo':max(obs)}
    for v in variants:
        detail={}
        for label,selected in [('annual',obs),('Q1',[x for x in obs if x[0]<90]),('Q4',[x for x in obs if x[0]>=273])]:
            if selected:detail[label]={'n':len(selected),'mae':sum(abs(stocks[v][pair][d-1][0]-q) for d,q,_ in selected)/len(selected),'bias':sum(stocks[v][pair][d-1][0]-q for d,q,_ in selected)/len(selected)}
        detail['last_simulated_physical']=stocks[v][pair][max(obs)[0]-1][0];out[v]=detail
    metrics['/'.join(pair)]=out
assert len(metrics)==29
regressions={};services={}
for v in variants:
    changed={k:metrics[k][v]['annual']['mae']-metrics[k]['baseline']['annual']['mae'] for k in metrics}
    regressions[v]={'improved':sum(x< -1e-6 for x in changed.values()),'degraded':sum(x>1e-6 for x in changed.values()),'equal':sum(abs(x)<=1e-6 for x in changed.values()),'annual_mae_delta_by_pair':changed}
    summary={};diff=0
    for item in sorted(set(k[1] for k in service[v])):
        itemsummary={}
        for label,end in [('year2025',364),('five_years',1824)]:
            selected=[(k,r) for k,r in service[v].items() if k[1]==item and k[2]<=end]
            worse=[(k,float(r['backlog_end_qty'])-float(service['baseline'][k]['backlog_end_qty'])) for k,r in selected if float(r['backlog_end_qty'])>float(service['baseline'][k]['backlog_end_qty'])+1e-5]
            diff+=sum(r['demand_qty']!=service['baseline'][k]['demand_qty'] for k,r in selected)
            itemsummary[label]={'served':sum(float(r['served_qty']) for _,r in selected),'demand':sum(float(r['demand_qty']) for _,r in selected),'end_backlog':sum(float(r['backlog_end_qty']) for k,r in selected if k[2]==end),'worse_backlog_days':len(worse),'maximum_backlog_increase':max((q for _,q in worse),default=0),'first_worse':worse[0] if worse else None}
        summary[item]=itemsummary
    services[v]=summary
    if diff:technical_errors.append(v+':customer_demand_changed')

against_total={}
if 'safety_total_all' in variants:
    for v in variants:
        changes={k:{period:metrics[k][v][period]['mae']-metrics[k]['safety_total_all'][period]['mae'] for period in ['annual','Q1','Q4'] if period in metrics[k][v] and period in metrics[k]['safety_total_all']} for k in metrics}
        annual=[x['annual'] for x in changes.values()]
        service_vs={}
        for item in sorted(set(k[1] for k in service[v])):
            service_vs[item]={}
            for label,end in [('year2025',364),('five_years',1824)]:
                worst=[(k,float(r['backlog_end_qty'])-float(service['safety_total_all'][k]['backlog_end_qty'])) for k,r in service[v].items() if k[1]==item and k[2]<=end and float(r['backlog_end_qty'])>float(service['safety_total_all'][k]['backlog_end_qty'])+1e-5]
                service_vs[item][label]={'worse_backlog_days':len(worst),'maximum_increase':max((q for _,q in worst),default=0),'first_worse':worst[0] if worst else None}
        against_total[v]={'improved':sum(x< -1e-6 for x in annual),'degraded':sum(x>1e-6 for x in annual),'equal':sum(abs(x)<=1e-6 for x in annual),'mae_delta_by_pair_period':changes,'service_backlog_comparison':service_vs}

assert hashes=={p:sha(Path(p)) for p in hashes}
result={'status':'independent_arithmetic_checked' if not technical_errors else 'anomalies_need_review','technical_errors':technical_errors,'variants':variants,'source_contract_supplement_021081_offers':supplement,'photo_convention':'source photo day d compared with closing simulated physical at d-1; opening excluded, no interpolation','metrics':metrics,'regressions':regressions,'comparisons_against_previous_safety':against_total,'physical_balances':physical,'date_trace_audit':date_audit,'delivery_timing_audit':delivery_timing,'integrity':integrity,'sourcing':sourcing,'sourcing_cost_001848':sourcing_cost,'service':services,'hashes':hashes,'limitations':['Technical arithmetic does not certify industrial calibration. No sum of MAE across different units is meaningful.','Source snapshots constrain weekly physical stocks, not individual observed orders; source I remains projected requirements.','Six-decimal CSV quantity outputs may accumulate rounding residual over 1825 days.','Parent performs toolbox qualifications separately on the same stable outputs.']}
outfile=root/'oracle'/('baseline_postrun_preparation.json' if args.baseline_only else ('total_only_postrun.json' if args.total_only else 'final_postrun.json'));outfile.write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({'status':result['status'],'proof':str(outfile),'sha256':sha(outfile),'integrity':integrity,'regressions':{k:{a:b for a,b in r.items() if a!='annual_mae_delta_by_pair'} for k,r in regressions.items()},'service':services}))
