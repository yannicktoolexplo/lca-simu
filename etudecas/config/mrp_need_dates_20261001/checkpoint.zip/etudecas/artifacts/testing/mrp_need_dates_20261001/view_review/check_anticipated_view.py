"""Read-only evidence chain: actual CSV -> payload -> offline rendered cells.

Only real generated study files are read. Reports/screenshots are new outputs;
no source rewriting, artificial fixture, timestamp change, or integrity probe.
"""
import argparse
import csv
from datetime import date, timedelta
import hashlib
import json
from pathlib import Path
import traceback
from uuid import uuid4


HERE = Path(__file__).resolve().parent
STUDY = HERE.parent
ROOT = HERE.parents[4]
FIELDS = ('purchase_need_date_policy', 'anticipated_safety_working_days',
          'anticipated_fixed_floor_qty', 'anticipated_late_qty',
          'anticipated_first_shortage_day', 'anticipated_no_extra_time_floor')
QUANTITIES = {'anticipated_fixed_floor_qty', 'anticipated_late_qty'}
DAYS = (75, 104, 300)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def same(actual, expected):
    if expected is None:
        assert actual is None, (actual, expected)
    elif isinstance(expected, str):
        assert actual == expected, (actual, expected)
    else:
        assert isinstance(actual, (int, float)) and abs(actual - expected) <= 1e-6, (actual, expected)


def load_sources(delivery, payload):
    result, hashes, conversion = {}, {}, {}
    for run_key, folder in delivery['runs'].items():
        run = Path(folder)
        summary_path = run / 'summaries/first_simulation_summary.json'
        summary = json.loads(summary_path.read_text(encoding='utf-8'))
        graph_path = Path(summary['input_file'])
        if not graph_path.is_absolute():
            graph_path = ROOT / graph_path
        assert sha(graph_path) == summary['input_sha256']
        graph = json.loads(graph_path.read_text(encoding='utf-8'))
        units = {(node['id'], state['item_id']): state['uom'].upper()
                 for node in graph['nodes'] for state in node.get('inventory', {}).get('states', [])}
        trace = run / 'data/mrp_trace_daily.csv'
        hashes[str(trace)] = sha(trace)
        result[run_key] = {}
        with trace.open(encoding='utf-8-sig', newline='') as stream:
            for row in csv.DictReader(stream):
                day = int(row['day'])
                if day not in DAYS:
                    continue
                pair = row['item_id'].removeprefix('item:') + '/' + row['node_id'].rsplit('-', 1)[-1]
                if pair not in payload['pairs']:
                    continue
                raw_unit = units.get((row['node_id'], row['item_id']))
                if raw_unit is None:
                    continue  # Outside the 22 modeled purchase boundaries.
                shown_unit = payload['pairs'][pair]['unit']
                factor = .001 if raw_unit == 'G' and shown_unit == 'KG' else 1.
                assert raw_unit == shown_unit or (raw_unit, shown_unit) == ('G', 'KG')
                conversion[(run_key, pair)] = dict(raw_unit=raw_unit, display_unit=shown_unit, factor=factor)
                expected = {}
                for field in FIELDS:
                    raw = row.get(field, '')
                    expected[field] = (None if raw == '' else raw if field == FIELDS[0]
                                       else float(raw) * (factor if field in QUANTITIES else 1.))
                result[run_key][(pair, day)] = expected
    return result, hashes, conversion


def check_physical_projections(delivery, payload):
    """Independent sums from actual weekly rows, including the 2026 forecast."""
    choices = {}
    for pair in ('001848/1810', '055703/1810', '021081/1450'):
        if pair not in payload['pairs']:
            raise AssertionError('Expected material projection missing: ' + pair)
        projections = payload['pairs'][pair]['simulations']['safety']['dated_projections']
        known = sorted(map(int, projections))
        assert known
        choices[pair] = sorted({min(known, key=lambda value: abs(value-day)) for day in DAYS})
    path = Path(delivery['runs']['safety']) / 'data/mrp_dated_plan_weekly.csv'
    before = sha(path)
    events = {(pair, day): [] for pair, days in choices.items() for day in days}
    with path.open(encoding='utf-8-sig', newline='') as stream:
        for raw in csv.DictReader(stream):
            pair = raw['item_id'].removeprefix('item:') + '/' + raw['node_id'].rsplit('-', 1)[-1]
            decision = int(raw['decision_day'])
            if (pair, decision) not in events:
                continue
            unit = raw['uom'].upper()
            shown = payload['pairs'][pair]['unit']
            assert unit == shown or (unit, shown) == ('G', 'KG')
            factor = .001 if unit == 'G' and shown == 'KG' else 1.
            events[(pair,decision)].append((raw['kind'], max(decision,int(raw['target_day'])),float(raw['qty'])*factor))
    checks, future_checks, snapshots = 0, 0, []
    for (pair, decision), rows in events.items():
        projection = payload['pairs'][pair]['simulations']['safety']['dated_projections'][str(decision)]
        openings = [quantity for kind, day, quantity in rows if kind == 'opening_available']
        assert len(openings) == 1
        envelope = sum(quantity for kind, day, quantity in rows if kind == 'anticipated_planning_requirement')
        assert envelope > 0
        same(projection['opening_available_qty'], openings[0])
        for horizon in ('rows', 'horizon_rows'):
            balance = openings[0]
            for displayed in projection[horizon]:
                start, end = displayed[6], displayed[7]
                window = [(kind,qty) for kind,day,qty in rows if start <= day <= end]
                firms = sum(qty for kind,qty in window if kind.startswith('firm_'))
                proposals = sum(qty for kind,qty in window if kind == 'proposal')
                physical_needs = sum(qty for kind,qty in window if kind == 'requirement')
                reserve = sum(qty for kind,qty in window if kind == 'reserve')
                balance += firms+proposals-physical_needs
                for value, expected in zip(displayed[1:6], (firms,proposals,physical_needs,reserve,balance)):
                    same(value, expected)
                    checks += 1
                    future_checks += int(start >= 365)
            # Every physical need appears once inside this displayed horizon;
            # the positive anticipated envelope contributes no consumption.
            horizon_start, horizon_end = projection[horizon][0][6], projection[horizon][-1][7]
            same(sum(row[3] for row in projection[horizon]), sum(qty for kind,day,qty in rows
                if kind == 'requirement' and horizon_start <= day <= horizon_end))
        snapshots.append(dict(pair=pair,decision_day=decision,anticipated_envelope_qty=envelope,
            physical_requirement_qty=sum(qty for kind,day,qty in rows if kind == 'requirement')))
    assert future_checks > 0
    assert sha(path) == before
    return dict(status='passed',csv=str(path),csv_sha256=before,checks=checks,
                checks_in_2026=future_checks,snapshots=snapshots,
                rule='Only kind=requirement enters physical projected use; anticipated envelope is audit only.')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--delivery', type=Path, default=STUDY / 'map_delivery.json')
    args = parser.parse_args()
    output = HERE / ('run_' + uuid4().hex[:10])
    output.mkdir(exist_ok=False)
    report = dict(status='running', offline=True, output=str(output), errors=[])
    try:
        delivery = json.loads(args.delivery.read_text(encoding='utf-8'))
        payload_path = args.delivery.parent / 'map_payload.json'
        payload = json.loads(payload_path.read_text(encoding='utf-8'))
        html = Path(delivery['standalone'])
        assert sha(html) == delivery['standalone_sha256']
        assert sha(payload_path) == delivery['payload_sha256']
        expected, csv_hashes, conversions = load_sources(delivery, payload)
        pairs = sorted({pair for (pair, day), values in expected['safety'].items()
                        if values[FIELDS[0]] == 'source_safety_backwards_v1'})
        assert len(pairs) == 22, pairs
        columns = {field: index for index, field in enumerate(payload['columns']['trace'])}
        checked = 0
        for pair in pairs:
            for run in delivery['runs']:
                rows = {row[0]: row for row in payload['pairs'][pair]['simulations'][run]['trace']}
                for day in DAYS:
                    for field in FIELDS:
                        same(rows[day][columns[field]], expected[run][(pair, day)][field])
                        checked += 1
        report.update(html=str(html), html_sha256=sha(html), payload_sha256=sha(payload_path),
                      csv_sha256=csv_hashes, pairs=pairs, days=list(DAYS), payload_checks=checked,
                      unit_conversions=[dict(run=run, pair=pair, **values)
                                        for (run,pair),values in conversions.items() if pair in pairs])
        report['physical_projections'] = check_physical_projections(delivery,payload)
        from playwright.sync_api import sync_playwright
        browser_checks = 0
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(headless=True)
            try:
                page = browser.new_page(offline=True, viewport={'width':1600, 'height':1050})
                page.on('pageerror', lambda error: report['errors'].append(str(error)))
                page.goto(html.resolve().as_uri(), wait_until='load', timeout=90000)
                root = page.locator('#sourceComparisonRoot')
                root.wait_for(state='visible')
                embedded = page.locator('#sourceComparisonPayload').evaluate(
                    '(el,args)=>{const d=JSON.parse(el.textContent), c=d.columns.trace;return {columns:c,policies:Object.fromEntries(args.pairs.map(p=>[p,Object.fromEntries(d.pairs[p].simulations.safety.trace.filter(r=>args.days.includes(r[0])).map(r=>[r[0],r[c.indexOf("purchase_need_date_policy")]]))]))}}',
                    dict(pairs=pairs,days=list(DAYS)))
                assert embedded['columns'] == payload['columns']['trace']
                for run in delivery['runs']:
                    page.locator(f'input[data-run="{run}"]').check()
                page.locator('#sourceComparisonPair').select_option('001848/1810')
                page.locator('[role="tab"][data-tab="stocks"]').click()
                assert page.locator('#chart-stocks').is_visible()
                page.locator('#chart-stocks').screenshot(path=str(output/'001848_stocks.png'))
                page.locator('[role="tab"][data-tab="mrp"]').click()
                for pair in pairs:
                    page.locator('#sourceComparisonPair').select_option(pair)
                    details = page.locator('#sourceComparisonPlanningDetails')
                    if details.get_attribute('open') is None:
                        details.locator('summary').click()
                    for day in DAYS:
                        page.locator('#sourceComparisonPlanningDay').select_option(str(day))
                        title = details.locator('h3').filter(has_text='Besoins anticipés : sécurité en jours appliquée une seule fois')
                        assert title.count() == 1
                        # The string policy controls this panel. Check actual browser payload too.
                        policy = embedded['policies'][pair][str(day)]
                        assert policy == expected['safety'][(pair,day)][FIELDS[0]]
                        for run in delivery['runs']:
                            for field in FIELDS[1:]:
                                cell = details.locator(f'[data-run="{run}"] [data-field="{field}"]')
                                assert cell.count() == 1
                                value = expected[run][(pair,day)][field]
                                displayed = cell.get_attribute('data-value')
                                text = cell.inner_text().strip()
                                if value is None:
                                    assert displayed == '' and text == '—', (pair,run,day,field,displayed,text)
                                else:
                                    same(float(displayed),value)
                                    if field == 'anticipated_first_shortage_day':
                                        assert text == (date.fromisoformat(payload['origin'])+timedelta(days=value)).isoformat()
                                    elif field == 'anticipated_no_extra_time_floor':
                                        assert text == 'Oui'
                                    else:
                                        assert text != '—'
                                browser_checks += 1
                        if pair == '001848/1810' and day == 75:
                            title.scroll_into_view_if_needed()
                            page.screenshot(path=str(output/'001848_anticipated_march17.png'))
                page.locator('#sourceComparisonPair').select_option('001848/1810')
                page.locator('input[data-run="safety"]').uncheck()
                assert 'safety' not in root.evaluate('()=>SOURCE_COMPARISON_VIEW.getState().runs')
                assert page.locator('h3').filter(has_text='Besoins anticipés : sécurité en jours appliquée une seule fois').count() == 0
                page.locator('input[data-run="safety"]').check()
                assert 'safety' in root.evaluate('()=>SOURCE_COMPARISON_VIEW.getState().runs')
                assert page.locator('h3').filter(has_text='Besoins anticipés : sécurité en jours appliquée une seule fois').count() == 1
                assert not report['errors'], report['errors']
                report['browser_cell_checks'] = browser_checks
                report['selector_and_tab_checks'] = '001848 stocks/MRP, all 22 pairs, three planning days, candidate toggle'
            finally:
                browser.close()
        for path, digest in csv_hashes.items():
            assert sha(Path(path)) == digest
        assert sha(html) == report['html_sha256']
        report.update(status='passed', limits='Focused new audit only; does not qualify all curves, lots, industrial calibration, or the complete-map shell.')
    except Exception:
        report.update(status='failed', exception=traceback.format_exc())
        raise
    finally:
        with (output/'report.json').open('x',encoding='utf-8') as stream:
            json.dump(report,stream,ensure_ascii=False,indent=2)
        print(json.dumps(dict(status=report['status'], report=str(output/'report.json'))))


if __name__ == '__main__':
    main()
