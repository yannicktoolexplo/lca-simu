"""Render the dated-need experiment using the existing comparison components."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

ROOT = Path.cwd().resolve()
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from etudecas.visualization.maps.source_comparison import build_comparison_payload
from etudecas.visualization.maps.portable_diagnostic import (
    comparison_document, strip_comparison, packed, COMPARISON_RUNTIME,
    COMPARISON_START, COMPARISON_END,
)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, allow_nan=False, separators=(',', ':'))


def previous_module(name):
    path = HERE.parent / 'mrp_global_rules_20261001' / (name + '.py')
    spec = importlib.util.spec_from_file_location('previous_' + name, path)
    module = importlib.util.module_from_spec(spec)
    if name == 'check_view':
        source = path.read_text(encoding='utf-8')
        original = 'raw=expected[run][day][field]'
        assert source.count(original) == 1
        # Inactive legacy diagnostics may be absent from the candidate CSV.
        source = source.replace(original, "raw=expected[run][day].get(field, '')")
        exec(compile(source, str(path), 'exec'), module.__dict__)
    else:
        spec.loader.exec_module(module)
    return module


def main():
    runs = {
        'nominal': HERE.parent / 'mrp_offer_alignment_20261001/shared_007923/run_shared',
        'total': HERE.parent / 'mrp_global_rules_20261001/experiment/run_safety_total_all',
        'safety': HERE / 'experiment/run_need_dates_2',
    }
    execution = json.loads((HERE / 'experiment/need_dates_execution_2.json').read_text(encoding='utf-8'))
    assert execution['returncode'] == 0 and execution['code_unchanged'] and execution['inputs_unchanged']
    source = ROOT / 'etudecas/data/source'
    payload = build_comparison_payload(
        source / 'Flow_Data_Inventory_and_Replenishment_rules.xlsx',
        source / 'Flow_Data_MRP_results.xlsx', runs)
    for key, label, color in (
        ('nominal', 'Référence conservée · 007923 amélioré', '#aa5e12'),
        ('total', 'Comparateur · couverture de sécurité précédente', '#6a7484'),
        ('safety', 'Essai · besoins anticipés des jours de sécurité sources', '#117f88'),
    ):
        payload['runs'][key].update(label=label, color=color)
    payload.update(default_pair='001848/1810', default_runs=list(runs))
    payload['conventions'][:0] = [
        'Essai séparé sur 1 825 jours, sans remplacement de la référence. Les photos et plans industriels permettent une comparaison sur 2025 seulement.',
        'Règle candidate commune aux 22 achats externes : disponibilité souhaitée = besoin restant moins sécurité source lundi–vendredi ; remonter ensuite traitement à réception et délai fournisseur. Aucune fermeture ou fête ajoutée.',
        'Le stock disponible et les réceptions engagées sont déduits à leur disponibilité. Les dates de consommation physique restent inchangées ; la sécurité temporelle ne crée pas une deuxième consommation.',
        'Le comparateur gris est le précédent essai besoins sur 22 achats et protection sur 20, avec fournisseurs explicités. Le candidat conserve ses données et remplace la protection temporelle par les besoins anticipés sur les 22 achats ; les quantités fixes de sécurité, standards et offres sont conservés.',
        '001848 conserve principal moins cher et secours plus rapide, maintenant évalués sur les besoins anticipés. 021081 conserve sa politique de plusieurs fournisseurs et un délai de planification agrégé conservateur.',
        'Les semaines non renseignées restent inconnues et les prévisions sont prises dans les versions connues à la décision. Les prévisions UN peuvent être fractionnaires, les mouvements physiques UN sont entiers.',
        'Les produits fabriqués et transferts internes ne deviennent pas des achats externes. Leurs résultats peuvent changer indirectement avec les disponibilités matières.',
        'Les autres panneaux de la carte complète et ses deux suivis de lots restent historiques. Seul ce panneau de comparaison représente le nouvel essai.',
    ]
    old = previous_module('deliver')
    metrics = old.metrics_for(payload)
    overview = old.overview(payload, metrics)
    overview = overview.replace('Besoins + sécurité', 'Besoins anticipés')
    overview = overview.replace('Besoins industriels', 'Comparateur : sécurité précédente')
    overview = overview.replace(
        'Les deux essais globaux ne la remplacent pas automatiquement.',
        'Le comparateur conserve la couverture précédente ; le nouvel essai applique les échéances anticipées. Aucun remplacement automatique.')
    document = comparison_document(payload).replace('</h1>', '</h1>' + overview, 1)
    folder = ROOT / 'etudecas/resultats/regroupement_001757_20260929'
    base = folder / 'carte_mrp_001893_007923.html'
    standalone = folder / 'comparaison_mrp_besoins_anticipes.html'
    complete = folder / 'carte_mrp_besoins_anticipes.html'
    base_hash = sha(base)
    original = strip_comparison(base.read_text(encoding='utf-8'))
    with standalone.open('x', encoding='utf-8') as stream:
        stream.write(document)
    runtime = COMPARISON_RUNTIME.replace('__ENTRY__', json.dumps(packed(document.encode('utf-8'), standalone.name, 'text/html')))
    runtime = runtime.replace("button.textContent='Comparaisons 2025'", "button.textContent='MRP · besoins anticipés'")
    head, closing, tail = original.rpartition('</html>')
    assert closing
    rendered = head + COMPARISON_START + runtime + COMPARISON_END + closing + tail
    assert strip_comparison(rendered) == original
    with complete.open('x', encoding='utf-8') as stream:
        stream.write(rendered)
    assert sha(base) == base_hash
    write(HERE / 'map_payload.json', payload)
    write(HERE / 'analysis.json', {'metrics': metrics})
    write(HERE / 'map_delivery.json', dict(
        base=str(base), base_sha256=base_hash, standalone=str(standalone), standalone_sha256=sha(standalone),
        complete=str(complete), complete_sha256=sha(complete), payload_sha256=sha(HERE / 'map_payload.json'),
        runs={k: str(v) for k, v in runs.items()}, historical_numeric_and_lot_payloads_unchanged=True))
    print(json.dumps({'status': 'rendered', 'pairs': len(metrics), 'standalone': str(standalone), 'complete': str(complete)}))


if __name__ == '__main__':
    if '--browser' in sys.argv:
        browser = previous_module('check_view')
        browser.HERE = HERE
        browser.ROOT = ROOT
        browser.main()
    else:
        main()
