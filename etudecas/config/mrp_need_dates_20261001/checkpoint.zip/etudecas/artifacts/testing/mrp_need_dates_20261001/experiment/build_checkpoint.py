"""Archive the completed experiment and its small reproduction inputs, once."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path.cwd().resolve()
STUDY = ROOT / 'etudecas/artifacts/testing/mrp_need_dates_20261001'
DEST = ROOT / 'etudecas/config/mrp_need_dates_20261001'
HEAD = '32d403792d4edc718cc8bc299403cfea1b9175bf'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def rel(path):
    return path.relative_to(ROOT).as_posix()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def main():
    assert not DEST.exists(), 'Never replace an existing checkpoint'
    files = set()
    def add(path):
        path = ROOT / path if isinstance(path, str) else path
        assert path.is_file(), path
        files.add(path)
    code = ['simulation/engine/mrp_planning.py', 'simulation/engine/run_first_simulation.py',
            'tests/simulation/test_mrp_policy_reconciliation.py', 'tests/simulation/test_source_comparison.py',
            'visualization/maps/source_comparison.py', 'visualization/maps/source_comparison_view.html']
    for path in code + ['data/reports/mrp_source_rules.md']:
        add('etudecas/' + path)
    specs = {
        'baseline': ('mrp_offer_alignment_20261001/shared_007923/shared_graph.json',
                     'mrp_offer_alignment_20261001/shared_007923/shared_execution.json'),
        'comparator': ('mrp_global_rules_20261001/experiment/safety_total_all_graph.json',
                      'mrp_global_rules_20261001/experiment/safety_total_all_execution.json'),
        'candidate': ('mrp_need_dates_20261001/experiment/candidate_graph.json',
                      'mrp_need_dates_20261001/experiment/need_dates_execution_2.json'),
    }
    recipes = {}
    sources = {}
    for name, (graph_name, proof_name) in specs.items():
        graph, proof = STUDY.parent / graph_name, STUDY.parent / proof_name
        add(graph); add(proof)
        execution = read(proof)
        assert execution['returncode'] == 0 and execution['code_unchanged'] and execution['inputs_unchanged']
        recipes[name] = dict(graph=rel(graph), graph_sha256=sha(graph), execution=rel(proof),
            command=execution['command'], days=1825,
            reference_output=execution['command'][execution['command'].index('--output-dir') + 1])
        for path, digest in execution['input_before'].items():
            if '/data/source/' in path.replace('\\', '/'):
                assert sha(ROOT / path) == digest
                sources[path] = digest
    for name in ['Flow_Data_Inventory_and_Replenishment_rules.xlsx', 'demand_PF.xlsx']:
        path = ROOT / 'etudecas/data/source' / name
        sources[rel(path)] = sha(path)
    for name in ['deliver.py', 'analysis.json', 'map_delivery.json',
                 'experiment/study.py', 'experiment/build_checkpoint.py', 'experiment/inventory.json',
                 'experiment/plan.json', 'experiment/plan_2.json', 'experiment/stable_code.json',
                 'experiment/stable_code_2.json', 'experiment/need_dates_execution.json',
                 'experiment/need_dates.log', 'experiment/need_dates_2.log',
                 'experiment/smoke_day1_execution.json', 'experiment/smoke_day1.log',
                 'oracle/contract_oracle.json', 'oracle/implementation_preflight.json',
                 'oracle/implementation_preflight_2.json', 'oracle/smoke_day1_review.json',
                 'oracle/final_postrun.json', 'oracle/review.py', 'oracle/postrun.py',
                 'view_f72e5ffe/report.json', 'view_review/check_anticipated_view.py',
                 'view_review/run_9e2515fbaa/report.json']:
        add(STUDY / name)
    for name in ['deliver.py', 'check_view.py', 'experiment/inventory.json', 'oracle/source_contract.json']:
        add(STUDY.parent / 'mrp_global_rules_20261001' / name)
    natives = ['doctor-b8e70dc60a5d4f9798cf54d7f038e0bf', 'tests-495f0a7fdbb44b19b6634f3f3b9e51a2',
               'qualify-ae76b4be4e8e45ad850270837a346a1a', 'browser-d381451b344c44cd9263e1bb70f31deb',
               'gate-f6265b4afaa94f24852365f298778ba1']
    for name in natives:
        folder = STUDY / 'native' / name
        assert folder.is_dir()
        for path in folder.rglob('*'):
            if path.is_file() and path.suffix in {'.json', '.xml', '.log'}:
                add(path)
    for path in files:
        assert not any(p.startswith('run_') for p in Path(rel(path)).parts[:-1]) or path.name == 'report.json', path
        assert path.suffix != '.csv', path
        assert path.suffix != '.html' or path.name == 'source_comparison_view.html', path
    README = '''# Essai MRP : besoins anticipés par la sécurité source

Ce checkpoint conserve un essai séparé, pas un nouveau nominal. Sur les 22 achats
externes, 7 références améliorent leur erreur de stock et 15 la dégradent face
au comparateur précédent. Voir le rapport métier et l'oracle archivés.

## Contenu et prérequis

- Trois graphes et leurs commandes exactes de 1 825 jours : référence acceptée
  007923, comparateur safety_total_all, candidat besoins anticipés.
- Six fichiers de code à superposer dans une copie de travail du dépôt au commit
  `32d403792d4edc718cc8bc299403cfea1b9175bf`, plus le rapport métier final.
- Scripts de rendu et leurs deux helpers historiques, petites preuves techniques,
  résultats d'oracle et trace conservée du premier échec d'export, corrigé ensuite.
- Aucun CSV de simulation, gros HTML, payload de carte ni fichier Excel.
  Les six classeurs restent dans `etudecas/data/source` ; leurs SHA-256 sont dans
  `checkpoint/recipes.json`. Les autres dépendances sont celles du dépôt indiqué.

Extraire le ZIP dans une copie de travail séparée de ce dépôt. Les entrées gardent
leurs chemins relatifs au dépôt. Examiner les six snapshots avant superposition.
`checkpoint/contents.json` contient le SHA-256 de chaque entrée archivée.

## Rejouer les trois calculs

Depuis la racine de cette copie, lire les commandes de `checkpoint/recipes.json`.
Elles sont les commandes réellement exécutées, avec leurs paramètres complets.
Remplacer seulement le premier argument par le Python local et choisir un dossier
de sortie neuf via `--output-dir`. Toujours conserver `-B`. Ne pas écraser un calcul.
Les graphes sont autonomes : il n'est pas nécessaire de rejouer la longue chaîne
de scripts de préparation des anciens artifacts.

Exemple de lancement Python, après examen de la recette choisie :

```python
import json, subprocess, sys
from pathlib import Path
recipes = json.loads(Path('checkpoint/recipes.json').read_text(encoding='utf-8'))
command = list(recipes['runs']['candidate']['command'])
command[0] = sys.executable
output = Path('etudecas/artifacts/testing/replay_need_dates/run_candidate')
assert not output.exists()
command[command.index('--output-dir') + 1] = str(output)
subprocess.run(command, check=True)
```

Les deux références ont été calculées avec l'ancien moteur. Le candidat est
opt-in : les tests du comportement par défaut passent, mais ces deux références
n'ont pas été resimulées à l'identique avec les six snapshots archivés. Un rejeu
sur le nouveau code doit être qualifié ; aucune identité bit à bit n'est promise.

## Refaire la comparaison HTML

Pour la comparaison autonome, `build_comparison_payload` et
`comparison_document` suffisent, avec les trois nouvelles sorties et les deux
classeurs Flow. Cela ne dépend pas d'une ancienne carte :

```python
from pathlib import Path
from etudecas.visualization.maps.source_comparison import build_comparison_payload
from etudecas.visualization.maps.portable_diagnostic import comparison_document
source = Path('etudecas/data/source')
runs = {'nominal': Path('CHEMIN_REFERENCE_REJOUEE'),
        'total': Path('CHEMIN_COMPARATEUR_REJOUE'),
        'safety': Path('CHEMIN_CANDIDAT_REJOUE')}
payload = build_comparison_payload(source/'Flow_Data_Inventory_and_Replenishment_rules.xlsx',
                                   source/'Flow_Data_MRP_results.xlsx', runs)
with Path('comparaison_rejouee.html').open('x', encoding='utf-8') as stream:
    stream.write(comparison_document(payload))
```

Le rendu complet livré (tableau de synthèse et insertion dans la carte) est dans
`artifacts/testing/mrp_need_dates_20261001/deliver.py`. Il dépend des helpers
`mrp_global_rules_20261001/deliver.py` et `check_view.py`, tous deux archivés.
Adapter ses chemins de sorties neuves et produire de nouvelles preuves avant
d'utiliser son contrôle navigateur. Ce script exige également la coque historique
`etudecas/resultats/regroupement_001757_20260929/carte_mrp_001893_007923.html`,
non archivée ici. Son SHA-256 figure dans `map_delivery.json`. Ses anciens panneaux
et suivis de lots restent historiques ; seul le panneau comparatif est actualisé.
Sans cette coque, la comparaison autonome ci-dessus reste reproductible.

## Limites des preuves conservées

Le dernier calcul réussit en 664,015 s, avec code et entrées inchangés. Le premier
lancement a échoué sur une colonne optionnelle CSV ; sa trace reste conservée.
Un calcul normal d'un jour a ensuite vérifié les 22 achats et les champs vides
des autres paires, puis le calcul complet a été exécuté et qualifié.
Les preuves natives, la comparaison numérique et le navigateur sont archivés.
Les CSV, captures et gros fichiers référencés ne sont pas tous conservés : ces
manifestes documentent l'exécution d'origine, pas une nouvelle qualification
autonome après extraction. Refaire les contrôles sur les résultats régénérés.
Ne jamais relancer les anciens tests d'altération de fichiers ou de dates.
'''
    DEST.mkdir(parents=True, exist_ok=False)
    with (DEST / 'README.md').open('x', encoding='utf-8') as stream:
        stream.write(README)
    archive = DEST / 'checkpoint.zip'
    entries = {rel(p): p.read_bytes() for p in sorted(files)}
    recipe = dict(base_commit=HEAD, runs=recipes, source_sha256=sources,
        code_snapshot_sha256={f'etudecas/{p}': sha(ROOT / 'etudecas' / p) for p in code},
        limitations='Old references were not re-run on new default engine; tests pass but byte identity is not asserted. Raw sources and large outputs are external.')
    entries['checkpoint/recipes.json'] = json.dumps(recipe, indent=2, ensure_ascii=False).encode('utf-8')
    entries['checkpoint/README.md'] = README.encode('utf-8')
    contents = {name: hashlib.sha256(content).hexdigest() for name, content in entries.items()}
    entries['checkpoint/contents.json'] = json.dumps(contents, indent=2).encode('utf-8')
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
        for name, content in entries.items():
            target.writestr(name, content)
    # Read-only verification of the real archive, not an artificial integrity test.
    with zipfile.ZipFile(archive, 'r') as target:
        assert target.testzip() is None
        assert set(target.namelist()) == set(entries)
        for name, digest in contents.items():
            assert hashlib.sha256(target.read(name)).hexdigest() == digest, name
    proof = dict(status='passed', archive=rel(archive), archive_sha256=sha(archive),
        readme=rel(DEST / 'README.md'), readme_sha256=sha(DEST / 'README.md'),
        entries=len(entries), bytes=archive.stat().st_size, base_commit=HEAD,
        graph_count=3, code_snapshot_count=6, source_workbook_count=len(sources),
        verification='Actual ZIP CRC and SHA-256 of every stored entry checked read-only; no file altered, timestamp restored or dummy fixture created.',
        large_simulation_CSV_or_HTML_included=False)
    with (STUDY / 'archive_proof.json').open('x', encoding='utf-8') as stream:
        json.dump(proof, stream, indent=2, ensure_ascii=False)
    print(json.dumps(proof, ensure_ascii=True))


if __name__ == '__main__':
    main()
