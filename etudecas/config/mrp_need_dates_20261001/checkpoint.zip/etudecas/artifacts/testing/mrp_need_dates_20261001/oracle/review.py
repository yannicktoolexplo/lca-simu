"""Independent date/source oracle and bounded memory examples; no engine imports."""
from pathlib import Path
import argparse,datetime,hashlib,json

parser=argparse.ArgumentParser();parser.add_argument('--implementation',action='store_true');parser.add_argument('--revision',type=int,default=0);args=parser.parse_args()

root=Path('etudecas/artifacts/testing/mrp_need_dates_20261001/oracle')
contract=Path('etudecas/artifacts/testing/mrp_global_rules_20261001/oracle/source_contract.json')
graph=Path('etudecas/artifacts/testing/mrp_global_rules_20261001/experiment/safety_total_all_graph.json')
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
hashes={str(p):sha(p) for p in [contract,graph]}
data=json.loads(contract.read_text());g=json.loads(graph.read_text())
def before_weekdays(day,count):
    assert isinstance(count,int) and count>=0
    result=day
    while count:
        result-=datetime.timedelta(days=1)
        if result.weekday()<5:count-=1
    return result
def timing(need,safety,receipt,delivery):
    available=before_weekdays(need,safety)
    # Latest calendar arrival whose forward QA clock meets the deadline.
    # A naive inverse weekday subtraction is not exact on weekend boundaries.
    def after_weekdays(day,count):
        while count:
            day+=datetime.timedelta(days=1)
            if day.weekday()<5:count-=1
        return day
    arrival=available
    while after_weekdays(arrival,receipt)>available:
        arrival-=datetime.timedelta(days=1)
    release=arrival-datetime.timedelta(days=delivery)
    return {'physical_need_date':need.isoformat(),'target_available_date':available.isoformat(),'target_physical_receipt_date':arrival.isoformat(),'target_order_release_date':release.isoformat()}
example=timing(datetime.date(2025,6,1),20,13,56)
assert example=={'physical_need_date':'2025-06-01','target_available_date':'2025-05-05','target_physical_receipt_date':'2025-04-16','target_order_release_date':'2025-02-19'}
assert timing(datetime.date(2025,6,1),20,13,21)['target_order_release_date']=='2025-03-26'
assert before_weekdays(datetime.date(2025,6,1),0)==datetime.date(2025,6,1)
assert before_weekdays(datetime.date(2025,6,1),1)==datetime.date(2025,5,30)
assert before_weekdays(datetime.date(2025,6,2),1)==datetime.date(2025,5,30)
assert before_weekdays(datetime.date(2025,1,1),1)==datetime.date(2024,12,31)
assert timing(datetime.date(2025,6,1),0,1,0)['target_physical_receipt_date']=='2025-05-29'
assert timing(datetime.date(2025,6,2),0,1,0)['target_physical_receipt_date']=='2025-06-01'
receipts={(r['node_id'],r['item_id']):r['receipt_days'] for r in g['meta']['supplier_delivery_receipt_policy']['rows']}
dates=[]
for row in data['pairs']:
    pair=tuple(row['pair'].split('/'));safety=int(row['source_safety']['days']);receipt=receipts[pair]
    assert float(safety)==row['source_safety']['days']
    for offer in row['edge_offers']:
        lead=offer['lead'];assert int(lead)==lead
        dates.append({'pair':row['pair'],'supplier':offer['supplier'],'safety_source_workdays':safety,'receipt_workdays':receipt,'delivery_calendar_days':lead,'fixed_source_stock_floor':row['graph_safety']['safety_stock_qty'],'uom':row['uom'],**timing(datetime.date(2025,6,1),safety,receipt,int(lead))})
cases=[
 {'name':'anticipated_deadline_past_but_stock_present','decision':20,'physical_due':30,'anticipated_due':16,'remaining_physical_need':100,'available':100,'firm':[],'fixed_floor':0,'expected_new_qty':0,'reason':'Deadline lateness does not create new physical need.'},
 {'name':'late_for_safety_firm_supply_not_bought_twice','decision':20,'physical_due':30,'anticipated_due':16,'remaining_physical_need':100,'available':0,'firm':[{'available_day':25,'qty':100}],'fixed_floor':0,'expected_new_qty':0,'reason':'Existing receipt misses safety anticipation but covers the physical due date; record anticipation lateness separately.'},
 {'name':'fixed_quantity_floor_without_second_time_reserve','decision':20,'physical_due':30,'anticipated_due':16,'remaining_physical_need':100,'available':120,'firm':[],'fixed_floor':50,'expected_new_qty':30,'reason':'120-100+30 leaves exactly50; moving the need must not add a second rate-times-safety quantity.'},
 {'name':'consumed_need_not_revived','decision':31,'physical_due':30,'anticipated_due':16,'remaining_physical_need':0,'available':0,'firm':[],'fixed_floor':0,'expected_new_qty':0,'reason':'Only remaining physical needs are passed to date anticipation, never already consumed original forecasts.'},
 {'name':'held_counted_once','decision':20,'physical_due':30,'anticipated_due':16,'remaining_physical_need':100,'available':20,'firm':[{'available_day':25,'qty':80}],'fixed_floor':0,'expected_new_qty':0,'reason':'Available20 plus held80; physical100 cannot also be credited as available100.'},
 {'name':'minimum_multiple_applies_after_netting','decision':20,'physical_due':30,'anticipated_due':16,'remaining_physical_need':405,'available':100,'firm':[],'fixed_floor':0,'expected_new_qty':305,'binding_purchase_multiple':300,'expected_executed_qty':600,'reason':'Round net305 to600 only where the source multiple is binding; future surplus295 is retained.'},
]
for c in cases:
    assert max(0,c['remaining_physical_need']+c['fixed_floor']-c['available']-sum(r['qty'] for r in c['firm']))==c['expected_new_qty']
assert hashes=={p:sha(Path(p)) for p in hashes}
result={'status':'independent_contract_oracle_prepared_not_implementation_validated','source_hashes':hashes,'calendar':'Monday-Friday safety and receipt; calendar-day delivery; no added holidays','example_001848':example,'source_pair_count':22,'source_offer_dates':dates,'memory_cases':cases,'acceptance':['Keep physical need identity, quantity and due date separate from anticipated planning date.','Reconcile industrial I and own/external demand before anticipation, respecting known vintages and missing weeks.','No source amount, supplier preference, fixed floor, standard, initial stock or actual commitment date changes.','Suppress time-coverage protection already represented by shifted needs; retain fixed quantity safety once.','Keep late firm commitments rather than duplicate procurement; expose anticipation/physical lateness separately.','Recompute from remaining requirements daily; never keep yesterday shifted needs in addition to today residual ones.','Working-day receipt inverse must agree with forward receipt availability, including weekend boundary convention.','Defaults and existing mode must remain identical when the new option is absent.','Final acceptance requires29photo-pair metrics, annual purchase quantities/dates, physical conservation, integerUN and5year customer service.'],'limitations':['This file validates independent dates and arithmetic expectations, not the yet-unreviewed implementation.','The quantity examples assume no demand/service priority conflict; they do not claim actual ERP identification.','Source dates specify model convention; industrial order creation dates are not directly observed.']}
if args.implementation:
    # Import the system under review only after independent expectations exist.
    # Every oracle expectation above uses datetime/simple arithmetic, not this helper.
    import sys
    sys.path.insert(0,str(Path.cwd()))
    files=[Path('etudecas/simulation/engine/mrp_planning.py'),Path('etudecas/simulation/engine/run_first_simulation.py'),Path('etudecas/tests/simulation/test_mrp_policy_reconciliation.py'),root.parent/'experiment/candidate_graph.json']
    before={str(p):sha(p) for p in files}
    candidate=json.loads(files[-1].read_text());assert candidate['meta'].pop('purchase_need_date_policy')=='source_safety_backwards_v1';assert candidate==g
    from etudecas.simulation.engine.mrp_planning import Requirement,FirmReceipt,LotSizing,plan_anticipated_requirements
    from etudecas.simulation.engine.run_first_simulation import mrp_network_plan_trace_values
    checked=[]
    optional=['purchase_need_date_policy','anticipated_safety_working_days','anticipated_fixed_floor_qty','anticipated_late_qty','anticipated_first_shortage_day','anticipated_no_extra_time_floor']
    for legacy in [None,{'dated_requirement_qty':100}]:
        serialized=mrp_network_plan_trace_values(legacy)
        assert all(serialized[k]=='' for k in optional)
    raw={'purchase_need_date_policy':'source_safety_backwards_v1','anticipated_safety_working_days':20,'anticipated_fixed_floor_qty':50,'anticipated_late_qty':100.123456789,'anticipated_first_shortage_day':124,'anticipated_no_extra_time_floor':1}
    serialized=mrp_network_plan_trace_values(raw)
    assert serialized['anticipated_safety_working_days']==20 and serialized['anticipated_first_shortage_day']==124 and serialized['anticipated_no_extra_time_floor']==1
    assert serialized['anticipated_late_qty']==100.123457 and raw['anticipated_late_qty']==100.123456789
    checked.append('CSV optional fields absent on nonpurchase pairs; date/day scalars unscaled')
    for c in cases:
        needs=[Requirement('physical_remaining',c['physical_due'],c['remaining_physical_need'])] if c['remaining_physical_need'] else []
        firm=[FirmReceipt('firm_'+str(n),r['available_day'],r['qty'],'held') for n,r in enumerate(c['firm'])]
        plan,_,audit=plan_anticipated_requirements(decision_day=c['decision'],available_qty=c['available'],requirements=needs,firm_receipts=firm,source_working_days=10,origin_weekday=2,fixed_floor_qty=c['fixed_floor'],lead_days=10)
        assert abs(sum(p.qty for p in plan.proposals)-c['expected_new_qty'])<1e-7,c['name']
        assert audit['protection_points']==(),c['name']
        assert all(a.requirement_id=='physical_remaining' and a.due_day==c['physical_due'] for a in plan.allocations),c['name']
        assert abs(sum(a.qty for a in plan.allocations)-c['remaining_physical_need'])<1e-7,c['name']
        if 'binding_purchase_multiple' in c:
            rounded,_,_=plan_anticipated_requirements(decision_day=c['decision'],available_qty=c['available'],requirements=needs,firm_receipts=firm,source_working_days=10,origin_weekday=2,fixed_floor_qty=c['fixed_floor'],lead_days=10,lot_sizing=LotSizing(multiple=c['binding_purchase_multiple']))
            assert sum(p.qty for p in rounded.proposals)==c['expected_executed_qty']
        checked.append(c['name'])
    origin=datetime.date(2025,1,1)
    def forward(day,n):
        while n:
            day+=datetime.timedelta(days=1)
            if day.weekday()<5:n-=1
        return day
    for need,S,R,L in [(datetime.date(2025,6,1),20,13,56),(datetime.date(2025,6,1),20,13,21),(datetime.date(2025,6,1),0,1,0),(datetime.date(2025,6,2),0,1,0)]:
        n=(need-origin).days;cal=tuple((release,(forward(origin+datetime.timedelta(days=release+L),R)-origin).days) for release in range(n+1))
        plan,_,_=plan_anticipated_requirements(decision_day=0,available_qty=0,requirements=[Requirement('need',n,100)],firm_receipts=[],source_working_days=S,origin_weekday=2,fixed_floor_qty=0,lead_days=L+R,availability_by_release=cal)
        expect=timing(need,S,R,L);assert len(plan.proposals)==1
        assert plan.proposals[0].release_day==(datetime.date.fromisoformat(expect['target_order_release_date'])-origin).days
        assert plan.proposals[0].available_day<=((datetime.date.fromisoformat(expect['target_available_date'])-origin).days)
        checked.append({'need':need.isoformat(),'S':S,'R':R,'L':L,'release':plan.proposals[0].release_day})
    assert before=={p:sha(Path(p)) for p in before}
    result['implementation_checked_cases']=checked;result['implementation_hashes']=before;result['status']='independent_memory_and_graph_preflight_pass_not_calibration'
root.mkdir(parents=True,exist_ok=True);out=root/(('implementation_preflight'+('_'+str(args.revision) if args.revision else '')+'.json') if args.implementation else 'contract_oracle.json');out.write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({'proof':str(out),'sha256':sha(out),'example':example,'offers_checked':len(dates),'cases':len(cases),'status':result['status']}))
