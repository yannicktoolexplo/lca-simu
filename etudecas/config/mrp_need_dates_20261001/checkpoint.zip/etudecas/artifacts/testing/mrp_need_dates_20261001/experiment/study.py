"""Isolated source-safety need-date experiment; new normal outputs only."""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
PREVIOUS = ROOT / 'etudecas/artifacts/testing/mrp_global_rules_20261001/experiment'
POLICY = 'source_safety_backwards_v1'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def rel(path):
    return Path(path).resolve().relative_to(ROOT).as_posix()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write(path, value, replace=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w' if replace else 'x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)


def code_hashes():
    paths = sorted((ROOT / 'etudecas/simulation/engine').glob('*.py'))
    paths.extend(sorted((ROOT / 'etudecas/tests/simulation').glob('test_mrp*.py')))
    paths.append(ROOT / 'etudecas/simulation/experiments/shared_components.py')
    return {rel(p): sha(p) for p in paths}


def prepare(replace=False):
    assert not (HERE / 'stable_code.json').exists(), 'Never revise after freeze'
    assert not (HERE / 'run_need_dates').exists(), 'Never revise after run'
    baseline_path = PREVIOUS / 'safety_total_all_graph.json'
    execution_path = PREVIOUS / 'safety_total_all_execution.json'
    old, execution = read(baseline_path), read(execution_path)
    assert execution['returncode'] == 0 and execution['inputs_unchanged'] and execution['code_unchanged']
    assert 'purchase_need_date_policy' not in old['meta']
    previous_inventory = read(PREVIOUS / 'inventory.json')
    pairs = {(s['node_id'], s['item_id']) for s in old['meta']['industrial_component_planning']['versioned_series']}
    assert len(pairs) == 22
    assert pairs == {(s['node_id'], s['item_id']) for s in previous_inventory['pairs']}
    states = {(n['id'], s['item_id']): s for n in old['nodes'] for s in n.get('inventory', {}).get('states', [])}
    nodes = {n['id']: n for n in old['nodes']}
    receipts = {(r['node_id'], r['item_id']): r for r in old['meta']['supplier_delivery_receipt_policy']['rows']}
    policies = {(r['node_id'], r['item_id']): r for r in old['meta']['supplier_planning_policy']['rows']}
    source_inventory = {(r['node_id'], r['item_id']): r for r in previous_inventory['pairs']}
    scenario = next(s for s in old['scenarios'] if s['id'] == 'scn:BASE')
    inventory = []
    for pair in sorted(pairs):
        node, item = pair
        policy = states[pair]['mrp_policy']
        source = source_inventory[pair]
        assert policy.get('safety_time_days', 0) == source['source_safety_working_days']
        assert policy.get('safety_stock_qty', 0) == source['source_safety_stock_qty']
        offers = []
        for edge in old['edges']:
            if edge.get('type') != 'transport' or edge['to'] != node or item not in edge.get('items', []):
                continue
            assert nodes[edge['from']]['type'] == 'supplier_dc'
            offers.append(dict(supplier_id=edge['from'], lead_time=deepcopy(edge['lead_time']),
                order_terms=deepcopy(edge.get('order_terms', {})), source_attrs=deepcopy(edge.get('attrs', {}))))
        assert offers
        inventory.append(dict(node_id=node, item_id=item, uom=states[pair]['uom'],
            safety_S_working_days=policy.get('safety_time_days', 0), safety_calendar='Monday-Friday',
            fixed_safety_qty=policy.get('safety_stock_qty', 0), fixed_safety_uom=policy.get('safety_stock_uom'),
            quality_R_working_days=receipts[pair]['receipt_days'], quality_source=deepcopy(receipts[pair]),
            supplier_offers=offers, baseline_supplier_policy=deepcopy(policies.get(pair)),
            baseline_executed_suppliers=source['reference_suppliers'],
            source_version_count=source['source_version_count'], source_future_rows=source['future_row_count'],
            source_known_days=source['source_known_days'],
            review_period_calendar_days=scenario['review_period_days'],
            planning_supplier_lead_unchanged=(source['selected_planning_supplier_lead']
                if pair in policies else source['old_planning_supplier_lead']),
            temporal_protection='Source safety time applied once to remaining need dates; previous temporal floor and coverage suppressed by opt-in engine rule only.',
            physical='Original demand dates, fixed source stock floor, supplier choices, source receipts, units and standard quantities unchanged.'))
    graph = deepcopy(old)
    graph['meta']['purchase_need_date_policy'] = POLICY
    restored = deepcopy(graph)
    del restored['meta']['purchase_need_date_policy']
    assert restored == old
    candidate = HERE / 'candidate_graph.json'
    write(candidate, graph, replace=replace)
    write(HERE / 'inventory.json', dict(pairs=inventory, count=22,
        source='Existing graph inventories, supplier offers, receipt policy and verified global source inventory; no inferred new parameter.',
        affected_scope='All 22 external aggregate purchase pairs, including multi-supplier pairs without freezing supplier choices.',
        physical_UN='Execution integer constraints retained; forecasts remain unrounded.',
        missing='Only actual source versions retained; 344135 has 17 vintages, not 52 invented ones.'), replace=replace)
    command = list(execution['command'])
    assert command[command.index('--input') + 1] == rel(baseline_path)
    assert command[command.index('--days') + 1] == '1825'
    assert command[1] == '-B'
    command[0] = sys.executable
    command[command.index('--input') + 1] = rel(candidate)
    command[command.index('--output-dir') + 1] = rel(HERE / 'run_need_dates')
    # Carry all original source fingerprints forward, including raw Excel inputs.
    paths = {ROOT / p for p in execution['input_before']}
    paths.update((baseline_path, execution_path, PREVIOUS / 'inventory.json', candidate,
                  HERE / 'inventory.json', Path(__file__).resolve()))
    for path, digest in execution['input_before'].items():
        assert sha(ROOT / path) == digest, path
    write(HERE / 'plan.json', dict(command=command, days=1825,
        input_sha256={rel(p): sha(p) for p in sorted(paths)},
        reference_run=rel(PREVIOUS / 'run_safety_total_all'),
        accepted_comparison_run='etudecas/artifacts/testing/mrp_offer_alignment_20261001/shared_007923/run_shared',
        graph_difference={'meta.purchase_need_date_policy': POLICY},
        graph_restoration_equal=True, inherited_policy_rows=len(policies),
        baseline_revision='Parent decision before freeze/run: use safety_total_all instead of total_all to preserve its 20 explicit supplier offers and aligned nominal delivery (001893 28 rather than 56 days); both bases carry exactly the same 22 total-I series. Candidate still changes one metadata key only.',
        contract='Shift remaining purchase requirements backwards by source working-day safety, bounded at current decision; preserve original physical requirement dates and fixed source stock floor. Disable temporal protection duplication in opt-in engine branch, preserve all old graph policies and sourcing.',
        unchanged='Total-I causal vintages, physical external needs, initial stocks, supplier choices/prices/nominal delivery/quality/standard quantities, source safety values, nonbinding standards, CRN/scenario/horizon/options.',
        pending='Freeze engine/test hashes only after engine owner and parent confirm stability and targeted tests; do not run before explicit parent go-ahead.',
        acceptance='Independent graph/source oracle, engine targeted memory tests, normal 1825-day run, invariant qualification, all-pair annual/Q1/Q4 stock and service comparison. No automatic industrial acceptance.'), replace=replace)
    print(json.dumps(dict(prepared=True, pairs=22, only_graph_change='meta.purchase_need_date_policy',
                         plan=rel(HERE / 'plan.json'), run_started=False)))


def attempt_file(name, attempt):
    path = Path(name)
    return HERE / (path.name if attempt == 1 else f'{path.stem}_{attempt}{path.suffix}')


def prepare_retry(attempt):
    assert attempt == 2
    first = read(HERE / 'need_dates_execution.json')
    assert first['returncode'] != 0, 'Retry requires a recorded failure'
    plan = deepcopy(read(HERE / 'plan.json'))
    this_script = rel(Path(__file__).resolve())
    for path, digest in plan['input_sha256'].items():
        if path != this_script:
            assert sha(ROOT / path) == digest, path
    plan['input_sha256'][this_script] = sha(Path(__file__).resolve())
    for name in ('plan.json', 'need_dates_execution.json', 'need_dates.log', 'stable_code.json'):
        plan['input_sha256'][rel(HERE / name)] = sha(HERE / name)
    plan['command'][plan['command'].index('--output-dir') + 1] = rel(HERE / 'run_need_dates_2')
    plan['attempt'] = 2
    plan['smoke_command'] = list(plan['command'])
    plan['smoke_command'][plan['smoke_command'].index('--days') + 1] = '1'
    plan['smoke_command'][plan['smoke_command'].index('--output-dir') + 1] = rel(HERE / 'smoke_day1')
    plan['prior_attempt'] = dict(execution=rel(HERE / 'need_dates_execution.json'),
        returncode=first['returncode'], reason='Optional CSV audit key missing on noneligible pairs; no valid result. Original failed outputs and proofs retained.')
    write(HERE / 'plan_2.json', plan)
    print(json.dumps(dict(prepared=True, attempt=2, run_started=False, plan=rel(HERE / 'plan_2.json'))))


def freeze(attempt=1):
    plan_path = attempt_file('plan.json', attempt)
    plan = read(plan_path)
    for path, digest in plan['input_sha256'].items():
        assert sha(ROOT / path) == digest, path
    stable_path = attempt_file('stable_code.json', attempt)
    write(stable_path, dict(utc=datetime.now(timezone.utc).isoformat(),
        plan_sha256=sha(plan_path), code=code_hashes()))
    print(json.dumps(dict(frozen=True, manifest=rel(stable_path))))


def run(attempt=1, smoke=False):
    plan_path, stable_path = attempt_file('plan.json', attempt), attempt_file('stable_code.json', attempt)
    plan, frozen = read(plan_path), read(stable_path)
    assert sha(plan_path) == frozen['plan_sha256']
    for path, digest in plan['input_sha256'].items():
        assert sha(ROOT / path) == digest, path
    before = code_hashes()
    assert before == frozen['code'], 'Code changed after freeze'
    command = plan['smoke_command'] if smoke else plan['command']
    output_path = ROOT / command[command.index('--output-dir') + 1]
    assert not output_path.exists(), 'Never overwrite a run'
    started_utc, started = datetime.now(timezone.utc).isoformat(), time.monotonic()
    log_path = HERE / 'smoke_day1.log' if smoke else attempt_file('need_dates.log', attempt)
    with log_path.open('x', encoding='utf-8') as stream:
        completed = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    after = code_hashes()
    inputs_after = {path: sha(ROOT / path) for path in plan['input_sha256']}
    result = dict(returncode=completed.returncode, seconds=time.monotonic() - started,
        started_utc=started_utc, ended_utc=datetime.now(timezone.utc).isoformat(), command=command,
        plan_sha256=sha(plan_path), stable_code_sha256=sha(stable_path), attempt=attempt,
        code_before=before, code_after=after, code_unchanged=before == after,
        input_before=plan['input_sha256'], input_after=inputs_after, inputs_unchanged=inputs_after == plan['input_sha256'])
    result_path = HERE / 'smoke_day1_execution.json' if smoke else attempt_file('need_dates_execution.json', attempt)
    write(result_path, result)
    print(json.dumps({k: result[k] for k in ('returncode', 'seconds', 'code_unchanged', 'inputs_unchanged')}))
    if completed.returncode or before != after or not result['inputs_unchanged']:
        raise SystemExit(completed.returncode or 1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'freeze', 'run', 'smoke'])
    parser.add_argument('--update-preparation', action='store_true')
    parser.add_argument('--attempt', type=int, choices=[1, 2], default=1)
    args = parser.parse_args()
    if args.update_preparation and args.action != 'prepare':
        parser.error('--update-preparation is only valid before freeze/run')
    if args.action == 'prepare':
        if args.attempt == 2:
            prepare_retry(args.attempt)
        else:
            prepare(replace=args.update_preparation)
    elif args.action == 'smoke':
        if args.attempt != 2:
            parser.error('smoke requires --attempt 2')
        run(args.attempt, smoke=True)
    else:
        {'freeze': freeze, 'run': run}[args.action](args.attempt)
