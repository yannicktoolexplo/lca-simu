"""Offline comparison checks against payload and raw CSVs, with Q4 selections."""
import csv
import hashlib
import json
from pathlib import Path
from uuid import uuid4
from playwright.sync_api import sync_playwright

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    output = HERE / ('view_' + uuid4().hex[:8])
    output.mkdir(exist_ok=False)
    data = json.loads((HERE/'map_payload.json').read_text(encoding='utf-8'))
    delivery = json.loads((HERE/'map_delivery.json').read_text(encoding='utf-8'))
    html = Path(delivery['standalone'])
    assert sha(html) == delivery['standalone_sha256']
    assert sha(HERE/'map_payload.json') == delivery['payload_sha256']
    errors, checked, q4_count, table_count, overview_count = [], [], 0, 0, 0
    focus=('002612/1810','007923/1810','016332/1810','029313/1810','038005/1430','039668/1810','049371/1810','333362/1430')
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=True)
        try:
            page = browser.new_page(offline=True, viewport={'width':1600,'height':1000})
            page.on('pageerror', lambda error: errors.append(str(error)))
            page.goto(html.resolve().as_uri(), wait_until='load', timeout=90000)
            root = page.locator('#sourceComparisonRoot')
            root.wait_for(state='visible')
            assert root.evaluate('()=>SOURCE_COMPARISON_VIEW.getState().pair') == data['default_pair']
            metrics=json.loads((HERE/'analysis.json').read_text(encoding='utf-8'))['metrics']
            for record in metrics:
                if not all(run in record['scenarios'] for run in data['runs']): continue
                row=page.locator(f'#globalRuleOverview tr[data-pair="{record["pair"]}"]')
                for run in data['runs']:
                    for field in ('mae','q4_mae'):
                        actual=row.locator(f'[data-overview-run="{run}"][data-metric="{field}"]').get_attribute('data-value')
                        expected=record['scenarios'][run][field]
                        assert expected is None and actual=='None' or abs(float(actual)-expected)<1e-6
                        overview_count+=1
            page.locator('#globalRuleOverview').screenshot(path=str(output/'overview.png'))
            for run in data['runs']:
                page.locator(f'input[data-run="{run}"]').check()
            tabs = page.locator('[role=tab][data-tab]').evaluate_all('xs=>xs.map(x=>x.dataset.tab)')
            for tab in tabs:
                page.locator(f'[data-tab="{tab}"]').click()
                assert page.locator('#sourceComparisonPanel').inner_text().strip()
            page.locator('[data-tab="stocks"]').click()
            for key,pair in data['pairs'].items():
                if not all(pair['simulations'].get(run,{}).get('metrics',{}).get('previous_day_physical') for run in data['runs']):
                    continue
                page.locator('#sourceComparisonPair').select_option(key)
                page.locator('#sourceComparisonBasis').select_option('physical')
                page.locator('#sourceComparisonReset').click()
                count = 0
                for run in data['runs']:
                    actual = root.evaluate('(el,key)=>SOURCE_COMPARISON_VIEW.getComparisonRows(key)', run)
                    stocks = {row[0]:row[5] for row in pair['simulations'][run]['stock']}
                    expected = [(d,q,stocks[d-1]) for d,q,_ in pair['observed'] if d>0 and isinstance(stocks.get(d-1),(int,float))]
                    assert len(actual)==len(expected)>0
                    for row,(day,source,simulated) in zip(actual,expected):
                        assert row['day']==day and abs(row['observed']-source)<1e-6 and abs(row['simulated']-simulated)<1e-6
                        count += 1
                checked.append({'pair':key,'values':count})
            for pair in focus:
                page.locator(f'button[data-open-pair="{pair}"]').click()
                assert root.evaluate('()=>SOURCE_COMPARISON_VIEW.getState().pair') == pair
                page.locator('#sourceComparisonStart').fill('2025-10-01')
                page.locator('#sourceComparisonStart').dispatch_event('change')
                for run in data['runs']:
                    rows = root.evaluate('(el,key)=>SOURCE_COMPARISON_VIEW.getComparisonRows(key)',run)
                    assert len(rows)==13 and all(273<=row['day']<=364 for row in rows)
                    q4_count += len(rows)
                if pair in ('007923/1810','333362/1430'):
                    page.locator('#chart-stocks').screenshot(path=str(output/(pair.split('/')[0]+'_q4.png')))
            page.locator('input[data-run="safety"]').uncheck()
            assert 'safety' not in root.evaluate('()=>SOURCE_COMPARISON_VIEW.getState().runs')
            page.locator('input[data-run="safety"]').check()
            assert 'safety' in root.evaluate('()=>SOURCE_COMPARISON_VIEW.getState().runs')
            before=root.evaluate('()=>SOURCE_COMPARISON_VIEW.getState()')
            page.locator('#sourceComparisonZoomIn').click()
            after=root.evaluate('()=>SOURCE_COMPARISON_VIEW.getState()')
            assert after['end']-after['start']<before['end']-before['start']
            page.locator('#sourceComparisonReset').click()
            page.locator('[data-tab="mrp"]').click()
            fields=['dated_protection_target_qty','dated_source_protection_target_qty','dated_coverage_complement_qty','industrial_source_requirement_qty','industrial_planning_requirement_qty','industrial_source_excess_own_qty']
            for pair in focus:
                page.locator('#sourceComparisonPair').select_option(pair)
                details=page.locator('#sourceComparisonPlanningDetails')
                if details.get_attribute('open') is None:
                    details.locator('summary').click()
                item,site=pair.split('/')
                expected={}
                for run in ('total','safety'):
                    with (Path(delivery['runs'][run])/'data/mrp_trace_daily.csv').open(encoding='utf-8-sig',newline='') as stream:
                        expected[run]={int(row['day']):row for row in csv.DictReader(stream) if row['item_id']=='item:'+item and row['node_id']=='M-'+site and int(row['day']) in (270,300,330,361)}
                for day in (270,300,330,361):
                    page.locator('#sourceComparisonPlanningDay').select_option(str(day))
                    for run in ('total','safety'):
                        for field in fields:
                            raw=expected[run][day][field]
                            if raw=='':
                                continue
                            cell=page.locator(f'#sourceComparisonPlanningDetails [data-run="{run}"] [data-field="{field}"]')
                            assert abs(float(cell.get_attribute('data-value'))-float(raw))<1e-6
                            table_count+=1
            complete=Path(delivery['complete'])
            assert sha(complete)==delivery['complete_sha256']
            page.goto(complete.resolve().as_uri(),wait_until='load',timeout=90000)
            page.locator('#sourceComparisonOpenBtn').click()
            frame=page.frame_locator('#sourceComparisonFrame')
            frame.locator('#globalRuleOverview').wait_for(state='visible',timeout=90000)
            assert frame.locator('#sourceComparisonRoot').evaluate('()=>SOURCE_COMPARISON_VIEW.getState().pair')==data['default_pair']
            assert frame.locator('#globalRuleOverview tbody tr').count()==len(checked)
            page.locator('#sourceComparisonCloseBtn').click()
            assert not errors, errors
        finally:
            browser.close()
    report={'status':'passed','html':str(html),'html_sha256':sha(html),'offline':True,
            'stock_values':sum(row['values'] for row in checked),'pairs':checked,'q4_values':q4_count,
            'planning_table_values':table_count,'overview_values':overview_count,'complete_map_comparison_open_close':True,'tabs':tabs,'javascript_errors':errors,
            'limits':'Stock values, selected planning cells, Q4 filtering, selectors and zoom checked; not exhaustive UI coverage.'}
    (output/'report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({'report':str(output/'report.json'),'status':'passed','stock_values':report['stock_values'],'planning_table_values':table_count}))


if __name__=='__main__':
    main()
