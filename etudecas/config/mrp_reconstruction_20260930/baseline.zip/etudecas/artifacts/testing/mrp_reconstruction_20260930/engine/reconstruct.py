"""Source-plan reconstruction only: no simulator and no modification of sources."""
from collections import defaultdict
from datetime import date, datetime, timedelta
from decimal import Decimal, ROUND_CEILING
import argparse
import hashlib
import json
from pathlib import Path
import openpyxl

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
SOURCE = ROOT / 'etudecas/data/source'
D = Decimal
ZERO = D(0)
EPS = D('0.000001')
CONFIG = {
    '001757': {'lead': 84, 'weeks': (4, 6, 7), 'step': 1000, 'unit': 'KG'},
    '001848': {'lead': 56, 'weeks': (6, 7), 'step': 6000, 'unit': 'KG'},
    '002612': {'lead': 35, 'weeks': (6,), 'step': 22500, 'alternative_steps': (23750,), 'unit': 'KG'},
    '338929': {'lead': 42, 'weeks': (3,), 'step': 1, 'unit': 'UN'},
}
HASHES = {}


def track(path):
    HASHES[path.relative_to(ROOT).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    return path


def stamp(v):
    return v.date() if isinstance(v, datetime) else date.fromisoformat(str(v)[:10])


def code(v):
    return str(v).strip().removesuffix('.0').zfill(6)


def dec(v, uom):
    if v is None or isinstance(v, bool) or uom not in {'G', 'KG', 'ZUN', 'UN'}:
        raise ValueError(('Not a source quantity', v, uom))
    value = D(str(v)) * (D('.001') if uom == 'G' else D(1))
    if not value.is_finite():
        raise ValueError(v)
    return value


def ceil_step(value, step):
    if value <= ZERO:
        return ZERO
    return (value / D(step)).to_integral_value(rounding=ROUND_CEILING) * D(step)


def read_sources():
    plans = {item: defaultdict(list) for item in CONFIG}
    wb = openpyxl.load_workbook(track(SOURCE / 'Flow_Data_MRP_results.xlsx'), read_only=True, data_only=True)
    for n, row in enumerate(wb.active.iter_rows(min_row=2, values_only=True), 2):
        item = code(row[1])
        if item not in plans or str(row[3]) != '1810':
            continue
        plans[item][stamp(row[0])].append(dict(source_row=n, date=stamp(row[6]),
            **{k: dec(row[c], row[5]) for k, c in [('H', 7), ('I', 8), ('J', 9), ('K', 10)]}))
    wb.close()
    previous = json.loads(track(ROOT / 'etudecas/artifacts/testing/mrp_common_rules_20260930/grouping/analysis.json').read_text(encoding='utf-8'))
    # Reuse the already audited catalogue only when its industrial inputs still match.
    for name in ['Flow_Data_MRP_results.xlsx', 'Flow_Data_Inventory_and_Replenishment_rules.xlsx', '268091.xlsx', 'Extract_En_cours.xlsx']:
        path = track(SOURCE / name)
        key = path.relative_to(ROOT).as_posix()
        if HASHES[key] != previous['input_sha256'][key]:
            raise ValueError(('Source changed since catalogue', key))
    track(ROOT / 'etudecas/artifacts/testing/mrp_source_driven_20260928/source_supply/autonomous_projection.json')
    for pp in plans.values():
        assert len(pp) == 52
        for rr in pp.values():
            rr.sort(key=lambda r: r['date'])
            assert len({r['date'] for r in rr}) == len(rr)
            previous_K = ZERO
            for r in rr:
                assert abs(r['K'] - (previous_K + r['J'] + r['H'] - r['I'])) < EPS
                previous_K = r['K']
    return plans, previous


def selected_period(vintage):
    if vintage == date(2025, 1, 5):
        return '2025_H1', date(2025, 1, 1), date(2025, 6, 30)
    if vintage == date(2025, 7, 6):
        return '2025_H2', date(2025, 7, 1), date(2025, 12, 31)
    return None, None, None


def scores(rows):
    if not rows:
        return None
    error = sum((abs(r['H_reconstructed'] - r['H_source']) for r in rows), ZERO)
    actual = sum((r['H_source'] for r in rows), ZERO)
    mismatch = next((r for r in rows if abs(r['H_reconstructed']-r['H_source']) >= EPS), None)
    return dict(H_n=len(rows), H_positive_n=sum(r['H_source'] > 0 for r in rows),
        H_exact=sum(abs(r['H_reconstructed']-r['H_source']) < EPS for r in rows),
        H_positive_exact=sum(r['H_source'] > 0 and abs(r['H_reconstructed']-r['H_source']) < EPS for r in rows),
        H_MAE=error / len(rows), H_WAPE=error / actual if actual else None,
        H_source_sum=actual, H_reconstructed_sum=sum((r['H_reconstructed'] for r in rows), ZERO),
        K_MAE=sum((abs(r['K_reconstructed']-r['K_source']) for r in rows), ZERO)/len(rows),
        rows_with_internal_gap_in_coverage=sum(bool(r['window_missing_dates']) for r in rows),
        first_divergence=None if mismatch is None else {k: mismatch[k] for k in ['date','source_row','H_source','H_reconstructed','K_source','K_reconstructed']})


def replay(item, vintage, source_rows, weeks, config):
    lookup = {r['date']: r for r in source_rows}
    first, last = source_rows[0]['date'], source_rows[-1]['date']
    assert all((r['date']-first).days % 7 == 0 for r in source_rows)
    period, low, high = selected_period(vintage)
    firm_end = vintage + timedelta(days=config['lead'])
    rows = []
    balance = ZERO  # Source recurrence begins with zero; initial stock arrives through dated J.
    n = (last-first).days//7+1
    for i in range(n):
        target = first + timedelta(days=7*i)
        source = lookup.get(target)
        needs = source['I'] if source else ZERO
        existing = source['J'] if source else ZERO
        before_receipt = balance + existing - needs
        future_dates = [target + timedelta(days=7*d) for d in range(1, weeks+1)]
        truncated = future_dates[-1] > last
        # Never label the beyond-source tail as known zero. A truncated candidate is
        # still drawn, but it is excluded from every comparable metric.
        in_domain = [t for t in future_dates if t <= last]
        missing = [t for t in in_domain if t not in lookup]
        coverage = sum((lookup[t]['I']-lookup[t]['J'] for t in in_domain if t in lookup), ZERO)
        imposed = target < firm_end
        if imposed:
            receipt = source['H'] if source else ZERO
            basis = 'source_H_assumed_firm' if source else 'missing_prefix_zero_hypothesis'
        else:
            receipt = ceil_step(coverage-before_receipt, config['step'])
            basis = 'candidate_netting_truncated_window' if truncated else 'candidate_netting'
        balance = before_receipt + receipt
        comparable = source is not None and not imposed and not truncated
        row = dict(date=target, day=(target-date(2025,1,1)).days,
            source_row=source['source_row'] if source else None,
            H_source=source['H'] if source else None, I_source=source['I'] if source else None,
            J_source=source['J'] if source else None, K_source=source['K'] if source else None,
            I_used=needs, J_used=existing, H_reconstructed=receipt, K_reconstructed=balance,
            prefix_imposed=imposed, missing_source=source is None,
            window_missing_dates=missing, window_truncated=truncated, coverage_incomplete=truncated,
            coverage_target_qty=coverage, H_basis=basis,
            comparable=comparable, scored=bool(comparable and period and low <= target <= high))
        if config['unit'] == 'UN':
            assert receipt == receipt.to_integral_value()
        rows.append(row)
    # No H/K values are read by the post-prefix transition above: they are comparison
    # fields only. This replay does not infer new purchase-order issue dates.
    return dict(variant_id=f'coverage_{weeks}w_round_{config["step"]}',
        coverage_weeks=weeks, rounding_qty=config['step'], lead_calendar='calendar_days',
        firm_prefix_end_exclusive=firm_end,
        scores=scores([r for r in rows if r['scored']]),
        diagnostic_single_plan_scores=scores([r for r in rows if r['comparable']]),
        rows=rows)


def serial(v):
    if isinstance(v, Decimal):
        return float(v)
    if isinstance(v, (date, datetime)):
        return v.isoformat()
    raise TypeError(type(v))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--replace-unqualified', action='store_true',
                        help='Explicitly regenerate this unqualified artifact after a coordinated contract update.')
    args = parser.parse_args()
    output = HERE / 'reconstruction.json'
    replaced_hash = hashlib.sha256(output.read_bytes()).hexdigest() if output.exists() else None
    if output.exists() and not args.replace_unqualified:
        raise FileExistsError('Do not overwrite a reconstruction evidence file')
    plans, previous = read_sources()
    result = dict(schema_version=1, status='source_plan_reconstruction_not_physical_simulation',
        replaces_unqualified_reconstruction_sha256=replaced_hash,
        input_sha256=HASHES, script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        equation='pre=K_reconstructed_previous+J_current-I_current; target=sum(I-J of following N weeks); H=ceil_step(max(target-pre,0)); K=pre+H',
        assumptions=dict(initial_balance='Zero before the first recorded row; stock supplied once via its dated J cells.',
            firm_prefix='Source H copied strictly before vintage+FIAlead calendar days; assumed engagements, excluded from scores.',
            gaps='Inside first/last recorded target only, absent I/J and imposed-prefix H use zero as an explicit hypothesis. Source fields remain null and absent target rows are not scored.',
            terminal='Coverage after last recorded target is unknown. Truncated-window proposals are labelled and excluded from comparable scores. No terminal stock fit.',
            balance='K is the source projected balance convention, not physical stock or proof of availability at the factory.',
            versions='52 independent alternative projections per article. Never add different vintages as executed movements.',
            evidence_status='Rules were selected after inspecting2025; distinct target semesters are descriptive checks, not an unseen statistical holdout.',
            demand='I forecasts known at the selected vintage; current I may contain carried backlog. No physical consumption is executed.'),
        pairs=[], main_scores=[], checks={},
        diagnostic_notes=dict(
            fixed_variants='001757 seven weeks added from the previously specified ceil((20+13)/5) formula;00261223750 is an existing FIA offer. Both candidates remain constant across all vintages, without seasonal selection.',
            article_001848_terminal='The3331.16 receipt onMay18 inJan5plan is terminal but its following seven weeks are inside the exported horizon endingOct19; it remains a valid positive counterexample, not excluded as incomplete.',
            article_001757_April13_versions=[dict(vintage=vintage, days_before_target=(date(2025,4,13)-vintage).days,
                source_row=r['source_row'], H_source=r['H'], I_source=r['I'], J_source=r['J'], K_source=r['K'])
                for vintage, rr in sorted(plans['001757'].items()) if vintage<=date(2025,4,13)
                for r in rr if r['date']==date(2025,4,13)],
            article_001757_April13_interpretation='3000 at98days changes to0 at91days then2000 at84days, stable thereafter. This does not support assuming the first3000 already firm beyondFIA84. Later stability is compatible with commitments but no order IDs prove it.'))
    total_rows = 0
    for item, config in CONFIG.items():
        desc = previous['items'][item]['description']
        pp = dict(item_id=item, node_id='M-1810', site_id='1810', unit=config['unit'],
            source_parameters=dict(fia=desc['fia'], stock_policies=desc['policies'], receipt_source_days=desc['receipt_source_days']),
            candidate_parameters=dict(firm_prefix_lead_days=config['lead'], coverage_weeks=list(config['weeks']),
                rounding_qty=config['step'], rounding_status=('empirical1000_receipt_pattern_not_source_FIA100' if item=='001757' else
                  'primary6000_only_no_invented_backup' if item=='001848' else
                  'chosen_source_standard22500_not_proven_single_supplier' if item=='002612' else
                  'unit_granularity_nonbinding5000_receipt_approximation'),
                alternative_rounding_qty=list(config.get('alternative_steps', ())),
                calendar_status='FIA interpreted in calendar days for consistency with existing candidate; not newly validated'), plans=[])
        for vintage, rr in sorted(plans[item].items()):
            label, _, _ = selected_period(vintage)
            plan = dict(vintage_date=vintage, domain_start=rr[0]['date'], domain_end=rr[-1]['date'],
                scored_target_period=label, source_rows=len(rr),
                variants=[replay(item, vintage, rr, w, dict(config, step=step))
                          for w in config['weeks'] for step in (config['step'], *config.get('alternative_steps', ()))])
            for variant in plan['variants']:
                total_rows += len(variant['rows'])
                if label:
                    result['main_scores'].append(dict(item_id=item, unit=config['unit'], vintage_date=vintage,
                        target_period=label, variant_id=variant['variant_id'], scores=variant['scores']))
            pp['plans'].append(plan)
        result['pairs'].append(pp)
    # Explicitly prove the main target-date sets are disjoint for each fixed candidate.
    for pair in result['pairs']:
        early = next(p for p in pair['plans'] if p['scored_target_period']=='2025_H1')
        late = next(p for p in pair['plans'] if p['scored_target_period']=='2025_H2')
        for a, b in zip(early['variants'], late['variants']):
            assert not ({r['date'] for r in a['rows'] if r['scored']} & {r['date'] for r in b['rows'] if r['scored']})
    result['checks'] = dict(source_balance_recurrence=True, all_pairs_52_versions=True,
        physical_UN_proposal_quantities_integral=True, main_scored_target_sets_disjoint=True,
        input_hashes_unchanged=all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in HASHES.items()),
        total_variant_rows=total_rows)
    assert result['checks']['input_hashes_unchanged']
    with output.open('w' if args.replace_unqualified else 'x', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, separators=(',', ':'), default=serial)
        f.write('\n')
    print(json.dumps(dict(path=output.as_posix(), sha256=hashlib.sha256(output.read_bytes()).hexdigest(),
        main_scores=result['main_scores'], checks=result['checks']), indent=2, default=serial))


if __name__ == '__main__':
    main()
