# Retrouver le calcul MRP à partir des plans industriels

## Résultat livré

La [carte de reconstitution](../../../resultats/regroupement_001757_20260929/carte_reconstitution_mrp.html) reprend intégralement la carte de regroupement choisie par l'utilisateur. Son bouton **Reconstitution MRP** ajoute une comparaison entre le plan industriel et un calcul indépendant. Les deux cartes de référence, leurs comparaisons de stocks et leurs suivis de lots sont conservés. Les calculs du nouveau panneau ne remplacent pas ceux des autres onglets.

Le panneau permet de choisir quatre articles à Avène, chacune de leurs 52 versions de plan, puis une règle candidate. Il affiche les entrées prévues et le solde projeté, les différences chiffrées et les cellules Excel correspondantes. Une réception prévue n'est pas assimilée à une réception réalisée ; le solde projeté n'est pas assimilé au stock physique.

## Ce que l'on retrouve, et ce qui manque

Le mécanisme commun testé consiste à soustraire les besoins datés du stock et des disponibilités connues, puis à proposer le complément nécessaire pour couvrir les semaines suivantes, avec un arrondi de quantité. Les paramètres restent constants pendant chaque calcul : aucune règle différente par saison n'a été ajoutée pour rejoindre les courbes.

| Article | Résultat utile | Différence restant à expliquer |
|---|---|---|
| 001757 | Sept semaines et un arrondi à 1 000 kg reproduisent mieux les propositions que quatre ou six semaines. Sur les échéances comparables du premier semestre : 4 réceptions positives exactes sur 6 ; second semestre : 3 sur 6. | Des propositions du plan initial sont ensuite annulées ou modifiées. Le calendrier et le statut des engagements restent à reconstituer. Le standard FIA de 100 kg n'est pas remplacé dans le simulateur. |
| 002612 | Six semaines et 22 500 kg reproduisent les 7 réceptions positives comparables du premier semestre. | Le second semestre comporte aussi des multiples du standard fournisseur de 23 750 kg. Un seul standard fixe ne suffit pas ; changer de standard améliore une période et dégrade l'autre. |
| 338929 | Trois semaines reproduisent 11 réceptions positives sur 13 au premier semestre et 10 sur 11 au second. Cette hypothèse prolonge les travaux précédents. | Des volumes identiques arrivent à des semaines différentes : par exemple 126 480 UN les 14 ou 21 décembre. Une anticipation calendaire est une piste, pas une fermeture industrielle démontrée. |
| 001848 | Le mécanisme situe certaines propositions à la bonne semaine. | Le pas principal de 6 000 kg ne reproduit ni la proposition terminale de 3 331,16 kg, ni celle de 4 000 kg. Les nombreuses semaines sans entrée rendent trompeur un simple pourcentage de semaines exactes. |

Ces chiffres concernent les échéances janvier–juin du plan du 5 janvier et juillet–décembre du plan du 6 juillet. Ils excluent les réceptions initiales imposées, les lignes sources absentes et les fenêtres de couverture incomplètes. Le [bilan détaillé](engine/bilan.md) expose tous les dénominateurs, les variantes moins bonnes et les premières divergences.

## Conditions de l'essai

Les réceptions projetées avant la date du plan augmentée du délai fournisseur sont reprises comme engagements **supposés**, puis exclues des scores. Au-delà, aucune réception ni aucun solde source ne sont réinjectés : les erreurs peuvent donc se propager. Cette frontière ne démontre pas une véritable période ferme industrielle.

Les semaines absentes à l'intérieur de l'export sont supposées sans besoins ni disponibilités supplémentaires. Elles restent signalées comme absentes, jamais comme des zéros industriels. Cette hypothèse peut déplacer des propositions, notamment pour 002612. Aucune prévision n'est inventée au-delà de la dernière semaine fournie. Les versions successives ne sont pas additionnées comme des mouvements réels.

Il s'agit d'une reconstitution du calcul projeté, **pas d'une nouvelle simulation physique**. Le moteur, les sécurités sources et les simulations antérieures ne sont pas modifiés. Les règles ont déjà été examinées sur 2025 : cette comparaison n'est pas une validation sur une année inconnue.

## Travail restant pour une règle commune exploitable

Les écarts permettent de séparer quatre mécanismes à vérifier : la couverture des besoins futurs ; la conservation ou révision des engagements existants ; la sélection des fournisseurs et de leurs quantités standard ; les ajustements des dates et de la dernière proposition d'un plan. Ce sont ces mécanismes qu'il faut identifier dans les versions successives avant de les intégrer au moteur. Choisir une règle différente pour chaque morceau de courbe ne répondrait pas au besoin.

La correspondance entre réceptions prévues, disponibilité du stock déjà présent et photos de stock doit rester distincte. Un écart de stock physique ne prouve pas, à lui seul, une erreur de calcul MRP : la consommation, la disponibilité qualité ou l'exécution du transport peuvent aussi intervenir.

## Vérifications

Le [manifeste consolidé](manifest.json) référence les contrôles réellement exécutés sur les empreintes finales : relecture indépendante des sources et recalcul numérique, navigation et rapprochement des points affichés, contrôle natif de la carte, conservation des deux références et du moteur. Les preuves de versions intermédiaires ne qualifient pas la livraison finale. Aucun essai d'altération de fichiers, de modification de dates ou de suppression simulée n'est nécessaire à cette étude.
