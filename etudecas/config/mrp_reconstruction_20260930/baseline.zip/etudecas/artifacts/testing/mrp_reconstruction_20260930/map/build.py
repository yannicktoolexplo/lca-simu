"""Add one independently embedded MRP panel without changing the original map."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
sys.path.insert(0,str(ROOT))
from etudecas.visualization.maps.portable_diagnostic import COMPARISON_RUNTIME, packed

START='<!-- ETUDECAS_MRP_RECONSTRUCTION_BEGIN -->'
END='<!-- ETUDECAS_MRP_RECONSTRUCTION_END -->'


def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def main():
    cli=argparse.ArgumentParser()
    cli.add_argument('--input',type=Path,required=True)
    args=cli.parse_args()
    original=ROOT/'etudecas/resultats/regroupement_001757_20260929/carte.html'
    reference=ROOT/'etudecas/resultats/mrp_source_driven_20260928/carte_corrigee.html'
    output=original.with_name('carte_reconstitution_mrp.html')
    if output.exists():raise ValueError('The new destination already exists; never overwrite a delivered map.')
    sources=[args.input.resolve(),original,reference,HERE/'view.html',Path(__file__),
             ROOT/'etudecas/visualization/maps/portable_diagnostic.py']
    before={str(p.relative_to(ROOT)):sha(p) for p in sources}
    payload=json.loads(args.input.read_text(encoding='utf-8'))
    assert payload['schema_version']==1
    assert {p['item_id'].removeprefix('item:') for p in payload['pairs']}=={'001757','001848','002612','338929'}
    for pair in payload['pairs']:
        assert pair['node_id']=='M-1810' and pair['unit'] in ('KG','UN')
        for plan in pair['plans']:
            assert plan['variants']
            for variant in plan['variants']:
                dates=[r['date'] for r in variant['rows']]
                assert dates==sorted(set(dates))
                for row in variant['rows']:
                    assert all(k in row for k in ('H_source','I_source','J_source','K_source','H_reconstructed','K_reconstructed','prefix_imposed','missing_source','scored'))
                    if row['missing_source']:
                        assert all(row[k] is None for k in ('H_source','I_source','J_source','K_source'))
    template=(HERE/'view.html').read_text(encoding='utf-8')
    assert template.count('__MRP_RECONSTRUCTION_PAYLOAD__')==1
    view=template.replace('__MRP_RECONSTRUCTION_PAYLOAD__',json.dumps(payload,ensure_ascii=True,allow_nan=False,separators=(',',':')).replace('<','\\u003c'))
    entry=packed(view.encode('utf-8'),'reconstitution_mrp.html','text/html')
    runtime=COMPARISON_RUNTIME.replace('sourceComparison','mrpReconstruction').replace('source-comparison','mrp-reconstruction')
    runtime=runtime.replace('Comparaisons 2025 — données et simulations','Reconstitution MRP — projections datées')
    runtime=runtime.replace("button.textContent='Comparaisons 2025'","button.textContent='Reconstitution MRP'")
    runtime=runtime.replace('Stocks observés, simulations, plans MRP, flux et service','Plans sources et reconstruction des entrées et stocks projetés')
    runtime=runtime.replace('Comparaisons interactives des stocks et du MRP en 2025','Reconstitution interactive des projections MRP')
    links=f'<nav aria-label="Cartes de référence" style="font:13px system-ui;display:flex;gap:14px"><a href="{os.path.relpath(original,output.parent).replace(chr(92),chr(47))}" target="_blank" rel="noopener">Carte regroupement d’origine</a><a href="{os.path.relpath(reference,output.parent).replace(chr(92),chr(47))}" target="_blank" rel="noopener">Carte source du 28 septembre</a></nav>'
    runtime=runtime.replace('</header>',links+'</header>',1)
    runtime=runtime.replace('__ENTRY__',json.dumps(entry,ensure_ascii=True))
    block=(START+runtime+END).encode('utf-8')
    raw=original.read_bytes()
    assert START.encode() not in raw and END.encode() not in raw
    head,mark,tail=raw.rpartition(b'</html>')
    assert mark
    rendered=head+block+mark+tail
    assert rendered.replace(block,b'',1)==raw
    assert {str(p.relative_to(ROOT)):sha(p) for p in sources}==before
    output.write_bytes(rendered)
    after={str(p.relative_to(ROOT)):sha(p) for p in sources}
    assert after==before
    proof=dict(ok=True,output=str(output.relative_to(ROOT)),output_sha256=sha(output),
        input_hashes_before=before,input_hashes_after=after,inputs_unchanged=True,
        embedded_document_sha256=entry['sha256'],embedded_document_bytes=entry['bytes'],
        original_map_bytes_preserved_by_removing_only_new_marked_block=True,
        existing_comparison_and_both_lot_views_preserved=True,
        scope='A separate projected MRP reconstruction, no simulation recomputation and no modification of the historical maps.',
        ui_ids=dict(button='mrpReconstructionOpenBtn',frame='mrpReconstructionFrame',
            pair='reconPair',plan='reconPlan',variant='reconVariant',incoming='incomingChart',balance='balanceChart',table='reconRows'))
    (HERE/'delivery.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=True))


if __name__=='__main__':main()
