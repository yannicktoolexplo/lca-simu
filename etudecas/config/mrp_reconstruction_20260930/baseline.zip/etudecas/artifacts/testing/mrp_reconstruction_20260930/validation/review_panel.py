"""Offline, bounded browser review of the additional MRP reconstruction panel.

Real delivered HTML/JSON only. Ordinary screenshots and one real CSV download;
no test filesystem mutation, timestamp alteration, server, or source editing.
"""
import csv
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path
import re
import uuid
from playwright.sync_api import sync_playwright

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
BASE=HERE.parent
HTML=ROOT/'etudecas/resultats/regroupement_001757_20260929/carte_reconstitution_mrp.html'
OLD=HTML.with_name('carte.html')
EARLIER=ROOT/'etudecas/resultats/mrp_source_driven_20260928/carte_corrigee.html'
PAYLOAD=BASE/'engine/reconstruction.json'
ORACLE=HERE/'reconstruction_check_final.json'
REFERENCES=BASE/'references.json'


def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def number(text):
    return float(''.join(text.split()).replace(',','.'))


def main():
    output=HERE/('ui-'+uuid.uuid4().hex)
    output.mkdir(parents=True,exist_ok=False)
    paths=[HTML,OLD,EARLIER,PAYLOAD,ORACLE,REFERENCES,BASE/'map/build.py',BASE/'map/view.html',Path(__file__)]
    before={str(p.relative_to(ROOT)):sha(p) for p in paths}
    payload=json.loads(PAYLOAD.read_text(encoding='utf-8'))
    oracle=json.loads(ORACLE.read_text(encoding='utf-8'))
    assert oracle['ok'] and oracle['input_hashes'][str(PAYLOAD.relative_to(ROOT))]==sha(PAYLOAD)
    refs=json.loads(REFERENCES.read_text(encoding='utf-8'))
    for r in refs['maps']:assert sha(ROOT/r['path'])==r['sha256']
    original=OLD.read_bytes();full=HTML.read_bytes()
    start=b'<!-- ETUDECAS_MRP_RECONSTRUCTION_BEGIN -->';end=b'<!-- ETUDECAS_MRP_RECONSTRUCTION_END -->'
    assert full.count(start)==full.count(end)==1
    left=full.index(start);right=full.index(end)+len(end)
    assert full[:left]+full[right:]==original
    report=dict(ok=False,created_utc=datetime.now(timezone.utc).isoformat(),offline=True,headless=True,
                input_hashes=before,checks=[],javascript_errors=[],network_requests=[],matrix=[],
                numeric_counts=dict(points=0,table_cells=0,metrics=0),
                scope='24 selected states: all articles and candidates at first, middle and last vintage; all embedded payload values match the separately verified full reconstruction.')
    def check(name,condition,context=None):
        report['checks'].append(dict(name=name,ok=bool(condition),context=context))
        if not condition:raise AssertionError((name,context))
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True)
        context=browser.new_context(offline=True,accept_downloads=True,viewport={'width':1600,'height':1100})
        page=context.new_page()
        page.on('pageerror',lambda e:report['javascript_errors'].append(str(e)))
        page.on('request',lambda r:report['network_requests'].append(r.url) if r.url.startswith(('http:','https:')) else None)
        try:
            page.goto(HTML.resolve().as_uri(),wait_until='load',timeout=90000)
            page.locator('#mrpReconstructionOpenBtn').wait_for(state='visible',timeout=90000)
            close=page.locator('#lotTracePanelCloseBtn')
            if close.is_visible():close.click()
            page.locator('#mrpReconstructionOpenBtn').click()
            page.locator('#mrpReconstructionModal').wait_for(state='visible')
            page.wait_for_function("document.getElementById('mrpReconstructionFrame').hidden===false",timeout=90000)
            frame=next(f for f in page.frames if f!=page.main_frame and f.locator('#reconstructionData').count())
            frame.wait_for_function("document.body.dataset.ready==='true'")
            embedded=json.loads(frame.locator('#reconstructionData').text_content())
            check('entire_payload_equals_independent_checked_JSON',embedded==payload)
            check('default_selection',frame.evaluate("() => {const s=window.__mrpReconstruction.state();return [s.pair.item_id,s.plan.vintage_date,s.variant.coverage_weeks]}")==['001757','2025-01-05',7])
            check('scope_projected',all(x in frame.locator('#scopeNotice').inner_text() for x in ('projections','pas de mouvements','hypothèse')))
            check('physical_stock_distinction','ni une photo de stock physique' in frame.locator('#balanceChart').locator('..').inner_text())
            check('all_article_options',frame.locator('#reconPair option').count()==4)

            def inspect(pair,plan,variant):
                rows=variant['rows'];unit=pair['unit'];key=[pair['item_id'],plan['vintage_date'],variant['variant_id']]
                observed=frame.evaluate("""() => ({
                  charts:[...document.querySelectorAll('#incomingChart svg,#balanceChart svg')].map(svg=>({
                    metric:svg.dataset.metric,unit:svg.dataset.unit,min:+svg.dataset.min,max:+svg.dataset.max,
                    prefix:svg.querySelector('[data-prefix-end]')?.dataset.prefixEnd,
                    paths:[...svg.querySelectorAll('path[data-series]')].map(p=>({series:p.dataset.series,count:+p.dataset.count,d:p.getAttribute('d'),color:getComputedStyle(p).stroke,dash:getComputedStyle(p).strokeDasharray})),
                    points:[...svg.querySelectorAll('circle')].map(c=>({series:c.dataset.series,date:c.dataset.date,value:+c.dataset.value,x:+c.getAttribute('cx'),y:+c.getAttribute('cy'),label:c.getAttribute('aria-label')}))})),
                  table:[...document.querySelectorAll('#reconRows tr')].map(r=>({date:r.dataset.date,cells:[...r.querySelectorAll('td[data-field]')].map(c=>({field:c.dataset.field,value:c.dataset.value,text:c.textContent})),scope:r.lastElementChild.textContent})),
                  metrics:[...document.querySelectorAll('#metrics .card b')].map(n=>n.textContent),method:document.getElementById('methodScope').textContent
                })""")
                check('two_charts',len(observed['charts'])==2,key)
                for chart in observed['charts']:
                    metric=chart['metric'];fields=[metric+'_source',metric+'_reconstructed']
                    values=[r[f] for r in rows for f in fields if r[f] is not None]
                    low=min([0]+values);high=max([1]+values);pad=(high-low)*.07
                    lower=low-pad if low<0 else 0;upper=high+pad
                    check('axes_from_actual_values',math.isclose(chart['min'],lower,abs_tol=1e-7)
                          and math.isclose(chart['max'],upper,abs_tol=1e-7) and chart['unit']==unit,key+[metric])
                    check('prefix_exclusive_label',chart['prefix']==variant['firm_prefix_end_exclusive'],key+[metric])
                    expected_points={(f,r['date']):(i,r[f]) for i,r in enumerate(rows) for f in fields if r[f] is not None}
                    check('exact_point_population',len(chart['points'])==len(expected_points)
                          and {(p['series'],p['date']) for p in chart['points']}==set(expected_points),key+[metric])
                    for point in chart['points']:
                        index,value=expected_points[(point['series'],point['date'])]
                        x=88+(1300-88-26)*(index/(len(rows)-1) if len(rows)>1 else .5)
                        y=290-48-(290-18-48)*(value-lower)/(upper-lower)
                        check('visible_SVG_point_value_and_position',point['value']==value
                              and math.isclose(point['x'],x,abs_tol=1e-7)
                              and math.isclose(point['y'],y,abs_tol=1e-7) and unit in point['label'],key+[point['series'],point['date']])
                        report['numeric_counts']['points']+=1
                    check('curve_styles_distinct',len(chart['paths'])==2 and len({(s['color'],s['dash']) for s in chart['paths']})==2,key+[metric])
                    for path in chart['paths']:
                        expected_tokens=[];active=False
                        for i,row in enumerate(rows):
                            value=row[path['series']]
                            if value is None:active=False;continue
                            x=88+(1300-88-26)*(i/(len(rows)-1) if len(rows)>1 else .5)
                            y=242-224*(value-lower)/(upper-lower)
                            expected_tokens.append(('L' if active else 'M',x,y));active=True
                        tokens=re.findall(r'([ML])\s*([-\d.]+)\s+([-\d.]+)',path['d'])
                        check('line_segments_respect_missing_values',len(tokens)==len(expected_tokens) and path['count']==len(tokens)
                              and all(a==e[0] and abs(float(x)-e[1])<=.000051 and abs(float(y)-e[2])<=.000051
                                      for (a,x,y),e in zip(tokens,expected_tokens)),key+[path['series']])
                check('table_row_population',len(observed['table'])==len(rows),key)
                for source,tr in zip(rows,observed['table'],strict=True):
                    check('table_date',source['date']==tr['date'],key+[tr['date']])
                    for cell in tr['cells']:
                        value=source[cell['field']]
                        valid=(cell['value']=='' and cell['text']=='Non fourni') if value is None else (
                            float(cell['value'])==value and abs(number(cell['text'])-value)<=.00050001)
                        check('table_actual_and_displayed_value',valid,key+[tr['date'],cell['field']])
                        report['numeric_counts']['table_cells']+=1
                    if source['missing_source']:check('missing_explicitly_labelled','Source absente' in tr['scope'],key+[tr['date']])
                    if source['prefix_imposed']:check('imposed_prefix_labelled','Préfixe H imposé' in tr['scope'],key+[tr['date']])
                    if source['coverage_incomplete']:check('incomplete_window_labelled','Fenêtre incomplète' in tr['scope'],key+[tr['date']])
                scores=variant['scores'] or variant['diagnostic_single_plan_scores']
                if scores:
                    metrics=observed['metrics']
                    check('metric_display_counts',number(metrics[0])==scores['H_n'] and number(metrics[1])==scores['H_exact'],key)
                    numerator,denominator=metrics[2].split('/')
                    check('metric_positive_count_not_confused_with_zeros',number(numerator)==scores['H_positive_exact']
                          and number(denominator)==scores['H_positive_n'],key)
                    check('metric_display_MAE',abs(number(metrics[3])-scores['H_MAE'])<=.00050001
                          and abs(number(metrics[4])-scores['K_MAE'])<=.00050001,key)
                    report['numeric_counts']['metrics']+=5
                check('main_or_secondary_label',('Évaluation principale' if plan['scored_target_period'] else 'Version secondaire') in observed['method'],key)
                report['matrix'].append(key)

            for pair_index,pair in enumerate(payload['pairs']):
                frame.locator('#reconPair').select_option(str(pair_index))
                check('52_vintage_options',frame.locator('#reconPlan option').count()==52,pair['item_id'])
                for plan_index in (0,26,51):
                    frame.locator('#reconPlan').select_option(str(plan_index));plan=pair['plans'][plan_index]
                    check('candidate_options',frame.locator('#reconVariant option').count()==len(plan['variants']),[pair['item_id'],plan_index])
                    for variant in plan['variants']:
                        frame.locator('#reconVariant').select_option(variant['variant_id'])
                        inspect(pair,plan,variant)
                        if plan_index==0 and variant==plan['variants'][-1]:
                            page.screenshot(path=str(output/f"{pair['item_id']}_first_plan.png"))
            # A real keyboard-accessible point, legend toggles and a real user export.
            frame.locator('#reconPair').select_option('0');frame.locator('#reconPlan').select_option('0')
            first_point=frame.locator('#incomingChart circle').first
            first_point.focus()
            check('keyboard_point_detail','Source :' in frame.locator('#pointDetail').inner_text())
            frame.locator('#showRule').uncheck()
            check('rule_toggle_hides_both_charts',frame.locator('circle[data-series$="reconstructed"]').count()==0)
            frame.locator('#showRule').check();frame.locator('#showSource').uncheck()
            check('source_toggle_hides_both_charts',frame.locator('circle[data-series$="source"]').count()==0)
            frame.locator('#showSource').check()
            selected=frame.evaluate("() => {const s=window.__mrpReconstruction.state();return {item:s.pair.item_id,site:s.pair.node_id,unit:s.pair.unit,vintage:s.plan.vintage_date,variant:s.variant.variant_id,rows:s.variant.rows}}")
            with page.expect_download() as pending:frame.locator('#reconExport').click()
            pending.value.save_as(str(output/'selected_plan.csv'))
            with (output/'selected_plan.csv').open(encoding='utf-8-sig',newline='') as stream:download=list(csv.DictReader(stream,delimiter=';'))
            check('export_row_count',len(download)==len(selected['rows']))
            for a,b in zip(download,selected['rows'],strict=True):
                check('export_identity',all(a[k]==selected[k] for k in ('site','unit','vintage','variant')) and a['article']==selected['item'])
                for field in a:
                    if field in ('article','site','unit','vintage','variant'):continue
                    value=b[field]
                    expected_text='' if value is None else str(value).lower() if isinstance(value,bool) else str(value)
                    check('export_value',a[field]==expected_text or value is not None and not isinstance(value,(str,bool)) and float(a[field])==value,[a['date'],field])
            page.locator('#mrpReconstructionCloseBtn').click()
            check('back_to_original_map',not page.locator('#mrpReconstructionModal').is_visible()
                  and page.locator('#sourceComparisonOpenBtn').is_visible())
            check('no_javascript_error',not report['javascript_errors'],report['javascript_errors'])
            check('no_http_request',not report['network_requests'],report['network_requests'])
        except Exception as exc:
            report['checks'].append(dict(name='browser_exception',ok=False,error=str(exc)))
            try:page.screenshot(path=str(output/'failure.png'))
            except Exception:pass
        finally:
            context.close();browser.close()
    after={str(p.relative_to(ROOT)):sha(p) for p in paths}
    report['checks'].append(dict(name='all_inputs_unchanged',ok=before==after))
    report['input_hashes_after']=after
    report['ok']=all(c['ok'] for c in report['checks']) and not report['javascript_errors']
    report['limitations']=['Old map journeys and both lot views are covered separately by the native toolbox browser.',
                           'This review validates displayed predictions, not industrial calibration or realised flows.',
                           'Only 24 render states and the named interactions are exercised; the entire embedded JSON is separately reconciled.']
    (output/'review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    manifest=dict(kind='independent_reconstruction_browser',status='passed' if report['ok'] else 'failed',
                  report=str((output/'review.json').relative_to(ROOT)),report_sha256=sha(output/'review.json'),
                  html=str(HTML.relative_to(ROOT)),html_sha256=sha(HTML),inputs=before,
                  checks=len(report['checks']),numeric_counts=report['numeric_counts'],states=len(report['matrix']))
    (output/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({**manifest,'manifest':str((output/'manifest.json').relative_to(ROOT)),
                      'failures':[c for c in report['checks'] if not c['ok']]},ensure_ascii=True))
    if not report['ok']:raise SystemExit(1)


if __name__=='__main__':main()
