# Contre-vérification de la reconstitution MRP

Les calculs livrés et leur affichage passent les contrôles indépendants décrits ci-dessous. Cela valide cette reconstitution conditionnelle des plans sources, pas l'identification exhaustive du système MRP industriel ni une simulation de flux physiques.

## Calculs directement rapprochés d'Excel

`reconstruction_check_final.json` : **317 070 contrôles réussis**, quatre références Avène, 52 versions chacune, **416 variantes et 17 908 lignes**. L'oracle lit les classeurs originaux et recalcule en Decimal ; il n'importe ni le générateur ni le simulateur. Les valeurs H/I/J/K, unités, dates, préfixes, hypothèses de trous, limites de couverture, métriques et premières divergences sont vérifiées. Les empreintes sont restées inchangées.

K commence à zéro avant la première ligne ; les J datés alimentent ensuite le calcul une seule fois. H source n'est imposé que strictement avant la date du plan plus le délai FIA choisi. Après cette borne, aucun H ou K source ne pilote la progression. Les scores excluent ce préfixe, les semaines absentes et les fenêtres tronquées après la dernière source.

Les **4 244 semaines imputées** incluent **575 occurrences de propositions positives** dans des semaines sans ligne source. Ces occurrences concernent plusieurs variantes/plans : ce ne sont pas 575 commandes industrielles. Leur propre semaine n'est pas évaluée, mais leur quantité alimente K et peut modifier les écarts ultérieurs. Les résultats dépendent donc de l'hypothèse explicite de semaines internes sans événements. Les H1/H2 portent des dates distinctes, mais les règles ont été recherchées sur les mêmes données : il ne s'agit pas d'une validation statistique inédite.

`reconstruction_check.json` est une preuve intermédiaire sur la première livraison à 312 variantes. Elle est conservée mais exclue du verdict final, après l'ajout des candidats 001757 sept semaines et 002612 arrondi 23 750 kg.

## Restitution et interactivité

Carte vérifiée : `etudecas/resultats/regroupement_001757_20260929/carte_reconstitution_mrp.html`, SHA-256 `1aa9aa2b28389289e6889ae02151d241dfc4dc75840f1ec706f15950ce35ea16`.

Revue ciblée : `ui-5bb2c9bbaa9e46638d6fd1efbb93db7a/manifest.json`, **12 273 assertions réussies** sur 24 états : quatre articles, tous les candidats, versions première/intermédiaire/dernière. Vérification de 3 620 points SVG et de leurs coordonnées, 6 078 cellules et 120 indicateurs, axes/unités, segments interrompus aux sources absentes, sélection des variantes, cases de visibilité, point au clavier et export CSV réel. Aucun appel HTTP ni erreur JavaScript. Le JSON embarqué entier est exactement celui de la preuve numérique finale.

Le défaut est bien 001757 / 5 janvier / sept semaines. La capture `001757_first_plan.png` montre séparément 10 H exacts sur 14 semaines comparées, **4/6 entrées positives exactes**, et une erreur moyenne H de 500 kg. Les deux courbes sont distinctes en couleur et tracé. Les titres distinguent prévisions H, solde projeté K et stock physique. Les captures ont été inspectées par le validateur, l'agent carte et le parent.

Navigateur natif : `toolbox/browser-f08c9b73f2274b72aea563ae6a058c7e/manifest.json`, PASS sur neuf parcours : chargement hors ligne, bilan matière, arbre KPI, modal de suivi de lots, comparaison de scénarios, risques, incertitude, curseur temporel et tableau de diagnostic. Le gate doctor + navigateur du parent est sous `../native/gate-b60277e48733420a823b7f22c5f1502b/manifest.json`.

**Précision de portée :** la phrase générique du rapport ciblé évoquant une couverture native des « both lot views » est trop large. Le navigateur natif ouvre le modal de suivi de lots ; il ne certifie pas toutes les interactions des deux suivis. Leur conservation, ainsi que celle des anciens onglets, est établie par l'identité exacte des octets de la carte historique lorsqu'on retire seulement le nouveau bloc marqué. Les deux cartes sources originales ont gardé leurs empreintes.

Le premier appel direct Playwright a été refusé avant le lancement navigateur par `WinError 5` sur le canal IPC du sous-processus. Aucun nouvel essai direct n'a été lancé. Le parent a fait examiner et autoriser l'exécution exacte hors sandbox par le contrôle automatique normal ; celle-ci a réussi, sans modification de protection, permission système ou source. Ce refus initial n'est pas compté comme un contrôle réussi.

## Limites et reproduction

Les quantités standard FIA, les délais de préfixe et les fenêtres candidates ne démontrent ni statut ferme, ni calendrier d'entreprise, ni sélection d'un fournisseur. Le candidat 001848 ne reconstitue pas sa politique de secours complète ; 002612 dispose de plusieurs offres. J futur reste du stock déjà présent, sans nouvelle réception physique. Aucune simulation du moteur ni modification applicative n'a été effectuée dans cette validation.

Commandes relues :

```powershell
python -B etudecas/artifacts/testing/mrp_reconstruction_20260930/validation/verify_reconstruction.py
python -B etudecas/artifacts/testing/mrp_reconstruction_20260930/validation/review_panel.py
python -B -m etudecas.toolbox browser --html etudecas/resultats/regroupement_001757_20260929/carte_reconstitution_mrp.html --output etudecas/artifacts/testing/mrp_reconstruction_20260930/validation/toolbox --task-id mrp-reconstruction-20260930 --owner etudecas_validator
```

L'oracle refuse d'écraser sa preuve finale ; chaque revue navigateur crée son dossier unique. Aucun test d'altération, de changement de date ou de fichier factice n'a été exécuté.
