"""Independent Decimal oracle for a source-conditioned MRP reconstruction.

Reads original workbooks and a frozen delivered JSON. Does not import the
reconstruction generator or simulator, modify sources, or simulate execution.
"""
from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal, ROUND_CEILING
import hashlib
import json
from pathlib import Path
import openpyxl

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
BASE = HERE.parent
SOURCE = ROOT / 'etudecas/data/source/Flow_Data_MRP_results.xlsx'
FIA = ROOT / 'etudecas/data/source/268091.xlsx'
DELIVERY = BASE / 'engine/reconstruction.json'
WEEK = timedelta(days=7)
ZERO = Decimal(0)
EPS = Decimal('0.000001')
PARAMETERS = {
    '001757': {'lead': 84, 'multiple': Decimal(1000), 'windows': (4,6,7), 'unit':'KG'},
    '001848': {'lead': 56, 'multiple': Decimal(6000), 'windows': (6,7), 'unit':'KG'},
    '002612': {'lead': 35, 'multiple': Decimal(22500), 'windows': (6,), 'unit':'KG'},
    '338929': {'lead': 42, 'multiple': Decimal(1), 'windows': (3,), 'unit':'UN'},
}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def dec(value):
    if value is None or isinstance(value,bool):
        raise ValueError('Unknown source quantity is not zero')
    return Decimal(str(value))


def read_sources():
    plans=defaultdict(lambda: defaultdict(dict))
    book=openpyxl.load_workbook(SOURCE,read_only=True,data_only=True)
    try:
        for row, raw in enumerate(book.active.iter_rows(min_row=2,values_only=True),2):
            item=str(raw[1]).zfill(6)
            if item not in PARAMETERS or str(raw[3])!='1810':continue
            if raw[5] not in {'G','KG','UN','ZUN','UN.'}:raise ValueError(('unit',row,raw[5]))
            scale=Decimal('.001') if raw[5]=='G' else Decimal(1)
            vintage,target=raw[0].date(),raw[6].date()
            if target in plans[item][vintage]:raise ValueError(('duplicate week',row))
            plans[item][vintage][target]=dict(row=row,source_unit=raw[5],receipt_days=raw[4],
                                              **{k:dec(raw[c])*scale for k,c in [('H',7),('I',8),('J',9),('K',10)]})
    finally:book.close()
    offers=defaultdict(list)
    book=openpyxl.load_workbook(FIA,read_only=True,data_only=True)
    try:
        for row, raw in enumerate(book['FIA'].iter_rows(min_row=2,values_only=True),2):
            item=str(raw[0]).zfill(6)
            if item in PARAMETERS:
                offers[item].append(dict(row=row,supplier=raw[1],lead_days=int(raw[5]),standard_qty=raw[6],source_unit=raw[7]))
    finally:book.close()
    return plans,offers


def independent_replay(source_rows,vintage,*,lead,multiple,weeks):
    """One initial zero state; direct I/J and only pre-lead H are inputs."""
    result=[]
    first,last=min(source_rows),max(source_rows)
    state=ZERO
    target=first
    while target<=last:
        raw=source_rows.get(target)
        required=raw['I'] if raw is not None else ZERO
        existing=raw['J'] if raw is not None else ZERO
        position=state+existing-required
        following=[target+WEEK*i for i in range(1,weeks+1)]
        known_following=[t for t in following if t<=last]
        future_net=sum((source_rows[t]['I']-source_rows[t]['J']
                        for t in known_following if t in source_rows),ZERO)
        prefix=(target-vintage).days<lead
        if prefix:
            incoming=raw['H'] if raw is not None else ZERO
        else:
            deficit=max(ZERO,future_net-position)
            incoming=(deficit/multiple).to_integral_value(rounding=ROUND_CEILING)*multiple
        closing=position+incoming
        result.append(dict(target=target,source_row=raw['row'] if raw else None,
                           source_H=raw['H'] if raw else None,source_K=raw['K'] if raw else None,
                           I=required,J=existing,H=incoming,K=closing,previous_K=state,
                           next_net=future_net,source_prefix=prefix,imputed_current=raw is None,
                           future_imputed_days=[t for t in known_following if t not in source_rows],
                           coverage_incomplete=target+WEEK*weeks>last,
                           scored=raw is not None and not prefix and target+WEEK*weeks<=last))
        state=closing
        target+=WEEK
    return result


def serial(value):
    if isinstance(value,Decimal):return float(value)
    if isinstance(value,date):return value.isoformat()
    raise TypeError(type(value))


def metrics(rr):
    if not rr:return None
    positive=[r for r in rr if r['source_H']>0]
    error=sum((abs(r['H']-r['source_H']) for r in rr),ZERO)
    total=sum((r['source_H'] for r in rr),ZERO)
    first=next((r for r in rr if abs(r['H']-r['source_H'])>=EPS),None)
    return dict(H_n=len(rr),H_positive_n=len(positive),
                H_exact=sum(abs(r['H']-r['source_H'])<EPS for r in rr),
                H_positive_exact=sum(abs(r['H']-r['source_H'])<EPS for r in positive),
                H_MAE=error/len(rr),H_WAPE=error/total if total else None,
                H_source_sum=total,H_reconstructed_sum=sum((r['H'] for r in rr),ZERO),
                K_MAE=sum((abs(r['K']-r['source_K']) for r in rr),ZERO)/len(rr),
                rows_with_internal_gap_in_coverage=sum(bool(r['future_imputed_days']) for r in rr),
                first_divergence=None if first is None else dict(date=first['target'].isoformat(),source_row=first['source_row'],
                    H_source=first['source_H'],H_reconstructed=first['H'],K_source=first['source_K'],K_reconstructed=first['K']))


def main():
    output=HERE/'reconstruction_check_final.json'
    if output.exists():raise FileExistsError(output)
    producer=BASE/'engine/reconstruct.py'
    tracked=(SOURCE,FIA,DELIVERY,producer)
    before={str(p.relative_to(ROOT)):sha(p) for p in tracked}
    expected=json.loads(DELIVERY.read_text(encoding='utf-8'))
    plans,offers=read_sources()
    checks,failures=0,[]
    def check(name,valid,context=None):
        nonlocal checks
        checks+=1
        if not valid:failures.append(dict(check=name,context=context))
    def same(actual,claimed):
        if actual is None or claimed is None:return actual is claimed
        return abs(dec(actual)-dec(claimed))<=EPS
    def compare_metrics(actual,claimed,context):
        check('metric_existence',(actual is None)==(claimed is None),context)
        if actual is None or claimed is None:return
        check('metric_field_contract',set(actual)==set(claimed),context)
        for k,a in actual.items():
            if k=='first_divergence':
                check('first_divergence_presence',(a is None)==(claimed[k] is None),context)
                if a is not None and claimed[k] is not None:
                    for f,v in a.items():
                        check('first_divergence_value',v==claimed[k][f] if f in ('date','source_row') else same(v,claimed[k][f]),context+[f])
            else:check('metric_value',same(a,claimed[k]),context+[k])
    check('result_status',expected['status']=='source_plan_reconstruction_not_physical_simulation')
    check('producer_bound_to_result',expected['script_sha256']==sha(producer))
    check('four_pair_identity',{p['item_id'] for p in expected['pairs']}==set(PARAMETERS))
    main_scores=[]
    counts=dict(variants=0,rows=0,source_rows=0,imputed_rows=0,imputed_positive_proposals=0,
                imposed_H_rows=0,truncated_rows=0,compared_rows=0)
    for pair in expected['pairs']:
        item=pair['item_id'];config=PARAMETERS[item]
        multiples=(Decimal(22500),Decimal(23750)) if item=='002612' else (config['multiple'],)
        check('pair_identity',pair['node_id']=='M-1810' and pair['site_id']=='1810' and pair['unit']==config['unit'],item)
        check('versions_exact',len(pair['plans'])==52 and {date.fromisoformat(p['vintage_date']) for p in pair['plans']}==set(plans[item]),item)
        check('lead_has_source_offer',config['lead'] in {r['lead_days'] for r in offers[item]},item)
        for f in pair['source_parameters']['fia']:
            raw=next((r for r in offers[item] if r['row']==f['row']),None)
            check('FIA_provenance',raw is not None and raw['supplier']==f['supplier'] and raw['lead_days']==f['lead_days'],[item,f['row']])
        check('candidate_parameters',pair['candidate_parameters']['firm_prefix_lead_days']==config['lead']
              and pair['candidate_parameters']['coverage_weeks']==list(config['windows'])
              and same(config['multiple'],pair['candidate_parameters']['rounding_qty']),item)
        target_sets={}
        for plan in pair['plans']:
            vintage=date.fromisoformat(plan['vintage_date']);raw=plans[item][vintage]
            check('domain_and_sources',plan['domain_start']==min(raw).isoformat() and plan['domain_end']==max(raw).isoformat()
                  and plan['source_rows']==len(raw),[item,str(vintage)])
            period='2025_H1' if vintage==date(2025,1,5) else '2025_H2' if vintage==date(2025,7,6) else None
            check('selected_period',plan['scored_target_period']==period,[item,str(vintage)])
            expected_variants={(w,q) for w in config['windows'] for q in multiples}
            check('variant_windows_and_multiples',
                  {(v['coverage_weeks'],dec(v['rounding_qty'])) for v in plan['variants']}==expected_variants
                  and len(plan['variants'])==len(expected_variants),[item,str(vintage)])
            for variant in plan['variants']:
                weeks=variant['coverage_weeks'];multiple=dec(variant['rounding_qty']);ctx=[item,str(vintage),weeks,str(multiple)]
                rr=independent_replay(raw,vintage,lead=config['lead'],multiple=multiple,weeks=weeks)
                counts['variants']+=1
                check('row_count',len(rr)==len(variant['rows']),ctx)
                check('firm_end',variant['firm_prefix_end_exclusive']==(vintage+timedelta(days=config['lead'])).isoformat(),ctx)
                for oracle,delivered in zip(rr,variant['rows'],strict=True):
                    target=oracle['target'];rctx=ctx+[str(target)]
                    counts['rows']+=1
                    counts['source_rows']+=not oracle['imputed_current']
                    counts['imputed_rows']+=oracle['imputed_current']
                    counts['imputed_positive_proposals']+=oracle['imputed_current'] and not oracle['source_prefix'] and oracle['H']>0
                    counts['imposed_H_rows']+=oracle['source_prefix']
                    counts['truncated_rows']+=oracle['coverage_incomplete']
                    counts['compared_rows']+=oracle['scored']
                    check('row_identity',delivered['date']==target.isoformat() and delivered['day']==(target-date(2025,1,1)).days
                          and delivered['source_row']==oracle['source_row'],rctx)
                    source=raw.get(target)
                    for col in 'HIJK':
                        check('raw_source_value',same(source[col] if source else None,delivered[col+'_source']),rctx+[col])
                    for old,new in [('I','I_used'),('J','J_used'),('H','H_reconstructed'),('K','K_reconstructed'),('next_net','coverage_target_qty')]:
                        check('independent_numeric',same(oracle[old],delivered[new]),rctx+[new])
                    for old,new in [('source_prefix','prefix_imposed'),('imputed_current','missing_source'),
                                    ('coverage_incomplete','window_truncated'),('coverage_incomplete','coverage_incomplete'),('scored','comparable')]:
                        check('row_scope',oracle[old]==delivered[new],rctx+[new])
                    check('gap_dates',[str(t) for t in oracle['future_imputed_days']]==delivered['window_missing_dates'],rctx)
                    main=oracle['scored'] and ((period=='2025_H1' and target<=date(2025,6,30))
                                              or (period=='2025_H2' and date(2025,7,1)<=target<=date(2025,12,31)))
                    check('main_score_scope',bool(main)==delivered['scored'],rctx)
                    oracle['main_scored']=bool(main)
                    if config['unit']=='UN':check('UN_proposal_integer',oracle['H']==oracle['H'].to_integral_value(),rctx)
                all_metrics=metrics([r for r in rr if r['scored']])
                selected=metrics([r for r in rr if r['main_scored']])
                compare_metrics(all_metrics,variant['diagnostic_single_plan_scores'],ctx+['diagnostic'])
                compare_metrics(selected,variant['scores'],ctx+['main'])
                if period:
                    main_scores.append(dict(item_id=item,unit=config['unit'],vintage_date=str(vintage),target_period=period,
                                            variant_id=variant['variant_id'],scores=selected))
                    target_sets[(weeks,multiple,period)]={r['target'] for r in rr if r['main_scored']}
        for weeks,multiple in expected_variants:
            check('target_sets_disjoint',not(target_sets[weeks,multiple,'2025_H1']&target_sets[weeks,multiple,'2025_H2']),[item,weeks,str(multiple)])
    claimed_scores={(r['item_id'],r['vintage_date'],r['variant_id']):r for r in expected['main_scores']}
    check('main_score_count',len(main_scores)==len(claimed_scores))
    for r in main_scores:
        key=(r['item_id'],r['vintage_date'],r['variant_id'])
        compare_metrics(r['scores'],claimed_scores[key]['scores'],list(key))
    for path in tracked:check('input_unchanged',sha(path)==before[str(path.relative_to(ROOT))],str(path.relative_to(ROOT)))
    result=dict(ok=not failures,checks=checks,failures=failures,input_hashes=before,script_sha256=sha(Path(__file__)),
                counts=counts,main_scores=main_scores,
                superseded_intermediate_proof='reconstruction_check.json evaluated the initial 312-variant delivery before two candidate extensions; it is not the final delivered JSON.',
                limits=[
                    'Full reconstruction starts with zero K and dated J; source H before the chosen calendar lead is a declared imposed prefix, not inferred firm industrial orders.',
                    'Internal missing weeks use an explicit zero-input hypothesis. Positive reconstructed H can occur there and affect later K; they are not source observations and are not scored.',
                    'Truncated coverage is displayed but excluded from all comparison metrics. Terminal stock is not fitted.',
                    'Date-disjoint H1/H2 scores were designed after examining the same 2025 source; they are not a blind holdout.',
                    'H/I/K are projected export fields. No real receipt, physical consumption or availability date is certified by this replay.',
                    '002612 may use multiple suppliers and 001848 has a confirmed backup; these single-step candidates do not reproduce all sourcing decisions.'
                ])
    output.write_text(json.dumps(result,default=serial,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(dict(ok=result['ok'],checks=checks,failures=failures[:10],counts=counts,proof=str(output.relative_to(ROOT))),default=serial))
    if failures:raise SystemExit(1)


if __name__=='__main__':main()
