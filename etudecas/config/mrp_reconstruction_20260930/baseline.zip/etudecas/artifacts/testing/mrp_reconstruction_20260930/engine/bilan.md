# Reconstitution de plans MRP : quatre articles, 52 versions chacun

Le JSON fournit **208 plans source**, **416 variantes** et **17 908 lignes datées** pour la carte. Il compare les réceptions projetées H et le solde projeté K avec leur reconstruction depuis I/J. Aucune simulation physique, modification du moteur, des sources ou des études antérieures n'a été effectuée.

## Calcul et provenance

Chaque version reste figée : seules ses prévisions I/J sont utilisées. Le calcul débute avec K = 0 avant la première ligne, puis intègre les stocks J à leur date source. Les réceptions H situées strictement avant la date de version + le délai FIA sont copiées comme **engagements supposés**, hors score. Ce préfixe vaut respectivement 84 / 56 / 35 / 42 jours calendaires pour 001757 / 001848 / 002612 / 338929. Il ne prouve ni statut ferme ni identité de commande.

Après ce préfixe : solde avant réception = K reconstruit précédent + J courant − I courant ; cible = somme I−J des N semaines suivantes ; H reconstruit = complément positif arrondi au pas candidat ; K reconstruit = solde avant réception + H reconstruit. Aucun K ou H source ultérieur n'est réinjecté.

Le calendrier va de la première à la dernière semaine renseignée de la version. Les semaines absentes à l'intérieur sont traitées avec I/J nuls **par hypothèse**, marquées dans les courbes ; leurs H/I/J/K source restent `null`, jamais présentés comme des zéros industriels. Des propositions peuvent apparaître dans ces semaines absentes. Les fenêtres dépassant la dernière ligne sont incomplètes : leurs propositions restent inspectables, mais ces lignes sont exclues des scores comparables. Aucun stock terminal n'est ajusté pour rejoindre K.

K est un solde prévisionnel selon l'export, pas le stock physique ni une preuve de disponibilité utilisable. Les 52 versions ne s'additionnent jamais comme des mouvements. I courant peut comporter des reports : le calcul n'en fait pas une consommation physique.

Les variantes sont constantes dans le temps : 001757 fenêtres 4/6/7 semaines et pas 1 000 kg ; 001848 6/7 semaines et 6 000 kg ; 002612 6 semaines et 22 500 ou 23 750 kg ; 338929 3 semaines et granularité 1 UN. Les standards FIA et les cellules des politiques sont conservés dans le JSON. Le pas 1 000 de 001757 est empirique, son standard FIA étant 100. Sept semaines proviennent de la formule déjà étudiée plafond((20 jours de sécurité + 13 jours de réception supposés ouvrés)/5). Les deux pas 002612 existent dans la FIA, mais le choix fournisseur n'est pas reconstitué. Aucun secours 4 000 de 001848 n'est inventé. La granularité 1 UN de 338929 est une approximation des réceptions projetées, pas la preuve d'abolition du standard de commande 5 000.

## Comparaisons principales

H1 utilise le plan du **5 janvier**, uniquement sur les échéances janvier–juin ; H2 le plan du **6 juillet**, uniquement sur juillet–décembre. Les échéances sont disjointes. Les règles ayant déjà été étudiées sur 2025, ce n'est pas une validation statistique sur une année inconnue. Les autres versions sont proposées au sélecteur, avec leurs diagnostics propres, sans moyenne regroupant des plans corrélés.

| Article, variante constante | H exacts H1 / H2 | H positifs exacts H1 / H2 | Erreur absolue moyenne H1 / H2 |
|---|---|---|---|
| 001757, 4 sem., 1 000 kg | 3/14 ; 5/12 | 0/6 ; 1/6 | 1 142,86 ; 666,67 kg |
| 001757, 6 sem., 1 000 kg | 4/14 ; 6/12 | 0/6 ; 2/6 | 1 000 ; 666,67 kg |
| 001757, 7 sem., 1 000 kg | 10/14 ; 6/12 | 4/6 ; 3/6 | 500 ; 500 kg |
| 001848, 6 sem., 6 000 kg | 14/16 ; 13/14 | 0/1 ; 0/1 | 583,20 ; 285,71 kg |
| 001848, 7 sem., 6 000 kg | 15/16 ; 13/14 | 0/1 ; 0/1 | 166,80 ; 142,86 kg |
| 002612, 6 sem., 22 500 kg | 21/21 ; 8/20 | 7/7 ; 1/9 | 0 ; 11 482,50 kg |
| 002612, 6 sem., 23 750 kg | 12/21 ; 12/20 | 0/7 ; 2/9 | 4 702,38 ; 5 982,50 kg |
| 338929, 3 sem., 1 UN | 16/19 ; 14/16 | 11/13 ; 10/11 | 30 876,53 ; 15 810 UN |

Les comptes de H positifs évitent d'interpréter une majorité de zéros corrects comme une reproduction des réapprovisionnements. Les scores sont conditionnés par le préfixe H imposé et l'hypothèse sur les trous ; les quantités KG et UN ne sont jamais additionnées.

## Premières divergences utiles

**001757.** Dans le plan de janvier, sept semaines retrouvent H = 1 000 au 6 avril (`Feuille1!H14`) ; quatre/six semaines produisent zéro. Mais au 13 avril, H source vaut 3 000 (`H15`), contre zéro à sept semaines : solde 6 219,672 supérieur à la cible 6 000. Ce H de 3 000, prévu 98 jours à l'avance, devient zéro dans la version du 12 janvier (`H998`), puis 2 000 à partir du 19 janvier (`H1981`, 84 jours avant), stable ensuite jusqu'à l'échéance. La stabilité ne confirme donc pas que les 3 000 initiaux étaient déjà fermes au-delà du délai FIA. Elle ne justifie pas d'imposer une fenêtre plus longue pour effacer cet écart. Les versions et cellules figurent dans `diagnostic_notes`.

**001848.** La réception de 3 331,16 au 18 mai du plan de janvier (`H101`) est la dernière H, mais les prévisions continuent jusqu'au 19 octobre. Son échéance possède donc bien sept semaines de couverture à l'intérieur du domaine : ce contre-exemple ne doit pas être exclu comme « fenêtre finale incomplète ». La règle 7 semaines propose 6 000 à la bonne semaine, avec un surplus de 2 668,84. Dans le plan de juillet, H source = 4 000 au 2 novembre (`H26194`) contre 6 000. Un pas principal unique ne reproduit ni le traitement terminal ni la répartition des offres ; le bon score global est surtout constitué de zéros.

**002612.** La règle 22 500 reproduit les 21 lignes comparables du premier semestre, mais pas le plan de juillet. Avec le pas 23 750, elle crée une proposition le **10 août**, semaine absente de la source, puis 23 750 le 24 août alors que la source prévoit **47 500 le 24** (`H26260`). K se rejoint le 24 août malgré ces dates différentes. Le 31 août, la source vaut 23 750 (`H26261`), puis 22 500 au 5 octobre (`H26266`). Le pas 23 750 améliore le second semestre et dégrade le premier ; cela expose la sélection fournisseur et les dates manquantes, sans autoriser une commutation automatique par saison. La date absente exclue du score peut néanmoins influencer le solde et les décisions suivantes : l'hypothèse de trou est matériellement importante.

**338929.** Dans le plan de juillet, la source place 126 480 UN le **14 décembre** (`H26760`), contre zéro dans le calcul ; celui-ci les place le **21 décembre** (`H26761` source = 0). Le solde se rejoint le 21. Le volume des seules lignes comparées de H2 est identique (1 626 850 UN), mais cette égalité ne valide pas les dates. Dans le plan de janvier, l'écart débute au 13 avril : 289 232 UN source contre 144 616 (`H719`). Les éventuelles anticipations ou fermetures doivent être étayées séparément ; aucun calendrier de fermeture n'est inventé ici.

## Contrôles et usage

`python -B .../engine/reconstruct.py --replace-unqualified` a terminé avec un code 0. Cette exécution finale coordonnée remplace une version intermédiaire avant qualification ; son empreinte est conservée dans le JSON. Les quatre sources industrielles sont inchangées, les quatre articles ont 52 versions, la récurrence source est vérifiée, les propositions UN sont entières et les dates des deux cohortes principales sont disjointes. Les calculs utilisent Decimal ; aucun test de fichiers factices, de dates, de disparition ou de corruption n'est exécuté.

Les fichiers permettent maintenant de voir **ce qui est imposé, reconstruit, absent et différent**. Ils ne constituent pas une nouvelle règle ERP validée ni un résultat de simulation physique. La contre-vérification du validateur est indépendante du script et doit être rapprochée de l'empreinte finale avant livraison de la carte.
