"""Compare the global MRP trials, with a clickable per-reference overview."""
from pathlib import Path
import csv
import hashlib
import html
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path.cwd().resolve()
sys.path.insert(0, str(ROOT))
from etudecas.visualization.maps.source_comparison import build_comparison_payload
from etudecas.visualization.maps.portable_diagnostic import (
    comparison_document, strip_comparison, packed, COMPARISON_RUNTIME,
    COMPARISON_START, COMPARISON_END,
)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value, replace=False):
    content=json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(',', ':'))
    with path.open('w' if replace else 'x', encoding='utf-8') as stream:
        stream.write(content)


def metrics_for(payload):
    result=[]
    for key,pair in payload['pairs'].items():
        record={'pair':key,'unit':pair['unit'],'site_name':pair['site_name'],'node_id':pair['site'],'scenarios':{}}
        for run in payload['runs']:
            simulation=pair['simulations'].get(run,{})
            metric=simulation.get('metrics',{}).get('previous_day_physical')
            if not metric: continue
            stocks={r[0]:r[5] for r in simulation['stock']}
            photos=[(d,q,stocks[d-1]) for d,q,_ in pair['observed']
                    if 0<d<365 and isinstance(stocks.get(d-1),(int,float))]
            q4=[r for r in photos if r[0]>=273]
            record['scenarios'][run]=dict(metric,
                q4_mae=sum(abs(q-s) for d,q,s in q4)/len(q4) if q4 else None,
                last_photo=dict(day=photos[-1][0],observed=photos[-1][1],simulated=photos[-1][2]),
                zero_available_days=sum(r[1] is not None and r[1]<1e-8 for r in simulation['stock']),
                zero_physical_days=sum(r[5] is not None and r[5]<1e-8 for r in simulation['stock']))
        if record['scenarios']: result.append(record)
    return result


def overview(payload, metrics):
    """Presentation derived from this payload, not replayed saved metrics."""
    runs=list(payload['runs'])
    labels={'nominal':'Référence','total':'Besoins industriels','safety':'Besoins + sécurité'}
    heads=''.join('<th>'+labels[k]+'<br>Année / T4</th>' for k in runs)
    rows=[]
    for pair in metrics:
        if not all(k in pair['scenarios'] for k in runs): continue
        cells=[]
        for key in runs:
            values=pair['scenarios'][key]
            parts=[]
            for field in ('mae','q4_mae'):
                value=values[field]
                shown=f'{value:,.1f}'.replace(',',' ').replace('.',',') if value is not None else '—'
                parts.append(f'<span data-overview-run="{key}" data-metric="{field}" data-value="{value}">{shown}</span>')
            cells.append('<td>'+' / '.join(parts)+'</td>')
        key=html.escape(pair['pair'],quote=True)
        label=html.escape(pair['pair'].split('/')[0]+' / '+pair['site_name'])
        rows.append(f'<tr data-pair="{key}"><th><button type="button" data-open-pair="{key}">{label}</button></th>'
                    +f'<td>{html.escape(pair["unit"])}</td>'+''.join(cells)+'</tr>')
    return '''<style>
#globalRuleOverview th,#globalRuleOverview td{padding:7px 12px;border-bottom:1px solid #e2e8ef;text-align:right;white-space:nowrap;font-variant-numeric:tabular-nums}
#globalRuleOverview th:first-child{text-align:left}
#globalRuleOverview thead{position:sticky;top:0;background:#f2f6fa}
#globalRuleOverview button{background:white;color:#15567d;border:1px solid #c4d7e3;border-radius:5px;padding:5px 9px;cursor:pointer}
</style><details id="globalRuleOverview" open style="margin:16px 0;padding:12px;border:1px solid #d8e2e8;border-radius:8px">
<summary><strong>Bilan par référence — cliquer pour afficher les courbes</strong></summary>
<p><strong>Essais comparatifs.</strong> La référence reste la version 007923 améliorée. Les deux essais globaux ne la remplacent pas automatiquement.</p>
<p>Écart absolu moyen entre stock physique simulé et photos sources de 2025. Plus bas signifie plus proche des sources.
Chaque cellule indique l’année entière puis octobre–décembre (T4), dans l’unité de sa ligne. Les unités ne sont pas additionnées.</p>
<div style="max-height:330px;overflow:auto"><table style="width:100%;border-collapse:collapse">
<thead><tr><th>Article / site</th><th>Unité</th>'''+heads+'''</tr></thead><tbody>'''+''.join(rows)+'''</tbody></table></div>
</details><script>
document.getElementById('globalRuleOverview').addEventListener('click', function(event) {
  var button=event.target.closest('[data-open-pair]'); if(!button) return;
  var select=document.getElementById('sourceComparisonPair');
  select.value=button.dataset.openPair; select.dispatchEvent(new Event('change',{bubbles:true}));
  document.querySelector('[data-tab="stocks"]').click();
  document.getElementById('sourceComparisonReset').click();
  document.getElementById('chart-stocks').scrollIntoView({behavior:'smooth',block:'start'});
});
</script>'''


def main():
    runs={'nominal':HERE.parent/'mrp_offer_alignment_20261001/shared_007923/run_shared',
          'total':HERE/'experiment/run_total_all','safety':HERE/'experiment/run_safety_total_all'}
    if '--refresh-view' in sys.argv:
        old=json.loads((HERE/'map_delivery.json').read_text(encoding='utf-8'))
        for key in ('base','standalone','complete'):
            assert sha(Path(old[key]))==old[key+'_sha256']
        assert sha(HERE/'map_payload.json')==old['payload_sha256']
        render(json.loads((HERE/'map_payload.json').read_text(encoding='utf-8')),runs,refresh=True)
        return
    for variant in ('total_all','safety_total_all'):
        proof=json.loads((HERE/'experiment'/f'{variant}_execution.json').read_text(encoding='utf-8'))
        assert proof['returncode']==0 and proof['code_unchanged'] and proof['inputs_unchanged']
    source=ROOT/'etudecas/data/source'
    payload=build_comparison_payload(source/'Flow_Data_Inventory_and_Replenishment_rules.xlsx',
        source/'Flow_Data_MRP_results.xlsx',runs)
    for key,label,color in [('nominal','Référence · 007923 amélioré','#aa5e12'),
        ('total','Essai global · besoins industriels sur 22 achats','#117f88'),
        ('safety','Essai global · besoins sur 22 + sécurité sur 20','#7254a3')]:
        payload['runs'][key].update(label=label,color=color)
    payload.update(default_pair='002612/1810',default_runs=list(runs))
    payload['conventions'][:0]=[
        'Essais globaux séparés, sans remplacement automatique de la référence. Deux nouveaux calculs de 1 825 jours ; rapprochement industriel limité aux données de 2025.',
        'Besoins industriels : toutes les semaines I effectivement renseignées des 22 achats externes. Les besoins propres sont conservés ; le complément est max(I − besoins propres, 0). Une semaine absente reste inconnue, pas un zéro.',
        'Besoins + sécurité : protection continue des jours et quantités sources sur 20 achats ; les offres déclarées sont celles déjà utilisées dans la référence. 001848 garde principal/secours et 021081 ses fournisseurs multiples : leur protection historique est conservée.',
        'Les prix, délais sources, standards, exceptions de standards non contraignants, stocks initiaux et hypothèses de demandes physiques restent conservés. La sélection explicite de 001893 aligne aussi son délai ; son effet n’est pas uniquement celui de la sécurité.',
        '344135 ne dispose que de 17 versions MRP renseignées ; aucune version manquante n’est inventée. Les prévisions UN peuvent rester fractionnaires, les mouvements physiques UN sont entiers ; 730384 conserve son unité M.',
        'Les intermédiaires fabriqués ou transférés et les produits finis ne sont pas convertis en achats externes. Leurs résultats peuvent changer indirectement avec les disponibilités matières.',
        'Les autres panneaux de la carte complète et les deux suivis de lots restent historiques. Seule cette comparaison représente les nouveaux essais.',
    ]
    render(payload,runs)


def render(payload,runs,refresh=False):
    metrics=metrics_for(payload)
    document=comparison_document(payload).replace('</h1>','</h1>'+overview(payload,metrics),1)
    folder=ROOT/'etudecas/resultats/regroupement_001757_20260929'
    base=folder/'carte_mrp_001893_007923.html'
    standalone=folder/'comparaison_mrp_regles_globales.html'
    complete=folder/'carte_mrp_regles_globales.html'
    base_hash=sha(base);original=strip_comparison(base.read_text(encoding='utf-8'))
    with standalone.open('w' if refresh else 'x',encoding='utf-8') as stream:stream.write(document)
    runtime=COMPARISON_RUNTIME.replace('__ENTRY__',json.dumps(packed(document.encode('utf-8'),standalone.name,'text/html')))
    runtime=runtime.replace("button.textContent='Comparaisons 2025'","button.textContent='MRP · règles globales'")
    head,closing,tail=original.rpartition('</html>');assert closing
    rendered=head+COMPARISON_START+runtime+COMPARISON_END+closing+tail
    assert strip_comparison(rendered)==original
    with complete.open('w' if refresh else 'x',encoding='utf-8') as stream:stream.write(rendered)
    assert sha(base)==base_hash
    if not refresh:
        save(HERE/'map_payload.json',payload)
        save(HERE/'comparison_metadata.json', {
            'runs': {k:{field:payload['runs'][k][field] for field in ('label','color')} for k in runs},
            'default_pair':payload['default_pair'],'default_runs':payload['default_runs'],
            'conventions':payload['conventions'],
        })
        save(HERE/'analysis.json',{'metrics':metrics})
    save(HERE/'map_delivery.json',dict(base=str(base),base_sha256=base_hash,complete=str(complete),complete_sha256=sha(complete),
        standalone=str(standalone),standalone_sha256=sha(standalone),payload_sha256=sha(HERE/'map_payload.json'),
        runs={k:str(v) for k,v in runs.items()},historical_numeric_and_lot_payloads_unchanged=True),replace=refresh)
    print(json.dumps({'status':'rendered','pairs':len(metrics),'standalone':str(standalone),'complete':str(complete)}))


if __name__=='__main__':main()
