/* V8 in-memory review. No browser, Node, network or filesystem mutation.
 * Inputs: real template script, derived HTML payload subset, independent oracle.
 * Invoke the returned function in functions.exec after reading those inputs.
 */
(function reviewFactoryDispatch(script, data, oracle) {
  new Function(script); // Compile the complete, unmodified executable template.
  const section=(start,end)=>{
    const a=script.indexOf(start),b=script.indexOf(end,a+start.length);
    if(a<0||b<0)throw new Error('Missing template section '+start);
    return script.slice(a,b);
  };
  const definitions = section('  function addChart(', '  function warnHtml(')
    + section('  function sectionTop(', '  function availabilityNotes(')
    + section('  function buildFactoryDispatchRows(', '  function renderMethods(')
    + section('  function render() {', '  function exportCoverageCsv(');
  const body = `
    const nodes=new Map(),checks=[];
    const check=(name,ok)=>{if(!ok)throw new Error(name);checks.push(name);};
    class Element {
      constructor(id=''){this.id=id;this.children=[];this.parts=new Map();this.events={};this.attributes={};this.dataset={};this.style={};this.hidden=false;this.clientWidth=1000;this.value='';this.classList={add(){},remove(){}};this._html='';}
      set innerHTML(value){this._html=String(value);this.children=[];this.parts=new Map();for(const match of this._html.matchAll(/<[^>]+id="([^"]+)"[^>]*>/g)){const n=new Element(match[1]);const v=match[0].match(/value="([^"]*)"/);if(v)n.value=v[1];nodes.set(n.id,n);}}
      get innerHTML(){return this._html;}
      insertAdjacentHTML(position,value){this._html+=String(value);for(const match of String(value).matchAll(/<[^>]+id="([^"]+)"[^>]*>/g))nodes.set(match[1],new Element(match[1]));}
      appendChild(node){this.children.push(node);node.parent=this;return node;}
      querySelector(selector){if(!this.parts.has(selector))this.parts.set(selector,new Element(selector));return this.parts.get(selector);}
      querySelectorAll(){return [];}
      setAttribute(k,v){this.attributes[k]=String(v);}
      removeAttribute(k){delete this.attributes[k];}
      addEventListener(k,fn){this.events[k]=fn;}
      getBoundingClientRect(){return {left:0,top:0,width:1000,height:400};}
      getScreenCTM(){return {inverse:()=>({})};}
      setPointerCapture(){}
      scrollIntoView(){}
      remove(){}
      focus(){}
      click(){this.events.click?.({target:this});}
    }
    const $=id=>{if(!nodes.has(id))nodes.set(id,new Element(id));return nodes.get(id);};
    const document={createElement:()=>new Element(),body:new Element()};
    const DOMPoint=class {constructor(x,y){this.x=x;this.y=y;}matrixTransform(){return this;}};
    const escape=x=>String(x??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
    const ORIGIN=Date.parse('2025-01-01T00:00:00Z'),DAY=86400000,LAST=361;
    const date=d=>new Date(ORIGIN+d*DAY).toISOString().slice(0,10);
    const shortDate=date,fullDate=date;
    const number=(x,dec=2)=>Number.isFinite(x)?new Intl.NumberFormat('fr-FR',{maximumFractionDigits:dec}).format(x):'—';
    const compact=x=>String(x);
    const OBS_COLOR='#152c40',manyScenarios=false,hiddenSeries=new Set();
    const state={tab:'factory_dispatch',pair:'338929/1810',start:0,end:361,runs:['corrected'],product:null,factoryProduct:null,factoryRun:'corrected',factoryLag:2};
    const initialRuns=['corrected'],runLabel=k=>data.runs[k]?.label||k,pair=()=>({item:'338929'});
    let renderedCharts=[],latestRanking=[],latestCoverage=[];
    const refreshControls=()=>{},toast=()=>{},nettingLabel=x=>x;
    const renderStocks=()=>{},renderMrp=()=>{},renderFlows=()=>{},renderCustomer=()=>{},renderGaps=()=>{};
    const chooseVintage=()=>{},exportCsv=()=>{},exportCoverageCsv=()=>{};
    ${definitions}
    let numericFields=0;
    for(const c of oracle.cases){
      const actual=buildFactoryDispatchRows(data.factory_dispatch.products[c.item],c.run,c.lag,c.start,c.end);
      check(c.case+':'+c.item+':'+c.run+': row count',actual.length===c.rows.length);
      actual.forEach((r,i)=>oracle.columns.forEach((k,j)=>{numericFields++;if(r[k]!==c.rows[i][j])throw new Error('Oracle '+c.item+'/'+c.case+'/'+i+'/'+k+': '+r[k]+' != '+c.rows[i][j]);}));
    }
    render();
    check('initial current simulation',state.factoryRun==='corrected');
    check('two labelled series',renderedCharts.length===1&&renderedCharts[0].series.length===2&&renderedCharts[0].series[0].label.startsWith('RÉEL RECONSTITUÉ')&&renderedCharts[0].series[1].label.startsWith('SIMULÉ'));
    const panel=$('sourceComparisonPanel');
    check('visible assumption',panel.innerHTML.includes('estimation sous hypothèses'));
    check('visible detail and negative',panel.innerHTML.includes('Reconstitution brute')&&panel.innerHTML.includes('-6611'));
    const firstChart=$('sourceComparisonFactoryCharts').children[0];
    check('actual SVG generated',firstChart.querySelector('.chart-area').innerHTML.includes('data-series-id="factory:source:268091"')&&firstChart.querySelector('.chart-area').innerHTML.includes('data-series-id="factory:simulation:268091:corrected"'));
    const svg=firstChart.querySelector('.chart-area').querySelector('svg');
    svg.events.keydown({key:'ArrowRight',preventDefault(){}});
    check('tooltip shows departure and arrival periods',firstChart.querySelector('.chart-area').querySelector('.chart-tooltip').innerHTML.includes('Arrivées source à Muret')&&firstChart.querySelector('.chart-area').querySelector('.chart-tooltip').innerHTML.includes('2025-01-06'));
    let csv=factoryExportRows();
    check('CSV all weekly rows and two roles',csv.length===103&&csv[1][4].startsWith('RÉEL')&&csv[2][4].startsWith('SIMULÉ'));
    check('CSV keeps raw negative but absent plotted value',csv.some(r=>r[20]===-6611&&r[4].startsWith('RÉEL')&&r[14]===null));
    firstChart.querySelector('.legend').children[0].click();
    csv=factoryExportRows();
    check('legend hiding reflected in export',csv.length===52&&csv.slice(1).every(r=>r[4].startsWith('SIMULÉ')));
    hiddenSeries.clear();
    $('sourceComparisonFactoryProduct').events.change({target:{value:'268967'}});
    check('product control changes graph',state.factoryProduct==='268967'&&renderedCharts[0].title.includes('Gien'));
    check('Permixon gap is not zero',factoryRows().some(r=>r.reconstructed_receipt_raw_qty===-13608&&r.source_plot_qty===null));
    $('sourceComparisonFactoryRun').events.change({target:{value:'nominal'}});
    check('scenario control',state.factoryRun==='nominal'&&renderedCharts[0].series[1].id.endsWith(':nominal'));
    $('sourceComparisonFactoryLag').events.change({target:{value:'7'}});
    check('delay control and partial initial week',state.factoryLag===7&&factoryRows()[0].comparison_status==='partial_window');
    $('sourceComparisonFactoryLag').events.change({target:{value:'2'}});
    setWindow(20,51);
    check('zoom excludes partial windows from graph',factoryRows().some(r=>!r.fully_in_window)&&renderedCharts[0].series.every(s=>s.points.every(p=>p[0]>=20&&p[0]+6<=51)));
    setWindow(0,361);
    check('reset full year',factoryRows().length===51);
    return {status:'passed',complete_template_syntax:true,checks,numeric_oracle_fields:numericFields,oracle_cases:oracle.cases.length,browser_executed:false,scope:'Real helper, render, SVG generation, tooltip, legend, selector handlers and export values in an in-memory DOM; no browser layout verification.'};
  `;
  return new Function('data','oracle',body)(data,oracle);
})
