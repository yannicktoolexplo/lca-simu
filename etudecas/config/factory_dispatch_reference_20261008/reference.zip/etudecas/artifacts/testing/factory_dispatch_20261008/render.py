"""Add factory departures to a new comparison; keep accepted input untouched."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT))
from etudecas.visualization.maps.source_comparison import build_factory_dispatch_comparison
from etudecas.visualization.maps.portable_diagnostic import comparison_document

BASE = Path(__file__).resolve().parent
SOURCE = ROOT / 'etudecas/resultats/demand_pf_20261008/comparaison.html'
OUTPUT = ROOT / 'etudecas/resultats/factory_dispatch_20261008/comparaison.html'
EXPECTED = '852ba4f9f463037e27f2437f9dc5a6f26850a18a4e33c274efb336ad828209d6'
MARKER = '<script id="sourceComparisonPayload" type="application/json">'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def parse(document):
    return json.loads(document.split(MARKER, 1)[1].split('</script>', 1)[0])


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--refresh', action='store_true', help='Regenerate only this new derived comparison.')
    args = parser.parse_args()
    assert sha(SOURCE) == EXPECTED, 'The accepted input comparison has changed.'
    assert not OUTPUT.exists() or args.refresh, 'Choose refresh explicitly for this derived document.'
    paths = [Path(__file__),
             ROOT / 'etudecas/visualization/maps/source_comparison.py',
             ROOT / 'etudecas/visualization/maps/source_comparison_view.html',
             ROOT / 'etudecas/visualization/maps/portable_diagnostic.py']
    frozen = {str(p.relative_to(ROOT)): sha(p) for p in paths}
    data = parse(SOURCE.read_text(encoding='utf-8'))
    baseline = canonical({k: v for k, v in data.items() if k != 'default_tab'})
    assert 'factory_dispatch' not in data
    runs = {
        'nominal': ROOT / 'etudecas/artifacts/testing/customer_orders_only_20261008/run_candidate_365',
        'corrected': ROOT / 'etudecas/artifacts/testing/demand_pf_20261008/run_pf_zero_362',
    }
    data['factory_dispatch'] = build_factory_dispatch_comparison(data['customer_demand'], data['pairs'], runs)
    data['default_tab'] = 'factory_dispatch'
    output = comparison_document(data)
    reread = parse(output)
    assert canonical({k: v for k, v in reread.items() if k not in ('factory_dispatch', 'default_tab')}) == baseline
    assert reread['factory_dispatch'] == data['factory_dispatch']
    assert sha(SOURCE) == EXPECTED
    assert all(sha(ROOT / path) == expected for path, expected in frozen.items())
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(output, encoding='utf-8')
    result = {
        'status': 'rendered_pending_independent_validation',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'source_html': str(SOURCE.relative_to(ROOT)), 'source_html_sha256': EXPECTED,
        'html': str(OUTPUT.relative_to(ROOT)), 'html_sha256': sha(OUTPUT),
        'baseline_payload_except_default_tab_sha256': baseline,
        'existing_data_preserved': True,
        'added_payload_field': 'factory_dispatch',
        'inputs_sha256': frozen,
        'products': list(data['factory_dispatch']['products']),
        'simulation_rerun': False, 'browser_executed': False,
        'industrial_dispatches_measured': False,
        'scope': 'Conditional factory dispatch reconstruction from dated DC stocks and Flow history; matched shifted windows with executed factory shipments.',
    }
    (BASE / 'render.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=True))


if __name__ == '__main__':
    main()
