"""Independent read-only Excel/CSV oracle for the factory dispatch HTML addition.

No application helper imports, simulation, browser, fixture files, timestamp
changes or integrity mutation tests. The sole output is an exclusive proof JSON.
"""
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
import argparse
import csv
import hashlib
import json
import re
import sys

from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parents[4]
BASE = Path(__file__).resolve().parent
ORIGIN = date(2025, 1, 1)
ITEMS = {"268091": ("M-1810", "Avène"), "268967": ("M-1430", "Gien")}
RUNS = {
    "corrected": "etudecas/artifacts/testing/demand_pf_20261008/run_pf_zero_362",
    "nominal": "etudecas/artifacts/testing/customer_orders_only_20261008/run_candidate_365",
}
BASELINE_HTML = "etudecas/resultats/demand_pf_20261008/comparaison.html"
HTML = "etudecas/resultats/factory_dispatch_20261008/comparaison.html"
BASELINE_SHA = "852ba4f9f463037e27f2437f9dc5a6f26850a18a4e33c274efb336ad828209d6"
BASELINE_PAYLOAD_SHA = "b6e8d4857f90b6633f9e180793300022644846732ccea6cc165fea916994f991"
FROZEN = {
    "etudecas/data/source/Flow_Data_Inventory_and_Replenishment_rules.xlsx": "549598fa1aab06cd8f3e3d76e73026d09c46ddbf188a3bb1c2019cb3310a4b0c",
    "etudecas/data/source/Flow_Data_Inventory_movements.xlsx": "3e0785e356468d958629dcea1f727a06fcee18a9ae2c855e08e8d6409750f05e",
    "etudecas/data/source/Flow_Data_Customer_Demand.xlsx": "f53ee6081d65e5e7da529d1a790f7b94d8a11243937c98d06ac775df99544354",
    RUNS["corrected"] + "/data/production_lot_events.csv": "6c32e012f555f9d0647c43d10f9b3852526062f4a7a46df80566297d09de9ade",
    RUNS["corrected"] + "/data/production_stock_availability_daily.csv": "1dd4bd814ad287c20f819acdf025a5c7098bcf167cad4eafe0075ba44adf24bd",
    RUNS["corrected"] + "/run/flows.json": "e4859061cabb095a56584c7d3f7504f753cb7e1749b9f4899c7bc77870f64232",
    RUNS["nominal"] + "/data/production_lot_events.csv": "4c72a75eff55860b2bc39f5e43f9f0e3fa0c442de057719849f384575d55ee6b",
    RUNS["nominal"] + "/data/production_stock_availability_daily.csv": "c4d81d8bd67970758736ae916c0e58cd0a9ddf200d570c29258cd23766b80e5c",
    RUNS["nominal"] + "/run/flows.json": "e4859061cabb095a56584c7d3f7504f753cb7e1749b9f4899c7bc77870f64232",
}
checks, errors, tracked = Counter(), [], {}


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def track(path):
    path = Path(path)
    path = path if path.is_absolute() else ROOT / path
    key, digest = path.relative_to(ROOT).as_posix(), sha(path)
    if key in tracked:
        eq("repeated_read_same_hash", digest, tracked[key], key)
    else:
        tracked[key] = digest
    return path


def check(label, condition, detail=None):
    checks[label] += 1
    if not condition:
        errors.append({"check": label, "detail": detail})


def eq(label, actual, expected, detail=None):
    check(label, actual == expected, None if actual == expected else {"where": detail, "actual": actual, "expected": expected})


def integer(value, *, signed=False):
    val = Decimal(str(value))
    if not val.is_finite() or val != val.to_integral_value() or (val < 0 and not signed):
        raise ValueError(f"Non-integral/invalid physical quantity: {value}")
    return int(val)


def json_read(path):
    return json.loads(track(path).read_text(encoding="utf-8"))


def csv_read(path):
    with track(path).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def worksheet(path, sheet):
    workbook = load_workbook(track(path), read_only=True, data_only=True)
    try:
        return list(workbook[sheet].values)
    finally:
        workbook.close()


def iso(day):
    return (ORIGIN + timedelta(days=day)).isoformat()


def excel_oracle():
    base = "etudecas/data/source/"
    photos, history, movements = {}, {}, {}
    rows = worksheet(base + "Flow_Data_Inventory_and_Replenishment_rules.xlsx", "Stocks")
    eq("stocks_headers", list(rows[0]), ["Numéro d'article", "Type d'article", "Division", "Nom Division", "Stock Total", "Valeur Stock Total", "Unité de quantité de base", "Date de photo DMP"])
    for line, row in enumerate(rows[1:], 2):
        if str(row[0]) not in ITEMS or str(row[2]) != "1920":
            continue
        when = date.fromisoformat(row[7])
        key = str(row[0]), when
        check("unique_stock_photo", key not in photos, str(key))
        check("photo_date_is_monday_or_opening", when.weekday() == 0 or when == ORIGIN, line)
        eq("photo_source_unit", row[6], "ZUN", line)
        photos[key] = integer(row[4]), line
    rows = worksheet(base + "Flow_Data_Customer_Demand.xlsx", "Historique")
    eq("history_headers", list(rows[0]), ["SKU Code", "First day of Week Year Horizon", "Actual Demand"])
    for line, row in enumerate(rows[1:], 2):
        if str(row[0]) in ITEMS:
            key = str(row[0]), row[1].date()
            check("unique_history_week", key not in history, str(key))
            eq("history_monday", key[1].weekday(), 0, line)
            history[key] = abs(integer(row[2], signed=True)), line
    rows = worksheet(base + "Flow_Data_Inventory_movements.xlsx", "Feuille1")
    eq("movement_divers_is_G", rows[0][6], "Divers")
    eq("movement_week_header", rows[0][4], "Semaine")
    for line, row in enumerate(rows[1:], 2):
        if str(row[0]) not in ITEMS or str(row[3]) != "1920":
            continue
        label = row[4].date()
        eq("movement_sunday_label", label.weekday(), 6, line)
        eq("movement_source_unit", row[5], "ZUN", line)
        key = str(row[0]), label + timedelta(days=1)
        check("unique_movement_week", key not in movements, str(key))
        movements[key] = integer(row[6], signed=True), line, label.isoformat()
    observed = {}
    for item in ITEMS:
        observed[item] = []
        for start in range(5, 356, 7):
            when, following = ORIGIN + timedelta(days=start), ORIGIN + timedelta(days=start + 7)
            opening, opening_line = photos[item, when]
            closing, closing_line = photos[item, following]
            outbound, history_line = history[item, when]
            other, movement_line, movement_date = movements[item, when]
            raw = closing - opening + outbound - other
            observed[item].append(dict(arrival_start_day=start, arrival_end_day=start + 6,
                arrival_start_date=when.isoformat(), arrival_end_date=iso(start + 6),
                stock_open_qty=opening, stock_close_qty=closing, stock_delta_qty=closing - opening,
                history_outbound_assumption_qty=outbound, other_net_qty=other,
                reconstructed_receipt_raw_qty=raw, reconstructed_receipt_qty=raw if raw >= 0 else None,
                status="reconstructed" if raw >= 0 else "negative_reconstruction",
                history_excel_row=history_line, history_date=when.isoformat(),
                opening_photo_excel_row=opening_line, opening_photo_date=when.isoformat(),
                closing_photo_excel_row=closing_line, closing_photo_date=following.isoformat(),
                movement_excel_row=movement_line, movement_label_date=movement_date))
    return observed


def simulation_oracle(run_name):
    root = RUNS[run_name]
    flows = json_read(root + "/run/flows.json")
    summary_path = root + "/summaries/first_simulation_summary.json"
    summary = json_read(summary_path)
    graph_path = track(summary["input_file"])
    graph = json.loads(graph_path.read_text(encoding="utf-8"))
    eq("graph_matches_run_hash", sha(graph_path), summary["input_sha256"], run_name)
    eq("run_origin", graph["meta"]["opening_open_orders"]["snapshot_date"], "2025-01-01", run_name)
    eq("run_warmup", summary["warmup_days"], 0, run_name)
    eq("run_horizon", summary["sim_days"], 362 if run_name == "corrected" else 365)
    eq("run_has_lot_ledger", summary["policy"]["lot_trace_enabled"], True)
    events = csv_read(root + "/data/production_lot_events.csv")
    availability = csv_read(root + "/data/production_stock_availability_daily.csv")
    result = {}
    for item, (factory, _) in ITEMS.items():
        routes = {row["id"] for row in flows if row["type"] == "transport" and row["from"] == factory and row["to"] == "DC-1920" and "item:" + item in row["items"]}
        graph_routes = {row["id"] for row in graph["edges"] if row["type"] == "transport" and row["from"] == factory and row["to"] == "DC-1920" and "item:" + item in row["items"]}
        eq("graph_routes_equal_frozen_run_flows", sorted(graph_routes), sorted(routes), (run_name, item))
        check("factory_route_present", bool(routes), item)
        site_days = defaultdict(set)
        for row in availability:
            if row["item_id"] == "item:" + item and row["node_id"] in (factory, "DC-1920"):
                day = int(row["day"])
                check("availability_unique", day not in site_days[row["node_id"]], (run_name, item, day))
                eq("availability_unit", row["uom"], "UN")
                integer(row["physical_qty"])
                site_days[row["node_id"]].add(day)
        documented = sorted(site_days[factory] & site_days["DC-1920"] & set(range(365)))
        eq("complete_daily_coverage", documented, list(range(summary["sim_days"])), (run_name, item))
        selected = [row for row in events if row["item_id"] == "item:" + item and row["source_id"] in routes and row["event_type"] in ("lane_ship", "lane_receipt") and 0 <= int(row["day"]) < 365]
        departures, receipts, daily = defaultdict(list), defaultdict(list), defaultdict(int)
        identities = set()
        for row in selected:
            is_ship = row["event_type"] == "lane_ship"
            eq("event_endpoint", row["node_id"], factory if is_ship else "DC-1920")
            eq("event_unit", row["uom"], "UN")
            check("event_unique", row["event_id"] not in identities)
            identities.add(row["event_id"])
            check("shipment_identifier_present", bool(row["shipment_id"]))
            qty = integer(row["qty"])
            (departures if is_ship else receipts)[row["shipment_id"]].append(row)
            if is_ship:
                daily[int(row["day"])] += qty
        matched, incomplete, unmatched, all_lags = [], [], [], set()
        for shipment_id, ships in departures.items():
            arrival = receipts.get(shipment_id, [])
            start = int(ships[0]["day"])
            route = ships[0]["source_id"]
            check("shipment_single_departure", all(int(row["day"]) == start and row["source_id"] == route for row in ships))
            check("receipt_matching_route", all(row["source_id"] == route and int(row["day"]) >= start for row in arrival))
            outqty = sum(integer(row["qty"]) for row in ships)
            inqty = sum(integer(row["qty"]) for row in arrival)
            days = sorted({int(row["day"]) for row in arrival})
            record = dict(shipment_id=shipment_id, route_id=route, departure_day=start, shipped_qty=outqty, received_qty=inqty,
                departure_event_ids=[row["event_id"] for row in ships], receipt_event_ids=[row["event_id"] for row in arrival], receipt_days=days)
            check("receipts_do_not_exceed_shipment", inqty <= outqty)
            if outqty > 0 and inqty == outqty and days:
                lags = sorted({day - start for day in days})
                record["transport_delay_days"] = lags
                all_lags.update(lags)
                matched.append(record)
            else:
                incomplete.append(record)
        for shipment_id, rows in receipts.items():
            if shipment_id not in departures:
                unmatched.extend(dict(shipment_id=shipment_id, receipt_day=int(row["day"]), received_qty=integer(row["qty"]), event_id=row["event_id"]) for row in rows)
        result[item] = dict(daily=[dict(day=day, shipped_qty=daily[day] if day in documented else None) for day in range(365)],
            documented_days=documented, route_ids=sorted(routes), has_event_ledger=True,
            transport_delay_days=next(iter(all_lags)) if len(all_lags) == 1 else None,
            transport_delay_evidence=dict(observed_delays_days=sorted(all_lags), matched_shipments=matched, incomplete_shipments=incomplete, unmatched_receipts=unmatched))
    return result


def ui_oracle(observed, simulation, lag, lower, upper):
    # Direct integer date-set aggregation; does not evaluate the application JS.
    daily = {row["day"]: row["shipped_qty"] for row in simulation["daily"]}
    records = []
    for source in observed:
        lo, hi = source["arrival_start_day"] - lag, source["arrival_end_day"] - lag
        if hi < lower or lo > upper:
            continue
        period = set(range(lo, hi + 1))
        full = period <= set(range(lower, upper + 1))
        covered = {day for day in period if daily.get(day) is not None}
        source_qty = source["reconstructed_receipt_qty"]
        shipped = sum(daily[day] for day in covered) if full and len(covered) == 7 else None
        status = "partial_window" if not full else source["status"] if source_qty is None else "missing_simulation" if len(covered) != 7 else "comparable"
        records.append(dict(arrival_start_day=source["arrival_start_day"], arrival_end_day=source["arrival_end_day"],
            departure_start_day=lo, departure_end_day=hi, transport_lag_days=lag,
            source_status=source["status"], source_estimate_qty=source_qty,
            source_plot_qty=source_qty if full else None, simulation_shipped_qty=shipped,
            simulation_covered_days=len(covered), fully_in_window=full, comparable=status == "comparable", comparison_status=status))
    comparable = [row for row in records if row["comparable"]]
    return dict(rows=records, summary=dict(comparable_weeks=len(comparable),
        source_total=sum(row["source_estimate_qty"] for row in comparable) if comparable else None,
        simulation_total=sum(row["simulation_shipped_qty"] for row in comparable) if comparable else None))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--readonly", action="store_true")
    args = parser.parse_args()
    track("etudecas/visualization/maps/source_comparison.py")
    track("etudecas/visualization/maps/source_comparison_view.html")
    track(__file__)
    for name, digest in FROZEN.items():
        eq("frozen_input_preserved", sha(track(name)), digest, name)
    eq("previous_html_preserved", sha(track(BASELINE_HTML)), BASELINE_SHA)
    pattern = r'<script[^>]*id="sourceComparisonPayload"[^>]*>(.*?)</script>'
    baseline = json.loads(re.search(pattern, (ROOT / BASELINE_HTML).read_text(encoding="utf-8"), re.S).group(1))
    canonical = json.dumps(baseline, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    eq("frozen_payload_preserved", hashlib.sha256(canonical).hexdigest(), BASELINE_PAYLOAD_SHA)
    html = track(HTML).read_text(encoding="utf-8")
    payload = json.loads(re.search(pattern, html, re.S).group(1))
    addition = payload["factory_dispatch"]
    eq("addition_fields_covered", sorted(addition), sorted(["schema_version", "origin", "products", "calendar", "default_transport_lag_days", "transport_lag_basis", "formula", "hypothesis", "comparison_basis", "source_columns", "limits", "provenance"]))
    eq("default_tab", payload["default_tab"], "factory_dispatch")
    eq("existing_payload_exactly_unchanged", {k: v for k, v in payload.items() if k not in ("factory_dispatch", "default_tab")}, {k: v for k, v in baseline.items() if k != "default_tab"})
    eq("payload_product_scope", sorted(addition["products"]), sorted(ITEMS))
    eq("payload_schema", addition["schema_version"], 1)
    eq("payload_origin", addition["origin"], ORIGIN.isoformat())
    eq("payload_calendar", addition["calendar"], "monday_sunday_complete_2025")
    eq("payload_default_lag", addition["default_transport_lag_days"], 2)
    eq("payload_formula", addition["formula"], "stock_close_qty - stock_open_qty + history_outbound_assumption_qty - other_net_qty")
    check("history_hypothesis_explicit", "HYPOTHÈSE" in addition["hypothesis"] and "Actual Demand" in addition["hypothesis"] and "pas prouvée" in addition["hypothesis"])
    check("source_G_explicit", "G Divers" in addition["source_columns"]["other_net"])
    check("raw_history_magnitude_explicit", "valeur absolue" in addition["source_columns"]["history"])
    check("unknown_industrial_departures_explicit", any("départ industriel" in limit and "observé" in limit for limit in addition["limits"]))
    check("lag_is_hypothesis", "hypothèse" in addition["transport_lag_basis"])
    check("same_shifted_window_explicit", "même fenêtre" in addition["comparison_basis"])
    observed = excel_oracle()
    simulations = {name: simulation_oracle(name) for name in RUNS}
    results, ui_cases = {}, []
    for item, (factory, name) in ITEMS.items():
        product = addition["products"][item]
        eq("product_fields_covered", sorted(product), sorted(["item", "name", "unit", "factory_id", "factory_name", "dc_id", "dc_name", "observed", "simulations"]))
        for field, value in dict(item=item, name=baseline["customer_demand"]["products"][item]["name"], unit="UN", factory_id=factory, factory_name=name, dc_id="DC-1920", dc_name="Muret").items():
            eq("product_metadata_" + field, product[field], value, item)
        eq("all_source_week_fields", product["observed"], observed[item], item)
        eq("product_run_scope", sorted(product["simulations"]), sorted(RUNS), item)
        results[item] = dict(weeks=len(observed[item]), raw_receipt_total=sum(row["reconstructed_receipt_raw_qty"] for row in observed[item]),
            outbound_hypothesis_total=sum(row["history_outbound_assumption_qty"] for row in observed[item]),
            divers_G_total=sum(row["other_net_qty"] for row in observed[item]),
            negative_weeks=[dict(date=row["arrival_start_date"], raw_qty=row["reconstructed_receipt_raw_qty"]) for row in observed[item] if row["status"] == "negative_reconstruction"], runs={})
        for run_name in RUNS:
            actual, expected = product["simulations"][run_name], simulations[run_name][item]
            eq("simulation_fields_covered", sorted(actual), sorted([*expected, "missing_basis"]))
            eq("evidence_fields_covered", sorted(actual["transport_delay_evidence"]), sorted([*expected["transport_delay_evidence"], "basis"]))
            for field, value in expected.items():
                if field == "transport_delay_evidence":
                    for name, val in value.items():
                        eq("shipment_evidence_" + name, actual[field][name], val, (item, run_name))
                    check("executed_lag_basis_explicit", "lane_ship" in actual[field]["basis"] and "lane_receipt" in actual[field]["basis"])
                else:
                    eq("simulation_" + field, actual[field], value, (item, run_name))
            check("missing_basis_explicit", "null" in actual["missing_basis"])
            daily = expected["daily"]
            evidence = expected["transport_delay_evidence"]
            results[item]["runs"][run_name] = dict(period_5_361_ship_total=sum(row["shipped_qty"] or 0 for row in daily if 5 <= row["day"] <= 361),
                matched_shipments=len(evidence["matched_shipments"]), incomplete_shipments=len(evidence["incomplete_shipments"]),
                unmatched_receipts=len(evidence["unmatched_receipts"]), transport_delay_days=expected["transport_delay_days"],
                documented_days=len(expected["documented_days"]))
            for label, lag, lower, upper in [("default", 2, 0, 361), ("first_partial", 2, 5, 361), ("zero_lag", 0, 0, 361), ("pre_horizon", 7, 0, 361), ("two_partial_bounds", 2, 20, 51)]:
                case = ui_oracle(observed[item], expected, lag, lower, upper)
                ui_cases.append(dict(case=label, item=item, run=run_name, lag=lag, start=lower, end=upper, **case))
                if label == "default":
                    results[item]["runs"][run_name]["default_comparable"] = case["summary"]
    eq("provenance_run_scope", sorted(addition["provenance"]), sorted(RUNS))
    for run_name, provenance in addition["provenance"].items():
        eq("provenance_run_directory", Path(provenance["run_directory"]).resolve(), (ROOT / RUNS[run_name]).resolve())
        eq("provenance_run_horizon", provenance["sim_days"], 362 if run_name == "corrected" else 365)
        check("provenance_nonempty", len(provenance["inputs"]) >= 4)
        for path, digest in provenance["inputs"].items():
            eq("provenance_current_input_hash", sha(track(path)), digest, path)
    track("etudecas/visualization/maps/source_comparison.py")
    track("etudecas/visualization/maps/source_comparison_view.html")
    track(__file__)
    for path, digest in list(tracked.items()):
        eq("unchanged_during_validation", sha(ROOT / path), digest, path)
    proof = dict(status="passed_independent_factory_dispatch" if not errors else "failed", created_at_utc=datetime.now(timezone.utc).isoformat(),
        checks=dict(checks), errors=errors, inputs_sha256=tracked, previous_html_sha256=BASELINE_SHA,
        previous_payload_canonical_sha256=BASELINE_PAYLOAD_SHA, results=results, oracle_ui_rows=ui_cases,
        browser_executed=False, simulation_rerun=False, industrial_calibration_certified=False,
        limits=["Historique magnitudes are only an assumption for physical depot outbound; inferred quantities are not observed factory dispatches.",
            "Raw ZUN stocks/movements are interpreted as physical units as in the frozen accepted source contract; no additional conversion is introduced.",
            "Two negative source reconstructions remain raw anomalies and absent curve values, not zero departures.",
            "Two days is established from matched executed simulation events; applying this lag to industrial movements remains an adjustable hypothesis.",
            "No observed daily factory dispatch schedule is supplied and none is invented.",
            "UI cases are independent expected data; their actual JavaScript evaluation is a separate parent proof, not a browser validation.",
            "Frozen numerical agreement and technical invariants do not certify industrial calibration."])
    if not args.readonly and not errors:
        with (BASE / "validation.json").open("x", encoding="utf-8") as stream:
            json.dump(proof, stream, ensure_ascii=False, indent=2)
    print(json.dumps(dict(status=proof["status"], checks=sum(checks.values()), errors=errors[:12], results=results, ui_cases=len(ui_cases)), ensure_ascii=False, default=str))
    return 1 if errors else 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    raise SystemExit(main())
