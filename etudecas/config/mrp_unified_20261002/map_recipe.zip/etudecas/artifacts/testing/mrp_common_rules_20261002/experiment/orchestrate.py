"""Isolated, sequential MRP comparisons. Never overwrites an existing run."""
import argparse
from collections import defaultdict
from copy import deepcopy
import csv
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
ACCEPTED = ROOT / 'etudecas/artifacts/testing/mrp_offer_alignment_20261001/shared_007923'
SOURCE = ROOT / 'etudecas/data/source'
POLICY = 'minimum_admissible_standard_until_release_v1'
LABELS = {'A': 'Reference acceptee recalculee', 'B': 'Lots provisoires, fournisseur au lancement',
          'C': 'Lots provisoires et anticipation des besoins'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def rel(path):
    return Path(path).resolve().relative_to(ROOT).as_posix()


def save(path, value, replace=False):
    with Path(path).open('w' if replace else 'x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)


def rows(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as stream:
        yield from csv.DictReader(stream)


def code_hashes():
    paths = list((ROOT / 'etudecas/simulation/engine').rglob('*.py'))
    paths += [ROOT / 'etudecas/simulation/experiments/shared_components.py', Path(__file__)]
    paths += list((ROOT / 'etudecas/visualization/maps').glob('source_comparison*'))
    paths += [ROOT / 'etudecas/visualization/maps/portable_diagnostic.py']
    return {rel(p): sha(p) for p in sorted(paths) if p.is_file()}


def prepare():
    old = read(ACCEPTED / 'shared_graph.json')
    execution = read(ACCEPTED / 'shared_execution.json')
    assert execution['returncode'] == 0
    assert not (HERE / 'report.json').exists(), 'Preparation already exists'
    assert 'purchase_proposal_lot_policy' not in old['meta']
    assert 'purchase_need_date_policy' not in old['meta']
    graphs = {'A': deepcopy(old), 'B': deepcopy(old), 'C': deepcopy(old)}
    graphs['B']['meta']['purchase_proposal_lot_policy'] = POLICY
    graphs['C']['meta'].update(purchase_proposal_lot_policy=POLICY,
                             purchase_need_date_policy='source_safety_backwards_v1')
    commands = {}
    for name, graph in graphs.items():
        restored = deepcopy(graph)
        restored['meta'].pop('purchase_proposal_lot_policy', None)
        restored['meta'].pop('purchase_need_date_policy', None)
        assert restored == old
        path = HERE / f'graph_{name}.json'
        if path.exists():
            assert read(path) == graph, 'Existing prepared graph differs'
        else:
            save(path, graph)
        for days in (365, 1825):
            command = list(execution['command'])
            assert command[1] == '-B'
            command[0] = sys.executable
            for option, value in (('--input', rel(path)), ('--days', str(days)),
                                  ('--output-dir', rel(HERE / f'run_{name}_{days}'))):
                command[command.index(option) + 1] = value
            commands[f'{name}_{days}'] = command
    source_paths = [p for p in SOURCE.glob('*.xlsx') if not p.name.startswith('~$')]
    source_paths += [ACCEPTED / 'shared_graph.json', ACCEPTED / 'shared_execution.json']
    source_paths += [HERE / f'graph_{name}.json' for name in graphs]
    policies = old['meta']['sourcing_policy']['rows']
    report = dict(status='prepared_not_started', labels=LABELS, commands=commands,
        accepted_historical_context=rel(ACCEPTED / 'run_shared'),
        graph_changes={'A': {}, 'B': {'meta.purchase_proposal_lot_policy': POLICY},
                       'C': {'meta.purchase_proposal_lot_policy': POLICY,
                             'meta.purchase_need_date_policy': 'source_safety_backwards_v1'}},
        restored_graphs_equal_accepted=True,
        configured_sourcing_pairs=[dict(node_id=r['node_id'], item_id=r['item_id'],
            policy=r['policy'], offers=r['offers']) for r in policies],
        scope=dict(B='Only explicit sourcing-policy pairs; currently 001848 at M-1810.',
                   C='Same proposal rule, plus backwards source safety on eligible aggregate external purchases. Actual exported scope must be counted after execution.',
                   comparison='All source pairs, with separate 22-external-purchase cohort; no selection by improvement.'),
        input_sha256={rel(p): sha(p) for p in sorted(source_paths)},
        protocol='Sequential 365-day pilots A/B/C on one frozen code state. Parent decides which 1825-day candidates to run; no automatic promotion.',
        metric_contract=dict(
            stock='Physical total at previous-day close versus dated 2025 source photos; annual/Q1/Q4 MAE and signed bias, units kept separate.',
            snapshot='Latest source vintage <= simulated decision day; record lag. Full common future weeks only; never future source vintage.',
            requirements='Only kind=requirement, on original physical dates. No sum of industrial audit decomposition or anticipated planning requirements.',
            H='Source H is weekly projected incoming quantity, not individual order identities. Compare weekly modelled physical deliveries; availability dates kept separate.',
            matching='One-to-one matching of positive weekly quantities rounded to 1e-6 unit; maximise matches then minimise date gap, exact week and +/-7 days reported separately.',
            limitations='Source H has no firm/planned identifiers. Report model firm/proposal amounts separately, but score their combined weekly incoming only when physical date is documented for every relevant receipt. No injection of future H.',
            repeated_vintages='Scores concern snapshot occurrences, not number of annual executed orders; no sum of 52 plans interpreted as annual purchase volume.'),
        runs={})
    save(HERE / 'report.json', report)
    print(json.dumps({'prepared': True, 'report': rel(HERE / 'report.json'), 'run_started': False}))


def freeze():
    report = read(HERE / 'report.json')
    assert not report.get('freeze'), 'Already frozen'
    assert not report['runs']
    for path, digest in report['input_sha256'].items():
        assert sha(ROOT / path) == digest, path
    report['freeze'] = dict(utc=datetime.now(timezone.utc).isoformat(), code=code_hashes())
    report['status'] = 'frozen_awaiting_authorized_run'
    save(HERE / 'report.json', report, replace=True)
    print(json.dumps({'frozen': True, 'code_files': len(report['freeze']['code'])}))


def prepare_smoke():
    report = read(HERE / 'report.json')
    assert not report.get('freeze') and not report['runs']
    assert 'B_8' not in report['commands']
    command = list(report['commands']['B_365'])
    command[command.index('--days') + 1] = '8'
    command[command.index('--output-dir') + 1] = rel(HERE / 'run_B_8')
    report['commands']['B_8'] = command
    report['protocol'] = 'Normal 8-day B export check first; then sequential 365-day A/B/C pilots on frozen code. Parent decides 1825-day runs. No automatic promotion.'
    report['preparation_checks'] = dict(syntax='compiled in memory',
        matching_memory_cases=4, matching_status='passed', independent_oracle='pending')
    save(HERE / 'report.json', report, replace=True)
    print(json.dumps({'smoke_prepared': True, 'days': 8, 'variant': 'B'}))


def run(variant, days):
    report = read(HERE / 'report.json')
    key = f'{variant}_{days}'
    assert key not in report['runs'], 'Existing execution must be retained'
    assert code_hashes() == report['freeze']['code'], 'Code changed since freeze'
    for path, digest in report['input_sha256'].items():
        assert sha(ROOT / path) == digest, path
    command = report['commands'][key]
    output = ROOT / command[command.index('--output-dir') + 1]
    assert not output.exists(), 'Never overwrite an output'
    started, utc = time.monotonic(), datetime.now(timezone.utc).isoformat()
    with (HERE / f'{key}.log').open('x', encoding='utf-8') as stream:
        process = subprocess.Popen(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
        print(json.dumps({'run': key, 'pid': process.pid, 'log': rel(HERE / f'{key}.log')}), flush=True)
        returncode = process.wait()
    after = code_hashes()
    inputs_after = {p: sha(ROOT / p) for p in report['input_sha256']}
    report['runs'][key] = dict(returncode=returncode, seconds=time.monotonic() - started,
        started_utc=utc, ended_utc=datetime.now(timezone.utc).isoformat(), command=command,
        code_before=report['freeze']['code'], code_after=after,
        code_unchanged=after == report['freeze']['code'],
        input_before=report['input_sha256'], input_after=inputs_after,
        inputs_unchanged=inputs_after == report['input_sha256'])
    report['status'] = 'executed_pending_independent_review'
    save(HERE / 'report.json', report, replace=True)
    result = report['runs'][key]
    print(json.dumps({k: result[k] for k in ('returncode', 'seconds', 'code_unchanged', 'inputs_unchanged')}))
    if returncode or not result['code_unchanged'] or not result['inputs_unchanged']:
        raise SystemExit(returncode or 1)


def positive_matches(source, model, tolerance_days):
    """Per equal-quantity group, sorted DP: max cardinality, then min date gap."""
    groups = defaultdict(lambda: [[], []])
    quantum = Decimal('0.000001')
    for side, records in enumerate((source, model)):
        for day, qty in records:
            if qty > 1e-6:
                q = str(Decimal(str(qty)).quantize(quantum, rounding=ROUND_HALF_UP))
                groups[q][side].append(day)
    matches = []
    for qty, (left, right) in groups.items():
        left.sort(); right.sort()
        states = [[(0, 0, ()) for _ in range(len(right) + 1)] for _ in range(len(left) + 1)]
        for i, a in enumerate(left, 1):
            for j, b in enumerate(right, 1):
                choices = [states[i - 1][j], states[i][j - 1]]
                if abs(a - b) <= tolerance_days:
                    n, cost, pairs = states[i - 1][j - 1]
                    choices.append((n + 1, cost + abs(a - b), pairs + ((a, b),)))
                states[i][j] = max(choices, key=lambda s: (s[0], -s[1]))
        matches.extend(dict(source_day=a, model_day=b, qty=float(qty))
                       for a, b in states[-1][-1][2])
    ns = sum(q > 1e-6 for _, q in source)
    nm = sum(q > 1e-6 for _, q in model)
    return dict(matches=len(matches), source_positive_weeks=ns, model_positive_weeks=nm,
        false_negative=ns - len(matches), false_positive=nm - len(matches),
        precision=len(matches) / nm if nm else None, recall=len(matches) / ns if ns else None,
        matched_pairs=matches)


def stock_metrics(payload):
    result = {}
    for key, pair in payload['pairs'].items():
        result[key] = {'unit': pair['unit'], 'scenarios': {}}
        for name, simulation in pair['simulations'].items():
            stock = {r[0]: r[5] for r in simulation['stock']}
            valid = [(d, q, stock[d - 1]) for d, q, _ in pair['observed']
                     if 0 < d < 365 and isinstance(stock.get(d - 1), (int, float))]
            metrics = {}
            for period, low, high in (('annual', 1, 365), ('Q1', 1, 90), ('Q4', 273, 365)):
                selected = [(q, s) for d, q, s in valid if low <= d < high]
                metrics[period] = dict(n=len(selected),
                    mae=sum(abs(s - q) for q, s in selected) / len(selected) if selected else None,
                    bias=sum(s - q for q, s in selected) / len(selected) if selected else None)
            metrics['last_photo'] = dict(day=valid[-1][0], source=valid[-1][1], model=valid[-1][2]) if valid else None
            result[key]['scenarios'][name] = metrics
    return result


def planned_metrics(payload, run):
    events = defaultdict(list)
    for row in rows(run / 'data/mrp_dated_plan_weekly.csv'):
        d = int(row['decision_day'])
        if 0 <= d < 365 and row['action_scope'] == 'component_procurement':
            events[row['item_id'].split(':')[-1] + '/' + row['node_id'].split('-')[-1], d].append(row)
    horizons = {(r['item_id'].split(':')[-1] + '/' + r['node_id'].split('-')[-1], int(r['day'])):
                int(float(r['dated_horizon_days'])) for r in rows(run / 'data/mrp_dated_plan_daily.csv')
                if int(r['day']) < 365}
    orders = {}
    for r in rows(run / 'data/mrp_orders_daily.csv'):
        if r['mrp_order_id']:
            orders[r['mrp_order_id']] = r
    output = []
    for (key, decision), rr in sorted(events.items()):
        pair = payload['pairs'].get(key)
        if not pair:
            continue
        vintages = [int(v) for v in pair.get('mrp_full', {}) if int(v) <= decision]
        if not vintages:
            continue
        vintage = max(vintages)
        horizon = horizons[key, decision]
        source = [r for r in pair['mrp_full'][str(vintage)]
                  if decision <= r[0] and r[0] + 7 <= decision + horizon + 1]
        known = {r[0] for r in source}
        demands, firm, proposed, available = (defaultdict(float) for _ in range(4))
        unknown = []
        for r in rr:
            kind, target, qty = r['kind'], int(r['target_day']), float(r['qty'])
            bucket = target - ((target - 4) % 7)
            if kind == 'requirement' and bucket in known:
                demands[bucket] += qty
            if kind == 'proposal' or kind == 'firm_in_transit':
                available[bucket] += qty
                physical = r.get('physical_receipt_day', '')
                if not physical and kind == 'firm_in_transit':
                    order = orders.get(r['identity'], {})
                    # Only a receipt present in the causal snapshot is joined; no future orders injected.
                    physical = order.get('physical_delivery_day', '')
                if physical == '' or physical is None:
                    unknown.append(dict(kind=kind, identity=r['identity'], qty=qty, availability_day=target))
                    continue
                pd = int(float(physical))
                pb = pd - ((pd - 4) % 7)
                if pb in known:
                    (proposed if kind == 'proposal' else firm)[pb] += qty
        incoming = [(d, firm[d] + proposed[d]) for d in sorted(known)]
        expected = [(r[0], r[1]) for r in source]
        record = dict(pair=key, unit=pair['unit'], decision_day=decision,
            source_vintage_day=vintage, source_lag_days=decision - vintage,
            common_week_count=len(source), horizon_days=horizon,
            requirements_weekly_mae=sum(abs(demands[r[0]] - r[2]) for r in source) / len(source) if source else None,
            requirements_source_sum=sum(r[2] for r in source), requirements_model_sum=sum(demands.values()),
            proposed_physical_qty=sum(proposed.values()), firm_physical_qty=sum(firm.values()),
            unknown_physical_dates=unknown,
            H_comparability='complete_modelled_physical_dates' if not unknown else 'incomplete_no_score',
            weeks=[dict(day=r[0], source_H=r[1], source_I=r[2], model_I=demands[r[0]],
                        model_firm_H=firm[r[0]], model_proposal_H=proposed[r[0]],
                        model_receipts_availability=available[r[0]]) for r in source])
        if not unknown:
            record['H_exact_week'] = positive_matches(expected, incoming, 0)
            record['H_within_7_days'] = positive_matches(expected, incoming, 7)
        output.append(record)
    return output


def service_metrics(run):
    result = defaultdict(lambda: dict(demand_qty=0., served_qty=0., backlog_days=0, last_backlog_qty=0.))
    for row in rows(run / 'data/production_demand_service_daily.csv'):
        if int(row['day']) >= 365:
            continue
        value = result[row['node_id'] + '/' + row['item_id']]
        value['demand_qty'] += float(row['demand_qty'])
        value['served_qty'] += float(row['served_qty'])
        value['backlog_days'] += float(row['backlog_end_qty']) > 1e-6
        value['last_backlog_qty'] = float(row['backlog_end_qty'])
    return dict(result)


def executed_purchase_metrics(run):
    result = defaultdict(lambda: dict(opening=[], new=[]))
    for r in rows(run / 'data/mrp_orders_daily.csv'):
        if not r['src_node_id'].startswith('SDC-') or 'purchase' not in r['order_type']:
            continue
        day = int(float(r['day']))
        if not 0 <= day < 365:
            continue
        key = r['item_id'].split(':')[-1] + '/' + r['node_id'].split('-')[-1]
        cohort = 'opening' if r['order_type'].startswith('opening_') else 'new'
        result[key][cohort].append(dict(order_id=r['mrp_order_id'], day=day,
            supplier=r['src_node_id'], qty=float(r['release_qty']),
            physical_delivery_day=r.get('physical_delivery_day'), available_day=r.get('available_day'),
            unit_cost=r.get('sourcing_purchase_unit_cost'), purchase_cost=r.get('sourcing_purchase_cost')))
    return dict(result)


def compare(days):
    sys.path.insert(0, str(ROOT))
    from etudecas.visualization.maps.source_comparison import build_comparison_payload
    from etudecas.visualization.maps.portable_diagnostic import comparison_document
    report = read(HERE / 'report.json')
    names = [v for v in LABELS if f'{v}_{days}' in report['runs']]
    assert names and names[0] == 'A'
    runs = {}
    for name in names:
        proof = report['runs'][f'{name}_{days}']
        assert proof['returncode'] == 0 and proof['inputs_unchanged'] and proof['code_unchanged']
        runs['nominal' if name == 'A' else name] = HERE / f'run_{name}_{days}'
    payload = build_comparison_payload(SOURCE / 'Flow_Data_Inventory_and_Replenishment_rules.xlsx',
        SOURCE / 'Flow_Data_MRP_results.xlsx', runs)
    for name in names:
        payload['runs']['nominal' if name == 'A' else name]['label'] = LABELS[name]
    payload['default_pair'] = '001848/1810'
    report.setdefault('comparisons', {})[str(days)] = dict(stock=stock_metrics(payload),
        plans={label: planned_metrics(payload, path) for label, path in runs.items()},
        service_2025={label: service_metrics(path) for label, path in runs.items()},
        executed_purchases_2025={label: executed_purchase_metrics(path) for label, path in runs.items()},
        provenance=payload['provenance'])
    output = HERE / f'comparaison_{days}.html'
    document = comparison_document(payload)
    document, replaced = re.subn(r'(<div[^>]+id="sourceComparisonHistoricalScope"[^>]*>).*?(</div>)',
        r'\1<strong>Comparaison autonome des nouveaux calculs.</strong> '
        'Chaque courbe provient du calcul indiqu\u00e9. Les plans sont des projections, '
        'les stocks industriels sont les photos sources de 2025. Aucun onglet historique n\u2019est greff\u00e9.\\2',
        document, count=1, flags=re.DOTALL)
    assert replaced == 1
    with output.open('x', encoding='utf-8') as stream:
        stream.write(document)
    report['comparisons'][str(days)]['html'] = dict(path=rel(output), sha256=sha(output))
    save(HERE / 'report.json', report, replace=True)
    print(json.dumps({'html': rel(output), 'sha256': sha(output), 'scenarios': names}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'prepare-smoke', 'freeze', 'run', 'compare'])
    parser.add_argument('--variant', choices=list(LABELS))
    parser.add_argument('--days', type=int, choices=[8, 365, 1825], default=365)
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare()
    elif args.action == 'prepare-smoke':
        prepare_smoke()
    elif args.action == 'freeze':
        freeze()
    elif args.action == 'run':
        if not args.variant:
            parser.error('--variant required')
        run(args.variant, args.days)
    else:
        compare(args.days)
