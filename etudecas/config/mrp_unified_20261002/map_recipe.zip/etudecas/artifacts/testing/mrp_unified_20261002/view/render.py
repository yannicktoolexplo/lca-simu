"""Render completed five-year runs only; never executes or changes a simulation."""
import argparse
from collections import defaultdict
from datetime import date, timedelta
import html
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
REFERENCE = ROOT / 'etudecas/artifacts/testing/mrp_730384_fixed_20261002/capacity_fixed'
COMMON = ROOT / 'etudecas/artifacts/testing/mrp_common_rules_20261002/experiment/orchestrate.py'
VERSION = 'source_safety_additive_v2'
sys.path.insert(0, str(ROOT))
from etudecas.visualization.maps.source_comparison import build_comparison_payload
from etudecas.visualization.maps.portable_diagnostic import comparison_document

spec = importlib.util.spec_from_file_location('common_stock_metrics', COMMON)
common = importlib.util.module_from_spec(spec)
spec.loader.exec_module(common)


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, separators=(',', ':'), allow_nan=False)


def yearly_service(run):
    result = {}
    for row in common.rows(run / 'data/production_demand_service_daily.csv'):
        day = int(row['day'])
        if not 0 <= day < 1825:
            continue
        year = str(day // 365 + 1)
        key = row['node_id'] + '/' + row['item_id']
        value = result.setdefault(year, {}).setdefault(key, dict(demand_qty=0., served_qty=0., last_backlog_qty=0.))
        value['demand_qty'] += float(row['demand_qty'])
        value['served_qty'] += float(row['served_qty'])
        value['last_backlog_qty'] = float(row['backlog_end_qty'])
    return result


def purchase_scope(run):
    """Scope from executed decision traces, never inferred from configuration alone."""
    result, days = {}, defaultdict(set)
    for row in common.rows(run / 'data/mrp_dated_plan_daily.csv'):
        if row.get('purchase_rule_version') != VERSION:
            continue
        assert row['purchase_need_date_policy'] == VERSION
        assert row['purchase_fixed_floor_mode'] == 'additive'
        pair = row['item_id'].removeprefix('item:') + '/' + row['node_id'].split('-')[-1]
        day = int(row['day'])
        assert day not in days[pair]
        days[pair].add(day)
        value = dict(safety_working_days=int(float(row['anticipated_safety_working_days'])),
                     fixed_floor_qty=float(row['anticipated_fixed_floor_qty']),
                     grouping_days=int(row['purchase_grouping_days']), uom=row['uom'])
        assert value['grouping_days'] >= 1
        assert pair not in result or result[pair] == value
        result[pair] = value
    assert len(result) == 22, ('Unexpected purchase scope', sorted(result))
    assert all(value == set(range(1825)) for value in days.values())
    assert len({row['grouping_days'] for row in result.values()}) == 1
    return result


def verify_completed(record, run):
    assert record['returncode'] == 0 and record['code_unchanged'] and record['inputs_unchanged']
    command = record['command']
    assert command[command.index('--days') + 1] == '1825'
    assert (ROOT / command[command.index('--output-dir') + 1]).resolve() == run.resolve()
    assert '--no-stochastic-lead-times' in command and '--stochastic-lead-times' not in command


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', required=True, type=Path)
    parser.add_argument('--report', required=True, type=Path)
    parser.add_argument('--run-key', required=True)
    parser.add_argument('--demand-scope', type=Path)
    parser.add_argument('--prefix-proof', type=Path)
    parser.add_argument('--receipt-plans-proof', type=Path)
    args = parser.parse_args()
    run = args.run.resolve()
    assert run.is_relative_to(ROOT / 'etudecas/artifacts/testing/mrp_unified_20261002')
    proof = common.read(args.report)['runs'][args.run_key]
    reference_run = REFERENCE / 'run_fixed_1825'
    verify_completed(proof, run)
    verify_completed(common.read(REFERENCE / 'report.json')['runs']['fixed_1825'], reference_run)
    output = ROOT / 'etudecas/resultats/mrp_unified_20261002/comparaison.html'
    assert not output.exists(), 'Never overwrite an existing comparison'
    assert bool(args.demand_scope) == bool(args.prefix_proof), 'Demand ratios need an independent equality proof for the first year'
    code = [Path(__file__), COMMON,
            ROOT / 'etudecas/visualization/maps/source_comparison.py',
            ROOT / 'etudecas/visualization/maps/source_comparison_view.html',
            ROOT / 'etudecas/visualization/maps/portable_diagnostic.py']
    before = {common.rel(path): common.sha(path) for path in code}
    scope = purchase_scope(run)
    receipt_summary, receipt_html = None, ''
    receipt_inputs = {}
    if args.receipt_plans_proof:
        receipt = common.read(args.receipt_plans_proof)
        assert receipt['status'] == 'three_snapshots_independent_H_comparison' and receipt['unchanged'] is True
        assert receipt['hashes_before'] == receipt['hashes_after']
        scored = {name: {(row['pair'], row['decision_day']): row for row in receipt['comparisons']
                        if row['scenario'] == name and 'source_fraction_within7' in row}
                  for name in ('before', 'common')}
        comparable = scored['before'].keys() & scored['common'].keys()
        assert comparable
        changes = [scored['common'][key]['source_fraction_within7'] - scored['before'][key]['source_fraction_within7'] for key in comparable]
        receipt_summary = dict(comparisons=len(comparable), decisions=receipt['decisions'],
            mean_before=sum(scored['before'][key]['source_fraction_within7'] for key in comparable) / len(comparable),
            mean_common=sum(scored['common'][key]['source_fraction_within7'] for key in comparable) / len(comparable),
            better=sum(value > 1e-10 for value in changes), worse=sum(value < -1e-10 for value in changes),
            equal=sum(abs(value) <= 1e-10 for value in changes))
        proof_link = os.path.relpath(args.receipt_plans_proof.resolve(), output.parent).replace('\\', '/')
        percent = lambda value: f'{100 * value:.2f}'.replace('.', ',') + ' %'
        receipt_html = ('<p id="commonRulesReceiptLimit" style="padding:12px;border-left:4px solid #b66a19;background:#fff7e9">'
            '<strong>Le MRP industriel n’est pas validé par ces courbes de stock.</strong> '
            'Contrôle complémentaire des essais sur trois dates de calcul de 2025 : '
            + str(receipt_summary['comparisons']) + ' comparaisons matière / date exploitables. '
            'La part moyenne des volumes H prévus retrouvée à ±7 jours passe de '
            + percent(receipt_summary['mean_before']) + ' à ' + percent(receipt_summary['mean_common'])
            + ' ; ' + str(receipt_summary['better']) + ' comparaisons s’améliorent, '
            + str(receipt_summary['worse']) + ' se dégradent et ' + str(receipt_summary['equal']) + ' sont inchangées. '
            'Ce sont des instantanés de prévision, pas un comptage des commandes annuelles ni des réceptions industrielles exécutées. '
            'Les dates physiques non déterminées restent exclues du score. <a href="'
            + html.escape(proof_link, quote=True) + '">Preuve et méthode du rapprochement H</a>.</p>')
        receipt_inputs = {common.rel(args.receipt_plans_proof): common.sha(args.receipt_plans_proof)}
    demand_scope = {}
    demand_inputs = {}
    if args.demand_scope:
        prefix = common.read(args.prefix_proof)
        assert prefix['all_compared_prefixes_equal'] is True
        diagnostic = common.read(args.demand_scope)
        assert diagnostic['unchanged'] is True and diagnostic['pair_count'] == 22
        assert diagnostic['hashes_before'] == diagnostic['hashes_after']
        for row in diagnostic['pairs']:
            site, item = row['pair'].split('/')
            key = item.removeprefix('item:') + '/' + site.split('-')[-1]
            assert key in scope and key not in demand_scope
            demand_scope[key] = {field: row[field] for field in (
                'unit', 'source_covered_days', 'unknown_days', 'source_I_covered_qty',
                'total_physical_consumed_covered_qty', 'physical_to_source_ratio')}
        assert set(demand_scope) == set(scope)
        demand_inputs = {common.rel(path): common.sha(path) for path in (args.demand_scope, args.prefix_proof)}
    grouping = next(iter(scope.values()))['grouping_days']
    labels = {'nominal': 'Référence : délais fixes, standard 730384 de 92 500 m',
              'G': f'Règles communes : stock fixe + anticipation, regroupement {grouping} j'}
    runs = {'nominal': reference_run, 'G': run}
    service_years = {name: yearly_service(path) for name, path in runs.items()}
    for name, annual in service_years.items():
        assert set(annual) == {'1', '2', '3', '4', '5'}
        for year, products in annual.items():
            assert all(row['served_qty'] > 0 for row in products.values() if row['demand_qty'] > 0), (name, year, products)
    source = ROOT / 'etudecas/data/source'
    payload = build_comparison_payload(source / 'Flow_Data_Inventory_and_Replenishment_rules.xlsx',
        source / 'Flow_Data_MRP_results.xlsx', runs)
    for name, label in labels.items():
        payload['runs'][name]['label'] = label
        assert payload['runs'][name]['days'] == 1825
    payload['default_pair'] = '708073/1430'
    payload['common_purchase_rules'] = dict(version=VERSION, grouping_days=grouping, pairs=scope,
        basis='Executed dated decision traces, all 1825 days; the grouping period is a scenario convention, not an identified ERP rule.')
    payload['demand_scope_2025'] = demand_scope
    payload['receipt_plans_snapshot_review'] = receipt_summary
    for pair, entry in payload['pairs'].items():
        if pair in scope and 'G' in entry.get('simulations', {}):
            simulation = entry['simulations']['G']
            simulation['common_purchase_rules'] = scope[pair]
            # Old graph-specific batching rules are superseded in this run.
            # Preserve their provenance, but do not label them as active rules.
            simulation['superseded_procurement_batching'] = simulation.get('procurement_batching')
            simulation['procurement_batching'] = None
    convention = (f'22 couples matière/site suivent le même calcul : stock fixe source ajouté une fois aux besoins '
        f'anticipés des jours ouvrés de sécurité sources ; stocks et engagements déduits une fois. '
        f'Regroupement de {grouping} jour(s), convention de cet essai, non démontrée comme règle ERP industrielle. '
        'La cible du contrôleur de production est maintenue dans les projections révocables ; elle ne constitue '
        'pas une fabrication exécutée. Les usages attribués aux autres produits restent des hypothèses inchangées.')
    payload['conventions'].insert(0, convention)
    stocks = common.stock_metrics(payload)
    focus = payload['pairs']['708073/1430']
    receipts = [row['actual_physical_receipt_day']
                for row in focus['simulations']['G']['supplier_purchase_execution']
                if row.get('actual_physical_receipt_day') is not None]
    first_receipt = min(receipts, default=None)
    photos = sorted(focus['observed'])
    first_rise = next(((before[0], after[0]) for before, after in zip(photos, photos[1:])
                       if after[1] > before[1] + 1e-6), None)
    shown_date = lambda day: (date(2025, 1, 1) + timedelta(days=int(day))).strftime('%d/%m/%Y')
    focus_limit = '708073 à Gien : la règle commune est appliquée, mais sa calibration reste à résoudre. '
    if first_receipt is not None:
        focus_limit += 'Première réception d’un nouvel achat simulé : ' + shown_date(first_receipt) + '. '
    else:
        focus_limit += 'Aucune réception d’un nouvel achat simulé n’est documentée. '
    if first_rise:
        focus_limit += ('La première remontée de stock source apparaît entre le ' + shown_date(first_rise[0])
                        + ' et le ' + shown_date(first_rise[1]) + '. ')
        if first_receipt is None or first_receipt > first_rise[1]:
            focus_limit += 'La réception simulée reste donc trop tardive pour reproduire cette remontée. '
    focus_limit += ('La consommation déduite de la nomenclature, les autres usages estimés et les dates de besoin '
                    'doivent encore être rapprochés des sources ; leur rôle causal n’est pas validé. '
                    'Une remontée de photo indique un bilan net, pas l’identification d’une commande fournisseur.')
    counts = dict(better=0, worse=0, equal=0)
    purchase_counts = dict(better=0, worse=0, equal=0)
    rows = []
    def number(value):
        return '—' if value is None else f'{value:,.1f}'.replace(',', ' ').replace('.', ',')
    for pair, record in stocks.items():
        values = record['scenarios']
        if not all(values[name]['annual']['mae'] is not None for name in labels):
            continue
        delta = values['G']['annual']['mae'] - values['nominal']['annual']['mae']
        direction = 'better' if delta < -1e-6 else 'worse' if delta > 1e-6 else 'equal'
        counts[direction] += 1
        if pair in scope:
            purchase_counts[direction] += 1
        cells = ''.join('<td>' + number(values[name]['annual']['mae']) + ' / '
                        + number(values[name]['Q4']['mae']) + '</td>' for name in labels)
        applied = pair in scope
        demand = demand_scope.get(pair)
        ratio = demand.get('physical_to_source_ratio') if demand else None
        ratio_title = (f"{demand['source_covered_days']} jours comparés ; {demand['unknown_days']} jours sans besoin source documenté. "
                       'Consommation physique simulée / besoins prévus I ; aucune consommation industrielle mesurée.'
                       if demand else 'Diagnostic de périmètre non documenté pour cette ligne.')
        ratio_cell = '<td title="' + html.escape(ratio_title, quote=True) + '">' + (number(100 * ratio) + ' %' if ratio is not None else '—') + '</td>'
        rows.append('<tr data-common-rule-scope="' + ('applied' if applied else 'other') + '"><th><button type="button" data-open-pair="'
            + html.escape(pair, quote=True) + '">' + html.escape(pair) + '</button></th><td>'
            + html.escape(record['unit']) + '</td>' + cells + ratio_cell + '<td>'
            + ('Achats : règle commune' if applied else 'Fabrication / transfert / stock associé') + '</td></tr>')
    assert len(rows) == 29
    scope_links = ' · '.join('<button type="button" data-open-pair="' + html.escape(pair, quote=True) + '">'
        + html.escape(pair) + '</button>' for pair in sorted(scope))
    overview = ('<section id="commonRulesOverview" style="margin:16px;padding:16px;border:1px solid #cedbe5;border-radius:12px">'
        '<h2>Règles MRP communes : comparaison avec les stocks et flux sources de 2025</h2>'
        '<p id="commonRulesStatement">' + html.escape(convention) + '</p>'
        '<p>La sécurité suit lundi–vendredi. La disponibilité protégée précède le besoin ; le traitement à réception '
        'puis le délai fournisseur déterminent la date de commande. Le standard de l’offre retenue arrondit le besoin net '
        'à la tranche supérieure ; son surplus couvre les besoins suivants. Une quantité déjà engagée ne se rachète pas automatiquement.</p>'
        '<p>Les délais restent fixes ; 730384 conserve le standard de 92 500 m demandé. Les capacités fournisseurs '
        'et les stocks initiaux restent ceux de la référence. Ces capacités sont des estimations du modèle.</p>'
        '<p><strong>Résultat global des 29 rapprochements : ' + str(counts['better']) + ' plus proches, '
        + str(counts['worse']) + ' plus éloignés, ' + str(counts['equal']) + ' inchangés.</strong> '
        'Parmi les 22 achats externes concernés : ' + str(purchase_counts['better']) + ' plus proches, '
        + str(purchase_counts['worse']) + ' plus éloignés et ' + str(purchase_counts['equal']) + ' inchangés. '
        'Une règle commune appliquée ne signifie pas que toutes les matières sont calibrées. '
        'Les écarts, consommations estimées et périmètres incomplets restent visibles.</p>'
        '<p id="commonRules708073Limit" style="padding:12px;border-left:4px solid #b66a19;background:#fff7e9">'
        + html.escape(focus_limit) + '</p>'
        + receipt_html
        + '<details id="commonRulesScope"><summary>22 couples matière / site : règle vérifiée dans les décisions exécutées</summary><p>'
        + scope_links + '</p></details>'
        '<p>Chaque cellule compare le stock physique total aux photos sources : écart absolu moyen annuel / octobre–décembre. '
        'Plus bas signifie plus proche. Les unités restent séparées par ligne. Les 29 lignes incluent aussi les produits et transferts internes ; '
        'elles ne constituent pas 29 achats externes. Cliquer sur une référence pour afficher ses courbes.</p>'
        '<p>« Consommé / besoin prévu » rapproche la consommation physique <strong>simulée</strong> '
        'et les besoins I du MRP source sur les mêmes jours documentés. I est une prévision, '
        'pas une consommation industrielle réalisée. Un faible ratio signale un écart de périmètre '
        'ou de trajectoire à examiner ; il ne prouve pas à lui seul la cause d’un surstock.</p>'
        '<div style="overflow:auto;max-height:440px"><table style="width:100%;border-collapse:collapse"><thead><tr>'
        '<th>Article / site</th><th>Unité</th>' + ''.join('<th>' + html.escape(label) + '</th>' for label in labels.values())
        + '<th>Consommé / besoin prévu</th><th>Périmètre</th></tr></thead><tbody>' + ''.join(rows) + '</tbody></table></div></section>'
        '<style>#commonRulesOverview th,#commonRulesOverview td{padding:7px;border-bottom:1px solid #dbe3e9;text-align:right;font-variant-numeric:tabular-nums}'
        '#commonRulesOverview th:first-child{text-align:left}#commonRulesOverview button{cursor:pointer;padding:5px;color:#15567d;background:white;border:1px solid #bacddd;border-radius:5px}'
        '#commonRulesOverview thead{position:sticky;top:0;background:#f2f6fa}</style>')
    interaction = """<script>document.getElementById('commonRulesOverview').addEventListener('click',function(event){const b=event.target.closest('[data-open-pair]');if(!b)return;const s=document.getElementById('sourceComparisonPair');s.value=b.dataset.openPair;s.dispatchEvent(new Event('change',{bubbles:true}));document.querySelector('[data-tab=stocks]').click();document.getElementById('chart-stocks').scrollIntoView({behavior:'smooth',block:'start'});});</script>"""
    document = comparison_document(payload)
    assert "['source_safety_backwards_v1','source_safety_additive_v2'].includes" in document, 'Active view must recognize both rule versions'
    document, changed = re.subn(r'(<div[^>]+id="sourceComparisonHistoricalScope"[^>]*>).*?(</div>)',
        r'\1<strong>Deux simulations de cinq ans, comparées sur 2025.</strong> '
        r'Les courbes proviennent des calculs indiqués ; aucun onglet historique n’est greffé.\2',
        document, count=1, flags=re.DOTALL)
    assert changed == 1
    document = re.sub(r'<title>.*?</title>', '<title>MRP commun — comparaison 2025, 708073 et toutes les matières</title>', document, count=1)
    document = document.replace('<body>', '<body>' + overview, 1).replace('</body>', interaction + '</body>', 1)
    metrics = dict(stock=stocks, MAE_counts_vs_previous=counts, common_purchase_rules=payload['common_purchase_rules'],
        demand_scope_2025=demand_scope,
        receipt_plans_snapshot_review=receipt_summary,
        external_purchase_MAE_counts_vs_previous=purchase_counts,
        focus_708073_limit=dict(first_new_purchase_physical_receipt_day=first_receipt,
                               first_source_stock_rise_interval=first_rise, text=focus_limit),
        service_by_simulation_year=service_years,
        service_2025={name: common.service_metrics(path) for name, path in runs.items()},
        method='Stock physique total à la clôture précédente comparé aux photos sources. MAE annuelle et T4, unités séparées.',
        limitations='Les bilans, la portée du code et les comparaisons ne certifient pas les règles du système industriel ni les autres usages hypothétiques.')
    output.parent.mkdir(parents=True, exist_ok=True)
    save(HERE / 'payload.json', payload)
    save(HERE / 'metrics.json', metrics)
    with output.open('x', encoding='utf-8') as stream:
        stream.write(document)
    after = {common.rel(path): common.sha(path) for path in code}
    assert before == after, 'Renderer changed during execution'
    assert {path: common.sha(ROOT / path) for path in demand_inputs} == demand_inputs
    assert {path: common.sha(ROOT / path) for path in receipt_inputs} == receipt_inputs
    delivery = dict(status='rendered_pending_browser', html=common.rel(output), html_sha256=common.sha(output),
        command=[sys.executable, '-B', common.rel(Path(__file__)), *sys.argv[1:]], cwd=str(ROOT),
        recipe_dependencies={common.rel(path): common.sha(path) for path in
            (Path(__file__), HERE / 'check_comparison.py', COMMON)},
        demand_scope_inputs=demand_inputs,
        receipt_plans_inputs=receipt_inputs,
        payload=common.rel(HERE / 'payload.json'), payload_sha256=common.sha(HERE / 'payload.json'),
        metrics=common.rel(HERE / 'metrics.json'), metrics_sha256=common.sha(HERE / 'metrics.json'),
        table_pairs=len(rows), direct_purchase_pairs=len(scope), grouping_days=grouping,
        comparison_year=2025, simulation_days=1825, new_run=common.rel(run), reference_run=common.rel(reference_run),
        parent_report=common.rel(args.report), parent_report_sha256=common.sha(args.report),
        previous_report_sha256=common.sha(REFERENCE / 'report.json'),
        code_before=before, code_after=after, code_unchanged=True)
    save(HERE / 'delivery.json', delivery)
    print(json.dumps(delivery, ensure_ascii=False))


if __name__ == '__main__':
    main()
