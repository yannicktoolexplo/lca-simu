"""Read-only CSV/payload reconciliation and offline interactions for the delivered comparison."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
from uuid import uuid4

from playwright.sync_api import sync_playwright


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--html', type=Path, required=True)
    parser.add_argument('--payload', type=Path, required=True)
    parser.add_argument('--run', action='append', required=True, help='payload_label=run_directory')
    args = parser.parse_args()
    runs = {label: Path(path) for label, path in (entry.split('=', 1) for entry in args.run)}
    data = json.loads(args.payload.read_text(encoding='utf-8'))
    assert set(runs) == set(data['runs'])
    paths = [args.html, args.payload, Path(__file__)]
    paths += [path / 'data/production_stock_availability_daily.csv' for path in runs.values()]
    candidate = next(label for label in runs if label != 'nominal')
    candidate_trace = runs[candidate] / 'data/mrp_dated_plan_daily.csv'
    paths.append(candidate_trace)
    before = {str(path.resolve()): digest(path) for path in paths}
    output = Path(__file__).resolve().parent / ('browser_' + uuid4().hex[:10])
    output.mkdir(exist_ok=False)
    stocks = {}
    for label, path in runs.items():
        values = {}
        with (path / 'data/production_stock_availability_daily.csv').open(encoding='utf-8-sig', newline='') as stream:
            for row in csv.DictReader(stream):
                day = int(row['day'])
                if day >= 365:
                    continue
                key = row['item_id'].split(':')[-1] + '/' + row['node_id'].split('-')[-1]
                if key not in data['pairs']:
                    continue
                target_unit = data['pairs'][key]['unit']
                factor = .001 if row['uom'] == 'G' and target_unit == 'KG' else 1
                assert factor != 1 or row['uom'] == target_unit or row['uom'] == 'ZUN' and target_unit == 'UN'
                values[key, day] = float(row['physical_qty']) * factor
        stocks[label] = values
    daily_checks, rule_trace_checks, decision_payload_checks = 0, 0, 0
    for label, values in stocks.items():
        for key, pair in data['pairs'].items():
            embedded = {row[0]: row[5] for row in pair.get('simulations', {}).get(label, {}).get('stock', [])}
            raw = {day: qty for (stock_pair, day), qty in values.items() if stock_pair == key}
            if not embedded and not raw:
                continue
            assert set(raw) == set(embedded) == set(range(365)), (label, key)
            for day, qty in raw.items():
                assert abs(embedded[day] - qty) <= max(1e-6, abs(qty) * 1e-10)
                daily_checks += 1
    scope = data['common_purchase_rules']['pairs']
    assert len(scope) == 22
    observed_scope, scope_days = set(), {}
    trace_fields = ('purchase_rule_version', 'purchase_fixed_floor_mode', 'purchase_grouping_days',
                    'purchase_requirement_basis', 'production_projection_floor_qty')
    trace_positions = {field: data['columns']['trace'].index(field) for field in trace_fields}
    traces = {key: {row[0]: row for row in pair.get('simulations', {}).get(candidate, {}).get('trace', [])}
              for key, pair in data['pairs'].items()}
    with candidate_trace.open(encoding='utf-8-sig', newline='') as stream:
        for row in csv.DictReader(stream):
            key = row['item_id'].split(':')[-1] + '/' + row['node_id'].split('-')[-1]
            day = int(row['day'])
            if 0 <= day < 365 and day in traces.get(key, {}):
                for field, position in trace_positions.items():
                    value = traces[key][day][position]
                    raw = row.get(field)
                    if raw in (None, ''):
                        assert value is None, (key, day, field, value)
                    elif field in ('purchase_rule_version', 'purchase_fixed_floor_mode', 'purchase_requirement_basis'):
                        assert value == raw, (key, day, field, value, raw)
                    else:
                        factor = .001 if field.endswith('_qty') and row['uom'] == 'G' and data['pairs'][key]['unit'] == 'KG' else 1
                        expected = float(raw) * factor
                        assert abs(value - expected) <= max(1e-6, abs(expected) * 1e-10)
                    decision_payload_checks += 1
            if row.get('purchase_rule_version') != data['common_purchase_rules']['version']:
                continue
            assert key in scope and row['purchase_fixed_floor_mode'] == 'additive'
            assert int(row['purchase_grouping_days']) == scope[key]['grouping_days']
            assert float(row['anticipated_safety_working_days']) == scope[key]['safety_working_days']
            assert float(row['anticipated_fixed_floor_qty']) == scope[key]['fixed_floor_qty']
            observed_scope.add(key)
            assert day not in scope_days.setdefault(key, set())
            scope_days[key].add(day)
            rule_trace_checks += 1
    assert observed_scope == set(scope)
    assert all(days == set(range(1825)) for days in scope_days.values())
    errors, counts, payload_checks, overview_checks = [], [], 0, 0
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=True)
        try:
            page = browser.new_page(offline=True, viewport={'width': 1600, 'height': 1000})
            page.on('pageerror', lambda error: errors.append(str(error)))
            page.goto(args.html.resolve().as_uri(), wait_until='load', timeout=90000)
            root = page.locator('#sourceComparisonRoot')
            root.wait_for(state='visible')
            assert root.evaluate('()=>SOURCE_COMPARISON_VIEW.getState().pair') == data['default_pair']
            assert data['default_pair'] == '708073/1430'
            assert page.locator('#commonRulesScope button[data-open-pair]').count() == 22
            assert 'hypothèses inchangées' in page.locator('#commonRulesStatement').inner_text()
            assert 'calibration reste à résoudre' in page.locator('#commonRules708073Limit').inner_text()
            receipt_review = data.get('receipt_plans_snapshot_review')
            if receipt_review:
                notice = page.locator('#commonRulesReceiptLimit')
                text = notice.inner_text()
                assert str(receipt_review['comparisons']) + ' comparaisons matière / date' in text
                for field in ('mean_before', 'mean_common'):
                    assert f"{100 * receipt_review[field]:.2f}".replace('.', ',') + ' %' in text
                assert 'pas un comptage des commandes annuelles' in text
                assert (args.html.parent / notice.locator('a').get_attribute('href')).resolve().is_file()
            for label in runs:
                page.locator(f'input[data-run="{label}"]').check()
            tabs = page.locator('[role=tab][data-tab]').evaluate_all('xs=>xs.map(x=>x.dataset.tab)')
            assert set(tabs) == {'stocks', 'mrp', 'flows', 'production', 'gaps', 'gaillac'}
            for tab in tabs:
                page.locator(f'[data-tab="{tab}"]').click()
                assert page.locator('#sourceComparisonPanel').inner_text().strip()
            page.locator('[data-tab="stocks"]').click()
            for key, pair in data['pairs'].items():
                if not all(pair.get('simulations', {}).get(label, {}).get('metrics', {}).get('previous_day_physical') for label in runs):
                    continue
                page.locator('#sourceComparisonPair').select_option(key)
                page.locator('#sourceComparisonBasis').select_option('physical')
                page.locator('#sourceComparisonReset').click()
                count = 0
                for label in runs:
                    embedded = {row[0]: row[5] for row in pair['simulations'][label]['stock']}
                    expected = []
                    for day, observed, *_ in pair['observed']:
                        raw = stocks[label].get((key, day - 1))
                        if day <= 0 or raw is None:
                            continue
                        assert isinstance(embedded.get(day - 1), (int, float))
                        assert abs(embedded[day - 1] - raw) <= max(1e-6, abs(raw) * 1e-10)
                        payload_checks += 1
                        expected.append((day, observed, raw))
                    actual = root.evaluate('(el,key)=>SOURCE_COMPARISON_VIEW.getComparisonRows(key)', label)
                    assert len(actual) == len(expected) > 0, (key, label, len(actual), len(expected))
                    for row, (day, observed, raw) in zip(actual, expected):
                        assert row['day'] == day
                        assert abs(row['observed'] - observed) <= max(1e-6, abs(observed) * 1e-10)
                        assert abs(row['simulated'] - raw) <= max(1e-6, abs(raw) * 1e-10)
                        count += 1
                counts.append({'pair': key, 'rows': count})
                overview = page.locator(f'#commonRulesOverview tr:has(button[data-open-pair="{key}"])')
                assert overview.count() == 1
                cells = overview.locator('td').all_text_contents()
                assert cells[0] == pair['unit']
                assert overview.get_attribute('data-common-rule-scope') == ('applied' if key in scope else 'other')
                for label, cell in zip(runs, cells[1:3]):
                    raw = [(day, abs(stocks[label][key, day - 1] - observed))
                           for day, observed, *_ in pair['observed']
                           if 0 < day < 365 and (key, day - 1) in stocks[label]]
                    for minimum_day, printed in zip((1, 273), cell.split('/')):
                        selected = [error for day, error in raw if day >= minimum_day]
                        assert selected
                        value = float(printed.strip().replace(' ', '').replace('\u202f', '').replace(',', '.'))
                        assert abs(value - sum(selected) / len(selected)) <= .050001
                        overview_checks += 1
                diagnostic = data.get('demand_scope_2025', {}).get(key)
                ratio = diagnostic.get('physical_to_source_ratio') if diagnostic else None
                if ratio is None:
                    assert cells[3] == '—'
                else:
                    assert diagnostic['source_I_covered_qty'] > 0
                    manual = diagnostic['total_physical_consumed_covered_qty'] / diagnostic['source_I_covered_qty']
                    assert abs(ratio - manual) <= 1e-12
                    printed = float(cells[3].replace('%', '').replace(' ', '').replace(',', '.'))
                    assert abs(printed - 100 * manual) <= .050001
                    title = overview.locator('td').nth(3).get_attribute('title')
                    assert str(diagnostic['source_covered_days']) + ' jours comparés' in title
            page.locator('#commonRulesOverview table button[data-open-pair="055703/1810"]').click()
            assert root.evaluate('()=>SOURCE_COMPARISON_VIEW.getState().pair') == '055703/1810'
            page.locator('#sourceComparisonPair').select_option('708073/1430')
            page.locator('#sourceComparisonReset').click()
            page.locator('#chart-stocks').screenshot(path=str(output / '708073_stocks.png'))
            page.locator('#sourceComparisonStart').fill('2025-10-01')
            page.locator('#sourceComparisonStart').dispatch_event('change')
            for label in runs:
                values = root.evaluate('(el,key)=>SOURCE_COMPARISON_VIEW.getComparisonRows(key)', label)
                assert len(values) == 13 and all(273 <= row['day'] <= 364 for row in values)
            page.locator(f'input[data-run="{candidate}"]').uncheck()
            assert candidate not in root.evaluate('()=>SOURCE_COMPARISON_VIEW.getState().runs')
            page.locator(f'input[data-run="{candidate}"]').check()
            state = root.evaluate('()=>SOURCE_COMPARISON_VIEW.getState()')
            page.locator('#sourceComparisonZoomIn').click()
            zoomed = root.evaluate('()=>SOURCE_COMPARISON_VIEW.getState()')
            assert zoomed['end'] - zoomed['start'] < state['end'] - state['start']
            page.locator('#sourceComparisonReset').click()
            page.locator('[data-tab="mrp"]').click()
            details = page.locator('#sourceComparisonPlanningDetails')
            details.locator('summary').click()
            assert details.locator('[data-field="anticipated_fixed_floor_qty"]').count() >= 1
            assert details.locator('[data-field="purchase_grouping_days"]').count() >= 1
            assert 'stock fixe' in details.inner_text().lower()
            page.locator('#sourceComparisonRoot').screenshot(path=str(output / '708073_mrp.png'))
            page.locator('[data-tab="stocks"]').click()
            page.locator('#sourceComparisonPair').select_option('730384/1430')
            page.locator('#chart-stocks').screenshot(path=str(output / '730384_stocks.png'))
            page.locator('#sourceComparisonPair').select_option('001848/1810')
            page.locator('#chart-stocks').screenshot(path=str(output / '001848_stocks.png'))
            assert not errors, errors
        finally:
            browser.close()
    assert {str(path.resolve()): digest(path) for path in paths} == before
    report = {'status': 'passed', 'offline': True, 'html': str(args.html.resolve()),
              'inputs_sha256': before, 'csv_payload_stock_checks': payload_checks,
              'csv_payload_daily_stock_checks': daily_checks, 'common_rule_trace_checks': rule_trace_checks,
              'csv_payload_new_decision_fields_checks': decision_payload_checks,
              'common_rule_scope_pairs': sorted(observed_scope),
              'displayed_stock_rows': sum(row['rows'] for row in counts), 'pairs': counts,
              'overview_metric_checks': overview_checks, 'overview_click': True,
              'tabs': tabs, 'q4_filter': True, 'scenario_toggle': True, 'zoom': True,
              'javascript_errors': errors,
              'limits': 'All 365 daily physical stock values and matched source-photo rows reconciled to CSV. Common rules checked for 22 pairs over 1825 days; tabs and selected controls exercised. Not an exhaustive visual or industrial validation.'}
    (output / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'status': 'passed', 'report': str(output / 'report.json'), 'stock_rows': report['displayed_stock_rows']}))


if __name__ == '__main__':
    main()
