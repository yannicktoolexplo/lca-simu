"""Independent sourcing oracles, entirely in memory.

Roles are supplied explicitly; these cases do not infer supplier roles from
price, nor certify the unidentified real purchasing policy.
"""
from copy import deepcopy
from dataclasses import replace
from datetime import date, timedelta

import pytest

from etudecas.simulation.engine.mrp_planning import (
    FirmReceipt, LotSizing, Requirement, StockProtection, SupplierOffer, plan_dated_requirements,
    plan_sourced_requirements,
)
from etudecas.simulation.engine.run_first_simulation import (
    resolve_sourcing_policies, supplier_receipt_available_day, provisional_purchase_weekly_fields,
    resolve_purchase_planning_lots,
    plan_component_network,
)


def test_common_additive_network_keeps_same_safety_rule_with_and_without_sourcing():
    """F=2000 is not free stock for two 1500 needs protected at day8."""
    one, two = ('plant', 'single'), ('plant', 'multiple')
    primary, backup = offers(primary_lead=10, backup_lead=5)
    plans, needs, audits = plan_component_network(
        decision_day=0, requirements_by_pair={p: [Requirement('a', 10, 1500), Requirement('b', 10, 1500)] for p in (one, two)},
        available_by_pair={one: 2000, two: 2000}, firm_receipts_by_pair={},
        transport_sources_by_pair={}, bom_by_pair={}, lead_days_by_pair={one: 5, two: 10},
        lot_sizing_by_pair={one: LotSizing(minimum=5000, multiple=5000)},
        reserve_targets_by_pair={}, coverage_days_by_pair={}, active_campaigns_by_pair={},
        sourcing_by_pair={two: dict(primary=primary, backups=(backup,))},
        grouping_days_by_pair={one: 1, two: 1},
        anticipated_need_by_pair={p: dict(source_working_days=2, origin_weekday=0,
            fixed_floor_qty=2000, fixed_floor_mode='additive') for p in (one, two)},
    )
    assert plans[one].proposed_qty == 5000
    assert plans[two].proposed_qty == 4000
    assert audits[two]['sourced_plan'].backup_proposed_qty == 4000
    for pair in (one, two):
        assert sum(r.qty for r in needs[pair]) == 3000  # no physical safety consumption
        assert plans[pair].closing_projected_qty >= 2000
        assert sum(r.qty for r in audits[pair]['anticipated_requirements']) == 5000
        assert all(p.requested_day == 8 for p in plans[pair].proposals)


def test_common_production_target_floor_projects_BOM_before_finished_stock_is_empty():
    """10UN stock -8 demand <6 target =>5UN lot, requiring10KG at launch."""
    fg, rm = ('plant', 'finished'), ('plant', 'raw')
    plans, needs, audits = plan_component_network(
        decision_day=0, requirements_by_pair={fg: [Requirement('sale', 20, 8)]},
        available_by_pair={fg: 10, rm: 0}, firm_receipts_by_pair={},
        transport_sources_by_pair={}, bom_by_pair={fg: [(rm, 2)]},
        lead_days_by_pair={fg: 2, rm: 5},
        lot_sizing_by_pair={fg: LotSizing(minimum=5, multiple=5, integer=True)},
        reserve_targets_by_pair={fg: 6}, coverage_days_by_pair={fg: 30}, active_campaigns_by_pair={},
        protection_by_pair={fg: [StockProtection('controller_target', 1, 6)]},
        production_floor_pairs={fg},
        anticipated_need_by_pair={rm: dict(source_working_days=0, origin_weekday=0,
            fixed_floor_qty=0, fixed_floor_mode='additive')},
    )
    assert [(p.release_day, p.qty) for p in plans[fg].proposals] == [(18, 5)]
    assert [(r.due_day, r.qty) for r in needs[rm]] == [(18, 10)]
    assert [(p.release_day, p.qty) for p in plans[rm].proposals] == [(13, 10)]
    assert plans[fg].closing_projected_qty == 7


def offers(*, primary_lead=75, backup_lead=40, primary_lot=6000, backup_lot=4000):
    return (
        SupplierOffer('VD0951020A', 1.58, 'EUR', 'KG', primary_lead,
            LotSizing(minimum=primary_lot, multiple=primary_lot)),
        SupplierOffer('VD0519670A', 4.20, 'EUR', 'KG', backup_lead,
            LotSizing(minimum=backup_lot, multiple=backup_lot)),
    )


def sourcing(requirements, *, stock=0, firms=(), day=0, options=None, protected=()):
    primary, backup = options or offers()
    return plan_sourced_requirements(decision_day=day, available_qty=stock,
        requirements=requirements, firm_receipts=firms, primary=primary, backups=(backup,),
        protected_backup_receipt_ids=protected)


def quantities(plan, role):
    return sum(p.proposal.qty for p in plan.proposals if p.role == role)


def source_calendar(delivery_days, through_day):
    result = []
    for release in range(through_day + 1):
        cursor = date(2025, 1, 1) + timedelta(days=release + delivery_days)
        remaining = 13
        while remaining:
            cursor += timedelta(days=1)
            if cursor.weekday() < 5:
                remaining -= 1
        result.append((release, (cursor - date(2025, 1, 1)).days))
    return tuple(result)


def assert_manual_conservation(result, stock, firms, requirements):
    total_in = stock + sum(r.qty for r in firms) + sum(p.proposal.qty for p in result.proposals)
    assert result.plan.closing_projected_qty == pytest.approx(total_in - sum(r.qty for r in requirements))
    assert sum(a.qty for a in result.plan.allocations) == pytest.approx(sum(r.qty for r in requirements))
    assert result.plan.proposed_qty == pytest.approx(sum(p.proposal.qty for p in result.proposals))


@pytest.mark.parametrize('physical_day, expected_date, expected_day', [
    (56, date(2025, 3, 17), 75),
    (21, date(2025, 2, 10), 40),
])
def test_sourcing_source_delivery_plus_receipt_calendar(physical_day, expected_date, expected_day):
    # Independent weekday loop: no holiday exclusions are claimed by this candidate.
    cursor, remaining = date(2025, 1, 1) + timedelta(days=physical_day), 13
    while remaining:
        cursor += timedelta(days=1)
        if cursor.weekday() < 5:
            remaining -= 1
    assert cursor == expected_date
    assert (cursor - date(2025, 1, 1)).days == expected_day
    assert supplier_receipt_available_day(physical_day, 13, origin_date='2025-01-01') == expected_day


def test_sourcing_primary_covers_a_timely_physical_requirement_without_backup():
    requirements = [Requirement('physical', 90, 3000)]
    result = sourcing(requirements)
    assert quantities(result, 'primary') == 6000
    assert quantities(result, 'backup') == 0
    assert result.primary_available_day == 75
    assert result.physical_shortage_before_primary_qty == 0
    assert [(p.proposal.release_day, p.proposal.available_day) for p in result.proposals] == [(15, 90)]
    assert_manual_conservation(result, 0, (), requirements)


def test_sourcing_stock_already_covers_early_consumption_without_any_purchase():
    requirements = [Requirement('physical', 20, 1000)]
    result = sourcing(requirements, stock=1000)
    assert result.proposals == ()
    assert result.backup_proposed_qty == 0
    assert_manual_conservation(result, 1000, (), requirements)


def test_sourcing_backup_lot_surplus_covers_later_requirement_before_primary_recalculation():
    requirements = [Requirement('physical-early', 50, 3000), Requirement('physical-later', 100, 1000)]
    result = sourcing(requirements)
    assert quantities(result, 'backup') == 4000
    assert quantities(result, 'primary') == 0
    assert result.backup_proposed_qty == 4000
    assert all(p.proposal.available_day <= 50 for p in result.proposals)
    assert result.plan.late_qty == 0
    assert_manual_conservation(result, 0, (), requirements)


def test_sourcing_reserve_alone_never_triggers_backup():
    requirements = [Requirement('reserve:M-1810:item:001848', 20, 3000)]
    result = sourcing(requirements)
    assert quantities(result, 'backup') == 0
    assert quantities(result, 'primary') == 6000
    assert result.physical_shortage_before_primary_qty == 0
    assert_manual_conservation(result, 0, (), requirements)


def test_sourcing_backup_for_physical_consumption_is_not_absorbed_by_earlier_reserve():
    requirements = [Requirement('reserve:technical-protection', 1, 3000), Requirement('physical', 50, 3000)]
    result = sourcing(requirements)
    physical = [a for a in result.plan.allocations if a.requirement_id == 'physical']
    assert sum(a.qty for a in physical) == 3000
    assert all(a.available_day <= 50 and a.delay_days == 0 for a in physical)
    backup_ids = {p.proposal.proposal_id for p in result.proposals if p.role == 'backup'}
    assert all(a.supply_id in backup_ids for a in physical)
    assert quantities(result, 'backup') == 4000
    assert quantities(result, 'primary') == 6000
    assert_manual_conservation(result, 0, (), requirements)


def test_sourcing_sufficient_existing_commitment_prevents_backup():
    requirements = [Requirement('physical', 50, 3000)]
    firms = [FirmReceipt('already-placed', 45, 6000)]
    result = sourcing(requirements, firms=firms)
    assert result.proposals == ()
    assert result.retained_firm_qty == 6000
    assert {(a.supply_id, a.available_day) for a in result.plan.allocations} == {('already-placed', 45)}
    assert_manual_conservation(result, 0, firms, requirements)


def test_sourcing_backup_that_arrives_after_an_existing_firm_does_not_improve_shortage():
    options = offers(primary_lead=75, backup_lead=40, primary_lot=1, backup_lot=1)
    requirements = [Requirement('physical', 20, 100)]
    firms = [FirmReceipt('already-placed', 30, 100)]
    result = sourcing(requirements, firms=firms, options=options)
    assert result.proposals == ()
    assert result.backup_proposed_qty == 0
    assert result.plan.late_qty == 100
    assert result.plan.late_qty_days == 1000
    assert_manual_conservation(result, 0, firms, requirements)


def test_sourcing_backup_bridge_keeps_late_firm_and_exposes_surplus():
    options = offers(primary_lead=75, backup_lead=40, primary_lot=1, backup_lot=1)
    requirements = [Requirement('physical', 20, 100)]
    firms = [FirmReceipt('already-placed', 70, 100)]
    saved = deepcopy((requirements, firms))
    result = sourcing(requirements, firms=firms, options=options)
    assert quantities(result, 'backup') == 100
    assert quantities(result, 'primary') == 0
    assert result.retained_firm_qty == 100
    assert result.bridge_surplus_qty == 100
    assert result.plan.closing_projected_qty == 100
    assert result.plan.late_qty_days == 2000
    assert (requirements, firms) == saved
    assert_manual_conservation(result, 0, firms, requirements)


def test_sourcing_next_review_keeps_committed_backup_without_buying_it_again():
    options = offers(primary_lead=75, backup_lead=40, primary_lot=1, backup_lot=1)
    requirements = [Requirement('physical', 20, 100)]
    firms = [FirmReceipt('late-primary', 70, 100), FirmReceipt('committed-backup', 40, 100)]
    result = sourcing(requirements, firms=firms, options=options, day=1)
    assert result.proposals == ()
    assert result.retained_firm_qty == 200
    assert result.plan.closing_projected_qty == 100
    assert_manual_conservation(result, 0, firms, requirements)


def test_sourcing_delayed_committed_backup_is_not_bought_again_at_nominal_lead():
    options = offers(primary_lead=75, backup_lead=40, primary_lot=1, backup_lot=1)
    requirements = [Requirement('physical', 20, 100)]
    firms = [FirmReceipt('late-primary', 100, 100), FirmReceipt('committed-backup', 80, 100)]
    result = sourcing(requirements, firms=firms, options=options, day=1, protected=('committed-backup',))
    assert result.proposals == ()
    assert result.retained_firm_qty == 200
    assert result.plan.closing_projected_qty == 100
    assert result.plan.late_qty_days == 6000
    assert_manual_conservation(result, 0, firms, requirements)


def test_sourcing_unknown_protected_commitment_is_not_silently_invented():
    with pytest.raises(ValueError):
        sourcing([Requirement('physical', 20, 100)], protected=('missing-order',))


def test_sourcing_backup_not_faster_than_primary_is_not_selected():
    result = sourcing([Requirement('physical', 20, 100)], options=offers(primary_lead=30, backup_lead=40))
    assert quantities(result, 'backup') == 0
    assert quantities(result, 'primary') == 6000


def test_sourcing_cost_rank_conflicting_with_named_policy_is_rejected_not_swapped():
    primary = SupplierOffer('explicit-primary', 5, 'EUR', 'KG', 75, LotSizing(multiple=6000))
    backup = SupplierOffer('explicit-backup', 1, 'EUR', 'KG', 40, LotSizing(multiple=4000))
    # The candidate policy explicitly names cheapest primary; conflicting
    # metadata must fail instead of inventing a new role for another supplier.
    with pytest.raises(ValueError):
        sourcing([Requirement('physical', 90, 3000)], options=(primary, backup))


def test_sourcing_offer_calendar_uses_provided_availability_without_adding_lead_twice():
    primary = SupplierOffer('primary', 1.58, 'EUR', 'KG', 56, LotSizing(multiple=6000), source_calendar(56, 40))
    backup = SupplierOffer('backup', 4.2, 'EUR', 'KG', 21, LotSizing(multiple=4000), source_calendar(21, 40))
    result = sourcing([Requirement('physical', 40, 3000)], options=(primary, backup))
    assert result.primary_available_day == 75
    assert [(p.proposal.release_day, p.proposal.available_day, p.proposal.qty) for p in result.proposals] == [(0, 40, 4000)]


def test_sourcing_receipt_calendar_accepts_weekend_plateau_without_moving_receipts():
    dates = source_calendar(56, 78)
    assert dates[2:5] == ((2, 77), (3, 77), (4, 77))
    primary = SupplierOffer('primary', 1.58, 'EUR', 'KG', 56, LotSizing(multiple=6000), dates)
    backup = SupplierOffer('backup', 4.2, 'EUR', 'KG', 21, LotSizing(multiple=4000), source_calendar(21, 78))
    result = sourcing([Requirement('physical', 78, 3000)], options=(primary, backup))
    assert quantities(result, 'backup') == 0
    assert [(p.proposal.release_day, p.proposal.available_day) for p in result.proposals] == [(5, 78)]


def test_sourcing_incomplete_explicit_calendar_does_not_impute_missing_release_dates():
    primary = SupplierOffer('primary', 1.58, 'EUR', 'KG', 56, LotSizing(multiple=6000), ((0, 75), (1, 76)))
    backup = SupplierOffer('backup', 4.2, 'EUR', 'KG', 21, LotSizing(multiple=4000), ((0, 40), (1, 41)))
    with pytest.raises(ValueError):
        sourcing([Requirement('physical', 40, 3000)], options=(primary, backup))


def test_sourcing_legacy_pure_planner_still_nets_late_commitments_without_bridge():
    # This protects the previous pure API. Runtime absence-policy scope is
    # additionally verified by independent graph and complete witness CSV checks.
    result = plan_dated_requirements(decision_day=0, available_qty=0,
        requirements=[Requirement('physical', 20, 100)],
        firm_receipts=[FirmReceipt('existing', 70, 100)], lead_days=75)
    assert result.proposals == ()
    assert result.late_qty_days == 5000


def source_policy_inputs():
    pair = ('M-1810', 'item:001848')
    primary, backup = 'SDC-VD0951020A', 'SDC-VD0519670A'
    payload = {'schema_version': 1, 'rows': [{'policy_id': 'confirmed-001848',
        'node_id': pair[0], 'item_id': pair[1], 'uom': 'KG', 'currency': 'EUR',
        'policy': 'cheapest_purchase_primary_with_dated_backup', 'confirmation': 'user_confirmed_roles_only',
        'backup_trigger': 'physical_shortage_before_primary', 'bridge_surplus_policy': 'retain_firm_and_disclose_surplus',
        'primary_supplier_id': primary, 'backup_supplier_ids': [backup], 'offers': [
            {'supplier_id': primary, 'purchase_unit_cost': 1.58, 'price_uom': 'KG', 'currency': 'EUR',
                'source_file': '268091.xlsx', 'source_cells': 'FIA!C4:H4'},
            {'supplier_id': backup, 'purchase_unit_cost': 4.2, 'price_uom': 'KG', 'currency': 'EUR',
                'source_file': '268091.xlsx', 'source_cells': 'FIA!C3:H3'},
        ]}]}
    lanes = {pair: [{'src': primary, 'unit_purchase_cost': 1.58}, {'src': backup, 'unit_purchase_cost': 4.2}]}
    return payload, lanes, {pair[1]: 'KG'}


@pytest.mark.parametrize('mode', ['historical', 'dated'])
def test_sourcing_absent_policy_does_not_enable_any_new_supplier_logic(mode):
    _, lanes, units = source_policy_inputs()
    assert resolve_sourcing_policies(None, execution_mode=mode, lanes_by_dest_item=lanes, item_unit_map=units) == {}


def test_sourcing_resolver_enables_only_the_explicit_confirmed_pair_without_mutation():
    payload, lanes, units = source_policy_inputs()
    saved = deepcopy((payload, lanes, units))
    result = resolve_sourcing_policies(payload, execution_mode='dated', lanes_by_dest_item=lanes, item_unit_map=units)
    assert set(result) == {('M-1810', 'item:001848')}
    assert (payload, lanes, units) == saved


@pytest.mark.parametrize('item', ['item:001893', 'item:021081'])
def test_sourcing_resolver_refuses_generalization_of_roles_to_other_materials(item):
    payload, lanes, units = source_policy_inputs()
    payload['rows'][0]['item_id'] = item
    with pytest.raises(ValueError):
        resolve_sourcing_policies(payload, execution_mode='dated', lanes_by_dest_item=lanes, item_unit_map=units)


@pytest.mark.parametrize('bad', [None, float('nan'), float('inf'), -1, True])
def test_sourcing_rejects_unknown_or_invalid_purchase_cost(bad):
    primary, backup = offers()
    with pytest.raises(ValueError):
        invalid = SupplierOffer('invalid', bad, 'EUR', 'KG', 75)
        sourcing([Requirement('physical', 90, 100)], options=(invalid, backup))


@pytest.mark.parametrize('currency,uom', [('USD', 'KG'), ('EUR', 'G')])
def test_sourcing_rejects_unconverted_currency_or_quantity_units(currency, uom):
    primary, _ = offers()
    with pytest.raises(ValueError):
        backup = SupplierOffer('backup', 4.2, currency, uom, 40)
        sourcing([Requirement('physical', 20, 100)], options=(primary, backup))


def provisional_sourcing(requirements, *, day=0, stock=0, firms=(), options=None, backups=True):
    primary, backup = options or offers()
    return plan_sourced_requirements(decision_day=day, available_qty=stock,
        requirements=requirements, firm_receipts=firms, primary=primary,
        backups=(backup,) if backups else (), provisional_lots_until_release=True)


def test_provisional_lot_future_4000_becomes_primary_6000_only_at_release():
    needs = [Requirement('need', 90, 3000)]
    future = provisional_sourcing(needs)
    assert [(r.proposal.qty, r.proposal.release_day, r.proposal.available_day,
             r.supplier_id, r.role) for r in future.proposals] == [(4000, 15, 90, '', 'provisional')]
    assert future.proposals[0].planning_supplier_id == 'VD0951020A'
    due = provisional_sourcing(needs, day=15)
    assert [(r.proposal.qty, r.proposal.release_day, r.supplier_id, r.role)
            for r in due.proposals] == [(6000, 15, 'VD0951020A', 'primary')]
    assert_manual_conservation(future, 0, (), needs)
    assert_manual_conservation(due, 0, (), needs)


def test_provisional_lot_backup_4000_when_primary_is_too_late():
    needs = [Requirement('need', 50, 3000)]
    due = provisional_sourcing(needs, day=10)
    assert [(r.proposal.qty, r.proposal.available_day, r.role) for r in due.proposals] == [(4000, 50, 'backup')]
    assert due.plan.late_qty == 0
    assert_manual_conservation(due, 0, (), needs)


def test_provisional_lot_primary_surplus_nets_next_need_and_committed_order_once():
    needs = [Requirement('first', 90, 3000), Requirement('second', 91, 2500)]
    due = provisional_sourcing(needs, day=15)
    assert [r.proposal.qty for r in due.proposals] == [6000]
    assert due.plan.closing_projected_qty == 500
    firm = [FirmReceipt('executed-primary', 90, 6000)]
    later = provisional_sourcing(needs, day=16, firms=firm)
    assert later.proposals == () and later.plan.closing_projected_qty == 500
    assert_manual_conservation(due, 0, (), needs)
    assert_manual_conservation(later, 0, firm, needs)
    assert provisional_sourcing(needs, day=16, stock=6000).proposals == ()


def test_provisional_lot_monosource_and_disabled_modes_are_identical():
    needs = [Requirement('need', 90, 5000)]
    primary, backup = offers()
    kwargs = dict(decision_day=0, available_qty=0, requirements=needs,
                  firm_receipts=(), primary=primary)
    assert plan_sourced_requirements(**kwargs, backups=()) == provisional_sourcing(needs, backups=False)
    assert plan_sourced_requirements(**kwargs, backups=(backup,)) == plan_sourced_requirements(
        **kwargs, backups=(backup,), provisional_lots_until_release=False)


def test_provisional_lot_physical_units_integer_with_fractional_forecast():
    primary, backup = offers(primary_lead=10, backup_lead=5, primary_lot=6, backup_lot=4)
    primary = replace(primary, uom='UN', lot_sizing=LotSizing(minimum=6, multiple=6, integer=True))
    backup = replace(backup, uom='UN', lot_sizing=LotSizing(minimum=4, multiple=4, integer=True))
    needs = [Requirement('forecast', 20, 3.1)]
    future = provisional_sourcing(needs, options=(primary, backup))
    due = provisional_sourcing(needs, day=10, options=(primary, backup))
    assert [r.proposal.qty for r in future.proposals] == [4]
    assert [r.proposal.qty for r in due.proposals] == [6]
    assert due.plan.closing_projected_qty == pytest.approx(2.9)
    assert_manual_conservation(due, 0, (), needs)


def test_provisional_lot_preserves_nonbinding_supplier_standard():
    primary, backup = offers()
    primary = replace(primary, lot_sizing=LotSizing(), standard_order_qty=6000)
    backup = replace(backup, lot_sizing=LotSizing(), standard_order_qty=4000)
    needs = [Requirement('need', 90, 3000)]
    future = provisional_sourcing(needs, options=(primary, backup))
    due = provisional_sourcing(needs, day=15, options=(primary, backup))
    assert [r.proposal.qty for r in future.proposals] == [4000]
    assert [r.proposal.qty for r in due.proposals] == [3000]
    assert due.plan.closing_projected_qty == 0


def test_provisional_lot_weekly_dates_are_nominal_reference_not_confirmation():
    needs = [Requirement('need', 90, 3000)]
    row = provisional_sourcing(needs).proposals[0]
    fields = provisional_purchase_weekly_fields(row, policy='candidate',
                                               delivery_days_by_supplier={'VD0951020A': 56})
    assert fields['supplier_id'] == ''
    assert fields['planning_supplier_id'] == 'VD0951020A'
    assert fields['physical_receipt_day'] == 71 and fields['available_day'] == 90
    assert fields['receipt_date_basis'] == 'nominal_supplier_reference_not_confirmation'
    assert fields['proposal_stage'] == 'provisional_unreleased'
    assert provisional_purchase_weekly_fields(None, policy='candidate', delivery_days_by_supplier={}) == {}


def aligned_purchase_lot(*, standard=300, dispatch=0, binding=True, uom='KG', lanes=None,
                         selected=None, protected=False, enabled=True):
    pair = ('plant', 'component')
    return resolve_purchase_planning_lots(
        'execution_standard_for_unambiguous_offer_v1' if enabled else None,
        purchase_pairs={pair}, lanes_by_dest_item={pair: lanes if lanes is not None else [
            {'src': 'supplier', 'standard_order_qty': standard, 'physical_dispatch_multiple': dispatch}]},
        selected_suppliers={pair: selected} if selected else {}, protected_pairs={pair} if protected else set(),
        nonbinding_pairs=set() if binding else {pair}, item_unit_map={pair[1]: uom})


@pytest.mark.parametrize('need,standard,expected', [(305, 300, 600), (4001, 4000, 8000)])
def test_purchase_lot_alignment_rounds_like_nominal_execution(need, standard, expected):
    policies, audit = aligned_purchase_lot(standard=standard)
    plan = plan_dated_requirements(decision_day=0, available_qty=0,
        requirements=[Requirement('need', 100, need)], firm_receipts=(), lead_days=20,
        lot_sizing=policies['plant', 'component'])
    assert [p.qty for p in plan.proposals] == [expected]
    assert plan.closing_projected_qty == expected - need
    assert audit[0]['status'] == 'aligned_nominal_execution'


def test_purchase_lot_alignment_uses_rounded_surplus_once():
    policies, _ = aligned_purchase_lot()
    needs = [Requirement('first', 100, 305), Requirement('second', 101, 295)]
    plan = plan_dated_requirements(decision_day=0, available_qty=0,
        requirements=needs, firm_receipts=(), lead_days=20, lot_sizing=policies['plant', 'component'])
    assert len(plan.proposals) == 1 and plan.proposed_qty == 600 and plan.closing_projected_qty == 0
    assert sum(a.qty for a in plan.allocations) == 600


def test_purchase_lot_alignment_nonbinding_identity_and_dispatch_only():
    policies, audit = aligned_purchase_lot(binding=False)
    assert policies['plant', 'component'] == LotSizing()
    assert audit[0]['standard_binding'] is False
    policies, _ = aligned_purchase_lot(binding=False, dispatch=20)
    assert policies['plant', 'component'] == LotSizing(multiple=20)


def test_purchase_lot_alignment_physical_un_is_integer_and_rejects_fractional_lot():
    policies, _ = aligned_purchase_lot(standard=6, uom='UN')
    plan = plan_dated_requirements(decision_day=0, available_qty=0,
        requirements=[Requirement('fractional_forecast', 100, 3.1)], firm_receipts=(), lead_days=20,
        lot_sizing=policies['plant', 'component'])
    assert plan.proposed_qty == 6
    with pytest.raises(ValueError, match='must be integer'):
        aligned_purchase_lot(standard=1.5, uom='UN')


def test_purchase_lot_alignment_selected_offer_only_without_price_inference():
    lanes = [{'src': 'cheap', 'standard_order_qty': 300}, {'src': 'selected', 'standard_order_qty': 500}]
    saved = deepcopy(lanes)
    policies, audit = aligned_purchase_lot(lanes=lanes, selected='selected')
    assert policies['plant', 'component'] == LotSizing(minimum=500, multiple=500)
    assert audit[0]['supplier_id'] == 'selected' and lanes == saved


def test_purchase_lot_alignment_ambiguous_offers_and_specific_policies_preserved():
    lanes = [{'src': 'one', 'standard_order_qty': 300}, {'src': 'two', 'standard_order_qty': 500}]
    policies, audit = aligned_purchase_lot(lanes=lanes)
    assert policies == {} and audit[0]['status'] == 'unchanged_ambiguous_offers'
    policies, audit = aligned_purchase_lot(protected=True)
    assert policies == {} and audit[0]['status'] == 'preserved_specific_policy'


def test_purchase_lot_alignment_disabled_does_not_change_existing_plan():
    policies, audit = aligned_purchase_lot(enabled=False)
    assert policies == {} and audit == []
    existing = LotSizing(integer=True)
    assert policies.get(('plant', 'component'), existing) is existing


def test_purchase_lot_alignment_refuses_incompatible_dispatch_rounding():
    with pytest.raises(ValueError, match='incompatible with the physical dispatch multiple'):
        aligned_purchase_lot(standard=300, dispatch=200)
    policies, _ = aligned_purchase_lot(standard=300, dispatch=100)
    assert policies['plant', 'component'] == LotSizing(minimum=300, multiple=300)
