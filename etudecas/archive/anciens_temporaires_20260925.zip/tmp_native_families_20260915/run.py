import json
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root.parent
graph = json.loads((repo/'tmp_native_sensitivity_20260911/graph.json').read_text())
scenario = graph['scenarios'][0]
scenario['initialization_policy'] = {'mode': 'explicit_state'}
scenario['economic_policy']['external_procurement_enabled'] = False
for node in graph['nodes']:
    if node['type'] != 'supplier_dc':
        for state in node.get('inventory', {}).get('states', []):
            state['initial'] = 0
graph['meta']['description'] = 'Synthetic two-supplier native sensitivity verification; no opening downstream stock, no external procurement. Not calibrated.'
(root/'graph.json').write_text(json.dumps(graph, indent=2))
(root/'options.json').write_bytes((repo/'tmp_native_sensitivity_20260911/options.json').read_bytes())
cmd = [sys.executable, 'etudecas/simulation/sensibility/run_supplier_parameter_sensitivity.py',
    '--input', str(root/'graph.json'), '--scenario-id', 'scenario:reference', '--days', '5',
    '--simulation-options-json', str(root/'options.json'), '--baseline-result-dir', str(root/'no_ranking'),
    '--output-dir', str(root/'native_final'), '--top-suppliers', '0',
    '--groups', 'stock,capacity,lead_time,reliability', '--stock-levels', '.5,1',
    '--capacity-levels', '.1,1', '--lead-time-levels', '1,3', '--reliability-levels', '.5,1',
    '--artifact-mode', 'full']
(root/'command.json').write_text(json.dumps(cmd,indent=2))
subprocess.run(cmd, cwd=repo, check=True)
subprocess.run([sys.executable, '-m', 'etudecas.visualization.maps.build_supplychain_worldmap',
    '--isolated-run', '--run-package', str(root/'native_final/cases/baseline/simulation_output/run'),
    '--native-sensitivity-dir', str(root/'native_final'), '--output', str(root/'map_final/map.html'),
    '--title', 'Sensibilite native : stocks, capacites, delais, fiabilite - exemple synthetique',
    '--compress-embedded-payload'], cwd=repo, check=True)
