import csv
import json
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root.parent/'tmp_functional_recovery_20260910'))
from inventory import payload

def csv_rows(path):
    with path.open(encoding='utf8', newline='') as f:
        return list(csv.DictReader(f))

native = root/'native_final'
cases = csv_rows(native/'supplier_parameter_sensitivity_cases.csv')
assert len(cases) == 25 and all(r['status'] == 'ok' for r in cases)
base = next(r for r in cases if r['case_id'] == 'baseline')
nominal = {r['supplier_id']: r for r in csv_rows(Path(base['case_output_dir'])/'data/supplier_nominal_parameters.csv')}
checks=[]
for row in cases:
    case = Path(row['case_output_dir'])
    assert json.loads((case/'inputs/case_config.json').read_text()) == {}
    level = float(row['level'])
    if level == 1:
        assert {k:v for k,v in row.items() if k.startswith(('kpi::', 'guard::'))} == {
            k:v for k,v in base.items() if k.startswith(('kpi::', 'guard::'))}, row['case_id']
    key = row['parameter_key']
    effective = {r['supplier_id']:r for r in csv_rows(case/'data/supplier_nominal_parameters.csv')}
    for family, field in [('capacity','effective_capacity_qty_per_day'), ('lead_time','planned_lead_time_days'),
                          ('reliability','nominal_reliability_otif')]:
        if not key.startswith('supplier_'+family):
            continue
        target = key.split('::',1)[1] if '::' in key else None
        for supplier in nominal:
            factor = level if target is None or supplier == target else 1
            expected = float(nominal[supplier][field])*factor
            actual = float(effective[supplier][field])
            assert abs(actual-expected) < 1e-6, (key,supplier,field,actual,expected)
        checks.append(dict(parameter=key, level=level, effective_values_verified=True))

before = payload((root/'map_final/map.html').read_text(encoding='utf8'))
after = payload((root/'map_complete/map.html').read_text(encoding='utf8'))
assert before['supplier_parameter_sensitivity_nodes'] == after['supplier_parameter_sensitivity_nodes']
for key in ['factory_sensitivity_hover_images','supplier_sensitivity_hover_images','distribution_center_sensitivity_hover_images']:
    for node, panel in before[key].items():
        current=after[key][node]
        for part, value in panel.items():
            if part!='outgoing':
                assert current[part]==value, (node,part)
        original=panel['outgoing'].get('bundle',[])
        if original:
            assert current['outgoing']['bundle'][:len(original)]==original

with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True)
    page=browser.new_page(viewport=dict(width=1700,height=1100))
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto((root/'map_complete/map.html').as_uri(),timeout=60000)
    page.wait_for_function("typeof DATA !== 'undefined' && document.getElementById('chart').data",timeout=60000)
    page.locator('#modeSensitivity').click()
    options=page.locator('#sensitivitySupplierSelect option').evaluate_all('(a)=>a.map(o=>o.value).filter(Boolean)')
    assert set(options)=={'supplier:mill_a','supplier:mill_b'}
    browser_checks=[]
    for node in options:
        page.locator('#sensitivitySupplierSelect').select_option(node)
        page.wait_for_function('id=>document.querySelector("#factoryHoverTitle").textContent.includes(id)',arg=node)
        plots=[]
        entries=after['supplier_sensitivity_hover_images'][node]['outgoing']['bundle']
        assert len(entries)==8
        for entry in entries:
            page.locator('#outgoingTabs').get_by_role('button',name=entry['label'],exact=True).click()
            page.wait_for_function("document.querySelector('#factoryOutgoingFigure .js-plotly-plot')?.data?.length > 0")
            plot=page.locator('#factoryOutgoingFigure .js-plotly-plot').first.evaluate('(p)=>({title:p.layout.title?.text,traces:p.data.map(t=>({x:Array.from(t.x||[]),y:Array.from(t.y||[])}))})')
            assert plot['title']==entry['asset']['figure']['title'], (entry['label'],plot)
            plots.append(plot)
        titles=' '.join(str(p['title']) for p in plots)
        for word in ['Stock', 'Capacite', 'Delai', 'Fiabilite']:
            assert word.lower() in titles.lower(), (node,word,titles)
        assert all(any(t['x'] and t['y'] for t in p['traces']) for p in plots)
        browser_checks.append(dict(supplier=node,plots=plots))
        page.locator('#factoryHoverClearSelection').click()
        assert page.locator('#sensitivitySupplierSelect').input_value()==''
    assert not errors,errors
    browser.close()
report=dict(status='passed',cases=25,parameters=12,unit_multiplier_checks=checks,
    baseline_levels_identical=True,historical_priority_curves_and_panels_preserved=True,
    browser=browser_checks,browser_errors=errors)
(root/'verification.json').write_text(json.dumps(report,indent=2))
print('Passed: 25 native cases, effective parameters, unchanged priority panels, four families in both supplier fiches')
