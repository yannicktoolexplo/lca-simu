import json
from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parent
with sync_playwright() as pw:
    browser = pw.chromium.launch(headless=True)
    page = browser.new_page(viewport=dict(width=1700, height=1100))
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.goto((root / 'map/map.html').as_uri(), timeout=60000)
    page.wait_for_function("typeof DATA !== 'undefined' && document.getElementById('chart').data", timeout=60000)
    values = page.evaluate("DATA.factory_hover_series['site:bracket_factory'].outgoing[0].values")
    assert values == [0, 10, 2, 0, 0]
    page.evaluate("""() => {
        const chart=document.getElementById('chart');
        for (let i=0;i<chart.data.length;i++) {
            const trace=chart.data[i];
            const j=(trace.customdata||[]).findIndex(v=>Array.isArray(v)&&v[0]==='site:bracket_factory');
            if (j>=0) {chart.emit('plotly_click',{points:[{customdata:trace.customdata[j],data:trace,curveNumber:i,pointNumber:j}]});return;}
        }
        throw new Error('Factory absent from map traces');
    }""")
    page.wait_for_function("document.querySelector('#factoryHoverTitle').textContent.includes('site:bracket_factory')")
    page.wait_for_function("document.querySelector('#factoryHoverPanel .js-plotly-plot')?.data?.length > 0")
    plots = page.locator('#factoryHoverPanel .js-plotly-plot').evaluate_all('(plots)=>plots.flatMap(p=>p.data.map(t=>({name:t.name,y:Array.from(t.y||[])})))')
    assert any(t['name'] == 'Lots produits au lancement' and t['y'] == [10, 2] for t in plots), plots
    page.screenshot(path=str(root/'production_corrected.png'))
    page.locator('#factoryHoverClearSelection').click()
    assert not errors, errors
    browser.close()
(root/'browser_checks.json').write_text(json.dumps(dict(status='passed', executed=values,
    total_executed=sum(values), factory_selection_and_curve=True, browser_errors=errors),indent=2))
print('Browser passed: 12 pieces in the existing production curve')
