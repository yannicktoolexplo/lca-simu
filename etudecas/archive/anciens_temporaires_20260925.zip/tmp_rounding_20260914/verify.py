import json
import csv
import sys
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parent))
from etudecas.experiment import execute_experiment
from etudecas.study_map import map_command

source = OUT.parent / 'tmp_nominal_reliability_20260911/example/reliability.json'
spec = json.loads(source.read_text())
spec['input_graph'] = str(source.parent / 'graph.json')
path = OUT / 'experiment.json'
path.write_text(json.dumps(spec, indent=2))
if not (OUT / 'experiment').exists():
    assert execute_experiment(path, OUT / 'experiment') == 0
comparisons = []
for name in ['reference', 'reliability_25', 'reliability_50', 'reliability_75']:
    old = source.parent / 'reliability/runs' / name
    new = OUT / 'experiment/runs' / name
    relative = 'simulation/inputs/simulation_input.json'
    assert json.loads((old / relative).read_text()) == json.loads((new / relative).read_text())
    def quantities(root):
        with (root / 'simulation/data/production_output_products_daily.csv').open() as f:
            return [float(r['executed_qty']) for r in csv.DictReader(f)]
    before, after = quantities(old), quantities(new)
    result = json.loads((new / 'simulation_result.json').read_text())
    for audit in ['component_balance', 'component_stock_balance', 'production_wip_balance']:
        assert result[audit]['status'] == 'passed', (name, audit, result[audit])
    comparisons.append(dict(case=name, before=before, after=after, same_input=True,
        component_balance='passed', component_stock_balance='passed', production_balance='passed'))
assert sum(comparisons[-1]['before']) == 11
assert sum(comparisons[-1]['after']) == 12
(OUT / 'comparison.json').write_text(json.dumps(comparisons, indent=2))
subprocess.run(map_command(OUT / 'experiment/runs/reliability_75', OUT / 'map',
    title='Correction arrondi : 2,4 kg permettent de fabriquer 12 pieces'), check=True)
print(json.dumps(comparisons))
