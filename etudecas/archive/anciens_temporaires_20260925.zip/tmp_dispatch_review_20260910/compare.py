"""Compare independent archived outputs and two matched current-engine runs."""
import csv, hashlib, html, json
from pathlib import Path

R=Path(__file__).resolve().parent
root=R.parent
def read(path):
    with path.open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))
archive=root/'etudecas/simulation/result/_reruns/active_ex344135_5y_20260717_114118/data'
control=R/'control_annual/data'
probe=R/'probe_annual/data'
key=lambda r:(int(r['day']),r['node_id'],r['item_id'])
outputs={name:{key(r):r for r in read(folder/'production_output_products_daily.csv') if int(r['day'])<365}
         for name,folder in [('archive',archive),('control',control),('probe',probe)]}
assert outputs['archive'].keys()==outputs['control'].keys()==outputs['probe'].keys()
rows=[]
for item in ['item:268967','item:268091','item:773474']:
    keys=[k for k in outputs['archive'] if k[2]==item]
    mismatches=[dict(day=k[0],old=outputs['archive'][k]['produced_qty'],probe=outputs['probe'][k]['produced_qty'])
        for k in keys if abs(float(outputs['archive'][k]['produced_qty'])-float(outputs['probe'][k]['produced_qty']))>1e-6]
    rows.append(dict(item_id=item,unit=outputs['probe'][keys[0]]['uom'],daily_release_mismatches=mismatches,
        release_totals={n:sum(float(v[k]['produced_qty']) for k in keys) for n,v in outputs.items()},
        executed_totals={n:sum(float(outputs[n][k]['executed_qty']) for k in keys) for n in ['control','probe']}))
commands={n:json.loads((R/(n+'_command.json')).read_text()) for n in ['control','probe']}
# The output directory and diagnostic wrapper are the only command differences.
for command in commands.values():
    command[1]='<engine>'
    command[command.index('--output-dir')+1]='<output>'
assert commands['control']==commands['probe']
current=read(root/'tmp_full_source_review_20260909/annual_historical_rules/simulation/data/production_output_products_daily.csv')
same_physical=all(all(a[k]==b[k] for k in ['day','node_id','item_id','produced_qty','executed_qty','stock_end_of_day'])
                  for a,b in zip(current,outputs['control'].values())) and len(current)==len(outputs['control'])
assert same_physical
service={n:read(p/'production_demand_service_daily.csv') for n,p in [('control',control),('probe',probe)]}
service_comparison=[]
for item in ['item:268967','item:268091']:
    per={n:[r for r in rs if r['item_id']==item] for n,rs in service.items()}
    service_comparison.append(dict(item_id=item,values={n:dict(demand=sum(float(r['demand_qty']) for r in rs),served=sum(float(r['served_qty']) for r in rs),final_backlog=float(rs[-1]['backlog_end_qty'])) for n,rs in per.items()}))
result=dict(rows=rows,compared_daily_releases=1095,matched_commands_except_wrapper_and_output=True,
    control_matches_previous_annual_physical_output=same_physical,service=service_comparison,
    status='diagnostic_not_adopted_transport_policy',
    cause='Production-batch multiples imposed on factory-to-DC shipments.',
    limits=['Exact daily release match is not identity of all stocks, work dates, costs or supplier traces.',
            'Truck capacities and loading policy must not be inferred from fabrication batch sizes.'])
(R/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
table=''.join('<tr><td>'+html.escape(r['item_id'])+'</td><td>'+r['unit']+'</td>'+''.join('<td>'+f"{r['release_totals'][n]:,.0f}".replace(',',' ')+'</td>' for n in ['archive','control','probe'])+'<td>'+str(len(r['daily_release_mismatches']))+'</td></tr>' for r in rows)
(R/'comparison.html').write_text('''<!doctype html><html lang="fr"><meta charset="utf-8"><title>Planning : cause de l’écart</title>
<style>body{font:17px system-ui;max-width:1050px;margin:40px auto;padding:0 20px;color:#182b40}table{border-collapse:collapse;width:100%}td,th{padding:12px;border:1px solid #ccd5df;text-align:right}th{background:#eef4fa}p{line-height:1.6}.note{background:#fff4d8;padding:15px}</style>
<h1>Pourquoi deux lots supplémentaires ?</h1>
<p>Le moteur arrondit les expéditions usine → distribution à un lot de fabrication. Cela vide plus tôt le stock de l’usine et déclenche de nouvelles fabrications. Cette règle a été introduite dans le commit REV-0293 du 29 août.</p>
<p>Deux simulations de 365 jours utilisent les mêmes données, options et graine 42. L’essai retire uniquement cet arrondi sur les deux voies de produits finis. Il conserve les tailles de fabrication et le semi-fini.</p>
<table><tr><th>Produit</th><th>Unité</th><th>Archive juillet</th><th>Moteur actuel</th><th>Essai sans arrondi PF</th><th>Jours différents de juillet</th></tr>'''+table+''')</table>
<p>Les 1 095 quantités journalières disponibles de l’essai concordent avec l’archive. Le tableau inclut les commandes du carnet ; il ne mesure pas seulement le travail nouvellement exécuté.</p>
<p class="note">Essai de diagnostic, pas une politique de transport validée. Un lot de fabrication n’est pas un camion. Les limites de poids et de palettes doivent être vérifiées séparément. Les coûts, tous les stocks et les dates de travail ne sont pas déclarés identiques.</p>
<p><a href="comparison.json">Comparaison vérifiable</a> · <a href="truck_audit/consolidation_audit.json">Audit des données de chargement</a> · <a href="../etudecas/DISPATCH_HISTORICAL_RECOVERY.md">Rapport et limites</a></p></html>'''.replace(')</table>','</table>'),encoding='utf8')
print(json.dumps(dict(compared=1095,mismatches=sum(len(r['daily_release_mismatches']) for r in rows),control_matches=same_physical)))
