import json, subprocess, sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
out=root/'tmp_dispatch_review_20260910'
mode=sys.argv[1] if len(sys.argv)>1 else 'probe'
assert mode in {'probe','control'}
manifest=json.loads((root/'etudecas/simulation/result/_reruns/active_ex344135_5y_20260717_114118/run_manifest.json').read_text())
args=manifest['simulator_command'][2:]
for flag,value in [('--input', str(root/'tmp_historical_conventions_20260909/fixed_adaptation/adapted_graph.json')),('--days','365'),('--output-dir',str(out/(mode+'_annual')))]:
    args[args.index(flag)+1]=value
script=out/'dispatch_probe.py' if mode=='probe' else root/'etudecas/simulation/engine/run_first_simulation.py'
command=[sys.executable,str(script),*args]
(out/(mode+'_command.json')).write_text(json.dumps(command,indent=2))
with (out/(mode+'.log')).open('w',encoding='utf8') as log:
    result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
print(mode,'exit:',result.returncode)
if result.returncode: print((out/(mode+'.log')).read_text(encoding='utf8')[-3000:])
sys.exit(result.returncode)
