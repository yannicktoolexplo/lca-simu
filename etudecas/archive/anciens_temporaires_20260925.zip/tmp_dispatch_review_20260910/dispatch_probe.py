"""Diagnostic-only removal of finished-product shipment rounding; no production changes."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from etudecas.simulation.engine import run_first_simulation as engine

original = engine.resolve_internal_dispatch_multiple
def probe(**kwargs):
    if (kwargs['origin_id'], kwargs['destination_id'], kwargs['item_id']) in {
        ('M-1430', 'DC-1920', 'item:268967'),
        ('M-1810', 'DC-1920', 'item:268091'),
    }:
        return None
    return original(**kwargs)

if __name__ == '__main__':
    engine.resolve_internal_dispatch_multiple = probe
    engine.main()
