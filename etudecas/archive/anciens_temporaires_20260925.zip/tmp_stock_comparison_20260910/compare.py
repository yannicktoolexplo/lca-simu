"""Compare observed weekly values with existing simulation valuation, without calibration."""
import csv,json,statistics
from pathlib import Path
from datetime import datetime
from collections import defaultdict
R=Path(__file__).resolve().parent
root=R.parent
g=json.loads((root/'tmp_historical_conventions_20260909/fixed_adaptation/adapted_graph.json').read_text())
data=root/'tmp_full_source_review_20260909/annual_historical_rules/simulation/data'
def csvrows(p,delimiter=','):
    raw=p.read_bytes()
    try:t=raw.decode('utf-8-sig')
    except UnicodeDecodeError:t=raw.decode('cp1252')
    return list(csv.DictReader(t.splitlines(),delimiter=delimiter))
states={(n['id'],s['item_id']):s for n in g['nodes'] for s in n.get('inventory',{}).get('states',[])}
stocks={}
for f in ['production_input_stocks_daily.csv','production_dc_stocks_daily.csv']:
    for r in csvrows(data/f):stocks[int(r['day']),r['node_id'],r['item_id']]=float(r['stock_end_of_day'])
out=[];detail=[]
for p in (root/'etudecas/data/source').glob('Stock_*csv'):
    rs=csvrows(p,';');cols=list(rs[0]);groups=defaultdict(list)
    for r in rs:groups[r[cols[0]] if len(cols)==3 else ('Cos' if '_Cos' in p.name else 'Pharma')].append(r)
    for group,records in groups.items():
        if group in ['Cos','Pharma']:
            node='M-1810' if group=='Cos' else 'M-1430'
            proc=next(n for n in g['nodes'] if n['id']==node)['processes'][0]
            items=[x['item_id'] for x in proc['inputs']]
        else:node='DC-1920';items=['item:'+group]
        observed=[];sim=[];same_day=[];byitem=defaultdict(list);fallbacks=[]
        for item in items:
            state=states[node,item];h=state['holding_cost']
            assert 'unit_value_basis' in h
            if 'fallback' in h.get('source',''):fallbacks.append(dict(item_id=item,unit=state['uom'],unit_value=h['unit_value_basis'],source=h['source']))
        for row in records:
            date=datetime.strptime(row[cols[-2]],'%d/%m/%Y %H:%M')
            day=(date.date()-datetime(2025,1,1).date()).days
            # Photos shortly after midnight: primary comparison is previous end-of-day.
            observed.append(float(row[cols[-1]]));total=0;total_same=0
            for item in items:
                value=states[node,item]['holding_cost']['unit_value_basis']
                qty=stocks[day-1,node,item];val=qty*value
                total+=val;total_same+=stocks[day,node,item]*value;byitem[item].append(val)
                detail.append(dict(group=group,date=date.isoformat(),day_used=day-1,node_id=node,item_id=item,quantity=qty,unit_value=value,stock_value=val))
            sim.append(total);same_day.append(total_same)
        assert len(observed)==52
        out.append(dict(group=group,scope=node,observed_mean=statistics.mean(observed),simulated_mean=statistics.mean(sim),simulated_same_day_mean=statistics.mean(same_day),
            ratio=statistics.mean(sim)/statistics.mean(observed),first_observed=observed[0],first_simulated=sim[0],last_observed=observed[-1],last_simulated=sim[-1],
            contributors=sorted([dict(item_id=i,mean_value=statistics.mean(v)) for i,v in byitem.items()],key=lambda r:-r['mean_value']),fallbacks=fallbacks))
(R/'comparison.json').write_text(json.dumps(dict(run=str(data.parent),valuation='Existing graph holding_cost.unit_value_basis; not recalibrated to observations',scope='Components: modeled BOM stocks at factory only. PF: distribution-center stock only. Transit excluded.',timing='Source photos at 00:05/00:06 compared to previous end-of-day; same-day alternative reported.',series=out),ensure_ascii=False,indent=2),encoding='utf8')
with (R/'component_values.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(detail[0]));w.writeheader();w.writerows(detail)
print(json.dumps(out,indent=2))
