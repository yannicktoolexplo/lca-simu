import csv
import json
from pathlib import Path

root = Path(__file__).resolve().parent
old = root / 'native_manifest'
new = root / 'native_final'
compared = []
for case in sorted((new / 'cases').iterdir()):
    a = old / 'cases' / case.name / 'simulation_output'
    b = case / 'simulation_output'
    sa = json.loads((a / 'summaries/first_simulation_summary.json').read_text())
    sb = json.loads((b / 'summaries/first_simulation_summary.json').read_text())
    assert sa['kpis'] == sb['kpis'], case.name
    assert (b / 'inputs/simulation_input.json').read_bytes() == (case / 'input_case.json').read_bytes()
    assert json.loads((b / 'inputs/case_config.json').read_text()) == {}
    count = 0
    for f in sorted((a / 'data').glob('*.csv')):
        assert f.read_bytes() == (b / 'data' / f.name).read_bytes(), (case.name, f.name)
        count += 1
    compared.append(dict(case=case.name, identical_daily_csv=count, identical_kpis=len(sa['kpis'])))
for name in ['supplier_parameter_sensitivity_cases.csv', 'supplier_parameter_threshold_summary.csv', 'supplier_parameter_recommendations.csv']:
    def rows(directory):
        with (directory / name).open(encoding='utf8', newline='') as f:
            return [{k:v for k,v in row.items() if k not in ('case_input', 'case_output_dir')} for row in csv.DictReader(f)]
    assert rows(old) == rows(new), name
report = dict(status='passed', comparison='native manifest versus native explicit options', cases=compared,
    native_criteria_and_recommendations_identical=True, own_inputs_archived=True)
(root / 'native_equivalence.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report))
