import json
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root.parent / 'tmp_functional_recovery_20260910'))
from inventory import payload

target = root / 'map/map.html'
data = payload(target.read_text(encoding='utf8'))
assert data['native_sensitivity_sources']['case_count'] == 5
assert set(data['supplier_sensitivity_hover_images']) == {'supplier:mill_a', 'supplier:mill_b'}
assert data['supplier_parameter_sensitivity_nodes']['supplier:mill_a']['locally_tested']
assert not data['supplier_parameter_sensitivity_nodes']['supplier:mill_b']['locally_tested']
with sync_playwright() as pw:
    browser = pw.chromium.launch(headless=True)
    page = browser.new_page(viewport=dict(width=1700, height=1100))
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.goto(target.as_uri(), timeout=60000)
    page.wait_for_function("typeof DATA !== 'undefined' && document.getElementById('chart').data", timeout=60000)
    page.locator('#modeSensitivity').click()
    options = page.locator('#sensitivitySupplierSelect option').evaluate_all('(options)=>options.map(o=>o.value).filter(Boolean)')
    assert set(options) == {'supplier:mill_a', 'supplier:mill_b'}, options
    checks = []
    for node in options:
        page.locator('#sensitivitySupplierSelect').select_option(node)
        page.wait_for_function('id=>document.querySelector("#factoryHoverTitle").textContent.includes(id)', arg=node)
        page.wait_for_function("document.querySelector('#factoryHoverPanel .js-plotly-plot')?.data?.length > 0")
        plots = page.locator('#factoryHoverPanel .js-plotly-plot').evaluate_all('(plots)=>plots.map(p=>({traces:p.data.length, points:p.data.reduce((n,t)=>n+(t.x||[]).length,0)}))')
        assert any(p['points'] > 0 for p in plots)
        checks.append(dict(supplier=node, plots=plots))
        page.locator('#factoryHoverClearSelection').click()
        assert page.locator('#sensitivitySupplierSelect').input_value() == ''
    assert not errors, errors
    page.screenshot(path=str(root / 'native_browser.png'))
    browser.close()
report = dict(status='passed', suppliers=checks, browser_errors=errors, native_local_and_global_scope_distinguished=True)
(root / 'native_browser_checks.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report))
