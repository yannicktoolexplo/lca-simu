from playwright.sync_api import sync_playwright
from pathlib import Path
import json
root=Path(__file__).resolve().parent
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True)
    page=browser.new_page(viewport={'width':1500,'height':1000})
    errors=[]
    page.on('pageerror',lambda error:errors.append(str(error)))
    page.goto((root/'ready_atlas/maps/reference/map.html').as_uri(),wait_until='load')
    page.locator('#modeSensitivity').click(timeout=30000)
    page.locator('#sensitivityTop3Modal.visible').wait_for(timeout=10000)
    text=page.locator('#sensitivityTop3Content').inner_text()
    assert 'Sensibilité fournisseurs' in text
    assert '796989' in text and '77.7156' in text
    assert page.locator('#sensitivityTop3Content tbody tr').count()==6
    assert not errors,errors
    page.screenshot(path=str(root/'sensitivity.png'))
    page.locator('#sensitivityTop3CloseBtn').click()
    assert not page.locator('#sensitivityTop3Modal').is_visible()
    page.locator('#modeSensitivity').click()
    assert page.locator('#sensitivityTop3Modal').is_visible()
    (root/'browser_validation.json').write_text(json.dumps({'rows':6,'errors':errors,'open_close_reopen':True},indent=2))
    print(text[:1500])
    browser.close()
