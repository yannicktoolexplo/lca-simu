"""Materialize the actual legacy lane decisions; never overwrite the reference."""
import json
from pathlib import Path
from etudecas.simulation.engine.run_first_simulation import lane_records
from etudecas.simulation.lot_policy.engine_adapter import resolve_canonical_lane_lot,resolve_internal_dispatch_multiple
R=Path(__file__).resolve().parent
g=json.loads((R.parent/'tmp_historical_conventions_20260909/fixed_adaptation/adapted_graph.json').read_text())
lanes,_=lane_records(g['edges'])
rules=[]
for l in lanes:
    kw=dict(origin_id=l['src'],destination_id=l['dst'],item_id=l['item_id'],lane_uom=l['standard_order_uom'])
    for kind,resolver in [('order',resolve_canonical_lane_lot),('dispatch',resolve_internal_dispatch_multiple)]:
        d=resolver(**kw)
        if d is None:continue
        rule=dict(kind=kind,origin_id=l['src'],destination_id=l['dst'],item_id=l['item_id'],**d.to_dict())
        if rule['order_frequency_days'] is None:del rule['order_frequency_days']
        rules.append(rule)
g['case_config']['use_historical_lot_catalog']=False
g['case_config']['lane_lot_rules']=rules
(R/'case_config.json').write_text(json.dumps(g['case_config'],ensure_ascii=False,indent=2),encoding='utf8')
(R/'graph.json').write_text(json.dumps(g,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(rules,ensure_ascii=False,indent=2))
