"""Reproduce the migrated annual study in a fresh caller-selected directory."""
import argparse,json
from pathlib import Path
from etudecas.study import configure_parser,execute_study

parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',required=True)
destination=parser.parse_args().output_dir
root=Path(__file__).resolve().parents[1]
study_parser=argparse.ArgumentParser();configure_parser(study_parser)
args=study_parser.parse_args(['--input-graph',str(root/'tmp_explicit_lots_20260910/graph.json'),
    '--output-dir',destination,'--run','--scenario-id','scn:BASE','--days','365','--seed','42'])
protocol=json.loads((root/'tmp_full_source_review_20260909/annual_protocol.json').read_text())
raise SystemExit(execute_study(args,engine_args=tuple(protocol['initialization_arguments']),common_random_numbers=False))
