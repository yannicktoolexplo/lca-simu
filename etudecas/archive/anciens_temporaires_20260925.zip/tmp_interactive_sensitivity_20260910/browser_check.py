"""Verify current annual sensitivity interactions against source quantities."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

OUT = Path(__file__).resolve().parent
MAP = OUT / 'annual_final/maps/reference/map.html'
results = {}
with sync_playwright() as pw:
    browser = pw.chromium.launch(headless=True)
    page = browser.new_page(viewport={'width': 1700, 'height': 1100})
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.goto(MAP.as_uri(), timeout=60000)
    page.wait_for_function("typeof DATA !== 'undefined' && document.getElementById('chart').data", timeout=60000)
    page.locator('#modeSensitivity').click()
    assert not page.locator('#sensitivityTop3Modal').is_visible()
    page.evaluate("document.getElementById('chart').emit('plotly_click',{points:[{customdata:['SDC-VD0914360C','supplier_dc']}],event:{clientX:1000,clientY:300}})")
    page.locator('#factoryHoverPanel.visible').wait_for()
    page.wait_for_function("document.querySelector('#outgoingBlock .js-plotly-plot')?.data?.length === 2")
    traces = page.evaluate("Array.from(document.querySelectorAll('#outgoingBlock .js-plotly-plot')).map(p=>p.data.map(t=>({x:t.x,y:t.y,mode:t.mode})))")
    assert any(any(abs(y - 796989) < .01 for y in t['y']) for p in traces for t in p)
    assert all(t['mode'] == 'markers' for p in traces for t in p)
    assert page.locator('#thirdBlock').is_visible()
    assert 'Expeditions et stocks' in page.locator('#thirdLabel').inner_text()
    tabs = page.locator('#outgoingBlock .panelSubTab')
    assert tabs.count() == 12  # 3 factors, 2 client/article pairs, 2 figures each.
    for i in range(tabs.count()):
        tabs.nth(i).click()
        page.wait_for_timeout(100)
    page.locator('#outgoingBlock .panelSubTab').first.click()
    page.locator('#outgoingBlock').scroll_into_view_if_needed()
    page.screenshot(path=str(OUT / 'annual_supplier.png'))
    results['supplier'] = {'curve_tabs': tabs.count(), 'final_backlog_stop': 796989,
        'no_forced_modal': True, 'points_only': True, 'local_stock_and_shipments_visible': True}
    for node, kind in [('M-1810', 'factory'), ('DC-1920', 'distribution_center')]:
        # Resolve actual DC ID from the connected payload, not assumed naming.
        if kind == 'distribution_center':
            node = page.evaluate("Object.keys(DATA.distribution_center_sensitivity_hover_images)[0]")
        page.evaluate("([id,kind])=>document.getElementById('chart').emit('plotly_click',{points:[{customdata:[id,kind]}],event:{clientX:1000,clientY:300}})", [node, kind])
        page.wait_for_function("document.querySelector('#outgoingBlock .js-plotly-plot')?.data?.length === 2")
        assert node in page.locator('#factoryHoverTitle').inner_text()
        results[node] = {'network_service_curves': True}
    assert page.evaluate("!DATA.supplier_parameter_sensitivity_nodes['M-1430']")
    page.locator('#factoryHoverClearSelection').click()
    page.locator('#sensitivityTop3Btn').click()
    assert page.locator('#sensitivityTop3Modal').is_visible()
    assert 'niveaux' in page.locator('#sensitivityTop3Content').inner_text()
    page.locator('#sensitivityTop3CloseBtn').click()
    page.locator('#modeOps').click()
    select = page.locator('#lotTraceSelect')
    assert select.locator('option').count() > 2
    select.select_option(index=1)
    page.locator('#lotTraceOpenBtn').click()
    page.wait_for_timeout(500)
    results['nominal_lots'] = {'available_lots': select.locator('option').count() - 1}
    assert not errors, errors
    results['browser_errors'] = errors
    (OUT / 'browser_checks.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf8')
    browser.close()
print(json.dumps(results, ensure_ascii=False), flush=True)
