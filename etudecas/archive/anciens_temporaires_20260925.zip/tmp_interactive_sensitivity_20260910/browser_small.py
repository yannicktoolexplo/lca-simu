import json
from pathlib import Path
import sys
from playwright.sync_api import sync_playwright

atlas = Path(sys.argv[1]).resolve()
output = Path(__file__).resolve().parent
checks = {}
with sync_playwright() as pw:
    browser = pw.chromium.launch(headless=True)
    for name in ['reference', 'mill_a_unavailable', 'both_mills_unavailable']:
        page = browser.new_page(viewport={'width': 1700, 'height': 1100})
        errors = []
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.goto((atlas / 'maps' / name / 'map.html').as_uri(), timeout=60000)
        page.wait_for_function("typeof DATA !== 'undefined' && document.getElementById('chart').data")
        assert page.evaluate('DATA.sensitivity_attachment.selected_run') == name
        page.locator('#modeSensitivity').click()
        assert not page.locator('#sensitivityTop3Modal').is_visible()
        page.evaluate("document.getElementById('chart').emit('plotly_click',{points:[{customdata:['supplier:mill_a','supplier_dc']}],event:{clientX:1000,clientY:300}})")
        page.wait_for_function("document.querySelector('#outgoingBlock .js-plotly-plot')?.data?.length === 2")
        values = page.evaluate("document.querySelector('#outgoingBlock .js-plotly-plot').data.map(t=>t.y)")
        assert values == [[100, 80], [0, 10]]
        assert 'KG' in page.locator('#thirdBlock').inner_text()
        assert 'UN' in page.locator('#outgoingBlock').inner_text()
        assert not errors, errors
        if name == 'reference':
            page.locator('#outgoingBlock').scroll_into_view_if_needed()
            page.screenshot(path=str(output / 'assembly_supplier.png'))
        checks[name] = dict(service_percent=values[0], final_backlog_UN=values[1],
                           separate_KG_and_UN=True, browser_errors=errors)
        page.close()
    browser.close()
(output / 'assembly_browser_checks.json').write_text(json.dumps(checks, indent=2), encoding='utf8')
print(json.dumps(checks))
