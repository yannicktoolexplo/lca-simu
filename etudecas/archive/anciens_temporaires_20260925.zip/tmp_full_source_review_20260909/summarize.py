"""Independent source and annual-run evidence, without changing model inputs."""
import csv
import hashlib
import json
from pathlib import Path

R = Path(__file__).resolve().parent
root = R.parent
inventory = json.loads((R/'source_contents.json').read_text(encoding='utf8'))
reconciliation = json.loads((R/'source_model_reconciliation.json').read_text(encoding='utf8'))
graph = json.loads((root/'tmp_historical_conventions_20260909/fixed_adaptation/adapted_graph.json').read_text())
data = R/'annual_historical_rules/simulation/data'
archive = root/'etudecas/simulation/result/_reruns/active_ex344135_5y_20260717_114118/data'

def rows(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

output = rows(data/'production_output_products_daily.csv')
demand = rows(data/'production_demand_service_daily.csv')
old_output = rows(archive/'production_output_products_daily.csv')
annual = []
for item in ['item:268967', 'item:268091', 'item:773474']:
    actual = [r for r in output if r['item_id'] == item]
    service = [r for r in demand if r['item_id'] == item]
    historical = [r for r in old_output if r['item_id'] == item and int(r['day']) < 365]
    annual.append(dict(item_id=item, unit=actual[0]['uom'],
        executed=sum(float(r['executed_qty']) for r in actual),
        source_order_receipts=sum(float(r['opening_released_qty']) for r in actual),
        released=sum(float(r['produced_qty']) for r in actual),
        archived_released_first_365=sum(float(r['produced_qty']) for r in historical),
        new_production_by_30_day_period=[sum(float(r['executed_qty']) for r in actual if start <= int(r['day']) < start+30) for start in range(0,365,30)],
        demand=sum(float(r['demand_qty']) for r in service),
        served=sum(float(r['served_qty']) for r in service),
        last_backlog=float(service[-1]['backlog_end_qty']) if service else None,
        days_with_backlog=sum(float(r['backlog_end_qty']) > 1e-6 for r in service)))

mrp=[]
for r in reconciliation['mrp_source']:
    v=r['values']; node={1430:'M-1430',1810:'M-1810',1920:'DC-1920'}[v[2]]
    item='item:'+str(v[0]).zfill(6)
    state=next(s for n in graph['nodes'] if n['id']==node for s in n['inventory']['states'] if s['item_id']==item)
    policy=state['mrp_policy']
    qty=float(v[5]) / (1000 if v[6]=='G' and policy['safety_stock_uom']=='KG' else 1)
    mrp.append(dict(source_row=r['row'], node_id=node, item_id=item,
        matched=qty==policy['safety_stock_qty'] and float(v[4])==policy['safety_time_days']))

hashes=[]
for f in inventory['files']:
    p=root/'etudecas/data/source'/f['name']
    hashes.append(dict(file=str(p.relative_to(root)), unchanged=hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']))
duplicate=root/'etudecas/donnees/Extract_En_cours.xlsx'
canonical=root/'etudecas/data/source/Extract_En_cours.xlsx'
result=dict(annual=annual, mrp_source_parameter_checks=mrp, source_hash_checks=hashes,
    carnet_duplicate_identical=duplicate.read_bytes()==canonical.read_bytes(),
    excluded_order_source_rows=[r['source_row'] for r in reconciliation['opening_orders'] if not r['model']],
    source_stock_rows_not_represented=[r for r in reconciliation['stocks'] if not r['model']],
    stock_rounding_differences=[r for r in reconciliation['stocks'] if r['model'] and not r['matched']],
    limitation='Annual replay uses the current engine with recovered historical settings; it is not a replay of the July engine.')
(R/'audit_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
assert all(x['unchanged'] for x in hashes)
assert all(x['matched'] for x in mrp)
assert result['carnet_duplicate_identical']
print(json.dumps(dict(annual=annual,mrp_matched=len(mrp),unchanged_sources=len(hashes),duplicate_identical=True),indent=2))
