"""Source-to-model reconciliation; retain mismatches rather than silently fixing them."""
from pathlib import Path
import csv
import json
from decimal import Decimal
from collections import Counter

R = Path(__file__).resolve().parent
source = json.loads((R/'source_contents.json').read_text(encoding='utf-8'))['files']
graph = json.loads((R.parent/'tmp_historical_conventions_20260909/fixed_adaptation/adapted_graph.json').read_text())

def sheet(file, name):
    return next(s for f in source if f['name'] == file for s in f['sheets'] if s['name'] == name)['rows'][1:]

def item(value):
    return 'item:' + str(value).strip().zfill(6)

def number(value):
    return Decimal(str(value))

def unit(value):
    return {'ZUN': 'UN', 'UN.': 'UN'}.get(str(value).strip().upper(), str(value).strip().upper())

def convert(qty, from_unit, to_unit):
    if unit(from_unit) == unit(to_unit):
        return number(qty)
    factors = {'G': Decimal('.001'), 'KG': Decimal(1)}
    return number(qty) * factors[unit(from_unit)] / factors[unit(to_unit)]

report = {}
extra = next(f['name'] for f in source if f['name'].startswith('Extract_Donn'))
nodes = {n['id']: n for n in graph['nodes']}
divisions = {'1430': 'M-1430', '1810': 'M-1810', '1450': 'SDC-1450', '1920': 'DC-1920'}
stocks = []
for record in sheet(extra, 'Stocks'):
    v = record['values']; node = divisions.get(str(v[2])); article = item(v[0])
    matches = [s for s in nodes.get(node, {}).get('inventory', {}).get('states', []) if s['item_id'] == article]
    row = dict(source_row=record['row'], node_id=node, item_id=article, source_quantity=v[4], source_unit=v[5], model=matches)
    row['matched'] = len(matches) == 1 and convert(v[4], v[5], matches[0]['uom']) == number(matches[0]['initial'])
    stocks.append(row)
report['stocks'] = stocks

boms = []
for file, node, output, indexes in [('268091.xlsx', 'M-1810', 'item:268091', (1,2,4,5)),
    ('268967.xlsx', 'M-1430', 'item:268967', (1,2,4,5)), ('773474.xlsx', 'SDC-1450', 'item:773474', (2,3,5,6))]:
    process = next(p for p in nodes[node]['processes'] if any(o['item_id'] == output for o in p['outputs']))
    for record in sheet(file, 'BOM'):
        v=record['values']; batch, component, qty, uom = (v[i] for i in indexes)
        candidates = [x for x in process['inputs'] if x['item_id'] == item(component)]
        matched = len(candidates) == 1 and abs(convert(qty, uom, candidates[0]['ratio_unit']) / number(batch) - number(candidates[0]['ratio_per_batch']) / number(process['batch_size'])) < Decimal('0.000000001')
        boms.append(dict(file=file, source_row=record['row'], output_item=output, input_item=item(component),
            source_quantity=qty, source_unit=uom, source_batch=batch, model_inputs=candidates, matched=matched))
report['boms'] = boms

fia = []
for file, destination in [('268091.xlsx','M-1810'), ('268967.xlsx','M-1430'), ('773474.xlsx','SDC-1450')]:
    for record in sheet(file, 'FIA'):
        v=record['values']; src='SDC-'+str(v[1]).strip(); article=item(v[0])
        edges=[e for e in graph['edges'] if e['from']==src and e['to']==destination and article in e.get('items', [])]
        fia.append(dict(file=file, source_row=record['row'], supplier=src, item_id=article,
            price=v[2], price_base=v[3], currency=v[4], lead_days=v[5], order_qty=v[6], unit=v[7],
            model_edges=[dict(id=e['id'], lead_time=e.get('lead_time'), attrs=e.get('attrs'), order_terms=e.get('order_terms')) for e in edges]))
report['supplier_terms'] = fia
report['mrp_source'] = sheet(extra, 'Politique de Stock MRP')
report['lot_sizes_source'] = sheet(extra, 'Taille de Lots')
report['lot_sizes_model'] = {n: nodes[n]['processes'] for n in ['M-1430','M-1810','SDC-1450']}
report['mrp_model'] = {n: nodes[n].get('inventory') for n in ['M-1430','M-1810','SDC-1450']}

orders = []
source_orders = sheet('Extract_En_cours.xlsx','Sheet1')
model_orders = graph['meta']['opening_open_orders']['rows']
for record in source_orders:
    matches = [o for o in model_orders if o['source_row']==record['row']]
    orders.append(dict(source_row=record['row'], source_values=record['values'], model=matches))
report['opening_orders'] = orders
report['order_interpretation_limit'] = 'No production start date or status column: O.Proc does not prove production had already started before the snapshot.'

daily = R/'annual_historical_rules/simulation/data/production_demand_service_daily.csv'
annual = list(csv.DictReader(daily.open(encoding='utf-8-sig'))) if daily.exists() else []
demand = []
for article in [268091,268967]:
    rows = [r for r in sheet('demand_PF.xlsx','Demande') if r['values'][0] == article]
    model = next(d for d in graph['scenarios'][0]['demand'] if d['item_id'] == item(article))
    points = model['profile'][0]['points']
    weekly = [dict(source_row=r['row'], week=r['values'][2], forecast=r['values'][3], real=r['values'][4],
                   model_daily_rate=next(p['value'] for p in points if p['t']==7*(r['values'][2]-1))) for r in rows]
    demand.append(dict(item_id=item(article), weeks=weekly, source_annual=sum(r['values'][4] or 0 for r in rows),
        simulated_annual=sum(float(r['demand_qty']) for r in annual if r['item_id']==item(article)),
        note='Weekly quantities divided by seven in the graph; the historical engine also smooths physical demand over seven forward days.'))
report['demand'] = demand
with (R/'source_model_reconciliation.json').open('x',encoding='utf-8') as f:
    json.dump(report,f,ensure_ascii=False,indent=2)
print(json.dumps(dict(stocks=len(stocks), stocks_matched=sum(x['matched'] for x in stocks), boms=len(boms), boms_matched=sum(x['matched'] for x in boms), fia=len(fia), fia_with_route=sum(bool(x['model_edges']) for x in fia), source_orders=len(orders), represented_orders=sum(bool(x['model']) for x in orders), demand=report['demand'] and [{k:d[k] for k in ['item_id','source_annual','simulated_annual']} for d in demand]),indent=2))
