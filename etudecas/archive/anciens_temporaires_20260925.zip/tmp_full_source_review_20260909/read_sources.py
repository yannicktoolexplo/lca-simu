"""Read every business source without altering it; preserve rows and provenance."""
from pathlib import Path
import csv
import hashlib
import json
from datetime import date, datetime
from collections import Counter
import openpyxl

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'etudecas/data/source'

def serial(value):
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    return value

files = []
for path in sorted(SOURCE.iterdir()):
    if not path.is_file() or path.name.startswith('~$'):
        continue
    raw = path.read_bytes()
    entry = dict(name=path.name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    if path.suffix == '.xlsx':
        values = openpyxl.load_workbook(path, data_only=True, read_only=True)
        formulas = openpyxl.load_workbook(path, data_only=False, read_only=True)
        sheets = []
        for sheet in values:
            records = [dict(row=i, values=[serial(v) for v in row]) for i, row in enumerate(sheet.values, 1) if any(v is not None for v in row)]
            formula_cells, error_cells, missing_cache = [], [], []
            for row in formulas[sheet.title]:
                for cell in row:
                    if cell.data_type == 'f':
                        formula_cells.append(dict(cell=cell.coordinate, formula=cell.value))
                        if values[sheet.title][cell.coordinate].value is None:
                            missing_cache.append(cell.coordinate)
                    if cell.data_type == 'e':
                        error_cells.append(dict(cell=cell.coordinate, value=cell.value))
            sheets.append(dict(name=sheet.title, rows=records, formula_cells=formula_cells,
                               missing_formula_cache=missing_cache, error_cells=error_cells))
        values.close(); formulas.close()
        entry['sheets'] = sheets
    elif path.suffix == '.csv':
        for encoding in ['utf-8-sig', 'cp1252']:
            try:
                text = raw.decode(encoding)
                break
            except UnicodeDecodeError:
                continue
        else:
            raise ValueError(f'Undecodable CSV {path.name}')
        dialect = csv.Sniffer().sniff(text[:8192], delimiters=',;\t')
        rows = list(csv.reader(text.splitlines(), dialect))
        entry.update(encoding=encoding, delimiter=dialect.delimiter, rows=rows,
                     column_count_histogram=dict(Counter(len(row) for row in rows)))
    elif path.suffix == '.json':
        entry['data'] = json.loads(raw.decode('utf-8-sig'))
    else:
        raise ValueError(f'Unreviewed source type: {path.name}')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256']
    files.append(entry)

report = dict(files=files, limitations=['All rows read; formulas inventoried, not recalculated.',
    'Public evidence is source text, not externally authenticated in this source audit.',
    'A source row is not automatically a validated model parameter.'])
with (ROOT/'source_contents.json').open('x', encoding='utf-8') as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2)
print(json.dumps(dict(files=len(files), sheets=sum(len(f.get('sheets', [])) for f in files),
    spreadsheet_rows=sum(len(s['rows']) for f in files for s in f.get('sheets', []))), indent=2))
