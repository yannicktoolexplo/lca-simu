import base64
import gzip
import hashlib
import json
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parent))
sys.path.insert(0, str(OUT.parent / 'tmp_functional_recovery_20260910'))
from inventory import payload
from etudecas.visualization.maps.worldmap_html_template import html_template
from etudecas.visualization.maps.compress_html_payload import compress_embedded
from etudecas.visualization.maps.simulation_payload import render_material_balance_table_html

source = Path('C:/dev/lca-simu-pr40-validation-artifacts-20260726/DEMONSTRATION_SUPPLY_CHAIN_AUTONOME_FICHIER_UNIQUE_20260831.html')
raw = source.read_bytes()
text = raw.decode('utf8')
files, _ = json.JSONDecoder().raw_decode(text[text.index('const files = ') + len('const files = '):])
original = gzip.decompress(base64.b64decode(files['views/carte_reseau_lots.html']['gzip_base64'])).decode('utf8')
data = payload(original)
table = data.get('material_balance_rows') or []
rendered = html_template('Contrôle du sélecteur — données de la référence du 31 août',
    json.dumps(data, ensure_ascii=False), render_material_balance_table_html(table), len(table), 'Données historiques inchangées')
compressed, _ = compress_embedded(rendered)
assert payload(compressed) == data
target = OUT / 'reference_current_selector.html'
target.write_text(compressed, encoding='utf8')
with sync_playwright() as pw:
    browser = pw.chromium.launch(headless=True)
    page = browser.new_page(viewport=dict(width=1700, height=1100))
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.goto(target.as_uri(), timeout=60000)
    page.wait_for_function("typeof DATA !== 'undefined' && document.getElementById('chart').data", timeout=60000)
    page.locator('#modeSensitivity').click()
    assert page.locator('#sensitivitySupplierSelect option').count() == 30
    for node in ['SDC-VD0914690A', 'SDC-VD0914360C', 'SDC-VD0956464A']:
        page.locator('#sensitivitySupplierSelect').select_option(node)
        page.wait_for_function('id=>document.querySelector("#factoryHoverTitle").textContent.includes(id)', arg=node)
        page.wait_for_function("document.querySelector('#factoryHoverPanel .js-plotly-plot')?.data?.length > 0")
        page.locator('#factoryHoverClearSelection').click()
        assert page.locator('#sensitivitySupplierSelect').input_value() == ''
    assert not errors, errors
    browser.close()
assert source.read_bytes() == raw
report = dict(status='passed', original_sha256=hashlib.sha256(raw).hexdigest(),
              payload_unchanged=True, historical_supplier_options=29,
              selection_clear_and_reselection=True, legacy_curves=True, browser_errors=errors)
(OUT / 'reference_selector_checks.json').write_text(json.dumps(report, indent=2), encoding='utf8')
print(json.dumps(report), flush=True)
