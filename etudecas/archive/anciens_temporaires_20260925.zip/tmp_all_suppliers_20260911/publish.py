"""Publish only when all declared studies and comparisons are complete."""
import json
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parent))
from etudecas.experiment_map import execute_experiment_map

if __name__ == '__main__':
    root = OUT / 'complete_experiment'
    while True:
        try:
            manifest = json.loads((root / 'experiment_manifest.json').read_text(encoding='utf8'))
        except json.JSONDecodeError:
            time.sleep(1)
            continue
        if manifest['status'] != 'running':
            break
        time.sleep(10)
    if manifest['status'] != 'passed':
        raise RuntimeError('Campaign incomplete or failed; no map published')
    subprocess.run([sys.executable, str(OUT / 'verify_results.py')], check=True)
    assert execute_experiment_map(root, OUT / 'atlas', display_run_ids=['reference'],
        title='Sensibilité fournisseurs — 27 testés, 29 fiches — référence annuelle') == 0
    subprocess.run([sys.executable, str(OUT / 'browser_check.py')], check=True)
