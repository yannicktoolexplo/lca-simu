import hashlib
import json
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright

OUT = Path(__file__).resolve().parent
atlas = sys.argv[1] if len(sys.argv) > 1 else 'atlas'
expected = int(sys.argv[2]) if len(sys.argv) > 2 else 27
source = OUT / atlas / 'maps/reference/map.html'
reference = Path('C:/dev/lca-simu-pr40-validation-artifacts-20260726/DEMONSTRATION_SUPPLY_CHAIN_AUTONOME_FICHIER_UNIQUE_20260831.html')
before = hashlib.sha256(reference.read_bytes()).hexdigest()
checks = {}
with sync_playwright() as pw:
    browser = pw.chromium.launch(headless=True)
    page = browser.new_page(viewport=dict(width=1700, height=1100))
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.goto(source.as_uri(), timeout=120000)
    page.wait_for_function("typeof DATA !== 'undefined' && document.getElementById('chart').data", timeout=120000)
    page.locator('#modeSensitivity').click()
    assert not page.locator('#sensitivityTop3Modal').is_visible()
    rows = page.evaluate('DATA.sensitivity_attachment.supplier_coverage')
    assert len(rows) == 29
    assert sum(r['status'] == 'tested' for r in rows) == expected
    assert page.locator('#sensitivitySupplierSelect option').count() == 30
    ids = []
    for row in rows:
        node = row['supplier_id']
        ids.append(node)
        page.locator('#sensitivitySupplierSelect').select_option(node)
        page.wait_for_function('(id) => document.querySelector("#factoryHoverTitle").textContent.includes(id)', arg=node)
        if row['status'] == 'tested':
            page.wait_for_function("document.querySelector('#outgoingBlock .js-plotly-plot')?.data?.length === 2")
            assert page.locator('#thirdBlock').is_visible()
            assert page.locator('#fourthBlock').is_visible()
        else:
            assert 'Non évalué' in page.locator('#incomingBlock').inner_text()
            assert page.locator('#outgoingBlock .js-plotly-plot:visible').count() == 0
            assert page.locator('#factoryHoverPanel .businessOk:visible').count() == 0
    page.locator('#sensitivitySupplierSelect').select_option('SDC-VD0956464A')
    page.screenshot(path=str(OUT / (atlas + '_unlocated_supplier.png')))
    page.locator('#sensitivitySupplierSelect').select_option('SDC-VD0914360C')
    page.wait_for_function("document.querySelector('#outgoingBlock .js-plotly-plot')?.data?.length === 2")
    values = page.evaluate("document.querySelector('#outgoingBlock .js-plotly-plot').data[0].y")
    assert 77 < values[0] < 78 and values[1] == 100
    page.screenshot(path=str(OUT / (atlas + '_packaging.png')))
    page.locator('#factoryHoverClearSelection').click()
    assert page.locator('#sensitivitySupplierSelect').input_value() == ''
    page.locator('#sensitivitySupplierSelect').select_option('SDC-VD0914360C')
    page.wait_for_function("document.querySelector('#factoryHoverTitle').textContent.includes('SDC-VD0914360C')")
    page.evaluate("document.getElementById('chart').emit('plotly_click',{points:[{customdata:['SDC-VD0508918A','supplier_dc']}],event:{clientX:1000,clientY:300}})")
    assert page.locator('#sensitivitySupplierSelect').input_value() == 'SDC-VD0508918A'
    page.locator('#factoryHoverClearSelection').click()
    page.locator('#sensitivityTop3Btn').click()
    assert page.locator('#sensitivityTop3Modal').is_visible()
    page.locator('#sensitivityTop3CloseBtn').click()
    page.locator('#modeOps').click()
    assert page.locator('#lotTraceSelect option').count() > 2
    page.locator('#lotTraceOpenBtn').click()
    assert not errors, errors
    checks['current'] = dict(supplier_count=len(ids), tested=expected, all_panels_opened=True,
        unlocated_selectable=True, nominal_lots=True, packaging_served_percent=values, browser_errors=errors)
    page.close()
    page = browser.new_page()
    page.goto(reference.as_uri(), timeout=60000)
    page.evaluate("window.ETUDECAS_SINGLE_HTML.openView('views/carte_reseau_lots.html')")
    page.wait_for_timeout(1000)
    frame = page.frames[-1]
    frame.wait_for_function("typeof DATA !== 'undefined' && document.getElementById('chart').data", timeout=60000)
    original_ids = frame.evaluate('Object.keys(DATA.supplier_sensitivity_hover_images).sort()')
    assert sorted(ids) == original_ids
    frame.locator('#modeSensitivity').click()
    frame.evaluate("document.getElementById('chart').emit('plotly_click',{points:[{customdata:['SDC-VD0914690A','supplier_dc']}],event:{clientX:1000,clientY:300}})")
    frame.wait_for_function("document.querySelector('#factoryHoverPanel .js-plotly-plot')?.data?.length > 0")
    assert hashlib.sha256(reference.read_bytes()).hexdigest() == before
    checks['reference'] = dict(sha256=before, supplier_ids_identical=True, supplier_count=len(original_ids))
    browser.close()
(OUT / (atlas + '_browser_checks.json')).write_text(json.dumps(checks, indent=2), encoding='utf8')
print(json.dumps(checks), flush=True)
