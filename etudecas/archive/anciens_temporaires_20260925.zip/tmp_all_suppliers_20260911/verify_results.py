"""Compare completed supplier studies and verify the unchanged annual nominal."""
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT / 'complete_experiment'
OLD = OUT.parent / 'tmp_annual_sensitivity_20260910/experiment'
manifest = json.loads((ROOT / 'experiment_manifest.json').read_text(encoding='utf8'))
graph = json.loads((ROOT / 'runs/reference/simulation/inputs/simulation_input.json').read_text(encoding='utf8'))
old_graph = json.loads((OLD / 'runs/reference/simulation/inputs/simulation_input.json').read_text(encoding='utf8'))
assert graph == old_graph
unchanged = []
for name in ['production_demand_service_daily.csv', 'production_input_stocks_daily.csv',
             'production_output_products_daily.csv', 'production_supplier_shipments_daily.csv',
             'production_campaigns.csv', 'production_constraint_daily.csv', 'mrp_orders_daily.csv']:
    a, b = [root / 'runs/reference/simulation/data' / name for root in (ROOT, OLD)]
    if not a.exists():
        raise ValueError(f'Required nominal export missing: {name}')
    assert a.read_bytes() == b.read_bytes(), name
    unchanged.append(name)
summaries = [json.loads((root / 'runs/reference/simulation/summaries/first_simulation_summary.json').read_text(encoding='utf8')) for root in (ROOT, OLD)]
assert summaries[0]['kpis'] == summaries[1]['kpis']
reference = json.loads((ROOT / 'runs/reference/service_metrics.json').read_text(encoding='utf8'))['rows']
key = lambda row: (row['node_id'], row['item_id'], row['uom'])
baseline = {key(row): row for row in reference}
results = []
for run in manifest['runs']:
    if run['id'] == 'reference' or run['status'] != 'passed':
        continue
    service = json.loads((ROOT / run['path'] / 'service_metrics.json').read_text(encoding='utf8'))
    perturbation = run['perturbations'][0]
    event_id = f"experiment:{run['id']}:1"
    event_days = set()
    event_file = ROOT / run['path'] / 'simulation/data/supplier_risk_events_applied_daily.csv'
    with event_file.open(encoding='utf8', newline='') as stream:
        for row in csv.DictReader(stream):
            if event_id not in row['event_ids']:
                continue
            assert row['supplier_id'] == perturbation['supplier_id']
            assert float(row[perturbation['kind'] + '_multiplier']) == perturbation['factor']
            day = int(row['day'])
            assert perturbation['start_day'] <= day <= perturbation['end_day']
            event_days.add(day)
    assert event_days, f'No application of declared event: {run["id"]}'
    pairs = []
    for row in service['rows']:
        base = baseline[key(row)]
        fraction = row['requirement_served_fraction']
        delta = None if fraction is None else fraction - base['requirement_served_fraction']
        waiting = row['backlog_quantity_days'] - base['backlog_quantity_days']
        pairs.append(dict(client=row['node_id'], item=row['item_id'], uom=row['uom'],
            delivered_fraction=fraction, delivered_fraction_delta=delta,
            final_backlog=row['final_backlog_qty'], backlog_quantity_days_delta=waiting,
            service_degraded=delta is not None and (delta < -1e-9 or waiting > 3e-6 * manifest['days'])))
    results.append(dict(id=run['id'], **perturbation, event_application_days=len(event_days), pairs=pairs))
report = dict(status=manifest['status'], run_status_counts=dict(Counter(r['status'] for r in manifest['runs'])),
    nominal_input_identical=True, nominal_kpis_identical=True, nominal_exports_identical=unchanged,
    baseline=reference, supplier_count=len({r['supplier_id'] for r in results}),
    variants_completed=len(results),
    suppliers_with_degraded_service=sorted({r['supplier_id'] for r in results if any(p['service_degraded'] for p in r['pairs'])}),
    variants=results)
(OUT / 'result_checks.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
print(json.dumps({k: v for k, v in report.items() if k not in ('variants', 'baseline')}, ensure_ascii=False), flush=True)
