from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
previous = root / 'tmp_functional_recovery_20260910'
sys.path.insert(0, str(previous))
source = previous / 'check_current_viewer.py'
script = source.read_text(encoding='utf8').replace(
    'OUT=Path(__file__).parent', "OUT=ROOT/'tmp_all_suppliers_20260911'")
exec(compile(script, str(source), 'exec'), {'__file__': str(source), '__name__': '__main__'})
