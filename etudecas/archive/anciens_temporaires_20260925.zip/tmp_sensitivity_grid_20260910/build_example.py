"""Five short deterministic tests using the existing engine and a declared synthetic case."""
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
sys.path.insert(0, str(ROOT))
from etudecas.experiment import execute_experiment
from etudecas.experiment_map import execute_experiment_map

graph = json.loads((ROOT / 'etudecas/config/cases/assembly_demo.json').read_text(encoding='utf8'))
graph['nodes'] = [n for n in graph['nodes'] if n['id'] != 'supplier:mill_b']
graph['edges'] = [e for e in graph['edges'] if e['from'] != 'supplier:mill_b']
graph['meta']['case_id'] = 'assembly_single_source_grid_demo'
graph['meta']['description'] = 'Synthetic single-source version of assembly_demo; mill B and its lane are explicitly removed to examine tested lead-time levels.'
graph['meta']['assumptions'].append('Single supplier for this synthetic test only; no real-case rule or source modified.')
for node, (lat, lon) in zip(graph['nodes'], [(46, -1), (47, 1), (48, 2)]):
    node['geo'] = dict(lat=lat, lon=lon)
spec = dict(schema_version='etudecas.experiment.v1', input_graph='case.json', scenario_id='scenario:reference',
    days=5, seed=1729, initialization='graph_stocks',
    description='Synthetic five-day grid; one deterministic realization per tested lead-time factor.',
    variants=[dict(id=f'lead_{str(factor).replace(".", "_")}', perturbations=[dict(
        supplier_id='supplier:mill_a', kind='lead_time', factor=factor, start_day=0, end_day=4)])
        for factor in [.5, 2, 3, 5]])
for name, data in [('case.json', graph), ('protocol.json', spec)]:
    path = OUT / name
    if path.exists():
        raise ValueError(f'Output already exists: {path}')
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf8')
assert execute_experiment(OUT / 'protocol.json', OUT / 'experiment') == 0
assert execute_experiment_map(OUT / 'experiment', OUT / 'example_atlas', display_run_ids=['reference']) == 0
