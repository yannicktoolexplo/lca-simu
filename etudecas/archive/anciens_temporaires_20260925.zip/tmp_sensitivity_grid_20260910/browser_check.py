import hashlib
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

OUT = Path(__file__).resolve().parent
SOURCE = Path('C:/dev/lca-simu-pr40-validation-artifacts-20260726/DEMONSTRATION_SUPPLY_CHAIN_AUTONOME_FICHIER_UNIQUE_20260831.html')
before = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
checks = {}
with sync_playwright() as pw:
    browser = pw.chromium.launch(headless=True)
    for name, source, supplier in [('annual', OUT / 'annual_atlas/maps/reference/map.html', 'SDC-VD0914360C'),
                                  ('example', OUT / 'example_atlas/maps/reference/map.html', 'supplier:mill_a')]:
        page = browser.new_page(viewport={'width': 1700, 'height': 1100})
        errors = []
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.goto(source.as_uri(), timeout=60000)
        page.wait_for_function("typeof DATA !== 'undefined' && document.getElementById('chart').data", timeout=60000)
        page.locator('#modeSensitivity').click()
        assert not page.locator('#sensitivityTop3Modal').is_visible()
        page.evaluate("id=>document.getElementById('chart').emit('plotly_click',{points:[{customdata:[id,'supplier_dc']}],event:{clientX:1000,clientY:300}})", supplier)
        page.wait_for_function("document.querySelector('#outgoingBlock .js-plotly-plot')?.data?.length === 2")
        grid_text = page.locator('#incomingBlock').inner_text()
        assert 'Groupes de points successifs' in grid_text
        assert 'intermédiaires restent inconnus' in grid_text
        colors = page.evaluate("document.querySelector('#outgoingBlock .js-plotly-plot').data[0].marker.color")
        values = page.evaluate("document.querySelector('#outgoingBlock .js-plotly-plot').data[0].y")
        if name == 'annual':
            assert colors == ['#dc2626', '#15803d']
            assert 77 < values[0] < 78 and values[1] == 100
            assert '100 %' in grid_text and '0 %' in grid_text
            assert page.locator('#fourthBlock').is_visible()  # Cost views preserved.
        else:
            assert colors == ['#15803d'] * 4 + ['#dc2626']
            assert values == [100, 100, 100, 100, 80]
            assert '300 %' in grid_text and '500 %' in grid_text
            grid = page.evaluate('DATA.sensitivity_attachment.tested_grids[0]')
            assert grid['nearest_degraded_above'] == 5
            assert grid['reference_group'] == [.5, 1, 2, 3]
            assert not grid['continuous_threshold_established']
        page.locator('#outgoingBlock').scroll_into_view_if_needed()
        page.screenshot(path=str(OUT / f'{name}_points.png'))
        # Exercise genuine Plotly hover on the first test point, including the new status text.
        page.evaluate("Plotly.Fx.hover(document.querySelector('#outgoingBlock .js-plotly-plot'),[{curveNumber:0,pointNumber:0}])")
        assert 'point teste' in page.locator('#outgoingBlock .hoverlayer').text_content()
        page.locator('#factoryHoverClearSelection').click()
        page.locator('#sensitivityTop3Btn').click()
        assert 'Groupes de points successifs' in page.locator('#sensitivityTop3Content').inner_text()
        page.locator('#sensitivityTop3CloseBtn').click()
        page.locator('#modeOps').click()
        assert page.locator('#lotTraceSelect option').count() > 2
        assert not errors, errors
        checks[name] = dict(values=values, colors=colors, hover_status=True, priorities_include_grids=True, browser_errors=errors)
        page.close()
    page = browser.new_page(viewport={'width': 1700, 'height': 1100})
    page.goto(SOURCE.as_uri(), timeout=60000)
    page.evaluate("window.ETUDECAS_SINGLE_HTML.openView('views/carte_reseau_lots.html')")
    page.wait_for_timeout(1000)
    frame = page.frames[-1]
    frame.wait_for_function("typeof DATA !== 'undefined' && document.getElementById('chart').data", timeout=60000)
    frame.locator('#modeSensitivity').click()
    frame.evaluate("document.getElementById('chart').emit('plotly_click',{points:[{customdata:['SDC-VD0914690A','supplier_dc']}],event:{clientX:1000,clientY:300}})")
    frame.wait_for_function("document.querySelector('#factoryHoverPanel .js-plotly-plot')?.data?.length > 0")
    checks['reference'] = dict(source=str(SOURCE), sha256=before,
        tabs=frame.locator('#factoryHoverPanel .panelSubTab:visible').all_text_contents())
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == before
    (OUT / 'browser_checks.json').write_text(json.dumps(checks, indent=2), encoding='utf8')
    browser.close()
print(json.dumps(checks), flush=True)
