# Étude de sensibilité fournisseurs

Comparaisons conditionnelles aux données, au stock initial et aux hypothèses déclarées.
Une seule réalisation par variante : aucune probabilité de rupture ni incertitude statistique estimée.
Les coûts ne constituent pas une valorisation calibrée ; la comparaison porte sur le service par article.

## Exécutions

- reference : passed ; couverture des audits : partial.
- mill_a_unavailable : passed ; couverture des audits : partial.
- both_mills_unavailable : passed ; couverture des audits : partial.

## Variante mill_a_unavailable

## Comparaison du service simulé

Statut : passed. Écart = candidat − référence.

Les quantités restent séparées par site et article. La part servie inclut le backlog initial ; elle ne mesure pas le respect des dates promises.

| Site | Article | Unité | Écart demande nouvelle | Écart servi | Écart backlog final | Écart part servie |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| customer:assembly | item:BRACKET | UN | 0 | 0 | 0 | 0 |


## Variante both_mills_unavailable

## Comparaison du service simulé

Statut : passed. Écart = candidat − référence.

Les quantités restent séparées par site et article. La part servie inclut le backlog initial ; elle ne mesure pas le respect des dates promises.

| Site | Article | Unité | Écart demande nouvelle | Écart servi | Écart backlog final | Écart part servie |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| customer:assembly | item:BRACKET | UN | 0 | 0 | 0 | 0 |

