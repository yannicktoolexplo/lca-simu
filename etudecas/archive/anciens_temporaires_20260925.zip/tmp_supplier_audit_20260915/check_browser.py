﻿import json
from pathlib import Path
import re
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parent
SOURCE=Path('C:/dev/lca-simu-pr40-validation-artifacts-20260726/DEMONSTRATION_CONTEXTE_AUDITS_FOURNISSEURS_20260915_V3.html')
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True)
    page=browser.new_page(viewport=dict(width=1800,height=1200),accept_downloads=True)
    errors=[]
    page.on('pageerror',lambda e: errors.append(str(e)))
    page.goto(SOURCE.as_uri(),timeout=60000)
    page.locator('[data-standalone-view="views/carte_reseau_lots.html"]').first.click()
    view=page.frame_locator('#standaloneFrame')
    view.locator('#modeRisk').wait_for(timeout=60000)
    view.locator('#modeRisk').click()
    select=view.locator('#supplierAuditSelect')
    options=select.locator('option').evaluate_all('(o)=>o.map(x=>x.value).filter(Boolean)')
    assert len(options)==29,options
    checked=[]
    for supplier in options:
        select.select_option(supplier)
        view.locator('#incomingTabs').get_by_role('button',name=re.compile('^28 ')).click()
        assert view.locator('.supplierAuditCriteriaPanel tbody tr').count()==28,supplier
        checked.append(supplier)
    for supplier in ['SDC-VD0993480A','SDC-VD0960508A','SDC-VD0956464A']:
        select.select_option(supplier)
        view.locator('#incomingTabs').get_by_role('button',name='Contexte public',exact=True).click()
        assert view.locator('.supplierPublicContextPanel').is_visible()
        for radar in ['Radar maturité','Radar criticité','Radar résilience']:
            view.locator('#incomingTabs').get_by_role('button',name=radar,exact=True).click()
            plot=view.locator('#factoryIncomingFigure .js-plotly-plot')
            plot.wait_for()
            assert plot.evaluate('(p)=>p.data.some(t=>(t.r||[]).length>0)')
        view.locator('#incomingTabs').get_by_role('button',name='Criticité simulée',exact=True).click()
        assert view.locator('#factoryHoverPanel').is_visible()
    for mode in ['modeOps','modeSensitivity','modeSimulatedRisk','modeUncertainty','modeRisk']:
        view.locator('#'+mode).click()
    view.get_by_text('Sources contexte et audit',exact=True).click()
    with page.expect_download() as pending:
        view.get_by_role('link',name='trame_audit_fournisseur.xlsx',exact=True).click()
    download=pending.value
    assert download.failure() is None
    download.save_as(ROOT/'downloaded_template.xlsx')
    page.screenshot(path=str(ROOT/'audit_map.png'))
    assert not errors,[e[:200] for e in errors]
    browser.close()
(ROOT/'browser_checks.json').write_text(json.dumps(dict(status='passed',supplier_criteria_checked=checked,
    criteria_per_supplier=28,radars_and_public_context_checked=3,template_download=True,
    historical_modes_opened=5,browser_errors=errors),indent=2))
print('Browser checks passed')

