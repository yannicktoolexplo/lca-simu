import json
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parent))
from etudecas.experiment import execute_experiment
from etudecas.study_map import map_command

if __name__ == '__main__':
    folder = OUT / 'example'
    folder.mkdir(exist_ok=True)
    graph = json.loads((OUT.parent / 'tmp_initial_stock_sensitivity_20260911/example/graph.json').read_text())
    for e in graph['edges']:
        if e['from'] == 'supplier:mill_a':
            e['service_level'] = dict(otif=.8, source='synthetic_assumption')
    graph['meta']['description'] = 'Synthetic finite stock: 4 KG, 2 KG per 10 pieces. Nominal received fraction .8. No upstream replenishment. Not measured OTIF.'
    (folder / 'graph.json').write_text(json.dumps(graph, indent=2), encoding='utf8')
    common = dict(schema_version='etudecas.experiment.v1', input_graph='graph.json', scenario_id='scenario:reference',
        days=5, seed=1729, initialization='graph_stocks')
    main = dict(**common, variants=[dict(id='stop', perturbations=[dict(supplier_id='supplier:mill_a',
        kind='availability', factor=0, start_day=0, end_day=4)])])
    nominal = dict(**common, variants=[dict(id='reliability_'+str(int(f*100)), perturbations=[dict(
        supplier_id='supplier:mill_a', kind='nominal_reliability', factor=f, start_day=0, end_day=4)]) for f in [.25,.5,.75]])
    for name, protocol in [('primary', main), ('reliability', nominal)]:
        path = folder / (name+'.json')
        path.write_text(json.dumps(protocol, indent=2), encoding='utf8')
        assert execute_experiment(path, folder / name) == 0
    subprocess.run(map_command(folder/'primary/runs/reference', folder/'map',
        title='Exemple synthétique — fraction reçue et fiabilité nominale', sensitivity_study=folder/'primary',
        additional_sensitivity_studies=[folder/'reliability']), check=True, cwd=OUT.parent)
