import csv
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT / 'experiment'
OLD = OUT.parent / 'tmp_all_suppliers_20260911/complete_experiment'
manifest = json.loads((ROOT/'experiment_manifest.json').read_text())
if manifest['runs'][0]['status'] != 'passed':
    print('Reference still running')
    raise SystemExit(0)
base_graph = json.loads((ROOT/'runs/reference/simulation/inputs/simulation_input.json').read_text())
assert base_graph == json.loads((OLD/'runs/reference/simulation/inputs/simulation_input.json').read_text())
assert manifest['engine_entry_sha256'] == json.loads((OLD/'experiment_manifest.json').read_text())['engine_entry_sha256']
files = ['production_demand_service_daily.csv', 'production_input_stocks_daily.csv',
    'production_output_products_daily.csv', 'production_supplier_shipments_daily.csv', 'production_campaigns.csv',
    'production_constraint_daily.csv', 'mrp_orders_daily.csv']
for name in files:
    assert (ROOT/'runs/reference/simulation/data'/name).read_bytes() == (OLD/'runs/reference/simulation/data'/name).read_bytes(), name
summaries = [json.loads((p/'runs/reference/simulation/summaries/first_simulation_summary.json').read_text()) for p in [ROOT,OLD]]
assert summaries[0]['kpis'] == summaries[1]['kpis']
service = json.loads((ROOT/'runs/reference/service_metrics.json').read_text())['rows']
baseline = {(r['node_id'],r['item_id'],r['uom']):r for r in service}
supplier_ids = {n['id'] for n in base_graph['nodes'] if n['type']=='supplier_dc'}
base_lanes = {e['id']:e for e in base_graph['edges'] if e['from'] in supplier_ids and e.get('items')}
with (ROOT/'runs/reference/simulation/data/supplier_nominal_parameters.csv').open() as stream:
    reference_lanes={(r['edge_id'],r['item_id']):r for r in csv.DictReader(stream)}
rows=[]
for run in manifest['runs'][1:]:
    if run['status']!='passed': continue
    p=run['perturbations'][0]
    folder=ROOT/run['path']/'simulation'
    with (folder/'data/supplier_nominal_parameters.csv').open() as stream:
        actual=list(csv.DictReader(stream))
    assert {r['edge_id'] for r in actual}==set(base_lanes)
    flow_changes=[]
    for r in actual:
        edge=base_lanes[r['edge_id']]
        f=p['factor'] if edge['from']==p['supplier_id'] else 1
        expected=round(min(1,max(.01,edge['service_level']['otif']*f)),6)
        assert float(r['nominal_reliability_otif'])==expected,(run['id'],r['edge_id'])
        assert float(r['planned_lead_time_days'])==edge['lead_time']['mean']
        if edge['from']==p['supplier_id']:
            ref=reference_lanes[(r['edge_id'],r['item_id'])]
            difference={k:float(r[k])-float(ref[k]) for k in ['total_pulled_qty','total_shipped_qty']}
            if any(abs(v)>1e-6 for v in difference.values()):
                flow_changes.append(dict(edge_id=r['edge_id'],item_id=r['item_id'],uom=r['uom'],**difference))
    graph=json.loads((folder/'inputs/simulation_input.json').read_text())
    assert graph['nodes']==base_graph['nodes'], 'Stocks, capacities or node rules changed'
    summary=json.loads((folder/'summaries/first_simulation_summary.json').read_text())
    assert summary['policy']['supplier_risk']['event_count']==0
    degraded=[]
    for r in json.loads((ROOT/run['path']/'service_metrics.json').read_text())['rows']:
        key=r['node_id'],r['item_id'],r['uom']; ref=baseline[key]
        if r['requirement_served_fraction']<ref['requirement_served_fraction']-1e-9 or r['backlog_quantity_days']>ref['backlog_quantity_days']+3e-6*manifest['days']:
            degraded.append(dict(client=key[0],item=key[1],uom=key[2],delivered_fraction=r['requirement_served_fraction'],
                final_backlog=r['final_backlog_qty'],extra_waiting_quantity_days=r['backlog_quantity_days']-ref['backlog_quantity_days']))
    rows.append(dict(id=run['id'],supplier=p['supplier_id'],factor=p['factor'],resolved_lanes_checked=len(actual),
        no_injected_events=True,node_inputs_unchanged=True,degraded_service=degraded,flow_changes=flow_changes))
report=dict(status=manifest['status'],run_status_counts=dict(Counter(r['status'] for r in manifest['runs'])),
    nominal_graph_identical=True,nominal_kpis_identical=True,nominal_exports_identical=files,
    engine_entry_identical=True,variants_completed=len(rows),suppliers_checked=len({r['supplier'] for r in rows}),
    suppliers_with_degraded_service=sorted({r['supplier'] for r in rows if r['degraded_service']}),
    suppliers_with_changed_flows=sorted({r['supplier'] for r in rows if r['flow_changes']}),variants=rows)
(OUT/'result_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in report.items() if k!='variants'}),flush=True)
