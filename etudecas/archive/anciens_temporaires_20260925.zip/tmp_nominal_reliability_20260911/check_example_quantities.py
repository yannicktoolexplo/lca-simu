import csv
import json
from pathlib import Path

OUT=Path(__file__).resolve().parent
rows=[]
for name,fraction in [('reliability_25',.2),('reliability_50',.4),('reliability_75',.6),('reference',.8)]:
    run=OUT/'example/reliability/runs'/name
    with (run/'simulation/data/production_supplier_shipments_daily.csv').open() as stream:
        shipments=[r for r in csv.DictReader(stream) if r['src_node_id']=='supplier:mill_a']
    pulled=sum(float(r['pulled_qty']) for r in shipments)
    shipped=sum(float(r['shipped_qty']) for r in shipments)
    assert pulled==4 and abs(shipped-4*fraction)<1e-9
    assert all(float(r['reliability'])==fraction and r['uom']=='KG' for r in shipments)
    with (run/'simulation/data/production_input_stocks_daily.csv').open() as stream:
        stock=[r for r in csv.DictReader(stream) if r['node_id']=='site:bracket_factory' and r['item_id']=='item:SHEET']
    final=float(stock[-1]['stock_end_of_day'])
    service=json.loads((run/'service_metrics.json').read_text())['rows'][0]
    delivered=service['served_qty']
    assert abs(shipped-delivered*.2-final)<1e-9
    theoretical=round(shipped/.2)
    assert theoretical-delivered==(1 if name=='reliability_75' else 0)
    rows.append(dict(run=name,received_fraction=fraction,pulled_kg=pulled,received_kg=shipped,
        delivered_pieces=delivered,theoretical_pieces=theoretical,remaining_kg=final))
report=dict(status='received_quantities_verified_production_rounding_defect_identified',rows=rows)
(OUT/'example_quantity_checks.json').write_text(json.dumps(report,indent=2),encoding='utf8')
print(json.dumps(report))
