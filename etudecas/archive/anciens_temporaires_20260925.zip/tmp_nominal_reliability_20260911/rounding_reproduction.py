"""Reproduce a pre-existing whole-piece boundary defect without a simulation."""
from decimal import Decimal
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parent))
from etudecas.simulation.lot_policy.engine_adapter import normalize_physical_quantity

stock = 4 * .6 - 10 * .2
possible = stock / .2
executed = normalize_physical_quantity(possible, 'UN', rounding='down')
remaining = stock - executed * .2
assert executed == 1 and normalize_physical_quantity(remaining / .2, 'UN', rounding='down') == 0
exact_possible = (Decimal('4') * Decimal('.6') - Decimal('10') * Decimal('.2')) / Decimal('.2')
assert exact_possible == 2
report = dict(status='known_defect_reproduced', stock_internal=stock, possible_internal=possible,
    executed_actual=executed, exact_possible=int(exact_possible), stranded_material=remaining,
    significance='One otherwise feasible whole piece is lost at a floating-point boundary; not a business shortage.',
    engine_changed=False)
(OUT/'rounding_defect.json').write_text(json.dumps(report,indent=2),encoding='utf8')
print(json.dumps(report))
