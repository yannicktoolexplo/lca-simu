import hashlib
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
SOURCE = Path('C:/dev/lca-simu-pr40-validation-artifacts-20260726/DEMONSTRATION_SUPPLY_CHAIN_AUTONOME_FICHIER_UNIQUE_20260831.html')
original_hash = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
report = {'reference': str(SOURCE), 'reference_sha256': original_hash}
with sync_playwright() as pw:
    browser = pw.chromium.launch(headless=True)
    page = browser.new_page(viewport={'width': 1700, 'height': 1100})
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.goto(SOURCE.as_uri(), timeout=60000)
    page.evaluate("window.ETUDECAS_SINGLE_HTML.openView('views/carte_reseau_lots.html')")
    page.wait_for_timeout(1000)
    frame = page.frames[-1]
    frame.wait_for_function("typeof DATA !== 'undefined' && document.getElementById('chart').data", timeout=60000)
    frame.locator('#modeSensitivity').click()
    frame.evaluate("document.getElementById('chart').emit('plotly_click',{points:[{customdata:['SDC-VD0914690A','supplier_dc']}],event:{clientX:1000,clientY:300}})")
    frame.wait_for_function("document.querySelector('#factoryHoverPanel .js-plotly-plot')?.data?.length > 0")
    report['historical_sensitivity'] = dict(
        supplier_panels=frame.evaluate('Object.keys(DATA.supplier_sensitivity_hover_images).length'),
        tabs=frame.locator('#factoryHoverPanel .panelSubTab:visible').all_text_contents(),
        plot_count=frame.locator('#factoryHoverPanel .js-plotly-plot').count())
    page.screenshot(path=str(OUT / 'reference_sensitivity.png'))
    assert not errors, errors
    page.close()
    page = browser.new_page(viewport={'width': 1700, 'height': 1100})
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.goto((OUT / 'annual_final/maps/reference/map.html').as_uri(), timeout=60000)
    page.wait_for_function("typeof DATA !== 'undefined' && document.getElementById('chart').data", timeout=60000)
    page.locator('#modeSensitivity').click()
    assert not page.locator('#sensitivityTop3Modal').is_visible()
    page.evaluate("document.getElementById('chart').emit('plotly_click',{points:[{customdata:['SDC-VD0914360C','supplier_dc']}],event:{clientX:1000,clientY:300}})")
    page.wait_for_function("document.querySelector('#fourthBlock .js-plotly-plot')?.data?.length === 2")
    assert page.locator('#fourthBlock').is_visible()
    costs = page.evaluate("document.querySelector('#fourthBlock .js-plotly-plot').data.map(t=>t.y)")
    summaries = [json.loads((ROOT / f'tmp_annual_sensitivity_20260910/experiment/runs/{run}/simulation/summaries/first_simulation_summary.json').read_text(encoding='utf8')) for run in ['supplier_stop', 'reference']]
    assert costs[0] == [s['kpis']['total_supply_cost_accounting'] for s in summaries]
    assert costs[1] == [s['kpis']['total_production_cost'] for s in summaries]
    assert costs[0][0] < costs[0][1]
    assert page.evaluate("DATA.supplier_parameter_sensitivity_nodes['SDC-VD0914360C'].status") == 'sensitive'
    page.locator('#thirdBlock .panelSubTab').filter(has_text='Disponibilité fournisseur · M-1810 / item:268091 · Production').click()
    page.wait_for_timeout(200)
    quantities = page.evaluate("document.querySelector('#thirdBlock .js-plotly-plot').data.map(t=>t.y)")
    assert quantities == [[411600, 1656000], [98, 0]]
    page.locator('#thirdBlock .panelSubTab').filter(has_text='Disponibilité fournisseur · M-1810 / item:268091 · Retards').click()
    page.wait_for_timeout(200)
    delays = page.evaluate("document.querySelector('#thirdBlock .js-plotly-plot').data.map(t=>t.y)")
    assert delays == [[1, 0], [99, 0]]
    page.locator('#thirdBlock').scroll_into_view_if_needed()
    page.screenshot(path=str(OUT / 'current_production_delays.png'))
    page.locator('#incomingBlock .panelSubTab').filter(has_text='Production · Disponibilité fournisseur').click()
    assert 'in_progress_delayed' in page.locator('#incomingBlock').inner_text()
    assert '6000 UN' in page.locator('#incomingBlock').inner_text()
    # Exercise every added cost subview; the final tab contains explicit source limits.
    tabs = page.locator('#fourthBlock .panelSubTab')
    assert tabs.count() == 13
    for i in range(tabs.count()):
        tabs.nth(i).click()
        page.wait_for_timeout(80)
    assert 'valeur immobilisée' in page.locator('#fourthBlock').inner_text()
    tabs.first.click()
    page.locator('#fourthBlock').scroll_into_view_if_needed()
    page.screenshot(path=str(OUT / 'current_costs.png'))
    report['current_sensitivity'] = dict(cost_curves=12, costs=costs,
        production_quantity_and_unserved_days=quantities, delayed_campaigns_and_days=delays,
        ongoing_delayed_campaign_visible=True, lower_cost_not_classified_as_improvement=True)
    page.locator('#factoryHoverClearSelection').click()
    page.locator('#modeOps').click()
    assert page.locator('#lotTraceSelect option').count() > 2
    assert not errors, errors
    report['browser_errors'] = errors
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == original_hash
    report['reference_unchanged'] = True
    (OUT / 'browser_checks.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    browser.close()
print(json.dumps(report, ensure_ascii=True), flush=True)
