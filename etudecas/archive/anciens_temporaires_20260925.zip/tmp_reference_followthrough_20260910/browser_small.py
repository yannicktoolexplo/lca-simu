import json
from pathlib import Path
import sys
from playwright.sync_api import sync_playwright

atlas = Path(sys.argv[1]).resolve()
output = Path(__file__).resolve().parent
results = {}
with sync_playwright() as pw:
    browser = pw.chromium.launch(headless=True)
    for run in ['reference', 'mill_a_unavailable', 'both_mills_unavailable']:
        page = browser.new_page(viewport={'width': 1700, 'height': 1100})
        errors = []
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.goto((atlas / 'maps' / run / 'map.html').as_uri(), timeout=60000)
        page.wait_for_function("typeof DATA !== 'undefined' && document.getElementById('chart').data")
        page.locator('#modeSensitivity').click()
        page.evaluate("document.getElementById('chart').emit('plotly_click',{points:[{customdata:['supplier:mill_a','supplier_dc']}],event:{clientX:1000,clientY:300}})")
        page.wait_for_function("document.querySelector('#fourthBlock .js-plotly-plot')?.data?.length === 2")
        assert page.locator('#fourthBlock').is_visible()
        assert 'EUR' in page.locator('#fourthBlock').inner_text()
        assert 'KG' in page.locator('#thirdBlock').inner_text()
        tab = page.locator('#thirdBlock .panelSubTab').filter(has_text='Perturbations simultanées · site:bracket_factory / item:BRACKET · Production')
        tab.click()
        page.wait_for_timeout(150)
        values = page.evaluate("document.querySelector('#thirdBlock .js-plotly-plot').data.map(t=>t.y)")
        assert values[0][1] < values[0][0]
        assert 'UN' in page.locator('#thirdBlock').inner_text()
        assert not errors, errors
        results[run] = dict(costs_EUR_visible=True, supplier_KG_separate_from_production_UN=True,
                            production_and_unserved_days=values, browser_errors=errors)
        page.close()
    browser.close()
(output / 'assembly_browser_checks.json').write_text(json.dumps(results, indent=2), encoding='utf8')
print(json.dumps(results))
