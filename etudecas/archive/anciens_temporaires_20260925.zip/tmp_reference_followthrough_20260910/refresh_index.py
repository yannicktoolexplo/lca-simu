"""Refresh only the atlas reading note; retain all validated map fingerprints."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from etudecas.visualization.maps.experiment_atlas import render_experiment_atlas

output = Path(__file__).resolve().parent / 'annual_final'
path = output / 'atlas_manifest.json'
manifest = json.loads(path.read_text(encoding='utf8'))
assert manifest['status'] == 'passed'
for record in manifest['maps']:
    assert hashlib.sha256((output / record['path']).read_bytes()).hexdigest() == record['sha256']
attachment = json.loads((output / 'attachment.json').read_text(encoding='utf8'))
index = output / 'index.html'
index.write_text(render_experiment_atlas(attachment, title='Sensibilité fournisseurs'), encoding='utf8')
manifest['index_sha256'] = hashlib.sha256(index.read_bytes()).hexdigest()
path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf8')
print('Atlas note updated; all four map fingerprints unchanged.')
