from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).parent/'atlas'
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True)
    page=browser.new_page(viewport={'width':1550,'height':1100})
    errors=[]
    page.on('pageerror',lambda error:errors.append(str(error)))
    page.goto((root/'index.html').resolve().as_uri())
    assert page.locator('#uncertainty-summary tbody tr').count()==3
    assert page.locator('#run-choice option').count()==4
    assert '4 tirages' in page.locator('#uncertainty-summary').inner_text()
    page.locator('#run-choice').select_option('draw_0003')
    frame=page.locator('#run-map').element_handle().content_frame()
    frame.wait_for_function("typeof DATA !== 'undefined' && DATA.map_sources && DATA.run_contract.output_dir.includes('draw_0003')",timeout=30000)
    assert frame.evaluate('DATA.map_sources.lot_trace_enabled') is True
    page.locator('#run-map').scroll_into_view_if_needed()
    frame.locator('#modeOps').wait_for(state='visible',timeout=30000)
    frame.locator('.js-plotly-plot .main-svg').first.wait_for(state='visible',timeout=30000)
    print('Rendered plot count',frame.locator('.js-plotly-plot').count())
    page.screenshot(path=str(root/'uncertainty-preview.png'),full_page=True)
    print('All-sample summary displayed; 4 map choices; third draw lots verified.')
    print('Browser errors',errors)
    browser.close()
    if errors: raise SystemExit(2)
