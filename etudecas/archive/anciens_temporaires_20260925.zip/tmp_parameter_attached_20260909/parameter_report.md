# Paramètres de l'étude

## Provenance des paramètres du modèle

Statut : partial. 22 paramètres reliés sur 22 inventoriés.
Les valeurs renseignées sans preuve restent non documentées ; les défauts connus restent des hypothèses.

| Famille | Paramètre | Valeur | Unité | Statut déclaré | Référence |
| --- | --- | ---: | --- | --- | --- |
| lead_time | edges/0/lead_time/mean | 1 | day | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| purchase_cost | edges/0/order_terms/price_base | 1 | KG | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| purchase_cost | edges/0/order_terms/sell_price | 3 | currency | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| transport_cost | edges/0/transport_cost/value | 0.1 | currency | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| lead_time | edges/1/lead_time/mean | 2 | day | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| purchase_cost | edges/1/order_terms/price_base | 1 | KG | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| purchase_cost | edges/1/order_terms/sell_price | 3.5 | currency | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| transport_cost | edges/1/transport_cost/value | 0.1 | currency | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| lead_time | edges/2/lead_time/mean | 1 | day | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| purchase_cost | edges/2/order_terms/price_base | 1 | UN | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| purchase_cost | edges/2/order_terms/sell_price | 5 | currency | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| transport_cost | edges/2/transport_cost/value | 0.1 | currency | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| holding_cost | nodes/0/inventory/states/0/holding_cost/value | 0.01 | currency | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| holding_cost | nodes/1/inventory/states/0/holding_cost/value | 0.01 | currency | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| holding_cost | nodes/2/inventory/states/0/holding_cost/value | 0.01 | currency | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| holding_cost | nodes/2/inventory/states/1/holding_cost/value | 0.01 | currency | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| capacity | nodes/2/processes/0/capacity/max_rate | 10 | UN/day | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| holding_cost | nodes/3/inventory/states/0/holding_cost/value | 0.01 | currency | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| economic_policy | scenarios/0/economic_policy/inventory_capital_cost_share_of_raw_holding | 0.35 | dimensionless | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| economic_policy | scenarios/0/economic_policy/inventory_risk_cost_share_of_raw_holding | 0.2 | dimensionless | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| production_cost | scenarios/0/economic_policy/production_cost_unit_rates/site:bracket_factory\|item:BRACKET | 2 | currency/catalog_quantity_unit | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |
| economic_policy | scenarios/0/economic_policy/warehouse_operating_cost_share_of_raw_holding | 0.45 | dimensionless | synthetic | etudecas/config/cases/assembly_demo.json: synthetic engineering fixture |

Défauts économiques connus appliqués : 6 (détails dans le JSON).
Ces déclarations ne prouvent ni la calibration ni la validité prédictive du modèle.

Le modèle de déclaration contient des champs vides à compléter. Aucun statut observé n'est inféré.
