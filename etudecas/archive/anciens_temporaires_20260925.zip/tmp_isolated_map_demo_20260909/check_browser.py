from pathlib import Path
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page(viewport={"width": 1400, "height": 950})
    errors = []
    page.on("pageerror", lambda error: errors.append(str(error)))
    page.goto((Path(__file__).parent / "final_view/map.html").resolve().as_uri())
    page.wait_for_function('typeof DATA !== "undefined" && DATA.nodes && DATA.nodes.length === 4', timeout=30000)
    assert page.locator("#modeSensitivity").is_disabled()
    assert page.locator("#modeOps").inner_text() == "Run s\u00e9lectionn\u00e9"
    page.locator("#map-source-report summary").click()
    page.screenshot(path=str(Path(__file__).parent / "final_view/map-preview.png"))
    print("Browser errors:", errors)
    print("Source panel:", page.locator("#map-source-report").inner_text())
    browser.close()
    if errors:
        raise SystemExit(2)
