import json
from pathlib import Path
from playwright.sync_api import sync_playwright

OUT=Path(__file__).parent
ROOT=OUT.parent
FULL=ROOT/'etudecas/simulation/result/_reruns/active_state_dependent_extended_5y_20260715/maps/supply_graph_active_state_dependent_extended_5y_20260715.html'
SCAN=Path('C:/dev/lca-simu-pr40-validation-artifacts-20260726/supplychain_worldmap_resilience_scan_closed_loop_v3_frequency_control_system_20260827_v14.html')

def capture(page,label):
 page.wait_for_timeout(450)
 text=page.locator('body').inner_text()
 page.screenshot(path=str(OUT/(label+'.png')))
 return {'text':text,'visible_plots':page.locator('.js-plotly-plot:visible').evaluate_all('(els)=>els.map(e=>({id:e.id,traces:e.data?.length,title:e.layout?.title?.text}))'),'visible_tabs':page.locator('.panelSubTab:visible').all_text_contents()}

def node(page,node_id):
 page.evaluate('''id=>{
 const chart=document.getElementById('chart');
 for(let i=0;i<chart.data.length;i++) {
  const t=chart.data[i]; const j=(t.customdata||[]).findIndex(c=>c[0]===id);
  if(j>=0){chart.emit('plotly_click',{points:[{customdata:t.customdata[j],curveNumber:i,pointNumber:j,data:t}],event:{clientX:1000,clientY:300}});return;}
 }
 throw Error('No selectable point '+id);
 }''',node_id)
 page.locator('#factoryHoverPanel.visible').wait_for()

with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True)
 page=browser.new_page(viewport={'width':1700,'height':1100})
 errors=[]
 page.on('pageerror',lambda exc:errors.append(str(exc)))
 page.goto(FULL.as_uri(),timeout=60000)
 page.wait_for_function("typeof DATA !== 'undefined' && DATA.nodes && document.getElementById('chart').data",timeout=60000)
 page.wait_for_timeout(700)
 result={'source':str(FULL),'checks':{},'errors':errors}
 for mode,ident in [('modeOps','M-1430'),('modeSensitivity','SDC-VD0914690A'),('modeSimulatedRisk','M-1810'),('modeRisk','SDC-VD0914690A'),('modeUncertainty','SDC-VD0914690A')]:
  clear=page.locator('#factoryHoverClearSelection')
  if clear.is_visible():clear.click()
  page.locator('#'+mode).click()
  page.wait_for_timeout(400)
  node(page,ident)
  result['checks'][mode]=capture(page,'detail_'+mode)
  # Exercise actual subtab controls, including figures, without changing simulations.
  tabs=page.locator('.panelSubTab:visible').all_text_contents()
  result['checks'][mode]['tab_visits']=[]
  for label in list(dict.fromkeys(tabs))[:18]:
   tab=page.locator('.panelSubTab:visible').filter(has_text=label).first
   if tab.count():
    tab.click();page.wait_for_timeout(150)
    result['checks'][mode]['tab_visits'].append({'label':label,'plots':page.locator('#factoryHoverPanel .js-plotly-plot:visible').count()})
  clear=page.locator('#factoryHoverClearSelection')
  if clear.is_visible():clear.click()
  if mode=='modeSensitivity':
   page.locator('#sensitivityTop3Btn').click()
   result['checks']['priorities']=capture(page,'sensitivity_priorities')
   page.locator('#sensitivityTop3CloseBtn').click()
  if mode=='modeUncertainty':
   page.locator('#monteCarloBtn').click()
   result['checks']['montecarlo']=capture(page,'montecarlo_curves')
   page.locator('#monteCarloCloseBtn').click()
 page.locator('#modeOps').click()
 page.locator('#lotTraceSelect').select_option(index=1)
 page.locator('#lotTraceOpenBtn').click()
 result['checks']['lot_trace']=capture(page,'lot_trace')
 page.locator('#lotTraceModalCloseBtn').click()
 page.locator('#kpiTreeBtn').click()
 result['checks']['kpi_tree']=capture(page,'kpi_tree')
 (OUT/'browser_features.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 print('Full map checks',list(result['checks']),'errors',errors,flush=True)
 page.close()
 page=browser.new_page(viewport={'width':1700,'height':1100})
 page.on('pageerror',lambda exc:errors.append(str(exc)))
 page.goto(SCAN.as_uri(),timeout=60000)
 page.wait_for_function("typeof DATA !== 'undefined' && DATA.scan_dashboard?.available",timeout=60000)
 page.locator('#scanDashboardBtn').click()
 result['scan']={}
 for tab in ['summary','curves','policies','closed-loop','closed-loop-v2','frequency','control-system']:
  page.locator(f'[data-scan-dashboard-tab="{tab}"]').click()
  result['scan'][tab]=capture(page,'scan_'+tab)
  result['scan'][tab]['visible_images']=page.locator('#scanDashboardModal img:visible').count()
 (OUT/'browser_features.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 print('SCAN checks',list(result['scan']),'errors',errors,flush=True)
 browser.close()
