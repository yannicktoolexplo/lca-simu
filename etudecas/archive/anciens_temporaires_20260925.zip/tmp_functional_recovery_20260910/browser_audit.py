import json
from pathlib import Path
from playwright.sync_api import sync_playwright

OUT=Path(__file__).parent
ROOT=OUT.parent
PAGES={
 'july':ROOT/'etudecas/simulation/result/_lot_truck_5y_fixed_20260725/maps/supply_graph_lot_truck_5y_fixed.html',
 'scan':Path('C:/dev/lca-simu-pr40-validation-artifacts-20260726/supplychain_worldmap_resilience_scan_closed_loop_v3_frequency_control_system_20260827_v14.html'),
}
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True)
 results={}
 for name,path in PAGES.items():
  page=browser.new_page(viewport={'width':1600,'height':1000})
  errors=[]
  page.on('pageerror',lambda exc:errors.append(str(exc)))
  page.goto(path.as_uri(),wait_until='load',timeout=60000)
  page.wait_for_function("typeof DATA !== 'undefined' && DATA.nodes && document.querySelector('.js-plotly-plot')",timeout=60000)
  page.wait_for_timeout(1200)
  result={'path':str(path),'errors':errors,'modes':{},'controls':page.locator('select').evaluate_all('(els)=>els.map(e=>({id:e.id,options:[...e.options].slice(0,8).map(o=>({v:o.value,t:o.text}))}))')}
  for mode in ['modeOps','modeSensitivity','modeSimulatedRisk','modeRisk','modeUncertainty']:
   page.locator('#'+mode).click()
   page.wait_for_timeout(400)
   result['modes'][mode]={'disabled':page.locator('#'+mode).is_disabled(),'visible_buttons':page.locator('button:visible').all_text_contents(),'modals':page.locator('.modal.visible').count(),'plot_traces':page.locator('.js-plotly-plot').evaluate_all('(els)=>els.map(e=>({id:e.id,traces:e.data?.length}))')}
   page.screenshot(path=str(OUT/(name+'_'+mode+'.png')))
  if name=='scan':
   page.locator('#scanDashboardBtn').click()
   page.wait_for_timeout(500)
   result['scan_text']=page.locator('#scanDashboardModal').inner_text()
   result['scan_buttons']=page.locator('#scanDashboardModal button').evaluate_all('(els)=>els.map(e=>({text:e.textContent,attrs:[...e.attributes].map(a=>[a.name,a.value])}))')
   page.screenshot(path=str(OUT/'scan_dashboard.png'))
  result['data_summary']=page.evaluate("Object.fromEntries(Object.entries(DATA).filter(([k])=>/sensitivity|uncertainty|lot_trace|scan_dashboard/.test(k)).map(([k,v])=>[k,{keys:Object.keys(v||{}),available:v?.available}]))")
  results[name]=result
  (OUT/'browser_audit.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
  print(name,'errors',errors,'controls',result['controls'],flush=True)
  page.close()
 browser.close()
