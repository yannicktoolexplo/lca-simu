"""Exercise the current viewer with unchanged archived analysis payloads."""
import hashlib
import json
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright
from inventory import payload

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from etudecas.visualization.maps.worldmap_html_template import html_template
from etudecas.visualization.maps.compress_html_payload import compress_embedded
from etudecas.visualization.maps.simulation_payload import render_material_balance_table_html

OUT=Path(__file__).parent
SOURCES={
 'historical_analysis':ROOT/'etudecas/simulation/result/_reruns/active_state_dependent_extended_5y_20260715/maps/supply_graph_active_state_dependent_extended_5y_20260715.html',
 'historical_audit':ROOT/'etudecas/simulation/result/_lot_truck_5y_fixed_20260725/maps/supply_graph_lot_truck_5y_fixed.html',
 'historical_scan':Path('C:/dev/lca-simu-pr40-validation-artifacts-20260726/supplychain_worldmap_resilience_scan_closed_loop_v3_frequency_control_system_20260827_v14.html'),
}
results={}
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True)
 for name,source in SOURCES.items():
  raw=source.read_bytes()
  data=payload(raw.decode('utf-8'))
  table=data.get('material_balance_rows') or []
  rendered=html_template('VERIFICATION - donnees archivees / visualiseur actuel',json.dumps(data,ensure_ascii=False),render_material_balance_table_html(table),len(table),'Archive de verification du visualiseur : consulter les equations dans le fichier original.')
  compressed,_=compress_embedded(rendered)
  target=OUT/(name+'_current_viewer.html')
  target.write_text(compressed,encoding='utf-8')
  # No mutation of any numerical or per-node embedded payload.
  assert payload(compressed)==data
  page=browser.new_page(viewport={'width':1700,'height':1100})
  errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(target.as_uri(),timeout=60000)
  page.wait_for_function("typeof DATA !== 'undefined' && DATA.nodes && document.getElementById('chart').data",timeout=60000)
  if name=='historical_analysis':
   page.locator('#modeSensitivity').click()
   assert not page.locator('#sensitivityTop3Modal').is_visible(), 'Mode must leave the map available'
   page.evaluate("document.getElementById('chart').emit('plotly_click',{points:[{customdata:['SDC-VD0914690A','supplier_dc']}],event:{clientX:1000,clientY:300}})")
   page.locator('#factoryHoverPanel.visible').wait_for()
   page.wait_for_function("document.querySelector('#factoryHoverPanel .js-plotly-plot')?.data?.length > 0")
   assert '50%' in page.locator('#factoryHoverPanel').inner_text()
   page.screenshot(path=str(OUT/'current_sensitivity.png'))
   page.locator('#factoryHoverClearSelection').click()
   page.locator('#modeUncertainty').click()
   page.locator('#monteCarloBtn').click()
   page.wait_for_function("document.getElementById('mcTrajectoryService')?.data?.length > 100")
   page.locator('#monteCarloCloseBtn').click()
   page.locator('#modeSimulatedRisk').click()
   page.locator('#scenarioComparisonBtn').click()
   page.wait_for_timeout(700)
   assert page.locator('#scenarioComparisonModal .js-plotly-plot').count()>0
   results[name]={'sensitivity_map_and_node_curve':True,'no_forced_table':True,'montecarlo_trajectories':True,'scenario_comparison_figures':True}
  elif name=='historical_audit':
   page.locator('#modeRisk').click()
   page.locator('#supplierAuditSelect').select_option('SDC-VD0993480A')
   page.locator('#factoryHoverPanel.visible').wait_for()
   buttons=page.locator('.panelSubTab:visible').all_text_contents()
   results[name]={'audit_tabs':buttons,'coverage':data['supplier_audit_coverage']}
   for label in ['Contexte public','Maturite','Maturité','Criticite','Criticité','Resilience','Résilience']:
    tab=page.locator('.panelSubTab:visible').filter(has_text=label).first
    if tab.count():tab.click();page.wait_for_timeout(150)
   page.screenshot(path=str(OUT/'current_supplier_audit.png'))
   page.locator('#supplierAuditSelect').select_option('SDC-VD0518550B')
   assert 'SDC-VD0518550B' in page.locator('#factoryHoverTitle').inner_text()
   results[name]['unlocated_supplier_selectable']=True
  else:
   page.locator('#scanDashboardBtn').click()
   tabs=page.locator('[data-scan-dashboard-tab]')
   assert tabs.count()==7
   for i in range(tabs.count()):tabs.nth(i).click()
   results[name]={'scan_tabs':tabs.count()}
  assert not errors, errors
  assert hashlib.sha256(source.read_bytes()).hexdigest()==hashlib.sha256(raw).hexdigest()
  results[name].update({'source':str(source),'source_sha256':hashlib.sha256(raw).hexdigest(),'payload_unchanged':True,'browser_errors':errors})
  (OUT/'current_viewer_checks.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
  print(name,results[name],flush=True)
  page.close()
 browser.close()
