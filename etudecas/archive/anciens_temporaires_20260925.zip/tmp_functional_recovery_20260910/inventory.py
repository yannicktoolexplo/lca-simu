import ast
import base64
import gzip
import hashlib
import json
import os
import re
from pathlib import Path
from collections import Counter

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).parent

def payload(text):
    decoder = json.JSONDecoder()
    for marker, mode in [('const DATA_GZIP_BASE64_CHUNKS =', 'gzip'), ('const DATA_CHUNKED_GZIP_BASE64 =', 'chunks'), ('const DATA =', 'raw')]:
        pos = text.find(marker)
        if pos < 0:
            continue
        obj, _ = decoder.raw_decode(text[pos + len(marker):].lstrip())
        if mode == 'gzip':
            return json.loads(gzip.decompress(base64.b64decode(''.join(obj))))
        if mode == 'chunks':
            return {k: json.loads(gzip.decompress(base64.b64decode(''.join(v)))) for k,v in obj.items()}
        return obj
    return None

def describe(value, depth=0):
    result = {'type': type(value).__name__}
    if isinstance(value, (dict,list,str)):
        result['count'] = len(value)
    if isinstance(value, dict) and depth < 2:
        result['children'] = {k: describe(v, depth+1) for k,v in value.items()}
    elif isinstance(value, list) and value:
        result['first_fields'] = list(value[0]) if isinstance(value[0],dict) else str(value[0])[:90]
    return result

def main():
    # Follow Windows result junctions, visiting each physical directory once.
    seen_dirs = set()
    files = []
    skip = {'.git','.venv','.venv-brightway','venv','node_modules','.pytest_cache','__pycache__','.ruff_cache','.codex'}
    for folder, dirs, names in os.walk(ROOT, followlinks=True):
        resolved = str(Path(folder).resolve()).lower()
        if resolved in seen_dirs:
            dirs[:] = []
            continue
        seen_dirs.add(resolved)
        dirs[:] = [d for d in dirs if d not in skip]
        for name in names:
            if name.lower().endswith('.html'):
                p = Path(folder)/name
                if p.stat().st_size > 1_000_000:
                    files.append(p)
    rows = []
    for p in files:
        text = p.read_text(encoding='utf-8',errors='replace')
        if 'modeSensitivity' not in text and 'RESILIENCE-SCAN' not in text:
            continue
        row = {'path':str(p.relative_to(ROOT)).replace('\\','/'), 'bytes':p.stat().st_size, 'sha256':hashlib.sha256(p.read_bytes()).hexdigest(), 'scan_button':'scanDashboardBtn' in text}
        try:
            data = payload(text)
            if data is not None:
                row['keys'] = list(data)
                row['sizes'] = {k:len(v) if isinstance(v,(dict,list,str)) else v for k,v in data.items()}
                scan = data.get('scan_dashboard') or {}
                row['scan'] = {k:v for k,v in scan.items() if not isinstance(v,(list,dict)) and len(str(v))<500}
                if scan or 'lot_truck_5y_fixed.html' in p.name:
                    dest = OUT/(p.stem+'.payload_inventory.json')
                    dest.write_text(json.dumps(describe(data),ensure_ascii=False,indent=2),encoding='utf-8')
                    print(row['path'], row['bytes'], row['scan'],flush=True)
        except Exception as exc:
            row['error'] = str(exc)
        rows.append(row)
    (OUT/'html_inventory.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    print('HTML candidates',len(files),'maps/research',len(rows),flush=True)
    modules = []
    for p in (ROOT/'etudecas').rglob('*.py'):
        if any(x in p.parts for x in ('result','results','outputs','__pycache__')):
            continue
        text = p.read_text(encoding='utf-8-sig')
        row = {'path':str(p.relative_to(ROOT)).replace('\\','/'),'lines':len(text.splitlines())}
        try:
            tree = ast.parse(text)
            row['docstring'] = ast.get_docstring(tree)
            row['functions'] = [{'name':n.name,'line':n.lineno} for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))]
            row['imports'] = sorted({n.module or '' for n in ast.walk(tree) if isinstance(n,ast.ImportFrom)} | {a.name for n in ast.walk(tree) if isinstance(n,ast.Import) for a in n.names})
            row['cli'] = [a.value for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='add_argument' for a in n.args if isinstance(a,ast.Constant) and isinstance(a.value,str)]
        except Exception as exc:
            row['error'] = str(exc)
        modules.append(row)
    (OUT/'code_inventory.json').write_text(json.dumps(modules,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Python modules',len(modules),'lines',sum(r['lines'] for r in modules),'syntax failures',sum('error' in r for r in modules))

if __name__ == '__main__':
    main()
