import json
from pathlib import Path
from playwright.sync_api import sync_playwright

OUT=Path(__file__).parent
SOURCE=Path('C:/dev/lca-simu-pr40-validation-artifacts-20260726/DEMONSTRATION_SUPPLY_CHAIN_AUTONOME_FICHIER_UNIQUE_20260831.html')
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True)
 page=browser.new_page(viewport={'width':1600,'height':1000})
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(SOURCE.as_uri(),timeout=60000)
 result={'source':str(SOURCE),'views':{},'errors':errors}
 for path in ['views/carte_reseau_lots.html','views/carte_retard_338929_incident_lots.html','views/carte_qualite_incident_lots.html','views/resilience_scan_v3.html','views/incidents_risques_lots.html','views/stress_tests_incidents_lots.html','views/comparaison_mrp_v3.html','views/comparaison_reseau_mrp_v3.html']:
  page.evaluate('path=>window.ETUDECAS_SINGLE_HTML.openView(path)',path)
  page.wait_for_timeout(1000)
  frame=page.frames[-1]
  entry={'title':frame.title(),'text':frame.locator('body').inner_text()[:7000]}
  if frame.locator('#modeSensitivity').count():
   frame.wait_for_function("typeof DATA !== 'undefined' && DATA.nodes && document.getElementById('chart').data",timeout=60000)
   entry['modes']={}
   for mode in ['modeOps','modeSensitivity','modeSimulatedRisk','modeRisk','modeUncertainty']:
    frame.locator('#'+mode).click();frame.wait_for_timeout(150)
    entry['modes'][mode]={'disabled':frame.locator('#'+mode).is_disabled(),'plot_traces':frame.locator('#chart').evaluate('e=>e.data.length')}
   entry['payload']=frame.evaluate('''()=>({
    horizon:DATA.timeline_horizon_days,nominal_sites:Object.keys(DATA.factory_hover_images||{}).length,
    supplier_panels:Object.keys(DATA.supplier_sensitivity_hover_images||{}).length,
    montecarlo_available:DATA.montecarlo_uncertainty?.available,
    scan_available:DATA.scan_dashboard?.available,
    lot_keys:Object.keys(DATA.lot_trace||{}),
    risk_nodes:Object.keys(DATA.simulated_risk_metrics?.nodes||{}).length
   })''')
  page.screenshot(path=str(OUT/('portable_'+Path(path).stem+'.png')))
  result['views'][path]=entry
  page.evaluate('window.ETUDECAS_SINGLE_HTML.closeViewer()')
  (OUT/'browser_portable.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
  print(path,entry.get('payload',entry['title']),'errors',errors,flush=True)
 browser.close()
