from inventory import *

paths = [
 Path('C:/dev/lca-simu-pr40-validation-artifacts-20260726/supplychain_worldmap_resilience_scan_closed_loop_v3_frequency_control_system_20260827_v14.html'),
 Path('C:/dev/lca-simu-pr40-validation-artifacts-20260726/DEMONSTRATION_SUPPLY_CHAIN_AUTONOME_FICHIER_UNIQUE_20260831.html'),
 ROOT/'etudecas/simulation/result/_lot_truck_5y_fixed_20260725/maps/supply_graph_lot_truck_5y_fixed.html',
]
for p in paths:
 t = p.read_text(encoding='utf-8')
 d = payload(t)
 print(p.name, 'bytes',p.stat().st_size, 'data',bool(d))
 if not d:
  print(t[:1000])
  continue
 info = {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'payload':describe(d)}
 (OUT/(p.stem+'.payload_inventory.json')).write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({k:len(v) if isinstance(v,(dict,list,str)) else v for k,v in d.items()},ensure_ascii=False))
 for k in ['scan_dashboard','supplier_parameter_sensitivity_nodes','montecarlo_uncertainty','simulated_risk','simulation_diagnostics']:
  v=d.get(k)
  if v:
   print(k, str(v)[:1700])
 print('buttons',re.findall(r'<button[^>]*id="([^"]+)"[^>]*>(.*?)</button>',t,re.S)[-45:])
