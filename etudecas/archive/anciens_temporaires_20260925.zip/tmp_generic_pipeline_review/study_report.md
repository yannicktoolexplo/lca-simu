# Diagnostic de chaîne d’approvisionnement

Contrôles d’entrée : acceptés.

## Exposition fournisseurs

| Fournisseur | Couples destination/article | Sans autre source déclarée |
| --- | ---: | ---: |
| supplier:alpha | 2 | 1 |
| supplier:beta | 1 | 0 |

## Qualité des données

Aucune anomalie détectée par les contrôles implémentés.

## Limites d’interprétation

- Exposition structurelle déclarée : ne mesure ni probabilité de rupture ni impact aval.
- Une source alternative déclarée ne prouve pas sa qualification ou sa capacité disponible.
- Les quantités de différents articles et unités ne sont pas additionnées.
- La demande quotidienne absente est interprétée comme zéro lors de la conversion.
- Une simulation exploratoire exige calibration et validation sur observations avant décision.
- Le moteur conserve des hypothèses génériques de coûts et de politiques ; ses résultats économiques nécessitent un paramétrage métier explicite.
