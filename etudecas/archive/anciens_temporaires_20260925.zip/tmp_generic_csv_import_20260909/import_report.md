# Import de données de supply chain

Statut : passed

Stocks : seuls les couples déclarés sont remplacés. Demande : la population du scénario est remplacée.
Les statuts observé, estimé, hypothèse, proxy et synthétique restent des déclarations par valeur.


- Only imported stock and demand quantities have field-level lineage; topology, processes and policies remain from the base graph.
- Data status and source references are declarations, not verified evidence of observation.
- Stock rows replace only their explicit site/article targets; other base stocks remain unchanged.
- Demand import replaces the selected scenario's entire demand population.
- No timestamp alignment or empirical calibration is inferred.
