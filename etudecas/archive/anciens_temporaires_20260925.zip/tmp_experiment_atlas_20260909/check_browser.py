import json
from pathlib import Path
from playwright.sync_api import sync_playwright
root = Path(__file__).parent / 'atlas'
attachment = json.loads((root / 'attachment.json').read_text(encoding='utf8'))
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page(viewport={'width':1550,'height':1100})
    errors=[]
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.goto((root/'index.html').resolve().as_uri())
    for run in attachment['runs']:
        page.locator('#run-choice').select_option(run['id'])
        page.wait_for_function("id => document.querySelector('#run-map').getAttribute('src').includes('/'+id+'/')", arg=run['id'])
        frame = page.locator('#run-map').element_handle().content_frame()
        frame.wait_for_function("digest => typeof DATA !== 'undefined' && DATA.map_sources && DATA.map_sources.summary.sha256 === digest", arg=run['source_report']['summary']['sha256'], timeout=30000)
        assert frame.evaluate('DATA.nodes.length') == 4
        assert frame.evaluate('DATA.map_sources.lot_trace_enabled') is True
        assert page.locator('.run-detail:not([hidden])').get_attribute('data-run') == run['id']
        if run['id'] == 'both_mills_unavailable':
            assert frame.evaluate("DATA.map_sources.panels.simulated_risks") == 'selected_run'
            frame.locator('#modeSimulatedRisk').click()
        print('Verified run',run['id'])
    assert page.locator('#service-comparison tbody tr').count() == 2
    page.screenshot(path=str(root/'atlas-preview.png'),full_page=True)
    page.locator('#back-reference').click()
    assert page.locator('#run-choice').input_value() == 'reference'
    print('Browser errors', errors)
    browser.close()
    if errors: raise SystemExit(2)
