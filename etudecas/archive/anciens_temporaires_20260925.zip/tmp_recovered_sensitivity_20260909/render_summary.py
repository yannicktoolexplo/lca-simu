"""Create the shared reading page from completed, checked experiments."""
import html
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
escape = lambda value: html.escape(str(value))
parts = ['''<!doctype html><html lang="fr"><meta charset="utf-8">
<title>Sensibilité sur le cas corrigé</title>
<style>body{font:17px system-ui;max-width:1200px;margin:40px auto;padding:20px;color:#18354d}table{border-collapse:collapse;font-size:14px}td,th{border:1px solid #ccd4dd;padding:9px;text-align:left}.note{background:#fff0cb;padding:16px}a{color:#005b9a}</style>
<h1>Sensibilité sur le cas corrigé</h1>
<p>Mêmes données, démarrage à froid, règles MRP et conventions économiques. Chaque variante change un seul paramètre pendant 170 jours, avec la graine 1729 et les nombres aléatoires communs du moteur.</p>
<p class="note">Les variations de 20 % et l'arrêt complet sont des hypothèses d'essai, pas des probabilités d'incident. Le carnet initial reste protégé des perturbations. Un service inchangé ne suffit pas à conclure qu'un fournisseur est peu critique.</p>''']
for name, title in [
    ('tmp_recovered_sensitivity_20260909', 'Premier fournisseur : SDC-VD0520132A, article 038005'),
    ('tmp_active_supplier_sensitivity_20260909', 'Fournisseur actif : SDC-VD0914360C, packaging 338929')]:
    root = ROOT.parent / name
    manifest = json.loads((root / 'experiment/experiment_manifest.json').read_text(encoding='utf-8'))
    assert manifest['status'] == 'passed'
    link = '.' if root == ROOT else '../' + name
    parts += [f'<h2>{escape(title)}</h2><p><a href="{link}/atlas/index.html">Ouvrir les cartes et explorer les lots</a> · <a href="{link}/upstream_review.json">Flux fournisseurs et traces des perturbations</a></p>',
        '<table><tr><th>Variante</th><th>Article client</th><th>Unité</th><th>Servi référence</th><th>Servi variante</th><th>Écart servi</th><th>Écart backlog final</th><th>Écart attente cumulée (unité·jour)</th></tr>']
    for comparison in manifest['comparisons']:
        content = json.loads((root / 'experiment' / comparison['path']).read_text(encoding='utf-8'))
        for row in content['rows']:
            m = row['metrics']
            cells = [comparison['id'],row['item_id'],row['uom'],m['served_qty']['reference'],m['served_qty']['candidate'],m['served_qty']['delta'],m['final_backlog_qty']['delta'],m['backlog_quantity_days']['delta']]
            parts.append('<tr>'+''.join(f'<td>{escape(x)}</td>' for x in cells)+'</tr>')
    parts.append('</table><p>Quantités séparées par article. Le servi comprend les retards initiaux ; ce tableau ne mesure pas les livraisons à la date promise.</p>')
parts.append('''<h2>Ce que les contrôles établissent</h2><p>La nouvelle référence du premier essai reproduit exactement six fichiers de la référence précédente, dont les coûts, les cibles MRP, les stocks initiaux et les lots. <a href="reference_comparison.json">Voir la comparaison</a>.</p>
<p>43 tests réussis. Les simulations et les cartes ont leurs propres manifestes et audits ; une couverture partielle ne certifie pas toutes les données métier.</p>
<h2>Limites</h2><p>Un seul tirage par variante, deux fournisseurs examinés, aucun classement global et aucun Monte Carlo. Les réceptions planifiées après J169 sont hors de l'observation. Les coûts de production à 30 % sont répartis sur toute la période ; ils ne sont pas des factures journalières. Aucun taux de change ni modèle économique n'a été remplacé.</p></html>''')
with (ROOT / 'index.html').open('x', encoding='utf-8') as stream:
    stream.write('\n'.join(parts))
