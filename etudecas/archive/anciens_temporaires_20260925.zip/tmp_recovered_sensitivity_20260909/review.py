"""Reproduce the descriptive shipment review of this sensitivity experiment."""
import csv
from decimal import Decimal
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent
EXP = ROOT / 'experiment'
manifest = json.loads((EXP / 'experiment_manifest.json').read_text(encoding='utf-8'))
assert manifest['status'] == 'passed', 'An experiment with failed checks is not interpretable'
days = manifest['days']
report = {'days': days, 'runs': [], 'sources': {}, 'limitations': [
    'Simulated quantities, not observations or calibrated event probabilities.',
    'Shipments are separated by supplier, destination, article, unit and opening-order origin.',
    'Arrivals on or after the horizon are scheduled arrivals outside observation, not proven future receipts.',
    'Unshipped orders are absent from shipment totals; no inference of total outstanding orders.',
    'Opening carnet receipts are protected from the experimental supplier events.',
]}

def read(path):
    report['sources'][str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))

for run in manifest['runs']:
    data = EXP / run['path'] / 'simulation/data'
    grouped = {}
    for row in read(data / 'production_supplier_shipments_daily.csv'):
        key = tuple(row[k] for k in ('src_node_id', 'dst_node_id', 'item_id', 'uom')) + (
            'opening_carnet' if row['transport_cost_basis'] == 'opening_order_book' else 'simulated_shipment',)
        assert all(key), 'Missing identity or unit'
        qty = Decimal(row['shipped_qty'])
        assert qty.is_finite() and qty >= 0
        arrival = Decimal(row['arrival_day'])
        assert arrival.is_finite() and arrival == int(arrival)
        values = grouped.setdefault(key, dict(shipped_qty=Decimal(0), scheduled_arrival_outside_horizon_qty=Decimal(0), shipment_rows=0))
        values['shipped_qty'] += qty
        values['shipment_rows'] += 1
        if arrival >= days:
            values['scheduled_arrival_outside_horizon_qty'] += qty
    events = read(data / 'supplier_risk_events_applied_daily.csv')
    event_signatures = sorted({tuple(row[k] for k in ('supplier_id', 'capacity_multiplier', 'lead_time_multiplier', 'availability_multiplier')) for row in events})
    report['runs'].append(dict(id=run['id'], event_application_rows=len(events),
        applied_multiplier_signatures=[dict(zip(('supplier_id', 'capacity_multiplier', 'lead_time_multiplier', 'availability_multiplier'), sig)) for sig in event_signatures],
        shipments=[dict(zip(('supplier_id', 'destination_id', 'item_id', 'uom', 'origin'), key), **{k: str(v) if isinstance(v, Decimal) else v for k, v in values.items()}) for key, values in sorted(grouped.items())]))
with (ROOT / 'upstream_review.json').open('x', encoding='utf-8') as stream:
    json.dump(report, stream, indent=2)
print('Shipment review written; quantities remain separated by article and unit.')
