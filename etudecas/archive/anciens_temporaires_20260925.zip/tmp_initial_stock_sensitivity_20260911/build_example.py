import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from etudecas.experiment import execute_experiment
from etudecas.study_map import map_command

if __name__ == '__main__':
    out = Path(__file__).resolve().parent / 'example'
    out.mkdir(exist_ok=True)
    graph = json.loads((ROOT / 'etudecas/config/cases/assembly_demo.json').read_text())
    graph['nodes'] = [n for n in graph['nodes'] if n['id'] != 'supplier:mill_b']
    graph['edges'] = [e for e in graph['edges'] if e['from'] != 'supplier:mill_b']
    for n, geo in zip(graph['nodes'], [(47,-2), (48,1), (49,2)]):
        n['geo'] = dict(lat=geo[0], lon=geo[1])
        for state in n.get('inventory', {}).get('states', []):
            state['initial'] = 4 if n['id'] == 'supplier:mill_a' else 0
    graph['scenarios'][0]['economic_policy']['external_procurement_enabled'] = False
    graph['meta']['description'] = 'Synthetic finite supplier stock: 4 KG sheet, 2 KG per 10 brackets; no initial factory/customer stock or external replenishment. Five-day demonstration, not the real case.'
    (out / 'graph.json').write_text(json.dumps(graph, indent=2), encoding='utf8')
    common = dict(schema_version='etudecas.experiment.v1', input_graph='graph.json', scenario_id='scenario:reference',
                  days=5, seed=1729, initialization='graph_stocks')
    main = dict(**common, variants=[dict(id='stop', perturbations=[dict(supplier_id='supplier:mill_a',
                kind='availability', factor=0, start_day=0, end_day=4)])])
    stock = dict(**common, variants=[dict(id='stock_'+str(int(f*100)), perturbations=[dict(supplier_id='supplier:mill_a',
                kind='initial_stock', factor=f, start_day=0, end_day=4)]) for f in [.25,.5,.75]])
    for name, protocol in [('primary', main), ('stock', stock)]:
        path = out / (name+'.json')
        path.write_text(json.dumps(protocol, indent=2), encoding='utf8')
        assert execute_experiment(path, out / name) == 0
    subprocess.run(map_command(out / 'primary/runs/reference', out / 'map',
        title='Exemple synthétique — stock initial fournisseur', sensitivity_study=out / 'primary',
        additional_sensitivity_studies=[out / 'stock']), cwd=ROOT, check=True)
