import json
from pathlib import Path
import re
import sys
from playwright.sync_api import sync_playwright

OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT.parent))
from etudecas.test_experiment_map import decode_map
mode=sys.argv[1] if len(sys.argv)>1 else 'example'
source=OUT/('map/map.html' if mode=='real' else 'example/map_final/map.html')
data=decode_map(source)
attachment=data['sensitivity_attachment']
assert len(attachment['campaigns'])==2
if mode=='real':
    old=decode_map(OUT.parent/'tmp_all_suppliers_20260911/atlas/maps/reference/map.html')
    assert attachment['group_count']==108 and len(attachment['run_sources'])==163
    assert len(attachment['supplier_coverage'])==29
    for supplier,panel in old['supplier_sensitivity_hover_images'].items():
        new=data['supplier_sensitivity_hover_images'][supplier]
        for key in ['outgoing','third','fourth']:
            for entry in panel.get(key,{}).get('bundle',[]):
                if 'figure' in entry.get('asset',{}):
                    assert entry in new[key]['bundle'],(supplier,key,entry['label'])
    supplier='SDC-VD0956464A'
    expected_initial=[45,90,135,180]
else:
    supplier='supplier:mill_a'
    expected_initial=[1,2,3,4]
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True)
    page=browser.new_page(viewport=dict(width=1700,height=1100))
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto(source.as_uri(),timeout=120000)
    page.wait_for_function("typeof DATA !== 'undefined' && document.getElementById('chart').data",timeout=120000)
    page.locator('#modeSensitivity').click()
    assert not page.locator('#sensitivityTop3Modal').is_visible()
    for row in attachment['supplier_coverage']:
        page.locator('#sensitivitySupplierSelect').select_option(row['supplier_id'])
        page.wait_for_function('id=>document.querySelector("#factoryHoverTitle").textContent.includes(id)',arg=row['supplier_id'])
        if row['status']=='tested':
            page.locator('#incomingBlock .panelSubTab').filter(has_text='Stock initial').first.click()
            assert 'quantité présente au départ' in page.locator('#incomingBlock').inner_text()
            page.locator('#outgoingBlock .panelSubTab').filter(has_text='Stock initial').first.click()
            page.wait_for_function("document.querySelector('#outgoingBlock .js-plotly-plot')?.data?.[0]?.x?.length===4")
        else:
            assert 'Non évalué' in page.locator('#incomingBlock').inner_text()
            assert page.locator('#factoryHoverPanel .businessOk:visible').count()==0
    page.locator('#sensitivitySupplierSelect').select_option(supplier)
    page.locator('#outgoingBlock .panelSubTab').filter(has_text='Stock initial').first.click()
    page.wait_for_function("document.querySelector('#outgoingBlock .js-plotly-plot')?.data?.[0]?.x?.length===4")
    service=page.evaluate("document.querySelector('#outgoingBlock .js-plotly-plot').data[0].y")
    if mode=='example': assert service==[10,20,30,40]
    page.locator('#thirdBlock .panelSubTab').filter(has_text='quantités').first.click()
    page.wait_for_function("document.querySelector('#thirdBlock .js-plotly-plot')?.data?.[0]?.name?.includes('Stock déclaré au départ')")
    initial=page.evaluate("document.querySelector('#thirdBlock .js-plotly-plot').data[0].y")
    assert initial==expected_initial,initial
    page.locator('#thirdBlock .js-plotly-plot').scroll_into_view_if_needed()
    page.screenshot(path=str(OUT/(mode+'_initial_stock.png')))
    page.locator('#factoryHoverClearSelection').click()
    assert page.locator('#sensitivitySupplierSelect').input_value()==''
    page.locator('#sensitivityTop3Btn').click()
    assert 'Stock initial' in page.locator('#sensitivityTop3Content').inner_text()
    page.locator('#sensitivityTop3CloseBtn').click()
    page.locator('#modeOps').click()
    assert page.locator('#lotTraceSelect option').count()>1
    assert not errors,errors
    browser.close()
report=dict(status='passed',mode=mode,campaigns=2,supplier_panels=len(attachment['supplier_coverage']),
    all_stock_grids_opened=True,initial_stock_quantities=initial,service_percent=service,
    old_curves_preserved=mode=='real',selection_priorities_nominal_lots=True,browser_errors=errors)
(OUT/(mode+'_browser_checks.json')).write_text(json.dumps(report,indent=2),encoding='utf8')
print(json.dumps(report),flush=True)
