import json
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
sys.path.insert(0,str(OUT.parent))
from etudecas.study_map import map_command

if __name__ == '__main__':
    root = OUT / 'experiment'
    while True:
        try:
            manifest = json.loads((root/'experiment_manifest.json').read_text(encoding='utf8'))
        except json.JSONDecodeError:
            time.sleep(1)
            continue
        if manifest['status'] != 'running': break
        time.sleep(10)
    if manifest['status'] != 'passed': raise RuntimeError('Incomplete campaign; map not published')
    subprocess.run([sys.executable,str(OUT/'verify_results.py')],check=True)
    primary = OUT.parent / 'tmp_all_suppliers_20260911/complete_experiment'
    command = map_command(primary/'runs/reference',OUT/'map',
        title='Sensibilité fournisseurs — stock initial et essais précédents',
        sensitivity_study=primary,additional_sensitivity_studies=[root])
    (OUT/'map_command.json').write_text(json.dumps(command,indent=2),encoding='utf8')
    subprocess.run(command,cwd=OUT.parent,check=True)
    subprocess.run([sys.executable,str(OUT/'browser_check.py'),'real'],check=True)
