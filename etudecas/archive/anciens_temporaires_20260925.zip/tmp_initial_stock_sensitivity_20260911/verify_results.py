import csv
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT / 'experiment'
OLD = OUT.parent / 'tmp_all_suppliers_20260911/complete_experiment'
manifest = json.loads((ROOT / 'experiment_manifest.json').read_text(encoding='utf8'))
base_graph = json.loads((ROOT / 'runs/reference/simulation/inputs/simulation_input.json').read_text())
assert base_graph == json.loads((OLD / 'runs/reference/simulation/inputs/simulation_input.json').read_text())
nominal_files = ['production_demand_service_daily.csv', 'production_input_stocks_daily.csv',
    'production_output_products_daily.csv', 'production_supplier_shipments_daily.csv', 'production_campaigns.csv',
    'production_constraint_daily.csv', 'mrp_orders_daily.csv']
for name in nominal_files:
    assert (ROOT / 'runs/reference/simulation/data' / name).read_bytes() == (OLD / 'runs/reference/simulation/data' / name).read_bytes(), name
summaries = [json.loads((p / 'runs/reference/simulation/summaries/first_simulation_summary.json').read_text()) for p in [ROOT, OLD]]
assert summaries[0]['kpis'] == summaries[1]['kpis']
base_service = json.loads((ROOT / 'runs/reference/service_metrics.json').read_text())['rows']
baseline = {(r['node_id'],r['item_id'],r['uom']): r for r in base_service}
base_initial = {(n['id'],s['item_id']): s['initial'] for n in base_graph['nodes'] if n['type']=='supplier_dc'
                for s in n.get('inventory',{}).get('states',[])}
results = []
for run in manifest['runs']:
    if run['id']=='reference' or run['status']!='passed': continue
    event = run['perturbations'][0]
    expected = {pair: round(q*event['factor'],6) if pair[0]==event['supplier_id'] else q for pair,q in base_initial.items()}
    path = ROOT / run['path'] / 'simulation/data/production_supplier_stock_flows_daily.csv'
    actual = {}
    with path.open(encoding='utf8',newline='') as stream:
        for row in csv.DictReader(stream):
            if int(row['day'])==0:
                pair = row['node_id'],row['item_id']
                assert pair not in actual
                actual[pair]=float(row['stock_start_of_day'])
    assert actual == expected, (run['id'],[(k,actual.get(k),v) for k,v in expected.items() if actual.get(k)!=v])
    summary = json.loads((ROOT / run['path'] / 'simulation/summaries/first_simulation_summary.json').read_text())
    assert summary['policy']['supplier_risk']['event_count']==0
    service = json.loads((ROOT / run['path'] / 'service_metrics.json').read_text())['rows']
    degraded = []
    for row in service:
        key = row['node_id'],row['item_id'],row['uom']
        ref = baseline[key]
        if row['requirement_served_fraction'] < ref['requirement_served_fraction']-1e-9 or row['backlog_quantity_days'] > ref['backlog_quantity_days']+3e-6*manifest['days']:
            degraded.append(dict(client=key[0],item=key[1],uom=key[2],delivered_fraction=row['requirement_served_fraction'],
                final_backlog=row['final_backlog_qty'],extra_waiting_quantity_days=row['backlog_quantity_days']-ref['backlog_quantity_days']))
    results.append(dict(id=run['id'],supplier=event['supplier_id'],factor=event['factor'],
        starting_stocks_checked=True,no_injected_events=True,degraded_service=degraded))
report = dict(status=manifest['status'],run_status_counts=dict(Counter(r['status'] for r in manifest['runs'])),
    nominal_graph_identical=True,nominal_kpis_identical=True,nominal_exports_identical=nominal_files,
    variants_completed=len(results),suppliers_checked=len({r['supplier'] for r in results}),
    suppliers_with_degraded_service=sorted({r['supplier'] for r in results if r['degraded_service']}),variants=results)
(OUT / 'result_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in report.items() if k!='variants'}),flush=True)
