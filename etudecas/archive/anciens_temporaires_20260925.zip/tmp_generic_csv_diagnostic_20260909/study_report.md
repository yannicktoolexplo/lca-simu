# Diagnostic de chaîne d’approvisionnement

Contrôles d’entrée : acceptés.

## Exposition fournisseurs

| Fournisseur | Couples destination/article | Sans autre source déclarée |
| --- | ---: | ---: |
| supplier:mill_a | 1 | 0 |
| supplier:mill_b | 1 | 0 |

## Qualité des données

- warning — scenarios[0].economic_policy.transport_cost_floor_per_unit : historical modeling default 0.02 applied; not an observed or calibrated value
- warning — scenarios[0].economic_policy.transport_cost_per_km_per_unit : historical modeling default 8e-05 applied; not an observed or calibrated value
- warning — scenarios[0].economic_policy.purchase_cost_floor_per_unit : historical modeling default 0.01 applied; not an observed or calibrated value
- warning — scenarios[0].economic_policy.holding_cost_scale : historical modeling default 1.0 applied; not an observed or calibrated value
- warning — scenarios[0].economic_policy.transport_cost_realism_multiplier : historical modeling default 8.0 applied; not an observed or calibrated value
- warning — scenarios[0].economic_policy.purchase_cost_realism_multiplier : historical modeling default 1.0 applied; not an observed or calibrated value

## Unités des quantités

Unités prêtes pour la simulation : oui. 1 annotations héritent du catalogue articles ; aucune quantité n’est convertie.
Le rapport JSON détaille les déclarations, les héritages et les champs de référence.

## Ajustements économiques par scénario

Valeurs effectives avant majorations de risque et d’expédition accélérée ; aucune calibration n’est attestée.

Scénario : scenario:reference

- transport_cost_floor_per_unit : 0.02 (hypothèse historique par défaut ; currency/legacy_billing_unit).
- transport_cost_per_km_per_unit : 8e-05 (hypothèse historique par défaut ; currency/km/legacy_billing_unit).
- purchase_cost_floor_per_unit : 0.01 (hypothèse historique par défaut ; currency/item_quantity).
- holding_cost_scale : 1.0 (hypothèse historique par défaut ; dimensionless).
- transport_cost_realism_multiplier : 8.0 (hypothèse historique par défaut ; dimensionless).
- purchase_cost_realism_multiplier : 1.0 (hypothèse historique par défaut ; dimensionless).

Part cible du coût de production : 0.3 (fraction du total ; hypothèse de composition des coûts).
Répartition du stockage : convention fraction, dénominateur 1.0. Les fractions effectives et leurs provenances figurent dans le rapport JSON.

## Substitutions de références

Équivalence quantitative 1 pour 1, sans conversion ni qualification technique vérifiée.
L'ancienne référence n'est utilisable que si le stock de la nouvelle est nul au début du prélèvement.
Le stock initial de transition s'ajoute au stock du graphe ; dates inclusives dans la période de mesure.
Les déclarations, défauts et unités sont détaillés dans reference_transition_contract du rapport JSON.

## Limites d’interprétation

- Exposition structurelle déclarée : ne mesure ni probabilité de rupture ni impact aval.
- Une source alternative déclarée ne prouve pas sa qualification ou sa capacité disponible.
- Les quantités de différents articles et unités ne sont pas additionnées.
- La demande quotidienne absente est interprétée comme zéro lors de la conversion.
- Une simulation exploratoire exige calibration et validation sur observations avant décision.
- Le moteur conserve des hypothèses génériques de coûts et de politiques ; ses résultats économiques nécessitent un paramétrage métier explicite.

## Provenance des données importées

Statut : partial. Couverture limitée aux valeurs importées déclarées.
Les statuts de données et références source ne constituent pas une authentification des observations.
Valeurs par statut déclaré : {'observed': 0, 'estimated': 0, 'assumed': 1, 'proxy': 0, 'synthetic': 10}.
