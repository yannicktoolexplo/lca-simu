"""Read-only explanation of the annual supplier experiment at article level."""
import csv,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent
exp=R/'experiment'
def read(path):
    with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
manifest=json.loads((exp/'experiment_manifest.json').read_text())
assert manifest['status']=='passed'
source=json.loads((exp/'inputs/graph_source.json').read_text())
records=[]
reference_daily={(x['day'],x['item_id']):float(x['backlog_end_qty']) for x in read(exp/'runs/reference/simulation/data/production_demand_service_daily.csv')}
for run in manifest['runs']:
    folder=exp/'runs'/run['id'];data=folder/'simulation/data'
    graph=json.loads((folder/'simulation/inputs/simulation_input.json').read_text())
    assert graph['case_config']==source['case_config'],run['id']
    service=json.loads((folder/'service_metrics.json').read_text())['rows']
    shipments=[x for x in read(data/'production_supplier_shipments_daily.csv') if x['src_node_id']=='SDC-VD0914360C' and x['item_id']=='item:338929']
    opening=[x for x in shipments if x['transport_cost_basis']=='opening_order_book']
    new=[x for x in shipments if x['transport_cost_basis']!='opening_order_book']
    assert all(x['uom']=='UN' for x in shipments)
    stocks=[x for x in read(data/'production_input_stocks_daily.csv') if x['node_id']=='M-1810' and x['item_id']=='item:338929']
    constraints=[x for x in read(data/'production_constraint_daily.csv') if x['node_id']=='M-1810']
    produced=[x for x in read(data/'production_output_products_daily.csv') if x['node_id']=='M-1810' and x['item_id']=='item:268091']
    daily_service=read(data/'production_demand_service_daily.csv')
    service_gap=[int(x['day']) for x in daily_service if x['item_id']=='item:268091' and float(x['backlog_end_qty'])>reference_daily[x['day'],x['item_id']]+1e-5]
    constrained=[x for x in constraints if float(x['shortfall_vs_lot_plan_qty'])>1e-6]
    factor_checks={
        'capacity_minus_20':('capacity_multiplier',0.8),
        'lead_time_plus_20':('lead_time_multiplier',1.2),
        'supplier_stop':('availability_multiplier',0.0),
    }
    applied=None
    if run['id'] in factor_checks:
        field,value=factor_checks[run['id']]
        affected=[x for x in read(data/'supplier_risk_events_applied_daily.csv') if x['edge_id']=='edge:SDC-VD0914360C_TO_M-1810_338929']
        assert affected and all(abs(float(x[field])-value)<1e-9 for x in affected)
        checked_days=set(int(x['day']) for x in affected)
        # The ledger records evaluated decisions, not an observation every day.
        decision_days={int(x['risk_decision_day']) for x in new if x['risk_decision_day']!=''}
        assert decision_days <= checked_days
        applied=dict(field=field,value=value,verified_decision_days=len(checked_days),
            shipment_decisions_covered=True,scope='Recorded evaluations, not continuous physical observations')
    item_records=dict(run_id=run['id'],case_configuration_unchanged=True,
        configuration_sha256=hashlib.sha256(json.dumps(graph['case_config'],sort_keys=True).encode()).hexdigest(),
        service=service,opening_packaging_shipped_qty=sum(float(x['shipped_qty']) for x in opening),
        new_packaging_shipped_qty=sum(float(x['shipped_qty']) for x in new if 0<=int(x['day'])<365),
        new_packaging_all_scheduled_shipments_qty=sum(float(x['shipped_qty']) for x in new),
        new_packaging_departure_after_horizon_qty=sum(float(x['shipped_qty']) for x in new if int(x['day'])>=365),
        new_packaging_arrival_within_horizon_qty=sum(float(x['shipped_qty']) for x in new if 0<=int(x['arrival_day'])<365),
        new_packaging_scheduled_after_horizon_qty=sum(float(x['shipped_qty']) for x in new if int(x['arrival_day'])>=365),
        minimum_packaging_stock=min(float(x['stock_end_of_day']) for x in stocks),
        new_finished_production_qty=sum(float(x['executed_qty']) for x in produced),
        new_completed_finished_qty=sum(float(x['released_qty'])-float(x['opening_released_qty']) for x in produced),
        final_unfinished_qty=float(produced[-1]['wip_end_qty']),
        first_service_gap_day=min(service_gap,default=None),
        source_order_finished_receipts_qty=sum(float(x['opening_released_qty']) for x in produced),
        constrained_days=len(set(x['day'] for x in constrained)),
        first_constrained_day=min((int(x['day']) for x in constrained),default=None),
        binding_components=sorted(set(x['binding_input_item_id'] for x in constrained)),
        applied_supplier_factor=applied,
        audit_coverage=json.loads((folder/'audit_coverage.json').read_text())['audits'])
    records.append(item_records)
result=dict(days=365,seed=1729,common_random_numbers=True,records=records,
    limitations=['Hypothetical supplier perturbations, not probabilities.',
        'Opening order book protected from perturbations under existing protocol.',
        'Scheduled departures and arrivals after day 364 are separated from within-year flows.',
        'Economic valuation unvalidated; no monetary ranking inferred.'])
(R/'flow_and_service_audit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf8')
print(json.dumps([{k:r[k] for k in ['run_id','new_packaging_shipped_qty','new_packaging_scheduled_after_horizon_qty','new_finished_production_qty','constrained_days','first_constrained_day','binding_components','service']} for r in records],indent=2))
